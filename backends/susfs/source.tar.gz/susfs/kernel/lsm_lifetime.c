/* SPDX-License-Identifier: GPL-2.0 */
#include <linux/rcupdate.h>
#include "lsm_hook.h"

void ksu_lsm_callback_enter(struct ksu_lsm_hook *hook)
{
    atomic_inc(&hook->active_callbacks);
    smp_mb__after_atomic();
}

void ksu_lsm_callback_exit(struct ksu_lsm_hook *hook)
{
    smp_mb__before_atomic();
    if (atomic_dec_and_test(&hook->active_callbacks))
        wake_up_all(&hook->callback_waitq);
}

void ksu_lsm_hook_drain(struct ksu_lsm_hook *hook)
{
    /* The caller has restored the dispatch target. Cover readers which saw the
     * old target but have not yet entered the callback; ordinary RCU also
     * covers the hook lists on older kernels. */
    synchronize_rcu();
    synchronize_rcu_tasks();

    /* A callback may voluntarily sleep inside SELinux, which is a Tasks RCU
     * quiescent state despite its live SUSFS frame. The counter spans that
     * sleeping original and all feature-data accesses. */
    wait_event(hook->callback_waitq,
               atomic_read(&hook->active_callbacks) == 0);

    /* Zero protects feature data, but is not proof that module text is no
     * longer executing: the final decrement, wake_up_all(), callback epilogue
     * and return can still be in flight. Run a NEW grace period after the
     * counter drains, rather than relying on the earlier period which may
     * have ended while that callback slept. */
    synchronize_rcu_tasks();
}
