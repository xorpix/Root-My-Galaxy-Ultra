// SPDX-License-Identifier: GPL-2.0
/* Resolve the live KernelSU policy once, retaining its owning module until all
 * SusFS hooks have been removed and drained. No weak imports, private policy
 * structures or credential changes. Built-in symbols require core ownership.
 */
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/types.h>
#include <linux/preempt.h>
#include <linux/rcupdate.h>
#include "ksu_umount_gate.h"
#include "symbol_resolver.h"
#include "susfs_log.h"

#define KSU_UMOUNT_GATE_SYMBOL "ksu_uid_should_umount"
#define KSU_ROOT_GATE_SYMBOL "ksu_is_uid_granted_root"
bool susfs_ksu_umount_gate_off = true;
static bool (*ksu_uid_should_umount_fn)(uid_t uid);
static bool (*ksu_uid_granted_root_fn)(uid_t uid);
static struct module *ksu_policy_owner;
static struct module *(*policy_module_address)(unsigned long addr);
static_assert(__same_type(typeof(policy_module_address), typeof(&__module_address)));

bool __nocfi noinline susfs_ksu_umount_ask(uid_t uid)
{
    return ksu_uid_should_umount_fn(uid);
}

bool susfs_ksu_root_available(void)
{
    return READ_ONCE(ksu_uid_granted_root_fn) != NULL;
}

bool __nocfi noinline susfs_ksu_uid_granted_root(uid_t uid)
{
    return ksu_uid_granted_root_fn(uid);
}

int __nocfi susfs_ksu_umount_gate_init(void)
{
    unsigned long umount, granted;
    unsigned long core_umount = find_kernel_symbol_exact(KSU_UMOUNT_GATE_SYMBOL);
    unsigned long core_granted = find_kernel_symbol_exact(KSU_ROOT_GATE_SYMBOL);
    struct module *owner;

    policy_module_address = (void *)find_kernel_symbol_exact("__module_address");
    if (!policy_module_address)
        goto unavailable;
    /* Raw lookup never sleeps. Preemption stays disabled from lookup through
     * owner/reference acquisition, closing the address-free/reuse window. */
    preempt_disable();
    umount = ksu_kallsyms_lookup_name(KSU_UMOUNT_GATE_SYMBOL);
    if (!umount)
        goto unlock;
    owner = policy_module_address(umount);
    if (owner) {
        if (!try_module_get(owner))
            goto unlock;
    } else if (umount != core_umount) {
        goto unlock;
    }
    ksu_policy_owner = owner;
    ksu_uid_should_umount_fn = (void *)umount;
    granted = ksu_kallsyms_lookup_name(KSU_ROOT_GATE_SYMBOL);
    if (granted && policy_module_address(granted) == owner &&
        (owner || granted == core_granted))
        ksu_uid_granted_root_fn = (void *)granted;
    WRITE_ONCE(susfs_ksu_umount_gate_off, false);
    preempt_enable();
    return 0;
unlock:
    preempt_enable();
unavailable:
    pr_warn("susfs: KernelSU policy could not be retained; legacy hide gates remain in use\n");
    return 0;
}

void susfs_ksu_umount_gate_exit(void)
{
    struct module *owner = ksu_policy_owner;

    WRITE_ONCE(susfs_ksu_umount_gate_off, true);
    /* This is the last policy consumer's exit, after every hook's drain.
     * Include preempted return tails before releasing the dependency. */
    if (ksu_uid_should_umount_fn)
        synchronize_rcu_tasks();
    ksu_uid_should_umount_fn = NULL;
    ksu_uid_granted_root_fn = NULL;
    ksu_policy_owner = NULL;
    if (owner)
        module_put(owner);
}
