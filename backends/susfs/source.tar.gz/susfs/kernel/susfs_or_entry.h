/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __SUSFS_OR_ENTRY_H
#define __SUSFS_OR_ENTRY_H

#include <linux/limits.h>

struct pt_regs;

/* The five open syscall entries this module replaces with its own wrappers: native openat and
 * openat2, and the AArch32 open/openat/openat2 entries.  Upstream (and this tree in an earlier
 * round) pointed a hooks function pointer at one implementation the wrappers all asked; here the
 * wrappers ask susfs_open_redirect_match_path() directly, because this module owns every open
 * entry (one syscall entry carries exactly one wrapper, and none of its other features touches
 * open(), so there is no other layer to share them with - create_gate has its own four).
 *
 * The layer is optional at run time: `or_entry=0` turns it off at load, and init() leaves the
 * entries untouched unless every symbol it resolves was found, so a missing symbol costs nothing
 * but the feature.  open_redirect refuses rules while the layer is unarmed, because a rule that
 * cannot fire is worse than no rule. */
enum susfs_or_entry_kind {
	SUSFS_OR_ENTRY_OPENAT = 0,
	SUSFS_OR_ENTRY_OPENAT2,
	SUSFS_OR_ENTRY_COMPAT_OPEN,
	SUSFS_OR_ENTRY_COMPAT_OPENAT,
	SUSFS_OR_ENTRY_COMPAT_OPENAT2,
	SUSFS_OR_ENTRY_KIND_COUNT,
};

/* Returned when the hook did not redirect: the caller then runs the original syscall.  LONG_MIN
 * cannot be a real answer here (a fd or a negative errno), so a mistake cannot be mistaken for
 * one. */
#define SUSFS_OR_ENTRY_PASS	LONG_MIN

/* True once redirection can actually happen: the native openat and openat2 entries both carry this
 * module's wrapper (the compat entries share their implementations, so they add nothing to the
 * question).  The open_redirect layer checks this when a rule is added: a rule that cannot fire
 * is worse than no rule, so it refuses rather than register one. */
bool susfs_or_entry_armed(void);

/* Redirected opens so far.  The wrapper runs in the task's own context, before the syscall the
 * caller asked for.  Read by the layer's diagnostic parameter, never printed by anything
 * performance-critical. */
unsigned long susfs_or_entry_hits(void);

/* Both are called from the open_redirect layer's init/exit, exit before that layer's reverse
 * probes come down, so no entry that is still installed can call into a layer that is going away.
 * init never fails: the layer is optional, and refusing to arm is reported and survived. */
int susfs_or_entry_init(void);
void susfs_or_entry_exit(void);

#endif /* __SUSFS_OR_ENTRY_H */
