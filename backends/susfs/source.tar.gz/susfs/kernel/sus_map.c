// SPDX-License-Identifier: GPL-2.0
/*
 * sus_map.c - hide mmapped real files from /proc/<pid>/maps (SUSFS SUS_MAP).
 *
 * Upstream sets AS_FLAGS_SUS_MAP on the inode's address_space and makes
 * show_map_vma()/show_smap() skip the line, the smaps_rollup() loop skip the vma it
 * accumulates and pagemap_read() skip the chunk covering such a vma.  An LKM cannot add a
 * flag bit, so: a listing layer (kprobes on show_map/show_smap, vma = regs->regs[1],
 * skip the line with regs->pc = x30) plus a page-walk layer for the two listings it cannot
 * reach (smaps_rollup, pagemap).  smaps_rollup is deliberately NOT probed directly (see
 * "the sentinel") and the skip is gated like upstream's, apps only (see "the read gate").
 */
#include <linux/module.h>
#include <linux/kprobes.h>
#include <linux/fs.h>
#include <linux/mm.h>		/* struct mm_struct; sus_map_find_vma() walks its vmas */
#ifdef VMA_PAD_START
#include <linux/pgsize_migration.h> /* native Android padding helper type */
#endif
#include <linux/mm_types.h>
#include <linux/version.h>	/* LINUX_VERSION_CODE: mm->mmap vs mm->mm_mt (6.1) */
#include <linux/namei.h>
#include <linux/dcache.h>
#include <linux/uaccess.h>
#include <linux/err.h>		/* IS_ERR/ERR_PTR for the getlink hook */
#include <linux/cred.h>		/* current_uid(), for the read gate */
#include <linux/spinlock.h>	/* serialises rule publication */
#include <linux/mutex.h>		/* serialises management and probe registration */
#include <linux/ptrace.h>
#include <linux/capability.h>
#include <linux/slab.h>
#include <linux/rcupdate.h>
#include <linux/wait.h>
#include <linux/delay.h>
#include <linux/list.h>
#include "proc/internal.h"	/* real proc_inode layout, never a local mirror */
#include "patch_memory.h"
#include "susfs_abi.h"
#include "susfs_log.h"
#include "susfs.h"	/* susfs_abi_path_ok */
#include "symbol_resolver.h"	/* find_kernel_symbol_exact, for the walk ops */
#include "ksu_umount_gate.h"	/* susfs_is_current_proc_umounted_app (issue #34) */

#define SUS_MAP_MAX 64

struct sus_map_entry {
    unsigned long target_ino;
    dev_t target_dev;
};

static struct sus_map_entry map_entries[SUS_MAP_MAX];
static int nmap;
static atomic_t n_maps_calls = ATOMIC_INIT(0);
static atomic_t n_maps_hides = ATOMIC_INIT(0);
static atomic_t n_smaps_calls = ATOMIC_INIT(0);
static atomic_t n_smaps_hides = ATOMIC_INIT(0);
static struct kprobe kp_map, kp_map_smap;

/* Rules can now be removed and slots reused. Readers hold this short IRQ-safe
 * lock while matching the inode/device pair, so compaction cannot expose a
 * mixture of two entries to a probe. No sleeping operation holds this lock. */
static DEFINE_SPINLOCK(map_table_lock);
static DEFINE_MUTEX(map_config_lock);
static bool map_ready;

/* temporary interface: insmod susfs_guard_lkm.ko map_ino=<n> hides that inode */
static unsigned long param_map_ino;
module_param_named(map_ino, param_map_ino, ulong, 0644);

/* dev==0 means "any filesystem": only the map_ino parameter can pick that. */
static int sus_map_add_full(unsigned long ino, dev_t dev)
{
    unsigned long flags;
    int i, rc = 0;

    if (!ino)
        return -EINVAL;

    spin_lock_irqsave(&map_table_lock, flags);
    for (i = 0; i < nmap; i++) {
        if (map_entries[i].target_ino == ino &&
            map_entries[i].target_dev == dev)
            goto out;
    }
    if (nmap < SUS_MAP_MAX) {
        map_entries[nmap].target_ino = ino;
        map_entries[nmap].target_dev = dev;
        smp_store_release(&nmap, nmap + 1);
    } else {
        rc = -ENOSPC;
    }
out:
    spin_unlock_irqrestore(&map_table_lock, flags);
    return rc;
}

static void sus_map_add(unsigned long ino)
{
    sus_map_add_full(ino, 0);
}

static bool sus_map_lookup(unsigned long ino, dev_t dev)
{
    unsigned long flags;
    bool found = false;
    int i;

    if (!smp_load_acquire(&nmap))
        return false;

    spin_lock_irqsave(&map_table_lock, flags);
    for (i = 0; i < nmap; i++) {
        if (map_entries[i].target_ino != ino)
            continue;
        if (map_entries[i].target_dev && map_entries[i].target_dev != dev)
            continue;
        found = true;
        break;
    }
    spin_unlock_irqrestore(&map_table_lock, flags);
    return found;
}

static int sus_map_remove_full(unsigned long ino, dev_t dev)
{
    unsigned long flags;
    int i, last, rc = -ENOENT;

    spin_lock_irqsave(&map_table_lock, flags);
    for (i = 0; i < nmap; i++) {
        if (map_entries[i].target_ino != ino ||
            map_entries[i].target_dev != dev)
            continue;
        last = nmap - 1;
        map_entries[i] = map_entries[last];
        memset(&map_entries[last], 0, sizeof(map_entries[last]));
        smp_store_release(&nmap, last);
        rc = 0;
        break;
    }
    spin_unlock_irqrestore(&map_table_lock, flags);
    return rc;
}

static void sus_map_clear(void)
{
    unsigned long flags;

    spin_lock_irqsave(&map_table_lock, flags);
    memset(map_entries, 0, sizeof(map_entries));
    smp_store_release(&nmap, 0);
    spin_unlock_irqrestore(&map_table_lock, flags);
}

/* ---- the read gate ----
 *
 * Upstream hides behind SUSFS_IS_INODE_SUS_MAP() -> susfs_is_current_proc_umounted_app()
 * = (test_thread_flag(TIF_PROC_UMOUNTED) && current_uid().val >= 10000): apps only, so
 * root/init see the real mapping.  TIF_PROC_UMOUNTED cannot be reproduced in this LKM
 * (KernelSU sets it only with the SUSFS integration compiled into the kernel, which this
 * device's kernel is not - AUDIT_FINDINGS.md).  The gate now asks KernelSU directly:
 * susfs_is_current_proc_umounted_app() resolves ksu_uid_should_umount() once at load
 * (ksu_umount_gate.h, issue #34), so the manager and su-granted apps are not hidden from;
 * with the symbol unresolved it keeps the old `uid >= 10000` proxy.  Configuration stays
 * ungated: the supercall and map_ino are rule management. */
static bool sus_map_gate_ok(void)
{
    return susfs_is_current_proc_umounted_app();
}

/* One handler for show_map (maps) and show_smap (smaps) - both are seq_operations
 * .show callbacks that emit only what they are given, so returning 0 means "handled,
 * nothing printed", which is upstream's SUS_MAP effect. show_map_vma is a void formatter
 * below show_map and may be inlined into it under LTO. CP13 registered its probe but
 * leaked the maps row while show_smap filtering worked. Hook the actual .show boundary.
 *
 * ---- the sentinel ----
 *
 * smaps_rollup must NOT be pointed at this handler: show_smaps_rollup() is reached
 * through single_open(), whose single_start() hands .show the iterator sentinel (void *)1
 * instead of a vma, and the function ignores its v argument.  Measured with the probe
 * registered: `cat /proc/<pid>/smaps_rollup` as an app took vma->vm_file at 0xa0 -> ldr
 * from 0xa1 -> "Unable to handle kernel NULL pointer dereference at virtual address
 * 00000000000000a1", pc sus_map_skip_vma_pre+0x3c, then a panic (last_kmsg 41346.347).
 * Unreachable from a kprobe too: upstream skips the vma *inside* the rollup loop, and
 * smap_gather_stats() is inlined by LTO here (absent from /proc/kallsyms), so only
 * walk_page_range() could be intercepted.  TECHNICAL_NOTES.md, "sus_map 与 smaps_rollup". */
static int sus_map_skip_vma_pre(struct kprobe *kp, struct pt_regs *regs)
{
    struct vm_area_struct *vma;
    struct inode *inode;

    if (!smp_load_acquire(&nmap))
        return 0;

    atomic_inc(kp == &kp_map ? &n_maps_calls : &n_smaps_calls);
    if (!sus_map_gate_ok())
        return 0;

    vma = (struct vm_area_struct *)regs->regs[1];
    /* Defence in depth against the sentinel above: a vma is always a slab object in
     * the linear map, so anything below one page is not one - this turns a future
     * mis-registration into a lost filter, not a panic. */
    if ((unsigned long)vma < PAGE_SIZE)
        return 0;
    if (!vma->vm_file)
        return 0;
    inode = file_inode(vma->vm_file);
    if (!inode)
        return 0;
    if (sus_map_lookup(inode->i_ino, inode->i_sb->s_dev)) {
        atomic_inc(kp == &kp_map ? &n_maps_hides : &n_smaps_hides);
        /* ratelimited like sus_path's; the rule stores no path, so ino/dev name it */
        pr_info_ratelimited("sus_map: hid %s line (ino=%lu dev=%lu uid=%u)\n",
                            kp->symbol_name, inode->i_ino,
                            (unsigned long)inode->i_sb->s_dev,
                            current_uid().val);
        regs_set_return_value(regs, 0);
        regs->pc = regs->regs[30];
        return 1;
    }
    return 0;
}

static struct kprobe kp_map = {
    .symbol_name = "show_map",
    .pre_handler = sus_map_skip_vma_pre,
};

static struct kprobe kp_map_smap = {
    .symbol_name = "show_smap",
    .pre_handler = sus_map_skip_vma_pre,
};

/* ---- the page-walk layer: smaps_rollup and pagemap ----
 *
 * Both listings test a vma upstream holds as a local, so neither is reachable from a
 * kprobe: no local at a function boundary, smap_gather_stats() inlined by LTO, and
 * pagemap_read() only has its vma after taking mmap_lock inside.
 *   show_smaps_rollup() -> for (vma = priv->mm->mmap; vma;) { ... skip ... }
 *   pagemap_read()      -> vma = vma_lookup(mm, start_vaddr); ... skip chunk
 * Both share one exported primitive, called with a caller-unique mm_walk_ops:
 *   smap_gather_stats(): walk_page_range(vma->vm_mm, ..., smaps_walk_ops|smaps_shmem_walk_ops, mss)
 *   pagemap_read():      walk_page_range(mm, start, end, &pagemap_ops, &pm)
 * Those three ops have no other user and every caller holds mmap_lock for read (the walk
 * asserts it), so skipping the call leaves upstream's result: the rollup vma adds nothing
 * to mss, the pagemap chunk stays unfilled and `ret = walk_page_range(...)` sees 0, as
 * upstream leaves it.  The ops are data symbols, so they come from kallsyms by name
 * (sus_mount's mnt_id_ida mechanism); if none resolves, the probe is not registered and both
 * listings stay unfiltered (logged).  The probe sits on a kernel-wide primitive, so it bails
 * out in one load and three compares - ops test first.
 *
 * Which of walk_page_range()/walk_page_vma() is the live call site cannot be assumed: with
 * CONFIG_LTO_CLANG_FULL either may be inlined into its caller (invisible to any probe - the
 * wall smap_gather_stats() hit), so both symbols are probed and walk_dbg=1 records every
 * distinct ops pointer with its call count (walk_ops), naming the real caller. */
static const void *sus_map_ops_smaps;
static const void *sus_map_ops_smaps_shmem;
static const void *sus_map_ops_pagemap;
static bool sus_map_walk_ops_done;
static atomic_t n_walk_skip = ATOMIC_INIT(0);
static atomic_t n_walk_seen = ATOMIC_INIT(0);		/* walk_page_range calls */
static atomic_t n_walk_seen_vma = ATOMIC_INIT(0);	/* walk_page_vma calls  */
/* One counter per resolution step: "the walk was not skipped" has four different causes. */
static atomic_t n_walk_ops_hit = ATOMIC_INIT(0);	/* ops was ours */
static atomic_t n_walk_scan_fail = ATOMIC_INIT(0);	/* no vma for (mm,start) */
static atomic_t n_walk_nofile = ATOMIC_INIT(0);		/* vma has no vm_file */
static atomic_t n_walk_nomatch = ATOMIC_INIT(0);	/* inode is not a rule */
static atomic_t n_walk_dbg_left = ATOMIC_INIT(4);
/* map_files symlink resolutions that were turned into ENOENT.  n_getlink_calls vs
 * n_getlink_skip keeps "the probe ran" apart from "the probe matched". */
static atomic_t n_map_files_hides = ATOMIC_INIT(0);
static atomic_t n_getlink_calls = ATOMIC_INIT(0);
static atomic_t n_getlink_skip = ATOMIC_INIT(0);
static atomic_t n_getlink_nomatch = ATOMIC_INIT(0);

/* walk_dbg: name every ops pointer reaching the two primitives, once per value (off by default - a linear scan per call). */
static int walk_dbg;
module_param_named(walk_dbg, walk_dbg, int, 0644);

#define WALK_OPS_MAX 8
static const void *walk_seen_ops[WALK_OPS_MAX];
static atomic_t walk_seen_cnt[WALK_OPS_MAX];
static int walk_seen_n;

static void sus_map_note_ops(const void *ops)
{
    int i, n = READ_ONCE(walk_seen_n);

    for (i = 0; i < n; i++) {
        if (READ_ONCE(walk_seen_ops[i]) == ops) {
            atomic_inc(&walk_seen_cnt[i]);
            return;
        }
    }
    if (n >= WALK_OPS_MAX)
        return;
    WRITE_ONCE(walk_seen_ops[n], ops);
    atomic_inc(&walk_seen_cnt[n]);
    smp_store_release(&walk_seen_n, n + 1);
    SUSFS_LOGI("sus_map: walk ops[%d] = %pS\n", n, ops);
}

static int sus_map_walk_ops_show(char *buf, const struct kernel_param *kp)
{
    int i, n = 0, cnt = READ_ONCE(walk_seen_n);

    for (i = 0; i < cnt; i++)
        n += scnprintf(buf + n, PAGE_SIZE - n, "%2d %pS\n", i, walk_seen_ops[i]);
    n += scnprintf(buf + n, PAGE_SIZE - n,
                   "counts: page_range=%d page_vma=%d skipped=%d\n",
                   atomic_read(&n_walk_seen), atomic_read(&n_walk_seen_vma),
                   atomic_read(&n_walk_skip));
    for (i = 0; i < cnt; i++)
        n += scnprintf(buf + n, PAGE_SIZE - n, "  [%d] n=%d\n", i,
                       atomic_read(&walk_seen_cnt[i]));
    return n;
}
static const struct kernel_param_ops sus_map_walk_ops_ops = {
    .get = sus_map_walk_ops_show,
};
module_param_cb(walk_ops, &sus_map_walk_ops_ops, NULL, 0400);

static void sus_map_resolve_walk_ops(void)
{
    if (sus_map_walk_ops_done)
        return;
    sus_map_walk_ops_done = true;

    sus_map_ops_smaps = (const void *)find_kernel_symbol_exact("smaps_walk_ops");
    sus_map_ops_smaps_shmem = (const void *)find_kernel_symbol_exact("smaps_shmem_walk_ops");
    sus_map_ops_pagemap = (const void *)find_kernel_symbol_exact("pagemap_ops");

    if (!sus_map_ops_smaps && !sus_map_ops_smaps_shmem && !sus_map_ops_pagemap) {
        pr_warn("sus_map: smaps/pagemap walk ops not found in kallsyms - "
                "smaps_rollup and pagemap stay unfiltered\n");
        return;
    }
    SUSFS_LOGI("sus_map: walk ops smaps=%px smaps_shmem=%px pagemap=%px\n",
            sus_map_ops_smaps, sus_map_ops_smaps_shmem, sus_map_ops_pagemap);
}

static bool sus_map_walk_ops_any(void)
{
    return sus_map_ops_smaps || sus_map_ops_smaps_shmem || sus_map_ops_pagemap;
}

static bool sus_map_walk_ops_ours(const void *ops)
{
    return ops && (ops == sus_map_ops_smaps || ops == sus_map_ops_smaps_shmem ||
                   ops == sus_map_ops_pagemap);
}

static bool sus_map_walk_answer(struct kprobe *kp, struct pt_regs *regs,
                                struct vm_area_struct *vma)
{
    struct inode *inode;

    /* Defence in depth, like the vma handler: a real vma is never below a page. */
    if ((unsigned long)vma < PAGE_SIZE)
        return false;
    if (!vma->vm_file) {
        atomic_inc(&n_walk_nofile);
        return false;
    }
    inode = file_inode(vma->vm_file);
    if (!inode) {
        atomic_inc(&n_walk_nofile);
        return false;
    }
    if (!sus_map_lookup(inode->i_ino, inode->i_sb->s_dev)) {
        atomic_inc(&n_walk_nomatch);
        return false;
    }

    atomic_inc(&n_walk_skip);
    pr_info_ratelimited("sus_map: skipped %s walk for ino=%lu dev=%lu uid=%u\n",
                        kp->symbol_name, inode->i_ino,
                        (unsigned long)inode->i_sb->s_dev, current_uid().val);
    /* Both primitives return int 0 for "walked, nothing wrong" and both callers expect
     * that from a skipped walk (upstream's own skip leaves the same value).  Leaving
     * x0 = mm would turn pagemap_read()'s `ret` into a kernel pointer handed to read(2). */
    regs_set_return_value(regs, 0);
    regs->pc = regs->regs[30];
    return true;
}

/* The VMA container changed in 6.1; both spellings answer the same question - "the first
 * vma whose end is past @start", i.e. the one containing @start or the next after a gap -
 * and the caller still compares the result against vm_start.
 *   <= 6.0  mm_struct.mmap heads a doubly linked list, walked with vma->vm_next
 *   >= 6.1  that list became the mm_struct.mm_mt maple tree, walked with the vma iterator
 *           helpers VMA_ITERATOR() / for_each_vma() (mm_types.h, mm.h) - which is why
 *           "no member named 'mmap' in 'struct mm_struct'" and "'vm_next' in
 *           'struct vm_area_struct'" appeared on android14-6.1 and android15-6.6.
 * Both forms are header-only (macros and static inlines), so neither needs a kernel symbol;
 * mmap_lock is held for read by every caller, as the walk itself requires. */
static struct vm_area_struct *sus_map_find_vma(struct mm_struct *mm, unsigned long start)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 1, 0)
	struct vm_area_struct *vma;
	VMA_ITERATOR(vmi, mm, 0);

	for_each_vma(vmi, vma) {
		if (start < vma->vm_end)
			return vma;
	}
	return NULL;
#else
	struct vm_area_struct *vma;

	for (vma = mm->mmap; vma; vma = vma->vm_next) {
		if (start < vma->vm_end)
			break;
	}
	return vma;
#endif
}

/* walk_dbg >= 2: dump the first few resolutions past the ops test, to tell "no vma for
 * (mm, start)" from "the vma is not the expected one". */
static void sus_map_walk_dbg_log(const char *what, struct mm_struct *mm,
                                 unsigned long start, struct vm_area_struct *vma)
{
    if (walk_dbg < 2)
        return;
    if (atomic_dec_if_positive(&n_walk_dbg_left) < 0)
        return;
    SUSFS_LOGI("sus_map: %s mm=%px start=%lx mmap=%px vma=%px %lx-%lx file=%px\n",
            what, mm, start, mm ? sus_map_find_vma(mm, 0) : NULL, vma,
            vma ? vma->vm_start : 0UL, vma ? vma->vm_end : 0UL,
            (vma && vma->vm_file) ? vma->vm_file : NULL);
}

/* walk_page_range(mm, start, end, ops, private): the vma is resolved from (mm, start) as
 * the walk itself would have done, under the mmap_lock every caller of these three ops
 * holds for read - so sus_map_find_vma()'s container cannot change underneath it. */
static int sus_map_skip_walk_pre(struct kprobe *kp, struct pt_regs *regs)
{
    const void *ops = (const void *)regs->regs[3];
    struct mm_struct *mm;
    struct vm_area_struct *vma;
    unsigned long start;

    atomic_inc(&n_walk_seen);
    if (walk_dbg)
        sus_map_note_ops(ops);
    if (!sus_map_walk_ops_ours(ops))
        return 0;

    atomic_inc(&n_walk_ops_hit);
    if (!sus_map_gate_ok())
        return 0;

    mm = (struct mm_struct *)regs->regs[0];
    start = (unsigned long)regs->regs[1];
    if (!mm)
        return 0;

    vma = sus_map_find_vma(mm, start);
    if (!vma || start < vma->vm_start) {
        atomic_inc(&n_walk_scan_fail);
        sus_map_walk_dbg_log("walk_page_range: no vma", mm, start, NULL);
        return 0;
    }
    sus_map_walk_dbg_log("walk_page_range: vma", mm, start, vma);

    return sus_map_walk_answer(kp, regs, vma) ? 1 : 0;
}

/* walk_page_vma(vma, ops, private): same walk, vma handed over directly. */
static int sus_map_skip_walk_vma_pre(struct kprobe *kp, struct pt_regs *regs)
{
    const void *ops = (const void *)regs->regs[1];

    atomic_inc(&n_walk_seen_vma);
    if (walk_dbg)
        sus_map_note_ops(ops);
    if (!sus_map_walk_ops_ours(ops))
        return 0;

    atomic_inc(&n_walk_ops_hit);
    if (!sus_map_gate_ok())
        return 0;

    return sus_map_walk_answer(kp, regs,
                               (struct vm_area_struct *)regs->regs[0]) ? 1 : 0;
}

static struct kprobe kp_map_walk = {
    .symbol_name = "walk_page_range",
    .pre_handler = sus_map_skip_walk_pre,
};

static struct kprobe kp_map_walk_vma = {
    .symbol_name = "walk_page_vma",
    .pre_handler = sus_map_skip_walk_vma_pre,
};

/* ---- /proc/<pid>/mem (and ptrace): the page-fetch primitive ----
 *
 * Upstream's fifth SUS_MAP site is __access_remote_vm() (mm/memory.c, patch:5667-5687):
 * after mmap_read_lock it resolves vma = vma_lookup(mm, addr) once and, inside the transfer
 * loop, breaks out when that vma's file is registered - so a read (or write) starting
 * inside a hidden mapping transfers nothing at all.  Its entry cannot be hooked usefully:
 * the lock is taken INSIDE it, and resolving a vma without that lock is a use-after-free
 * waiting for the target process to munmap.  What can be hooked is the primitive the loop
 * calls with the lock held:
 *   __access_remote_vm()       -> get_user_pages_remote(mm, addr, 1, ...)
 *   process_vm_rw_single_vec() -> pin_user_pages_remote(mm, pa, ...)
 *   (both *_remote variants require mmap_read_lock)
 * Reject a nonempty request with -EFAULT, leaving page outputs and the caller's mmap lock
 * unchanged.  get_user_page_vma_remote() tests only `got < 0`: returning zero without a
 * page lets __access_remote_vm() copy through an uninitialized page pointer.  This caused
 * the CP12 BZIG panic in mem_rw -> __access_remote_vm -> __memcpy.  Zero is valid only for
 * a zero-page request, which must pass through.  Both consumers take their failure path
 * on -EFAULT; no page is pinned because the call never runs.
 *
 * The second primitive is not needed for upstream parity (upstream patches
 * __access_remote_vm only, and process_vm_readv does not go through it - measured from this
 * kernel's mm/process_vm_access.c: process_vm_rw_single_vec calls pin_user_pages_remote
 * directly); it is hooked because the same short circuit closes one more probe.
 *
 * Cost control: the handler runs on every *_remote page fetch while a rule exists, so the
 * cheapest tests come first (no rules -> one load; not an umounted app -> the gate) and find_vma()
 * only runs for callers the gate lets through. */
static atomic_t n_gup_calls = ATOMIC_INIT(0);
static atomic_t n_pin_calls = ATOMIC_INIT(0);
static atomic_t n_vm_hides = ATOMIC_INIT(0);

static int sus_map_vm_access_pre(struct kprobe *kp, struct pt_regs *regs);

/* Hook the public remote wrappers, whose callers already hold mmap_read_lock.  BZIG has
 * no __get_user_pages_remote symbol.  Do not substitute __get_user_pages_locked: other
 * callers use it before acquiring the lock, making a VMA lookup unsafe there.  LTO may
 * inline either public wrapper; registration and hit counts do not prove reachability. */
static struct kprobe kp_gup_remote = {
    .symbol_name = "get_user_pages_remote",
    .pre_handler = sus_map_vm_access_pre,
};

static struct kprobe kp_pin_remote = {
    .symbol_name = "pin_user_pages_remote",
    .pre_handler = sus_map_vm_access_pre,
};

static int sus_map_vm_access_pre(struct kprobe *kp, struct pt_regs *regs)
{
    struct mm_struct *mm = (struct mm_struct *)regs->regs[0];
    unsigned long addr = regs->regs[1];
    unsigned long nr_pages = regs->regs[2];
    struct vm_area_struct *vma;
    struct inode *inode;

    if (!smp_load_acquire(&nmap))
        return 0;
    if (!sus_map_gate_ok())
        return 0;
    if (!mm || !nr_pages)
        return 0;

    atomic_inc(kp == &kp_pin_remote ? &n_pin_calls : &n_gup_calls);

    /* both callers hold mmap_read_lock: the *_remote contract of this primitive */
    vma = find_vma(mm, addr);
    /* find_vma can return the next VMA when addr is in an unmapped gap. */
    if (!vma || addr < vma->vm_start || addr >= vma->vm_end || !vma->vm_file)
        return 0;
    inode = file_inode(vma->vm_file);
    if (!inode)
        return 0;
    if (!sus_map_lookup(inode->i_ino, inode->i_sb->s_dev))
        return 0;

    atomic_inc(&n_vm_hides);
    regs_set_return_value(regs, -EFAULT); /* no page output: return a failure */
    regs->pc = regs->regs[30];          /* skip the call: nothing is pinned */
    return 1;
}

/* ---- /proc/<pid>/map_files/<start>-<end> ---- */
#include "sus_map_files.h"

/* Kept in one table so init and exit cannot drift apart. */
static struct kprobe *const map_probes[] = {
    &kp_map, &kp_map_smap, &kp_map_walk, &kp_map_walk_vma,
    &kp_gup_remote, &kp_pin_remote,
};
#define N_MAP_PROBES ARRAY_SIZE(map_probes)
static bool map_registered;
static bool map_probe_armed[N_MAP_PROBES];

/* Reachability, not configuration: "the probe is registered" says nothing on a kernel built
 * with CONFIG_LTO_CLANG_FULL, where the call site it should catch may have been inlined away
 * (walk_page_range() is EXPORT_SYMBOL_GPL and LTO may still inline the calls inside
 * pagemap_read()/smap_gather_stats()).  walk_seen == 0 while a rule matches fingerprints such
 * an inlined call site, not a rule that failed to match. */
static int sus_map_stat_show(char *buf, const struct kernel_param *kp)
{
    int i, armed = 0;

    for (i = 0; i < (int)N_MAP_PROBES; i++)
        armed += map_probe_armed[i] ? 1 : 0;

    return scnprintf(buf, PAGE_SIZE,
                     "rules=%d armed=%d/%d walk_seen=%d walk_vma=%d walk_skipped=%d "
                     "ops_hit=%d scan_fail=%d nofile=%d nomatch=%d getlink: calls=%d skip=%d nomatch=%d hides=%d\n"
                     "vm: gup_calls=%d pin_calls=%d hides=%d\n"
                     "listing: maps_calls=%d maps_hides=%d smaps_calls=%d smaps_hides=%d\n"
                     "map_files: ready=%d route=kprobe divert_checked=1 probe_slot=%d probe_error=%d diverted=%d bypassed=%d iterate_calls=%d entries_hidden=%d readlink_calls=%d follow_calls=%d paths_acquired=%d paths_released=%d paths_jumped=%d\n"
                     "map_metadata: checkpoint=19 ready=%d lookup_calls=%d lookup_hides=%d revalidate_calls=%d revalidate_hides=%d rcu_retries=%d\n"
                     "ops: smaps=%px smaps_shmem=%px pagemap=%px\n",
                     READ_ONCE(nmap), armed, (int)N_MAP_PROBES,
                     atomic_read(&n_walk_seen), atomic_read(&n_walk_seen_vma),
                     atomic_read(&n_walk_skip),
                     atomic_read(&n_walk_ops_hit), atomic_read(&n_walk_scan_fail),
                     atomic_read(&n_walk_nofile), atomic_read(&n_walk_nomatch),
                     atomic_read(&n_getlink_calls), atomic_read(&n_getlink_skip),
                     atomic_read(&n_getlink_nomatch), atomic_read(&n_map_files_hides),
                     atomic_read(&n_gup_calls), atomic_read(&n_pin_calls),
                     atomic_read(&n_vm_hides),
                     atomic_read(&n_maps_calls), atomic_read(&n_maps_hides),
                     atomic_read(&n_smaps_calls), atomic_read(&n_smaps_hides),
                     READ_ONCE(map_files_installed), READ_ONCE(map_files_probe_slot),
                     READ_ONCE(map_files_probe_error), atomic_read(&n_map_files_diverted),
                     atomic_read(&n_map_files_bypassed), atomic_read(&n_map_files_iterate),
                     atomic_read(&n_map_files_entries_hidden), atomic_read(&n_map_files_readlink),
                     atomic_read(&n_map_files_follow), atomic_read(&n_map_files_paths),
                     atomic_read(&n_map_files_puts), atomic_read(&n_map_files_jumps),
                     READ_ONCE(map_files_installed), atomic_read(&n_map_files_lookup),
                     atomic_read(&n_map_files_lookup_hides), atomic_read(&n_map_files_revalidate),
                     atomic_read(&n_map_files_revalidate_hides), atomic_read(&n_map_files_revalidate_rcu),
                     sus_map_ops_smaps, sus_map_ops_smaps_shmem,
                     sus_map_ops_pagemap);
}
static const struct kernel_param_ops sus_map_stat_ops = {
    .get = sus_map_stat_show,
};
module_param_cb(map_stat, &sus_map_stat_ops, NULL, 0400);

/* Registers whichever of the probes are not up yet.  Called from init (when a rule
 * already exists) and from the supercall that adds the first rule, so both paths arm
 * exactly the same set. */
static int sus_map_register_probes(void)
{
    int i, n = 0, first_err = 0;

    sus_map_resolve_walk_ops();

    for (i = 0; i < (int)N_MAP_PROBES; i++) {
        int rc;

        if (map_probe_armed[i])
            continue;
        if ((map_probes[i] == &kp_map_walk || map_probes[i] == &kp_map_walk_vma) &&
            !sus_map_walk_ops_any())
            continue;
        map_probes[i]->addr = NULL;
        map_probes[i]->flags = 0;
        rc = register_kprobe(map_probes[i]);
        if (rc) {
            pr_warn("sus_map: register_kprobe(%s) failed %d - that listing is not filtered\n",
                    map_probes[i]->symbol_name, rc);
            if (!first_err)
                first_err = rc;
            continue;
        }
        map_probe_armed[i] = true;
        n++;
    }

    if (n)
        SUSFS_LOGI("sus_map: %d/%d probes armed (%d rules)\n",
                n, (int)N_MAP_PROBES, nmap);

    {
        int rc = sus_map_files_install();
        if (rc && !first_err)
            first_err = rc;
    }

    map_registered = map_probe_armed[0] && map_files_installed;
    return map_registered ? 0 : first_err;
}


int susfs_sus_map_init(void)
{
    int rc;

    mutex_lock(&map_config_lock);
    sus_map_add(param_map_ino);
    if (nmap == 0) {
        SUSFS_LOGI("sus_map: no rules, hook not installed\n");
        rc = 0;
        goto out;
    }

    /* Every probe is optional on its own: without show_smap the maps listing is still
     * filtered, so one missing symbol must not take the rest down. */
    rc = sus_map_register_probes();
out:
    map_ready = !rc;
    mutex_unlock(&map_config_lock);
    return rc;
}

void susfs_sus_map_exit(void)
{
    int i;

    mutex_lock(&map_config_lock);
    map_ready = false;
    sus_map_files_remove();
    for (i = 0; i < (int)N_MAP_PROBES; i++) {
        if (!map_probe_armed[i])
            continue;
        unregister_kprobe(map_probes[i]);
        map_probe_armed[i] = false;
    }
    map_registered = false;
    sus_map_clear();
    mutex_unlock(&map_config_lock);
}

/* Caller holds map_config_lock. Arm the required listing hook before publishing
 * a new rule; a failed registration must not leave a hidden inode behind. */
static int sus_map_configure_path(const char *name, bool add)
{
    struct path p;
    struct inode *inode;
    int rc;

    if (!map_ready)
        return -ENODEV;
    rc = kern_path(name, LOOKUP_FOLLOW, &p);
    if (rc)
        return rc;
    inode = d_backing_inode(p.dentry);
    if (!inode || !inode->i_ino) {
        rc = -ENOENT;
        goto out;
    }
    if (add) {
        rc = sus_map_register_probes();
        if (rc)
            goto out;
        rc = sus_map_add_full(inode->i_ino, inode->i_sb->s_dev);
    } else {
        rc = sus_map_remove_full(inode->i_ino, inode->i_sb->s_dev);
    }
out:
    path_put(&p);
    return rc;
}

/* supercall: CMD_SUSFS_ADD_SUS_MAP (resolve path -> ino/dev, register hook) */
void susfs_sus_map_supercall(void __user **arg)
{
    struct st_susfs_sus_map info = {0};

    if (copy_from_user(&info, (void __user *)*arg, sizeof(info))) {
        info.err = -EFAULT;
        goto out;
    }

    /* char[256] field that need not be NUL-terminated: reject it before kern_path() can read off the end of our stack copy. */
    if (!susfs_abi_path_ok(info.target_pathname, sizeof(info.target_pathname))) {
        info.err = -ENAMETOOLONG;
        goto out;
    }

    mutex_lock(&map_config_lock);
    info.err = sus_map_configure_path(info.target_pathname, true);
    mutex_unlock(&map_config_lock);
out:
    /* upstream writes back only ->err for input-type commands */
    if (copy_to_user(&((struct st_susfs_sus_map __user *)*arg)->err,
                     &info.err, sizeof(info.err)))
        pr_warn("sus_map supercall copy_to_user failed\n");
}

/* Root-only management extension; the upstream add supercall stays unchanged.
 * Deleting a rule leaves probes registered but unable to match that inode, so
 * readers regain the original views immediately. */
static int sus_map_rules_set(const char *val, const struct kernel_param *kp)
{
    char command[sizeof(((struct st_susfs_sus_map *)0)->target_pathname) + 8];
    char *text, *end;
    int rc;

    if (strnlen(val, sizeof(command)) >= sizeof(command))
        return -ENAMETOOLONG;
    strscpy(command, val, sizeof(command));
    text = command;
    while (*text == ' ' || (*text >= '\t' && *text <= '\r'))
        text++;
    end = text + strlen(text);
    while (end > text && (end[-1] == ' ' ||
                         (end[-1] >= '\t' && end[-1] <= '\r')))
        *--end = '\0';
    mutex_lock(&map_config_lock);
    if (!map_ready) {
        rc = -ENODEV;
    } else if (!strcmp(text, "clear")) {
        sus_map_clear();
        rc = 0;
    } else if ((!strncmp(text, "add /", 5) ||
                !strncmp(text, "del /", 5)) &&
               susfs_abi_path_ok(text + 4,
                                 sizeof(((struct st_susfs_sus_map *)0)->target_pathname))) {
        rc = sus_map_configure_path(text + 4, text[0] == 'a');
    } else {
        rc = -EINVAL;
    }
    mutex_unlock(&map_config_lock);
    return rc;
}

static int sus_map_rules_show(char *buf, const struct kernel_param *kp)
{
    unsigned long flags;
    int i, len;

    spin_lock_irqsave(&map_table_lock, flags);
    len = scnprintf(buf, PAGE_SIZE, "rules=%d/%d\n", nmap, SUS_MAP_MAX);
    for (i = 0; i < nmap; i++)
        len += scnprintf(buf + len, PAGE_SIZE - len, "ino=%lu dev=%lu\n",
                         map_entries[i].target_ino,
                         (unsigned long)map_entries[i].target_dev);
    spin_unlock_irqrestore(&map_table_lock, flags);
    return len;
}
static const struct kernel_param_ops sus_map_rules_ops = {
    .set = sus_map_rules_set,
    .get = sus_map_rules_show,
};
module_param_cb(map_rules, &sus_map_rules_ops, NULL, 0600);
