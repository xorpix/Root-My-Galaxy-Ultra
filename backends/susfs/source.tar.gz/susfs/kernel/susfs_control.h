/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef SUSFS_CONTROL_H
#define SUSFS_CONTROL_H

/* Process-context configuration only. A successful get must be paired with a
 * final put, followed by no further resource access or voluntary scheduling.
 * Parameter parsing before init is allowed; layers still validate readiness.
 * Shutdown closes admission permanently and drains accepted configurations. */
int susfs_control_get(void);
void susfs_control_put(void);
void susfs_control_shutdown(void);

#endif
