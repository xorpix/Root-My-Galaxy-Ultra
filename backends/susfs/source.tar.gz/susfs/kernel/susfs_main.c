// SPDX-License-Identifier: GPL-2.0
/*
 * susfs_main.c - SUSFS LKM entry point: the layer table plus this module's control nodes.
 * Loaded via `ksud insmod`, with unexported symbols relocated via kallsyms.
 */
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/version.h>	/* LINUX_VERSION_CODE: the MODULE_IMPORT_NS spelling below */

#include "symbol_resolver.h"
#include "susfs_log.h"
#include "susfs_fp_hook.h"	/* susfs_fp_init: the sys_call_table cache the create_gate layer installs through */
#include "lsm_hook.h"
#include "susfs.h"
#include "ksu_umount_gate.h"	/* issue #34: the hide gates ask KernelSU */

/* Prototyped in patch_memory.h for patch_memory.c, which defines it; declared again here
 * rather than via that header, which pulls arch-specific cache and patch headers the
 * host test models for this file do not provide. */
int ksu_patch_memory_init(void);

#define SUSFS_LKM_VERSION "2.3.0-gki"
/* The module's own name lives in susfs.h (SUSFS_LKM_MODULE_NAME / SUSFS_LKM_SYSFS_DIR):
 * /sys/module's directory and the rules that hide it (susfs_hide_syms.c) must agree. */

/* The /proc/susfs_* control nodes are created by default and are 0777 on purpose.
 * Measured on device, 0600 plus sus_path hiding does not work: `ls -l /proc/susfs_kstat`
 * -> ENOENT (the inode_getattr hook fired) but `cat` -> Permission denied (it did not), with
 * sus_path's perm counter stuck at 0 - inode_permission() runs the DAC check BEFORE
 * security_inode_permission(), so a 0600 root-owned node fails DAC first, the LSM hook is
 * never reached, and EACCES advertises that the node exists.  General to sus_path's path
 * layer: it can only turn an ENOENT-shaped answer out of files DAC would have ALLOWED.
 * Hence 0777: DAC passes, the LSM layer is the only thing that answers (ENOENT for every
 * non-root caller).
 * The nodes exist only when the layer that hides them is installed
 * (susfs_control_node_allowed()), so an unprotected world-writable node cannot happen, and
 * root-only access is enforced by the handlers' uid checks, not by the mode.  expose_proc=0
 * removes the nodes entirely. */
bool susfs_expose_proc = true;
module_param_named(expose_proc, susfs_expose_proc, bool, 0600);

static const char *const susfs_self_hide_paths[] = {
    "/proc/susfs_kstat",
    "/proc/susfs_open_redirect",
    "/proc/susfs_enable_log",
    "/proc/susfs_avc_spoof",
    SUSFS_HIDE_MODULES_NODE,
    SUSFS_HIDE_MOUNTS_NODE,
    /* sus_path's own interface (the rule listing): it goes through the same table it
     * prints, so a broken rule table is visible in the very view that reports it. */
    SUSFS_PATH_NODE,
    /* The module's own sysfs directory is NOT here: it belongs to hide_module
     * (susfs_hide_syms.c), which adds and drops that rule at runtime. */
};

/* Register our control nodes in sus_path's hidden set: probing them must answer ENOENT,
 * not EACCES.  Runs after every feature init (the nodes must exist for kern_path() to
 * resolve them) and after sus_path_init(), so the hooks are already patched. */
static void susfs_self_hide_nodes(void)
{
    int i;

    if (!susfs_expose_proc)
        return;

    for (i = 0; i < ARRAY_SIZE(susfs_self_hide_paths); i++) {
        int rc = sus_path_add_self_hidden(susfs_self_hide_paths[i]);

        if (rc)
            pr_warn("susfs_guard_lkm: self-hide %s failed %d\n",
                    susfs_self_hide_paths[i], rc);
    }
}

/* ---- layer table: arming order IS the teardown order, reversed --------------
 * A failed load must leave NOTHING armed: when module_init() returns an error the kernel
 * frees this module's memory, so anything still installed - a patched security_hook_heads
 * slot above all - becomes a function pointer into freed memory that the next syscall goes
 * through.  Hence the exits of the already-armed layers run before failing.
 * Teardown runs in the exact reverse of arming, in one place, and the order matters:
 * sus_path's LSM layer is what answers ENOENT for this module's own 0777 control nodes (see
 * the expose_proc note), so unhooking it before the nodes are removed would expose them to
 * every process during the unload - here the nodes go first and the LSM layer last.
 * A failed layer either refuses the load (fatal, rollback leaves nothing armed) or leaves
 * that one feature off while the module keeps working (non-fatal: the two layers whose
 * failure answers exactly what the stock kernel answers, ksu_umount_gate and create_gate).
 * The exits are idempotent, so one path serves rollback and unload alike. */
static int layer_lsm_hook_init(void)
{
    ksu_lsm_hook_init();
    if (!ksu_lsm_hook_ready()) {
        pr_err("lsm_hook: the table the hook insertion walks is not resolvable on this kernel - refusing to load\n");
        return -ENOENT;
    }
    return 0;
}

/* Not const: the `armed` flags live here (the pointers must outlive __init too). */
static struct {
    const char *name;
    int (*init)(void);
    void (*exit)(void);
    bool armed;			/* exit is run for every layer that was attempted */
    bool fatal;			/* a failing init refuses the load; false keeps the module up
				 * with that one feature off */
    int feature;		/* enum susfs_feature armed on a successful init, or -1 */
} susfs_layers[] = {
    /* First, and FATAL: the fp-hook layer every syscall-table entry replaces an entry through.
     * A module that loads without the table cannot intercept a single syscall and would arm
     * rules it can neither answer nor expose - the "loaded but inert" shape the layer table
     * refuses as a whole.  susfs_fp_init() only resolves and caches the table; the entries
     * themselves are installed by the layers that use it (create_gate here; this fork's kstat
     * rides the sys_exit tracepoint instead). */
    { "fp_hook",	susfs_fp_init,			NULL,			false, true,  -1 },
    /* NOT fatal: this layer only decides whether KernelSU's predicate was found at load.
     * When it was not, the gates answer the pre-#34 way (uid >= 10000) and every other layer still
     * works - so a failure here is a degradation, not a reason to refuse the module.  Skipping this
     * init entirely (fail_layer=2) is safe for the same reason: the flag it sets defaults to the
     * pre-#34 answer. */
    { "ksu_umount_gate",	susfs_ksu_umount_gate_init,	susfs_ksu_umount_gate_exit,			false, false, -1 },
    /* FATAL: every LSM layer below (sus_path first) inserts through this file's table hooks.
     * A module that loads without it would accept rules no LSM layer can apply - the same
     * "loaded but inert" shape fp_hook is fatal for.  ksu_lsm_hook_init() itself only
     * reports; the refusal lives here, where a failure can fail the load. */
    { "lsm_hook",	layer_lsm_hook_init,		ksu_lsm_hook_exit,	false, true,  -1 },
    { "sus_path",	sus_path_init,			sus_path_exit,		false, true,  SUSFS_FEAT_SUS_PATH },
    /* After sus_path, whose rule table and per-caller gate it asks.  NOT fatal: when it
     * cannot arm, the create family keeps answering the kernel's own errno - which is the
     * behaviour this module had before the gate existed, not a broken hide. */
    { "create_gate",	susfs_create_gate_init,		susfs_create_gate_exit,	false, false, SUSFS_FEAT_SUS_PATH },
    { "uname",		susfs_uname_init,		susfs_uname_exit,	false, true,  SUSFS_FEAT_SPOOF_UNAME },
    { "kstat",		susfs_kstat_init,		susfs_kstat_exit,	false, true,  SUSFS_FEAT_SUS_KSTAT },
    { "sus_map",	susfs_sus_map_init,		susfs_sus_map_exit,	false, true,  SUSFS_FEAT_SUS_MAP },
    { "sus_mount",	susfs_sus_mount_init,		susfs_sus_mount_exit,	false, true,  SUSFS_FEAT_SUS_MOUNT },
    { "cmdline",	susfs_spoof_cmdline_init,	susfs_spoof_cmdline_exit, false, true,	SUSFS_FEAT_SPOOF_CMDLINE },
    { "open_redirect",	susfs_open_redirect_init,	susfs_open_redirect_exit, false, true, SUSFS_FEAT_OPEN_REDIRECT },
    { "enable_log",	susfs_enable_log_init,		susfs_enable_log_exit,	false, true,  SUSFS_FEAT_ENABLE_LOG },
    { "avc_spoof",	susfs_avc_spoof_init,		susfs_avc_spoof_exit,	false, true,  SUSFS_FEAT_AVC_SPOOF },
    { "hide_syms",	susfs_hide_syms_init,		susfs_hide_syms_exit,	false, true,  SUSFS_FEAT_HIDE_SYMS },
    /* Optional: no priority rule is accepted unless native AND compat hooks all armed. */
    { "priority_filter", susfs_priority_filter_init, susfs_priority_filter_exit,
      false, false, SUSFS_FEAT_PRIORITY_FILTER },
    /* Requests can use every feature above.  Stop/drain this entry point before
     * tearing down any feature, including hide_syms. */
    { "supercall",	susfs_supercall_init,		susfs_supercall_exit,	false, true,  -1 },
};

/* Diagnostic: make one layer's init fail, by 1-based index, to exercise the rollback path
 * on the device - a `fatal` layer failing must leave the load with nothing armed.
 * `fail_layer=2` forces the ksu_umount_gate init to fail WITHOUT failing the load (that
 * layer is not fatal): its flag stays on the pre-#34 answer, which is exactly what that
 * layer's own failure is, so the two diagnostic routes are equivalent there.
 * Layer index map (1-based):
 *   1 fp_hook   2 ksu_umount_gate  3 lsm_hook   4 sus_path   5 create_gate
 *   6 uname     7 kstat            8 sus_map    9 sus_mount  10 cmdline
 *   11 open_redirect  12 enable_log  13 avc_spoof  14 hide_syms  15 priority_filter  16 supercall */
static int fail_layer;
module_param_named(fail_layer, fail_layer, int, 0644);

/* Not __init/__exit: it is called from both, and an __exit callee in __init code is a
 * modpost section mismatch. */
static void susfs_layers_down(int upto)
{
    int i;

    for (i = upto; i >= 0; i--) {
        if (!susfs_layers[i].armed)
            continue;
        susfs_layers[i].armed = false;
        if (susfs_layers[i].exit)
            susfs_layers[i].exit();
    }
}

static int __init susfs_init(void)
{
    int i;

    /* rcupdate.h aliases synchronize_rcu_tasks() to ordinary RCU without this
     * configuration.  That alias cannot protect a preempted callback's return
     * tail.  Reject before installing any hooks, including on failed init. */
    if (!IS_ENABLED(CONFIG_TASKS_RCU)) {
        pr_err("susfs_guard_lkm: CONFIG_TASKS_RCU is required for callback lifetime safety\n");
        return -EOPNOTSUPP;
    }

    SUSFS_LOGI("init v%s\n", SUSFS_LKM_VERSION);
    ksu_init_symbol_resolver();

    /* The flush helper the text/data patching needs is resolved by name here, before any layer
     * installs a hook: a kernel that exports neither dcache spelling cannot patch, and the hooking
     * layers (fp_hook, lsm_hook, sus_path) are fatal, so refuse the load cleanly up front rather
     * than let each patch fail one by one. */
    {
        int pm = ksu_patch_memory_init();

        if (pm) {
            pr_err("susfs_guard_lkm: no kernel cache-flush symbol - text patching unavailable, refusing to load\n");
            return pm;
        }
    }

    for (i = 0; i < (int)ARRAY_SIZE(susfs_layers); i++) {
        int ret;

        /* Marked before the call: a layer that half-ran still has to be taken down. */
        susfs_layers[i].armed = true;

        if (fail_layer == i + 1) {
            pr_warn("susfs_guard_lkm: fail_layer=%d - forcing %s's init to fail (diagnostic)\n",
                    fail_layer, susfs_layers[i].name);
            ret = -EIO;
        } else {
            ret = susfs_layers[i].init ? susfs_layers[i].init() : 0;
        }

        if (!ret) {
            /* Arm the feature only after its layer's init reported success: the SHOW
             * list and the command gate read this same bit, so an un-armed layer is
             * both unadvertised and refuses its commands (a non-fatal failure above
             * left the module up but that feature off). */
            if (susfs_layers[i].feature >= 0)
                susfs_supercall_arm_feature(susfs_layers[i].feature);
            continue;
        }

        if (susfs_layers[i].fatal) {
            pr_err("susfs_guard_lkm: required feature %s init failed %d, rolling back\n",
                   susfs_layers[i].name, ret);
            /* Failed init frees module text. Remove every attempted hook first. */
            susfs_layers_down(i);
            return ret;
        }
        pr_warn("susfs_guard_lkm: %s init failed %d - that feature stays off\n",
                susfs_layers[i].name, ret);
    }

    /* Registered last and undone implicitly: these are entries in sus_path's table, which
     * sus_path_exit() empties while its LSM layer still answers ENOENT for the nodes. */
    susfs_self_hide_nodes();

    /* Operator note.  The module hides its own traces from EVERY caller, root included (a
     * built-in SUSFS has no module entry, so hiding it only from non-root would leave a
     * trace upstream does not have): `lsmod | grep susfs` stays empty and a second `insmod`
     * fails with -EEXIST, which reads like a broken module.
     * This load confirmation and the fallback warning below ignore enable_log:
     * they are the evidence of a completed load and its delivery route, so both
     * stay unconditional even for a silent load - otherwise
     * "loaded but logging off" is indistinguishable from "not loaded".  The prefix comes
     * from pr_fmt (susfs_log.h), so the message must not repeat it. */
    pr_info("loaded. This module is filtered out of /proc/modules for every caller including root, so `lsmod | grep susfs` stays empty - check /sys/module/%s instead (a second insmod fails with -EEXIST while it is loaded).\n",
            SUSFS_LKM_MODULE_NAME);

    if (susfs_supercall_kprobe_active())
        pr_warn("supercall uses the kprobe fallback: the breakpoint on __arm64_sys_reboot is visible through kernel debugging and instruction inspection.\n");

    return 0;
}

static void __exit susfs_exit(void)
{
    susfs_layers_down((int)ARRAY_SIZE(susfs_layers) - 1);
    SUSFS_LOGI("susfs_guard_lkm: exit\n");
}

module_init(susfs_init);
module_exit(susfs_exit);
MODULE_LICENSE("GPL");

/* The VFS symbol namespace of this kernel's GKI builds.
 * kern_path, ihold (fs/) and override_creds/revert_creds (kernel/cred.c) are exported as
 * EXPORT_SYMBOL_NS(sym, ANDROID_GKI_VFS_EXPORT_ONLY); the Android build maps that name to
 * the long string below with a per-directory ccflag before the compiler stringifies it
 * (fs/Makefile subdir-ccflags-y, plus kernel/Makefile for cred.o on some releases).  A
 * module that does not import the RESULTING string is refused with "module uses symbol
 * (kern_path) from namespace VFS_internal_... but does not import it" -> "Unknown symbol
 * kern_path (err -22)" - why plain insmod failed on the phone before this line existed.
 * 6.13 changed the SPELLING ("module: convert symbol namespace to string literal"):
 *   <= 6.12  #define MODULE_IMPORT_NS(ns) MODULE_INFO(import_ns, __stringify(ns))
 *   >= 6.13  #define MODULE_IMPORT_NS(ns) MODULE_INFO(import_ns, ns)
 * so a BARE identifier is required before that and a QUOTED string after - MODULE_IMPORT_NS
 * stringifies its argument up to 6.12, which is also why the long form here has to be
 * literal (measured: passing the macro name left the built .ko's .modinfo with no import_ns
 * entry at all).  Wrong is silent one way (<= 6.12 stringifies the quotes too, importing a
 * namespace no kernel creates) and a hard error the other (>= 6.13 rejects a bare
 * identifier: 'expected ; after top level declarator', measured on android17-6.18).  Both
 * spellings emit the same .modinfo entry, checked per variant by the CI step that fails a
 * .ko with no import_ns entry.
 * Necessary but NOT sufficient for plain insmod: nine further symbols are not in the export
 * table in any of the six GKI variants (kallsyms_lookup_name and friends, saved_boot_config,
 * task_work_add, init_mm, __set_fixmap, copy_to_kernel_nofault, dcache_clean_inval_poc), so
 * tools/susfs_insmod.c rewrites undefined symbols to absolute addresses, as ksud does. */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 13, 0)
MODULE_IMPORT_NS("VFS_internal_I_am_really_a_filesystem_and_am_NOT_a_driver");
#else
MODULE_IMPORT_NS(VFS_internal_I_am_really_a_filesystem_and_am_NOT_a_driver);
#endif
MODULE_DESCRIPTION("SUSFS guard LKM (susfs_guard_lkm) v2.3.0-gki");
