/* SPDX-License-Identifier: GPL-2.0 */
/*
 * lsm_hook.c - runtime LSM hook installation (ported from KernelSU/SukiSU hook/lsm_hook.c).
 * Both mechanisms write through ksu_patch_text(): every word they touch is read-only text, and the
 * replacement lives in module .text, so a patch has to go through stop_machine.
 *
 *   replace - overwrite the entry's function slot; the old pointer goes to hook->original
 *             for pass-through.  The slot is SELinux's, so a caller LSM returning non-zero
 *             first masks this hook.
 *   insert  - get in front of every registered LSM, so the hook can only ADD a denial:
 *               < 6.12   add our OWN security_hook_list node at the HEAD of the hlist
 *                        (hook->insert, KSU_LSM_HOOK_INSERT): no symbol, no original.
 *               >= 6.12  no hlist exists - dispatch is one static call per (hook, LSM
 *                        slot) - so insertion TAKES OVER SELinux's slot, whose original
 *                        must be called for pass-through (SUS_LSM_PASS_ORIG(), sus_path.c).
 */
#include <linux/compiler.h>
#include <linux/errno.h>
#include <linux/kernel.h>
#include <linux/lsm_hooks.h>
#include <linux/mutex.h>
#include <linux/delay.h>
#include <linux/rcupdate.h>
#include <linux/string.h>
#include <linux/version.h>		/* LINUX_VERSION_CODE for the gates below (do not rely on a transitive include) */

#include "symbol_resolver.h"
#include "lsm_hook.h"
#include "patch_memory.h"
#include "susfs_log.h"
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
#include <linux/static_call.h>		/* __static_call_update() - EXPORT_SYMBOL_GPL */
#include <linux/static_call_types.h>	/* struct static_call_key */
#include <linux/lsm_count.h>		/* MAX_LSM_COUNT = the slots each hook has */
#include <linux/kallsyms.h>		/* KSYM_SYMBOL_LEN, to name the target function */
#include <linux/uaccess.h>		/* copy_from_kernel_nofault(), layout probe */
#endif

struct ksu_lsm_hook_entry {
    struct ksu_lsm_hook *hook;
};

static DEFINE_MUTEX(ksu_lsm_hook_lock);
static struct ksu_lsm_hook_entry ksu_lsm_hook_entries[16];
static int ksu_lsm_hook_count;

static bool ksu_lsm_hook_is_tracked(struct ksu_lsm_hook *hook)
{
    int i;

    for (i = 0; i < ksu_lsm_hook_count; i++) {
        if (ksu_lsm_hook_entries[i].hook == hook)
            return true;
    }

    return false;
}

static int ksu_lsm_hook_track(struct ksu_lsm_hook *hook)
{
    if (ksu_lsm_hook_is_tracked(hook))
        return 0;

    if (ksu_lsm_hook_count >= ARRAY_SIZE(ksu_lsm_hook_entries)) {
        pr_err("lsm_hook: tracking table full, cannot record %s\n", hook->head_name ?: "unknown");
        return -ENOSPC;
    }

    ksu_lsm_hook_entries[ksu_lsm_hook_count++].hook = hook;
    return 0;
}

static void ksu_lsm_hook_untrack(struct ksu_lsm_hook *hook)
{
    int i;

    for (i = 0; i < ksu_lsm_hook_count; i++) {
        if (ksu_lsm_hook_entries[i].hook != hook)
            continue;

        ksu_lsm_hook_entries[i] = ksu_lsm_hook_entries[--ksu_lsm_hook_count];
        return;
    }
}

static int ksu_lsm_hook_patch_slot(void **slot, void *value)
{
    void *patched = value;
    int ret;

    ret = ksu_patch_text(slot, &patched, sizeof(patched), KSU_PATCH_TEXT_FLUSH_DCACHE);
    if (!ret)
        smp_wmb();

    return ret;
}

#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 12, 0)
/* ---- insertion into a hook list (hook->insert) -------------------------------
 * SELinux's node lives in selinux_hooks[] __lsm_ro_after_init, hence ksu_patch_text()
 * below; our node is writable and becomes reachable only once head->first is patched, so
 * no walk can observe a half-initialised node. */

/* How many entries of a list are looked at while identifying it; a list is short and this only
 * bounds the walk. */
#define KSU_LSM_HEAD_SCAN_ENTRIES	64

/* Find the list head for @hook by IDENTITY instead of by the build-time offset.
 *
 * offsetof(struct security_hook_heads, member) is only this hook's list when the kernel's hook
 * order matches the tree this module was compiled against - and the offset-based cross-check
 * below cannot tell the difference: it compares first->head with the address it computed, and a
 * list belonging to ANOTHER hook reports exactly that value, because its entries were linked to
 * it.  Inserting the replacement into the wrong list means the kernel calls it with another
 * hook's prototype, which under kCFI is a panic at best.  Measured on 6.12.23-android16: the
 * table offset landed on a different hook there entirely (see the technical notes).
 *
 * What identifies a list is which implementation of `selinux_<member>` its entries hold: resolve
 * that name to its addresses (kallsyms, normally one) and take the first head whose list contains
 * an entry holding one of them.  Returns -ENOENT when nothing matches; the caller then falls back
 * to the computed offset, which is what every kernel that works today relies on. */
static int ksu_lsm_hook_head_by_identity(unsigned long heads_addr, struct ksu_lsm_hook *hook,
                                        struct hlist_head **out)
{
    unsigned long addrs[8];
    char want[64];
    int n_addrs, i;
    unsigned long off;

    snprintf(want, sizeof(want), "selinux_%s", hook->head_name);
    n_addrs = ksu_find_symbol_all(want, addrs, (int)ARRAY_SIZE(addrs));
    if (!n_addrs)
        return -ENOENT;

    for (off = 0; off + sizeof(struct hlist_head) <= sizeof(struct security_hook_heads);
         off += sizeof(struct hlist_head)) {
        struct hlist_head *head = (struct hlist_head *)(heads_addr + off);
        struct security_hook_list *e =
            hlist_entry_safe(READ_ONCE(head->first), struct security_hook_list, list);
        int seen = 0;

        for (; e && seen < KSU_LSM_HEAD_SCAN_ENTRIES; seen++) {
            void *fn = *(void **)((char *)e + hook->hook_offset);

            for (i = 0; i < n_addrs; i++) {
                if (fn == (void *)addrs[i]) {
                    *out = head;
                    return 0;
                }
            }
            e = hlist_entry_safe(READ_ONCE(e->list.next), struct security_hook_list, list);
        }
    }

    return -ENOENT;
}

/* Locate the list head for hook->head_name: by identity first (above), then - and only then - by
 * offsetof(struct security_hook_heads, member), a __randomize_layout struct (RANDSTRUCT is off in
 * every GKI build this module targets).  The offset path also cross-checks that the first entry at
 * that address points back at it, and an offset that lands on no list is -ENOENT (as in replace);
 * what it cannot see is an offset that lands on ANOTHER hook's list, which is why identity goes
 * first and says so when the two disagree. */
static int ksu_lsm_hook_head_at(unsigned long heads_addr, struct ksu_lsm_hook *hook,
                                struct hlist_head **out)
{
    struct hlist_head *head;
    struct security_hook_list *first;

    if (ksu_lsm_hook_head_by_identity(heads_addr, hook, &head) == 0) {
        first = hlist_entry_safe(READ_ONCE(head->first), struct security_hook_list, list);
        if (first && first->head != head) {
            pr_err("lsm_hook: %s: identified head %px but its first entry reports %px - refusing\n",
                    hook->head_name ?: "unknown", head, first->head);
            return -EINVAL;
        }
        if ((unsigned long)head != heads_addr + hook->head_offset) {
            pr_warn("lsm_hook: %s: its list is at offset %#lx of security_hook_heads while offsetof() names %#lx - this kernel's hook order differs from the tree this module was built against\n",
                    hook->head_name ?: "unknown",
                    (unsigned long)((char *)head - (char *)heads_addr),
                    (unsigned long)hook->head_offset);
        }
        SUSFS_LOGI("lsm_hook: %s: list head found by identity at offset %#lx\n",
                hook->head_name ?: "unknown",
                (unsigned long)((char *)head - (char *)heads_addr));
        *out = head;
        return 0;
    }

    pr_warn("lsm_hook: %s: no list in security_hook_heads holds this hook's selinux_%s implementation (name not in kallsyms, or renamed) - falling back to the offsetof() slot, unverified\n",
            hook->head_name ?: "unknown", hook->head_name);

    if (hook->head_offset + sizeof(struct hlist_head) > sizeof(struct security_hook_heads)) {
        pr_err("lsm_hook: %s: head offset %#lx is outside security_hook_heads\n",
                hook->head_name ?: "unknown", (unsigned long)hook->head_offset);
        return -EINVAL;
    }

    head = (struct hlist_head *)(heads_addr + hook->head_offset);
    first = hlist_entry_safe(READ_ONCE(head->first), struct security_hook_list, list);

    if (!first) {
        pr_err("lsm_hook: %s: hook list is empty - refusing to insert (nothing to cross-check the head offset against)\n",
                hook->head_name ?: "unknown");
        return -ENOENT;
    }
    if (first->head != head) {
        pr_err("lsm_hook: %s: entry at %px reports head %px, computed %px - struct security_hook_heads layout mismatch, refusing to patch\n",
                hook->head_name ?: "unknown", first, first->head, head);
        return -EINVAL;
    }

    *out = head;
    return 0;
}

/* Insert our node at the head of the list; lock held, head already validated. */
static int ksu_lsm_hook_insert_head(struct ksu_lsm_hook *hook, struct hlist_head *head)
{
    struct security_hook_list *node = &hook->list;
    struct hlist_node *first = READ_ONCE(head->first);
    struct security_hook_list *first_entry;
    int ret;

    first_entry = hlist_entry_safe(first, struct security_hook_list, list);
    if (!first_entry || first_entry->head != head) {
        pr_err("lsm_hook: %s: head %px changed under us, refusing to insert\n",
                hook->head_name ?: "unknown", head);
        return -EAGAIN;
    }

    /* Set the hook word through the offset the slot path uses (the per-hook initialiser
     * need not name the union member); `lsm` is char * on 5.10/5.15, const char * on 6.1. */
    memset(node, 0, sizeof(*node));
    *(void **)((char *)node + hook->hook_offset) = hook->replacement;
    node->head = head;
    node->lsm = "susfs";
    node->list.next = first;
    node->list.pprev = &head->first;

    /* 1. head->first, in __lsm_ro_after_init memory: this write publishes the node. */
    ret = ksu_lsm_hook_patch_slot((void **)&head->first, node);
    if (ret)
        return ret;

    /* 2. the displaced node's back pointer, inside selinux_hooks[] (also RO after init):
     *    a later removal of THAT node must not unlink from a stale pointer into ours. */
    ret = ksu_lsm_hook_patch_slot((void **)&first->pprev, &node->list.next);
    if (ret) {
        /* Roll back the publication - a wrong-way neighbour corrupts the list. */
        if (ksu_lsm_hook_patch_slot((void **)&head->first, first))
            pr_err("lsm_hook: %s: failed to roll back head->first after a failed insert\n",
                    hook->head_name ?: "unknown");
        /* Leave ->next alone: a walker can still be inside this node, and NULL there would end
         * its walk early - every LSM after us (SELinux included) goes unasked. */
        node->list.pprev = NULL;
        return ret;
    }

    hook->entry = node;
    SUSFS_LOGI("lsm_hook: inserted %s as the first node of its list (head %px, before %px, replacement %px)\n",
            hook->head_name ?: "unknown", head, first, hook->replacement);
    return 0;
}

/* Unlink our node; the words it writes live in memory only ksu_patch_text() may touch. */
static int ksu_lsm_hook_remove_head(struct ksu_lsm_hook *hook)
{
    struct hlist_node **pprev = hook->list.list.pprev;
    struct hlist_node *next = READ_ONCE(hook->list.list.next);
    int ret;

    if (!pprev || READ_ONCE(*pprev) != &hook->list.list) {
        pr_err("lsm_hook: %s: back pointer %px does not point at our node - refusing to unlink\n",
                hook->head_name ?: "unknown", pprev);
        return -EINVAL;
    }

    ret = ksu_lsm_hook_patch_slot((void **)pprev, next);
    if (ret)
        return ret;

    /* 2. the successor's back pointer: not needed for the walk, but a later removal of
     *    THAT node must not write through a pointer into this module's memory. */
    if (next) {
        ret = ksu_lsm_hook_patch_slot((void **)&next->pprev, pprev);
        if (ret) {
            /* Our node is already out; re-link rather than leave a stale back pointer. */
            if (ksu_lsm_hook_patch_slot((void **)pprev, &hook->list.list))
                pr_err("lsm_hook: %s: failed to re-link our node after a failed unlink\n",
                        hook->head_name ?: "unknown");
            return ret;
        }
    }

    /* ->next is deliberately left set: hlist removal does not clear it either, and the dispatch
     * loop reads pos->next AFTER the callee returns - a NULL here ends the walk early. */
    hook->list.list.pprev = NULL;
    hook->entry = NULL;
    SUSFS_LOGI("lsm_hook: removed %s node from its list\n", hook->head_name ?: "unknown");
    return 0;
}
#endif /* < 6.12 */

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
/* The kernel's own __static_call_update(), resolved by name at load and called through a __nocfi
 * wrapper like every other resolved-address call in this module.
 *
 * Why not the compile-time one: linux/static_call.h defines __static_call_update() as a
 * `static __always_inline` unless the kernel was built with CONFIG_HAVE_STATIC_CALL_INLINE, and
 * the trees this module is compiled against all take the inline arm.  With the inline arm the
 * call SITE has to be patched (arch_static_call_transform()), and the generic
 * `WRITE_ONCE(key->func, func)` only changes what a trampoline reads - so on a kernel that has
 * the inline arm the takeover would silently not take effect.  Resolving the symbol means using
 * the very implementation the running kernel registers its own hooks with, on any config;
 * lsm_static_call_init() itself calls it as __static_call_update(scall->key, scall->trampoline,
 * hl->hook.lsm_func_addr), i.e. with exactly the two values this wrapper passes on.  When the
 * kernel has no such symbol (every tree this module currently builds against:
 * CONFIG_HAVE_STATIC_CALL(_INLINE) unset, so it is an inline) the compile-time call is the same
 * thing and stays the fallback.  Either way the module looks the name up itself, like
 * static_calls_table and every other by-name symbol - nothing new for the loader. */
static void (*ksu_static_call_update_fn)(struct static_call_key *key, void *tramp, void *func);

static __nocfi void ksu_lsm_call_scall_update(struct static_call_key *key, void *tramp, void *func)
{
    ksu_static_call_update_fn(key, tramp, func);
}

static int ksu_lsm_hook_update_scall(struct lsm_static_call *scall, void *value)
{
    if (ksu_static_call_update_fn) {
        ksu_lsm_call_scall_update(scall->key, scall->trampoline, value);
        smp_wmb();
        return READ_ONCE(scall->key->func) == value ? 0 : -EIO;
    }

    __static_call_update(scall->key, scall->trampoline, value);
    smp_wmb();
    if (READ_ONCE(scall->key->func) != value)
        return -EIO;
    return 0;
}

/* ---- insertion on >= 6.12: taking over SELinux's static-call slot ----------------
 *
 * 6.12 replaced the hlist dispatch with one static call per (hook, LSM slot), so there
 * is no list left to insert into: struct security_hook_list (include/linux/lsm_hooks.h)
 * lost its hlist node and its `lsm` field, and each (hook, LSM slot) is now a
 *   struct lsm_static_call { struct static_call_key *key; void *trampoline; struct
 *                            security_hook_list *hl; struct static_key_false *active; }
 * inside `extern struct lsm_static_calls_table static_calls_table __ro_after_init`.
 * security/security.c dispatches with
 *   if (static_branch_unlikely(&SECURITY_HOOK_ACTIVE_KEY(HOOK, NUM)))
 *       R = static_call(LSM_STATIC_CALL(HOOK, NUM))(...);
 * and lsm_static_call_init() filled each slot at boot: it walked hl->scalls, took the
 * first slot with !scall->hl, ran __static_call_update(scall->key, scall->trampoline,
 * hl->hook.lsm_func_addr), set scall->hl and enabled THAT slot's static key.
 *
 * An unregistered LSM cannot get a slot of its own (that needs static-key work this module
 * has no business doing), but it CAN take over a live one, and SELinux's is the right one:
 * its static key is already enabled, and it holds its documented position in the order, so
 * an earlier slot (capabilities) still runs first and later ones (safesetid, landlock,
 * bpf-lsm) still run whenever the hook's default is returned.  The displaced function is
 * called from the replacement (hook->original via SUS_LSM_PASS_ORIG()), so nothing SELinux
 * decided is lost - including the -ECHILD inode_permission's RCU walk depends on.  The only
 * symbol needed is static_calls_table; the switch itself goes through
 * ksu_lsm_hook_update_scall() above, i.e. the kernel's own __static_call_update() whenever
 * the running kernel has it as a symbol.
 *
 * NOTHING IS WRITTEN until the slot passes all five validations below: the failure this must
 * not have is a jump target that is wrong rather than absent.  Every read uses
 * copy_from_kernel_nofault() - a bogus pointer cannot fault the check that exists to catch
 * it - and failing any of them returns without patching, so the hook is simply not armed
 * (-ENOSYS for every insert on this branch before the change) and an unknown layout costs
 * coverage, never a corrupted jump target:
 *   1. key/hl/trampoline are readable, key and hl are plausible kernel addresses, trampoline is
 *      NULL or one.  NULL is NOT a layout problem: security.c's LSM_HOOK_TRAMP() is NULL whenever
 *      the tree lacks CONFIG_HAVE_STATIC_CALL and lsm_static_call_init() hands that same NULL to
 *      __static_call_update() at boot (measured on both DDK trees this branch targets); either arm
 *      ends at key->func, which is what this code reads, saves and replaces;
 *   2. hl->scalls == &static_calls_table.<member>[0]: the entry is registered for THIS hook,
 *      which validates head_offset against the kernel's real layout - a RANDSTRUCT kernel
 *      (or any table whose member order moved) makes the two disagree;
 *   3. hl->lsmid->name reads as "selinux" - only SELinux's slot is ever taken;
 *   4. the slot's current target (key->func, what the dispatch calls) equals the entry's own
 *      hook word (hl + hook_offset): two places lsm_static_call_init() filled from one value;
 *   5. that target really is THIS hook's SELinux implementation: named through kallsyms as
 *      "selinux_<member>" (clone suffix allowed), exact match against the name-resolved symbol as
 *      fallback - the check offsetof() cannot do, a reordered table's slot having a different prototype.
 */
#define KSU_LSM_SLOTS_PER_HOOK	MAX_LSM_COUNT

/* arm64 kernel addresses (image, modules, vmalloc) all live in the top of the address space.
 * The bound is loose on purpose: it only has to reject NULL, a small integer, a user address. */
#define KSU_LSM_KPTR_MIN	0xff00000000000000UL

static unsigned long ksu_lsm_scalls_addr;

static bool ksu_lsm_kptr_plausible(const void *p)
{
    return (unsigned long)p >= KSU_LSM_KPTR_MIN;
}

/* Read one pointer-sized word without faulting.  @out is `void *`, not `void **`: callers
 * pass the address of a TYPED pointer and -Wincompatible-pointer-types is an error here. */
static int ksu_lsm_read_ptr(const void *addr, void *out)
{
    memset(out, 0, sizeof(void *));
    return (int)copy_from_kernel_nofault(out, addr, sizeof(void *));
}

/* Same implementation as @want?  Allows the ".clone"/".constprop.0" suffix a compiler adds. */
static bool ksu_lsm_name_is(const char *name, const char *want)
{
    size_t n = strlen(want);

    if (strncmp(name, want, n) != 0)
        return false;

    return name[n] == '\0' || name[n] == '.';
}

/* Is @fn the SELinux implementation of @member?  0 yes, negative no/unknown.
 *
 * Three sources of evidence, strongest first:
 *   1. the kallsyms name is exactly selinux_<member>, clone suffixes allowed
 *      (.cold/.isra/.constprop/.llvm.N) - what a stock kernel registers;
 *   2. the kallsyms name CONTAINS <member>: an OEM wrapper around selinux_<member>, a
 *      vendor-prefixed symbol, or an LTO renaming that does not begin with the base name.
 *      This is the relaxation a vendor device needs - issue #1 (6.12.23-android16) refuses to
 *      load with "holds ... which is not selinux_inode_getattr", and upstream's
 *      lsm_hook_defs.h / lsm_hooks.h / selinux/hooks.c are byte-identical between v6.12.23 and
 *      the v6.12 DDK this module is built from, so that device registers something other than
 *      the stock symbol for this hook.  It does NOT cost the shifted-layout guard: no OTHER
 *      hook name CONTAINS <member> in any hook list this module builds against (234 hooks on
 *      5.10, 238/5.15, 243/6.1, 249/6.6, 268/6.12, 273/6.18 - checked pairwise), so a slot
 *      that belongs to a different hook still cannot match this;
 *   3. the address equals the resolved selinux_<member> (@expect), used when the kallsyms name
 *      could not be read at all.
 *
 * A module-owned function is refused before either name test: the static-call table lives in
 * core (security/security.c) and an LSM registered in it cannot come from a module, so a
 * modname here is a resolution error rather than a renamed hook.
 *
 * Both the accept-by-relaxation and every rejection name the function that was actually
 * found: the caller's message prints only the expected name, which is the one fact a field
 * report cannot supply (issue #1).
 */
static int ksu_lsm_fn_is_selinux_hook(void *fn, const char *member, void *expect)
{
    char buf[KSYM_SYMBOL_LEN];
    char want[64];
    char *mod = NULL;
    int len;

    snprintf(want, sizeof(want), "selinux_%s", member);

    len = ksu_symbol_name_of((unsigned long)fn, buf, &mod);
    if (len > 0) {
        if (!mod && ksu_lsm_name_is(buf, want))
            return 0;
        if (!mod && strstr(buf, member)) {
            pr_warn("lsm_hook: %s: %px is not %s but its name contains it (%s) - accepting\n",
                    member, fn, want, buf);
            return 0;
        }
        if (mod)
            pr_warn("lsm_hook: %s: %px resolves to %s [%s], which is neither %s nor contains \"%s\"\n",
                    member, fn, buf, mod, want, member);
        else
            pr_warn("lsm_hook: %s: %px resolves to %s, which is neither %s nor contains \"%s\"\n",
                    member, fn, buf, want, member);
        return -EINVAL;
    }

    if (expect)
        return (fn == expect) ? 0 : -EINVAL;

    return -ENOSYS;
}

/* ---- locating this hook's slot in static_calls_table, on a kernel we did not build against
 *
 * offsetof(struct lsm_static_calls_table, <member>) is only the right slot when the kernel's
 * hook order AND its MAX_LSM_COUNT match the tree this module was compiled against.  Measured
 * on 6.12.23-android16-4k they do not: MAX_LSM_COUNT is 3 there (its per-hook static call keys
 * are named ..._0/_1/_2) and 5 in the DDK tree, so every offset is 5/3 too large and lands on a
 * LATER hook's array.  That array's SELinux entry passes every structural check - its `scalls`
 * points back at the array being read, its lsmid is SELinux's, and `key->func` equals the
 * entry's hook word, which is the SAME word for all 13 hooks because `hook` is a union and
 * every member sits at offset 0.  Only the function the kernel registered can tell them apart.
 *
 * So the slot is found by identity: resolve the addresses kallsyms has for `selinux_<member>`
 * once, then scan the table for the element whose SELinux entry holds one of them.  Bounded by
 * the table's own neighbour in .data (lsm_active_cnt) and, failing that, by a hard cap; nothing
 * matched means refuse, exactly as before. */
#define KSU_LSM_SCAN_MAX	(64 * 1024)

static unsigned long ksu_lsm_scan_end;	/* 0 = not resolved yet, ~0UL = no neighbour available */

static unsigned long ksu_lsm_scalls_end(void)
{
    unsigned long next;

    if (!ksu_lsm_scan_end) {
        next = find_kernel_symbol_exact("lsm_active_cnt");
        ksu_lsm_scan_end = (next > ksu_lsm_scalls_addr &&
                            next - ksu_lsm_scalls_addr < KSU_LSM_SCAN_MAX) ? next : ~0UL;
    }

    return ksu_lsm_scan_end == ~0UL ? ksu_lsm_scalls_addr + KSU_LSM_SCAN_MAX : ksu_lsm_scan_end;
}

/* Is @s an occupied static-call slot whose SELinux entry is worth looking at?
 *
 * Scan-friendly on purpose: anything that does not look like a slot is skipped rather than
 * reported, because the scan walks elements the previous code never touched.  Returns 0 with
 * *hl_out == NULL for "not this one", and fills *hl_out / *cur_out when it is a SELinux slot.
 * Nothing here identifies the HOOK - that is the caller's address test. */
static void ksu_lsm_slot_selinux(struct lsm_static_call *s, struct ksu_lsm_hook *hook,
                                 struct security_hook_list **hl_out, void **cur_out)
{
    unsigned long end = ksu_lsm_scalls_end();
    struct security_hook_list *hl;
    void *key, *tramp, *scalls, *lsmid, *namep, *hookfn, *cur;
    char namebuf[16];

    *hl_out = NULL;
    *cur_out = NULL;

    if (ksu_lsm_read_ptr(&s->key, &key) || ksu_lsm_read_ptr(&s->trampoline, &tramp) ||
        ksu_lsm_read_ptr(&s->hl, &hl))
        return;
    if (!key || !hl)
        return;			/* empty: no LSM implements this hook in this slot */
    if (!ksu_lsm_kptr_plausible(key) || !ksu_lsm_kptr_plausible(hl) ||
        (tramp && !ksu_lsm_kptr_plausible(tramp)))
        return;

    if (ksu_lsm_read_ptr((const char *)hl + offsetof(struct security_hook_list, scalls), &scalls))
        return;
    if ((unsigned long)scalls < ksu_lsm_scalls_addr || (unsigned long)scalls >= end ||
        ((unsigned long)scalls & (sizeof(void *) - 1)))
        return;			/* not an array inside the table: not a slot we can reason about */

    if (ksu_lsm_read_ptr((const char *)hl + offsetof(struct security_hook_list, lsmid), &lsmid) ||
        !ksu_lsm_kptr_plausible(lsmid) ||
        ksu_lsm_read_ptr((const char *)lsmid + offsetof(struct lsm_id, name), &namep) ||
        !ksu_lsm_kptr_plausible(namep) ||
        copy_from_kernel_nofault(namebuf, namep, 8))
        return;
    namebuf[8] = '\0';
    if (strncmp(namebuf, "selinux", 8) != 0)
        return;			/* capability, safesetid, landlock, bpf-lsm, ... */

    if (ksu_lsm_read_ptr((const char *)key + offsetof(struct static_call_key, func), &cur) ||
        ksu_lsm_read_ptr((const char *)hl + hook->hook_offset, &hookfn) ||
        !cur || !hookfn || cur != hookfn)
        return;			/* mid-update, or not the shape of a static call */

    *hl_out = hl;
    *cur_out = cur;
}

/* Scan the table for the slot whose SELinux entry registered one of @addrs. */
static void ksu_lsm_scan_slot(struct ksu_lsm_hook *hook, const unsigned long *addrs, int n_addrs,
                              struct lsm_static_call **chosen_out,
                              struct security_hook_list **hl_out, void **orig_out,
                              unsigned long *scanned_out)
{
    unsigned long end = ksu_lsm_scalls_end();
    unsigned long p;
    int i;

    *chosen_out = NULL;
    *hl_out = NULL;
    *orig_out = NULL;
    *scanned_out = 0;

    for (p = ksu_lsm_scalls_addr; p + sizeof(struct lsm_static_call) <= end;
         p += sizeof(struct lsm_static_call)) {
        struct security_hook_list *hl;
        void *cur;

        (*scanned_out)++;
        ksu_lsm_slot_selinux((struct lsm_static_call *)p, hook, &hl, &cur);
        if (!hl)
            continue;

        for (i = 0; i < n_addrs; i++) {
            if (cur != (void *)addrs[i])
                continue;
            *chosen_out = (struct lsm_static_call *)p;
            *hl_out = hl;
            *orig_out = cur;
            return;
        }
    }
}

/* Lock held; success sets ->scall/->entry/->original and the static call to the replacement. */
static int ksu_lsm_hook_insert_scall(struct ksu_lsm_hook *hook)
{
    struct lsm_static_call *slots;
    struct lsm_static_call *chosen = NULL;
    struct security_hook_list *chosen_hl = NULL;
    void *chosen_orig = NULL;
    unsigned long addrs[8];
    unsigned long scanned = 0;
    void *expect = NULL;
    char want[64];
    int i, n_addrs, ret;

    if (!hook->head_name) {
        pr_err("lsm_hook: insert: hook has no head_name, cannot identify its static calls\n");
        return -EINVAL;
    }

    if (!ksu_lsm_scalls_addr) {
        ksu_lsm_scalls_addr = find_kernel_symbol_exact("static_calls_table");
        if (!ksu_lsm_scalls_addr) {
            pr_err("lsm_hook: insert: static_calls_table not resolved\n");
            return -ENOENT;
        }
        SUSFS_LOGI("lsm_hook: static_calls_table at %px (%d slots per hook)\n",
                (void *)ksu_lsm_scalls_addr, (int)KSU_LSM_SLOTS_PER_HOOK);
    }

    snprintf(want, sizeof(want), "selinux_%s", hook->head_name);
    expect = ksu_resolve_symbol_for_functable_hook(want);

    /* What the kernel registered is what identifies the slot, so resolve the addresses kallsyms
     * has for `selinux_<member>` (normally one) and scan the table for it. */
    n_addrs = ksu_find_symbol_all(want, addrs, (int)ARRAY_SIZE(addrs));
    if (n_addrs == 0 && expect) {
        addrs[0] = (unsigned long)expect;
        n_addrs = 1;
    }

    if (n_addrs) {
        ksu_lsm_scan_slot(hook, addrs, n_addrs, &chosen, &chosen_hl, &chosen_orig, &scanned);
        if (chosen) {
            unsigned long idx = (unsigned long)(chosen -
                                  (struct lsm_static_call *)ksu_lsm_scalls_addr);
            unsigned long off = hook->head_offset / sizeof(struct lsm_static_call);

            if (idx != off) {
                pr_warn("lsm_hook: %s: its slot is element %lu of static_calls_table while offsetof() names %lu - this kernel's MAX_LSM_COUNT or hook order differs from the tree this module was built against (%d slots per hook assumed)\n",
                        hook->head_name, idx, off, (int)KSU_LSM_SLOTS_PER_HOOK);
            }
            SUSFS_LOGI("lsm_hook: %s: slot found by identity at element %lu (%d address(es) named %s, %lu elements scanned)\n",
                    hook->head_name, idx, n_addrs, want, scanned);
        }
    }

    /* Fallback, only when nothing was found by identity: the slot the build-time offset names,
     * judged by the NAME of the function in it.  That is what this module always did, and it
     * keeps the case a name-based test can accept working (a vendor wrapper whose name merely
     * contains the member).  It fails closed: an offset that lands on another hook is refused
     * by the identity test inside the loop. */
    slots = (struct lsm_static_call *)(ksu_lsm_scalls_addr + hook->head_offset);

    for (i = 0; !chosen && i < KSU_LSM_SLOTS_PER_HOOK; i++) {
        struct lsm_static_call *s = &slots[i];
        struct security_hook_list *hl;
        void *key, *tramp, *scalls, *lsmid, *namep, *hookfn, *cur;
        char namebuf[16];

        if (ksu_lsm_read_ptr(&s->key, &key) ||
            ksu_lsm_read_ptr(&s->trampoline, &tramp) ||
            ksu_lsm_read_ptr(&s->hl, &hl)) {
            pr_err("lsm_hook: insert: %s: slot %d of static_calls_table is not readable - refusing\n",
                    hook->head_name, i);
            return -EFAULT;
        }
        if (!hl)
            continue;	/* empty slot: no LSM implements this hook there */

        if (!key || !ksu_lsm_kptr_plausible(key) || !ksu_lsm_kptr_plausible(hl) ||
            (tramp && !ksu_lsm_kptr_plausible(tramp))) {
            pr_err("lsm_hook: insert: %s: slot %d has implausible key/trampoline/hl (%px/%px/%px) - struct lsm_static_call layout mismatch, refusing\n",
                    hook->head_name, i, key, tramp, hl);
            return -EINVAL;
        }

        if (ksu_lsm_read_ptr((const char *)hl + offsetof(struct security_hook_list, scalls), &scalls) ||
            scalls != (void *)slots) {
            pr_err("lsm_hook: insert: %s: slot %d entry %px reports scalls %px, expected %px - struct/table layout mismatch, refusing\n",
                    hook->head_name, i, hl, scalls, slots);
            return -EINVAL;
        }

        if (ksu_lsm_read_ptr((const char *)hl + offsetof(struct security_hook_list, lsmid), &lsmid) ||
            !ksu_lsm_kptr_plausible(lsmid) ||
            ksu_lsm_read_ptr((const char *)lsmid + offsetof(struct lsm_id, name), &namep) ||
            !ksu_lsm_kptr_plausible(namep) ||
            copy_from_kernel_nofault(namebuf, namep, 8)) {
            pr_err("lsm_hook: insert: %s: slot %d entry %px has no readable lsm_id name - refusing\n",
                    hook->head_name, i, hl);
            return -EINVAL;
        }
        namebuf[8] = '\0';
        if (strncmp(namebuf, "selinux", 8) != 0)
            continue;	/* capabilities, safesetid, landlock, bpf-lsm, ... */

        if (ksu_lsm_read_ptr((const char *)key + offsetof(struct static_call_key, func), &cur) ||
            ksu_lsm_read_ptr((const char *)hl + hook->hook_offset, &hookfn) ||
            !cur || !hookfn) {
            pr_err("lsm_hook: insert: %s: slot %d (selinux) has no readable current target - refusing\n",
                    hook->head_name, i);
            return -EINVAL;
        }
        if (cur != hookfn) {
            pr_err("lsm_hook: insert: %s: slot %d (selinux) calls %px while the entry's hook word holds %px - layout mismatch, refusing\n",
                    hook->head_name, i, cur, hookfn);
            return -EINVAL;
        }

        ret = ksu_lsm_fn_is_selinux_hook(cur, hook->head_name, expect);
        if (ret) {
            pr_err("lsm_hook: insert: %s: slot %d (selinux) holds %px, which is not %s (%d) - another owner or a shifted layout, refusing\n",
                    hook->head_name, i, cur, want, ret);
            return ret == -ENOSYS ? -ENOSYS : -EINVAL;
        }

        chosen = s;
        chosen_hl = hl;
        chosen_orig = cur;
        break;
    }

    if (!chosen) {
        pr_err("lsm_hook: insert: %s: no slot for it among the %lu scanned elements of static_calls_table, and the element offsetof() names (%lu) is not it either (%d address(es) named %s) - refusing\n",
                hook->head_name, scanned,
                (unsigned long)(hook->head_offset / sizeof(struct lsm_static_call)),
                n_addrs, want);
        return -ENOENT;
    }

    for (i = 0; i < ksu_lsm_hook_count; i++) {
        if (ksu_lsm_hook_entries[i].hook->scall == chosen) {
            pr_err("lsm_hook: insert: %s: that static-call slot is already taken over by %s\n",
                    hook->head_name, ksu_lsm_hook_entries[i].hook->head_name ?: "another hook");
            return -EALREADY;
        }
    }

    ret = ksu_lsm_hook_track(hook);
    if (ret) {
        pr_err("lsm_hook: too many hooks to track: %d\n", ret);
        return ret;
    }

    /* Publish in this order on purpose: the replacement reads hook->original on its
     * pass-through path, so it must become visible BEFORE the static call can reach it - a call in
     * between would see original == NULL and drop SELinux's decision.  The fence is needed on arm64
     * (static_call_update is a plain WRITE_ONCE of key->func, and the smp_wmb() inside
     * ksu_lsm_hook_update_scall() comes after that store); SUS_LSM_PASS_ORIG() has the matching
     * smp_rmb(), without which the reader can still load original before the key->func load. */
    hook->scall = chosen;
    hook->entry = chosen_hl;
    hook->original = chosen_orig;
    smp_wmb();
    ret = ksu_lsm_hook_update_scall(chosen, hook->replacement);
    if (ret) {
        /* Keep the attempted publication tracked. Init rollback must restore
         * and drain it even if verification failed after a callback entered. */
        pr_err("lsm_hook: %s static-call installation failed verification (%d)\n",
               hook->head_name, ret);
        return ret;
    }

    SUSFS_LOGI("lsm_hook: insert via static call slot (selinux, element %lu, %s static call) %s: %px -> %px\n",
            (unsigned long)(chosen - (struct lsm_static_call *)ksu_lsm_scalls_addr),
            chosen->trampoline ? "trampolined" : "key->func",
            hook->head_name, chosen_orig, hook->replacement);
    return 0;
}
#endif

int ksu_lsm_hook(struct ksu_lsm_hook *hook)
{
    int ret = 0;
    struct security_hook_list *entry;
    void *target;
    const char *target_name;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
    static unsigned long scalls_addr = 0;
    struct lsm_static_call *scalls = NULL;
    static size_t scalls_count = 0;
    struct security_hook_list *selected_entry = NULL;
    struct lsm_static_call *selected_scall = NULL;
    void **selected_slot = NULL;
    void *selected_origin = NULL;
    size_t i;
#else
    unsigned long heads_addr;
    struct hlist_head *head;
    struct security_hook_list *selected_entry = NULL;
    void **selected_slot = NULL;
    void *selected_origin = NULL;
#endif

    if (!hook || !hook->replacement)
        return -EINVAL;

    mutex_lock(&ksu_lsm_hook_lock);
    if (!hook->lifetime_initialized) {
        atomic_set(&hook->active_callbacks, 0);
        init_waitqueue_head(&hook->callback_waitq);
        hook->lifetime_initialized = true;
    }

    if (hook->entry) {
        ret = -EALREADY;
        goto out_unlock;
    }

    if (hook->insert) {
        /* Insertion resolves no symbol on < 6.12 (no original, no slot to match), and both
         * branches validate everything before their first patched write. */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
        ret = ksu_lsm_hook_insert_scall(hook);
        goto out_unlock;
#else
        heads_addr = find_kernel_symbol_exact("security_hook_heads");
        if (!heads_addr) {
            pr_err("lsm_hook: failed to resolve security_hook_heads\n");
            ret = -ENOENT;
            goto out_unlock;
        }

        ret = ksu_lsm_hook_head_at(heads_addr, hook, &head);
        if (ret)
            goto out_unlock;

        ret = ksu_lsm_hook_track(hook);
        if (ret) {
            pr_err("lsm_hook: too many hooks to track: %d\n", ret);
            goto out_unlock;
        }

        ret = ksu_lsm_hook_insert_head(hook, head);
        if (ret) {
            pr_err("lsm_hook: failed to insert %s at the head of its list: %d\n",
                    hook->head_name ?: "unknown", ret);
            ksu_lsm_hook_untrack(hook);
            goto out_unlock;
        }
        goto out_unlock;
#endif
    }

    /* ---- replace path: find the entry whose function slot holds the resolved symbol. ---- */
    target_name = hook->target_name;
    if (!target_name) {
        pr_err("lsm_hook: hook %s: target_name is required\n", hook->head_name ?: "unknown");
        ret = -EINVAL;
        goto out_unlock;
    }

    target = hook->original;
    if (!target)
        target = ksu_resolve_symbol_for_functable_hook(target_name);
    if (!target) {
        pr_err("lsm_hook: failed to resolve target for %s\n", hook->head_name ?: "unknown");
        ret = -ENOENT;
        goto out_unlock;
    }
    SUSFS_LOGI("target: 0x%lx %pSb\n", (unsigned long)target, target);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
    if (!scalls_addr) {
        scalls_addr = find_kernel_symbol_exact("static_calls_table");
    }
    if (!scalls_addr) {
        pr_err("lsm_hook: failed to resolve static_calls_table\n");
        ret = -ENOSYS;
        goto out_unlock;
    }

    if (scalls_count == 0) {
        /* sym_size is sizeof() and not kallsyms_lookup_size_offset(): that symbol is UNEXPORTED
         * in every GKI tree this module targets, so importing it makes the module unloadable by
         * a plain `insmod` (unknown symbol) - it is the fifth name the "Verify sections" CI step
         * refuses in the .ko's undefined list - and the number is the same either way. */
        unsigned long sym_size = sizeof(struct lsm_static_calls_table);
        unsigned long addr = find_kernel_symbol_exact("lsm_active_cnt");

        /* The STRIDE is the compile-time MAX_LSM_COUNT the table is dimensioned with, NOT the
         * runtime number of active LSMs: lsm_active_cnt counts the enabled SECURITY_ options
         * (plus BPF_LSM etc.) and says nothing about how many slots each hook has.  Using it as
         * the stride picked the wrong struct lsm_static_call whenever the two differ, i.e.
         * patched a function pointer into another hook's slot (kCFI panic at the next call). */
        if (addr)
            SUSFS_LOGI("lsm_active_cnt = %d (only informational; the table stride is %d)\n",
                    (int)*(u32 *)addr, (int)KSU_LSM_SLOTS_PER_HOOK);

        if (sym_size % (KSU_LSM_SLOTS_PER_HOOK * sizeof(struct lsm_static_call)) != 0) {
            pr_warn("lsm_hook: static_calls_table is %lu bytes, not a whole number of %d-slot hooks\n",
                    sym_size, (int)KSU_LSM_SLOTS_PER_HOOK);
        }
        scalls_count = sym_size / sizeof(struct lsm_static_call);
        SUSFS_LOGI("scalls_count = %zu\n", scalls_count);
    }

    if (scalls_count == 0) {
        pr_err("no scalls_count found!\n");
        ret = -ENOSYS;
        goto out_unlock;
    }

    scalls = (struct lsm_static_call *)scalls_addr;
    for (i = 0; i < scalls_count; i++) {
        struct lsm_static_call *scall = &scalls[i];
        void **slot;
        void *current_origin;

        entry = READ_ONCE(scall->hl);
        if (!entry)
            continue;

        slot = (void **)((char *)entry + hook->hook_offset);
        current_origin = READ_ONCE(*slot);

        int j;
        for (j = 0; j < ksu_lsm_hook_count; j++) {
            if (ksu_lsm_hook_entries[j].hook->replacement == current_origin) {
                current_origin = ksu_lsm_hook_entries[j].hook->original;
                break;
            }
        }

        if (current_origin == hook->replacement) {
            ret = -EALREADY;
            goto out_unlock;
        }

        if (current_origin != target) {
            continue;
        }

        SUSFS_LOGI("found slot %ld orig %pSb\n", i, current_origin);

        if (!hook->offset) {
            selected_entry = entry;
            selected_scall = scall;
            selected_slot = slot;
            selected_origin = current_origin;
        } else {
            size_t hook_idx = (i / KSU_LSM_SLOTS_PER_HOOK + hook->offset) * KSU_LSM_SLOTS_PER_HOOK;
            if (hook_idx >= scalls_count) {
                pr_err("last lsm hook reached\n");
                ret = -EINVAL;
                goto out_unlock;
            }
            scall = &scalls[hook_idx];
            entry = READ_ONCE(scall->hl);
            if (entry) {
                slot = (void **)((char *)entry + hook->hook_offset);
                current_origin = READ_ONCE(*slot);
            } else {
                current_origin = NULL;
            }
            SUSFS_LOGI("found real slot %ld orig %pSb\n", i, current_origin);

            if (current_origin == hook->replacement) {
                ret = -EALREADY;
                goto out_unlock;
            }
            selected_entry = entry;
            selected_scall = scall;
            selected_slot = slot;
            selected_origin = current_origin;
        }
        break;
    }

    if (!selected_scall) {
        pr_err("lsm_hook: target %s not found in head %s\n", target_name, hook->head_name ?: "unknown");
        ret = -ENOENT;
        goto out_unlock;
    }

    ret = ksu_lsm_hook_track(hook);
    if (ret) {
        pr_err("lsm_hook: too many hooks to track: %d\n", ret);
        goto out_unlock;
    }

    if (ksu_lsm_hook_patch_slot(selected_slot, hook->replacement)) {
        pr_err("lsm_hook: failed to patch %s\n", hook->head_name ?: "unknown");
        ret = -EFAULT;
        goto out_untrack;
    }

    /* Publish BEFORE the switch, exactly like the insert path: the replacement reads
     * hook->original on its pass-through path, so a call arriving between the static-call
     * update and this store would see NULL and fall through to `return 0` - dropping
     * SELinux's decision (fail-open).  smp_wmb() pairs with the smp_rmb() in
     * SUS_LSM_PASS_ORIG(). */
    hook->entry = selected_entry;
    hook->scall = selected_scall;
    hook->original = selected_origin;
    smp_wmb();

    if (ksu_lsm_hook_update_scall(selected_scall, hook->replacement)) {
        /* Undo the publication as well: the replacement must not look armed, or a later
         * unhook would try to restore a static call that was never switched. */
        hook->entry = NULL;
        hook->scall = NULL;
        hook->original = NULL;
        if (ksu_lsm_hook_patch_slot(selected_slot, selected_origin)) {
            pr_err("lsm_hook: failed to roll back %s after static call update failure\n", hook->head_name ?: "unknown");
        }
        ret = -EFAULT;
        goto out_untrack;
    }

    if (!selected_origin)
        static_branch_enable(selected_scall->active);

    SUSFS_LOGI("lsm_hook: patched %s hook slot %px from %px to %px\n", hook->head_name ?: "unknown", selected_slot,
            selected_origin, hook->replacement);
#else
    heads_addr = find_kernel_symbol_exact("security_hook_heads");
    if (!heads_addr) {
        pr_err("lsm_hook: failed to resolve security_hook_heads\n");
        ret = -ENOENT;
        goto out_unlock;
    }
    unsigned long heads_size = sizeof(struct security_hook_heads);
    /* heads_size is sizeof(), not kallsyms_lookup_size_offset(), which is UNEXPORTED in every
     * GKI tree this module targets - see the same call site in the >= 6.12 branch. */

    head = (struct hlist_head *)heads_addr;
    struct hlist_head *head_end = (struct hlist_head *)(heads_addr + heads_size);
    SUSFS_LOGI("heads_addr 0x%lx head_offset 0x%lx heads_size %ld hook_offset 0x%lx\n", (unsigned long)heads_addr,
            hook->head_offset, heads_size, hook->hook_offset);

    for (; head < head_end; head++) {
        hlist_for_each_entry (entry, head, list) {
            void **slot = (void **)((char *)entry + hook->hook_offset);
            void *current_origin = READ_ONCE(*slot);
            int j;
            for (j = 0; j < ksu_lsm_hook_count; j++) {
                if (ksu_lsm_hook_entries[j].hook->replacement == current_origin) {
                    current_origin = ksu_lsm_hook_entries[j].hook->original;
                    break;
                }
            }
            if (current_origin == hook->replacement) {
                ret = -EALREADY;
                goto out_unlock;
            }
            if (current_origin == target) {
                SUSFS_LOGI("found %s (target %s) at head offset %ld (provided %ld)\n", hook->head_name, hook->target_name,
                        (unsigned long)head - heads_addr, hook->head_offset);
                selected_entry = entry;
                selected_slot = slot;
                selected_origin = current_origin;
                break;
            }
        }
        if (selected_entry) {
            if (hook->offset) {
                head += hook->offset;
                if (head < (struct hlist_head *)heads_addr || head >= head_end) {
                    pr_err("invalid offset\n");
                    ret = -EINVAL;
                    goto out_unlock;
                }
                hlist_for_each_entry (entry, head, list) {
                    void **slot = (void **)((char *)entry + hook->hook_offset);
                    void *current_origin = READ_ONCE(*slot);
                    if (current_origin == hook->replacement) {
                        ret = -EALREADY;
                        goto out_unlock;
                    }
                }
                if (head->first) {
                    selected_entry = hlist_entry(head->first, struct security_hook_list, list);
                    selected_slot = (void **)((char *)selected_entry + hook->hook_offset);
                    selected_origin = *selected_slot;
                } else {
                    selected_entry = &hook->list;
                    hook->list.head = head;
                    hook->list.list.next = NULL;
                    hook->list.list.pprev = &head->first;
                    hook->list.lsm = "ksu";
                    *(void **)((char *)selected_entry + hook->hook_offset) = hook->replacement;
                    selected_slot = (void **)&head->first;
                    selected_origin = NULL;
                }
            }
            break;
        }
    }

    if (!selected_entry) {
        pr_err("lsm_hook: target %s not found in head %s\n", target_name, hook->head_name ?: "unknown");
        ret = -ENOENT;
        goto out_unlock;
    }

    ret = ksu_lsm_hook_track(hook);
    if (ret) {
        pr_err("lsm_hook: too many hooks to track: %d\n", ret);
        goto out_unlock;
    }

    if (selected_origin) {
        SUSFS_LOGI("patch func addr\n");
        ret = ksu_lsm_hook_patch_slot(selected_slot, hook->replacement);
    } else {
        SUSFS_LOGI("patch head->first\n");
        ret = ksu_lsm_hook_patch_slot(selected_slot, &hook->list);
    }

    if (ret) {
        pr_err("lsm_hook: failed to patch %s\n", hook->head_name ?: "unknown");
        ret = -EFAULT;
        goto out_untrack;
    }

    hook->entry = selected_entry;
    hook->original = selected_origin;
    SUSFS_LOGI("lsm_hook: patched %s hook slot %px from %px to %px\n", hook->head_name ?: "unknown", selected_slot,
            selected_origin, hook->replacement);
#endif
    goto out_unlock;
out_untrack:
    ksu_lsm_hook_untrack(hook);

out_unlock:
    mutex_unlock(&ksu_lsm_hook_lock);
    return ret;
}

void ksu_lsm_unhook(struct ksu_lsm_hook *hook)
{
    void **slot;
    mutex_lock(&ksu_lsm_hook_lock);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
    if (!hook->entry || !hook->scall) {
        mutex_unlock(&ksu_lsm_hook_lock);
        return;
    }
    if (hook->insert) {
        int restore_ret;

        /* Symmetric with ksu_lsm_hook_insert_scall(): the takeover only replaced the
         * static call, and the entry's own hook word still holds the original.
         *
         * Module exit cannot report failure back to delete_module().  Returning from
         * here with the slot still pointing at module text would therefore turn a
         * restoration error into a guaranteed use-after-free.  Keep the module exit
         * pinned in this function and retry until read-back proves the slot no longer
         * targets SUSFS.  A broken restore may make rmmod hang, but it cannot free live
         * callback text. */
        do {
            void *current_target = READ_ONCE(hook->scall->key->func);

            if (current_target == hook->original) {
                restore_ret = 0;
            } else if (current_target != hook->replacement) {
                /* A foreign hook may still chain through our callback. Do
                 * not overwrite it or let init/exit free reachable text. */
                restore_ret = -EBUSY;
            } else {
                restore_ret = ksu_lsm_hook_update_scall(hook->scall, hook->original);
            }
            if (!restore_ret)
                break;
            pr_emerg("lsm_hook: restore verification failed for %s (%d); refusing to let teardown free live LSM text, retrying\n",
                     hook->head_name ?: "unknown", restore_ret);
            mutex_unlock(&ksu_lsm_hook_lock);
            msleep(100);
            mutex_lock(&ksu_lsm_hook_lock);
        } while (1);
        SUSFS_LOGI("lsm_hook: insert static call slot (selinux) for %s restored to %px\n",
                hook->head_name ?: "unknown", hook->original);
    } else {
        slot = (void **)((char *)hook->entry + hook->hook_offset);
        if (ksu_lsm_hook_patch_slot(slot, hook->original)) {
            pr_err("lsm_hook: failed to restore %s\n", hook->head_name ?: "unknown");
            mutex_unlock(&ksu_lsm_hook_lock);
            return;
        }
        if (ksu_lsm_hook_update_scall(hook->scall, hook->original)) {
            if (ksu_lsm_hook_patch_slot(slot, hook->replacement))
                pr_err("lsm_hook: failed to reapply %s after static call restore failure\n", hook->head_name ?: "unknown");
            mutex_unlock(&ksu_lsm_hook_lock);
            return;
        }
        SUSFS_LOGI("lsm_hook: restored %s hook slot %px to %px\n", hook->head_name ?: "unknown", slot, hook->original);
    }
#else
    if (!hook->entry) {
        mutex_unlock(&ksu_lsm_hook_lock);
        return;
    }

    if (hook->entry == &hook->list) {
        /* Our own security_hook_list node is in the list: an insert node, or (legacy) a
         * replace-mode hook that found its head empty; both unlink through list.pprev. */
        if (ksu_lsm_hook_remove_head(hook)) {
            mutex_unlock(&ksu_lsm_hook_lock);
            return;
        }
    } else {
        slot = (void **)((char *)hook->entry + hook->hook_offset);
        SUSFS_LOGI("unhook patch slot\n");
        if (ksu_lsm_hook_patch_slot(slot, hook->original)) {
            pr_err("lsm_hook: failed to restore %s\n", hook->head_name ?: "unknown");
            mutex_unlock(&ksu_lsm_hook_lock);
            return;
        }
        SUSFS_LOGI("lsm_hook: restored %s hook slot %px to %px\n", hook->head_name ?: "unknown", slot, hook->original);
    }
#endif

    ksu_lsm_hook_untrack(hook);
    hook->entry = NULL;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
    hook->scall = NULL;
#endif
    mutex_unlock(&ksu_lsm_hook_lock);

    /* Synchronize after the lock is released: the wait is unbounded, and
     * holding ksu_lsm_hook_lock across it serialises every
     * other hook operation, while the node/slot is already unlinked above and only a task
     * already inside the replacement can still be there. */
    ksu_lsm_hook_drain(hook);
}

int ksu_register_lsm_hook(struct ksu_lsm_hook *hook)
{
    return ksu_lsm_hook(hook);
}

void ksu_unregister_lsm_hook(struct ksu_lsm_hook *hook)
{
    ksu_lsm_unhook(hook);
}

/* Whether the table the hook insertion actually walks can be resolved at all: the < 6.12
 * path inserts into security_hook_heads, the >= 6.12 path into static_calls_table.  The init
 * below only reports; refusing the load is the layer table's call, because only the caller
 * can turn a missing symbol into a failed module load. */
bool ksu_lsm_hook_ready(void)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
    return find_kernel_symbol_exact("static_calls_table") != 0;
#else
    return find_kernel_symbol_exact("security_hook_heads") != 0;
#endif
}

/* No __init/__exit annotation on these two on purpose: the layer table (susfs_main.c) holds their
 * addresses and calls the exit from the rollback path of a FAILED load, i.e. from plain .text. */
void ksu_lsm_hook_init(void)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
    /* The device's own implementation, when it has one as a symbol - see the note on
     * ksu_lsm_hook_update_scall().  NULL is the normal case on the trees this module is built
     * against (the header's static inline is not a symbol) and selects the compiled-in call. */
    ksu_static_call_update_fn = (void *)find_kernel_symbol_exact("__static_call_update");
    SUSFS_LOGI("lsm_hook: static-call switch via %s\n",
            ksu_static_call_update_fn ? "the kernel's __static_call_update() symbol" :
            "the compiled-in __static_call_update() (no such symbol on this kernel)");
#endif
    SUSFS_LOGI("lsm_hook: init, tracked hooks=%d\n", READ_ONCE(ksu_lsm_hook_count));
}

void ksu_lsm_hook_exit(void)
{
    struct ksu_lsm_hook *hooks[ARRAY_SIZE(ksu_lsm_hook_entries)];
    int count;
    int i;

    mutex_lock(&ksu_lsm_hook_lock);
    count = ksu_lsm_hook_count;
    for (i = 0; i < count; i++)
        hooks[i] = ksu_lsm_hook_entries[i].hook;
    mutex_unlock(&ksu_lsm_hook_lock);

    for (i = count - 1; i >= 0; i--)
        ksu_lsm_unhook(hooks[i]);
}
