// SPDX-License-Identifier: GPL-2.0-only
#include <linux/errno.h>
#include <linux/kernel.h>
#include <linux/mutex.h>
#include <linux/rcupdate.h>
#include <linux/sched.h>
#include <linux/wait.h>
#include "susfs_control.h"

static DEFINE_MUTEX(control_lock);
static DECLARE_WAIT_QUEUE_HEAD(control_waitq);
static unsigned int control_active;
static bool control_stopping;

int susfs_control_get(void)
{
    int rc = 0;

    mutex_lock(&control_lock);
    if (control_stopping)
        rc = -ENODEV;
    else
        control_active++;
    mutex_unlock(&control_lock);
    return rc;
}

void susfs_control_put(void)
{
    mutex_lock(&control_lock);
    if (WARN_ON_ONCE(!control_active)) {
        mutex_unlock(&control_lock);
        return;
    }
    if (!--control_active)
        wake_up_all(&control_waitq);
    mutex_unlock(&control_lock);
}

void susfs_control_shutdown(void)
{
    mutex_lock(&control_lock);
    control_stopping = true;
    mutex_unlock(&control_lock);
    wait_event(control_waitq, !READ_ONCE(control_active));
    /* The final put may wake us before its caller has returned to the kernel. */
    synchronize_rcu_tasks();
}
