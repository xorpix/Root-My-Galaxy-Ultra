/* SPDX-License-Identifier: GPL-2.0 */
/* Layouts consumed by the kernel's native fs/readdir.c actors. Keep these
 * checked against that source, including the 32-bit getdents record. */
struct sp_getdents_callback64 {
    struct dir_context ctx;
    struct linux_dirent64 __user *current_dir;
    int prev_reclen;
    int count;
    int error;
};

struct sp_compat_linux_dirent {
    compat_ulong_t d_ino;
    compat_ulong_t d_off;
    unsigned short d_reclen;
    char d_name[];
};

struct sp_compat_getdents_callback {
    struct dir_context ctx;
    struct sp_compat_linux_dirent __user *current_dir;
    int prev_reclen;
    int count;
    int error;
};
