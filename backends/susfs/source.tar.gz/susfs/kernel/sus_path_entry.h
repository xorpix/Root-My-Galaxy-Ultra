/* SPDX-License-Identifier: GPL-2.0 */
/* Samsung Android16/6.12 adaptation of upstream's pre-emission, O_PATH and
 * readlink fixes. Included by sus_path.c so every face uses the same rules.
 * Divert normal function entries through kprobes, as the tested map_files
 * layer does. No syscall-table or inode-operation-table stores are needed.
 * Native VFS still owns lookup, directory locking, file positions, DAC/LSM
 * checks and the actual user-buffer emitter, including both compat ABIs. */

static typeof(&iterate_dir) sp_native_iterate;
static typeof(&getname_flags) sp_getname;
static typeof(&putname) sp_putname;
static int (*sp_lookup)(int, struct filename *, unsigned int,
                        struct path *, struct path *);
static typeof(&security_inode_readlink) sp_security_readlink;
static typeof(&touch_atime) sp_touch_atime;
static typeof(&vfs_readlink) sp_vfs_readlink;
static typeof(&fget) sp_fget;
static typeof(&fput) sp_fput;
static typeof(((struct dir_context *)0)->actor) sp_filldir64, sp_compat_filldir;
static struct kprobe sp_entry_probes[5];
static bool sp_entry_armed[5];
static bool sp_entry_installed;
static atomic_t sp_entry_callbacks = ATOMIC_INIT(0);
#include "ksu_umount_gate.h"	/* susfs_ksu_umount_uid_applies, the full per-caller hide policy */

static DECLARE_WAIT_QUEUE_HEAD(sp_entry_waitq);

#include "sus_path_dirent_abi.h"

static bool sp_dirent_gate(const struct sus_path_entry *e, uid_t caller_uid,
                           bool caller_umounted)
{
    if (e->self_protect)
        return caller_uid != 0;
    if (!READ_ONCE(hide_from_apps))
        return true;
    return e->inode && caller_umounted &&
           caller_uid != e->inode->i_uid.val;
}

struct sp_iterate_guard {
    struct list_head link;
    struct task_struct *task;
};
static LIST_HEAD(sp_iterate_guards);
static DEFINE_SPINLOCK(sp_iterate_guard_lock);

static void sp_entry_leave(void)
{
    smp_mb__before_atomic();
    if (atomic_dec_and_test(&sp_entry_callbacks))
        wake_up_all(&sp_entry_waitq);
}

static bool sp_iterate_bypass(void)
{
    struct sp_iterate_guard *guard;
    unsigned long flags;
    bool found = false;

    spin_lock_irqsave(&sp_iterate_guard_lock, flags);
    list_for_each_entry(guard, &sp_iterate_guards, link) {
        if (guard->task == current) {
            found = true;
            break;
        }
    }
    spin_unlock_irqrestore(&sp_iterate_guard_lock, flags);
    return found;
}

/* Names supplied to an actor are counted bytes, including on FUSE. Match the
 * by-inode layer's (dev, ino) identity; our own control nodes additionally use
 * (filesystem type, ino) across procfs instances in other mount namespaces.
 * Ordinary rules never get that fallback, and names alone are not identity. */
static bool sp_dirent_is_hidden(struct super_block *sb, u64 ino,
                                 const char *name, int namelen, uid_t caller_uid,
                                 bool caller_umounted)
{
    struct sus_path_entry *e;
    bool hidden = false;
    size_t debug_len;

    if (sus_path_is_resolver() || namelen <= 0 || namelen > NAME_MAX)
        return false;
    spin_lock(&sus_path_lock);
    for (e = sus_path_index[sus_path_index_bucket(ino)]; e; e = e->index_next) {
        if (!e->inode || !e->ino || e->ino != ino)
            continue;
        if (e->dev != (u64)sb->s_dev &&
            (!e->self_protect || e->inode->i_sb->s_type != sb->s_type))
            continue;
        if (sp_dirent_gate(e, caller_uid, caller_umounted)) {
            hidden = true;
            break;
        }
    }
    spin_unlock(&sus_path_lock);
    debug_len = strnlen(hide_name, sizeof(hide_name));
    if (!hidden && (!READ_ONCE(hide_from_apps) || caller_umounted) && debug_len == namelen &&
        debug_len && !memcmp(name, hide_name, debug_len))
        hidden = true;
    return hidden;
}

struct sp_dir_context {
    struct dir_context ctx;
    struct dir_context *caller;
    struct super_block *sb;
    uid_t caller_uid;
    bool caller_umounted;
};

static bool sp_dir_emit(struct dir_context *ctx, const char *name, int len,
                         loff_t offset, u64 ino, unsigned int type)
{
    struct sp_dir_context *filter = container_of(ctx, struct sp_dir_context, ctx);
    bool result;

    if (sp_dirent_is_hidden(filter->sb, ino, name, len, filter->caller_uid,
                             filter->caller_umounted)) {
        return true; /* keep walking; no placeholder and no user-buffer write */
    }
    filter->caller->pos = ctx->pos;
    result = filter->caller->actor(filter->caller, name, len, offset, ino, type);
    ctx->pos = filter->caller->pos;
    return result;
}

/* The resolved kernel call is outside the probe callback, in ordinary process
 * context. The guard follows the task across sleep/migration. */
static __nocfi noinline int sp_iterate_original(struct file *file, struct dir_context *ctx)
{
    struct sp_iterate_guard guard;
    unsigned long flags;
    int rc;

    guard.task = current;
    spin_lock_irqsave(&sp_iterate_guard_lock, flags);
    list_add(&guard.link, &sp_iterate_guards);
    spin_unlock_irqrestore(&sp_iterate_guard_lock, flags);
    rc = sp_native_iterate(file, ctx);
    spin_lock_irqsave(&sp_iterate_guard_lock, flags);
    list_del(&guard.link);
    spin_unlock_irqrestore(&sp_iterate_guard_lock, flags);
    return rc;
}

static int sp_iterate_body(struct file *file, struct dir_context *ctx)
{
    struct sp_dir_context filter = {
        .ctx = {.actor = sp_dir_emit, .pos = ctx->pos},
        .caller = ctx,
        .sb = file_inode(file)->i_sb,
        .caller_uid = current_uid().val,
        /* Capture before the filesystem can override current credentials. */
        .caller_umounted = susfs_is_current_proc_umounted_app(),
    };
    int rc;

    rc = sp_iterate_original(file, &filter.ctx);
    ctx->pos = filter.ctx.pos;
    return rc;
}

static int sp_iterate(struct file *file, struct dir_context *ctx)
{
    int rc = sp_iterate_body(file, ctx);
    sp_entry_leave();
    return rc;
}

/* Samsung can inline iterate_dir inside the syscall wrappers, bypassing its
 * out-of-line probe. Enter the filtered iterator explicitly at both reachable
 * syscall bodies; the native actors still perform every user-buffer write.
 *
 * Use the stable fget/fput interface rather than the private fdget_pos return
 * ABI, which changed during 6.12. With our extra reference, fdget_pos's
 * file_needs_f_pos_lock predicate is exactly FMODE_ATOMIC_POS. Lock before
 * iterating and retain the file until after the final cookie write. */
static __nocfi struct file *sp_getdents_file(unsigned int fd)
{
    struct file *file = sp_fget(fd);

    if (file && (file->f_mode & FMODE_ATOMIC_POS))
        mutex_lock(&file->f_pos_lock);
    return file;
}

static __nocfi void sp_getdents_file_put(struct file *file)
{
    if (file->f_mode & FMODE_ATOMIC_POS)
        mutex_unlock(&file->f_pos_lock);
    sp_fput(file);
}

/* The pinned fs/readdir.c return/error/last-cookie sequence. The same wrapper
 * serves native syscall 61 and AArch32 syscall 217 on arm64. */
static long sp_getdents64(const struct pt_regs *regs)
{
    unsigned int count = (unsigned int)regs->regs[2];
    struct sp_getdents_callback64 buf = {
        .ctx.actor = sp_filldir64,
        .current_dir = (struct linux_dirent64 __user *)regs->regs[1],
        .count = count,
    };
    struct file *file;
    int error;

    file = sp_getdents_file((unsigned int)regs->regs[0]);
    if (!file) {
        error = -EBADF;
        goto out;
    }
    error = sp_iterate_body(file, &buf.ctx);
    if (error >= 0)
        error = buf.error;
    if (buf.prev_reclen) {
        struct linux_dirent64 __user *last =
            (void __user *)buf.current_dir - buf.prev_reclen;

        if (put_user(buf.ctx.pos, &last->d_off))
            error = -EFAULT;
        else
            error = count - buf.count;
    }
    sp_getdents_file_put(file);
out:
    sp_entry_leave();
    return error;
}

/* AArch32 syscall 141 has a different record and 32-bit cookie. Let the
 * kernel's compat actor retain its overflow and access-check semantics. */
static long sp_compat_getdents(const struct pt_regs *regs)
{
    unsigned int count = (unsigned int)regs->regs[2];
    struct sp_compat_getdents_callback buf = {
        .ctx.actor = sp_compat_filldir,
        .current_dir = compat_ptr((compat_uptr_t)regs->regs[1]),
        .count = count,
    };
    struct file *file;
    int error;

    file = sp_getdents_file((unsigned int)regs->regs[0]);
    if (!file) {
        error = -EBADF;
        goto out;
    }
    error = sp_iterate_body(file, &buf.ctx);
    if (error >= 0)
        error = buf.error;
    if (buf.prev_reclen) {
        struct sp_compat_linux_dirent __user *last =
            (void __user *)buf.current_dir - buf.prev_reclen;

        if (put_user(buf.ctx.pos, &last->d_off))
            error = -EFAULT;
        else
            error = count - buf.count;
    }
    sp_getdents_file_put(file);
out:
    sp_entry_leave();
    return error;
}

/* do_o_path() reaches vfs_open() before returning/installing a descriptor.
 * Denying the already resolved inode here avoids a second pathname walk and
 * never installs, takes or restores a shared fd-table slot. Failed unopened
 * files retain the normal alloc_empty_file()/fput() cleanup contract. */
static int sp_opath_reject(const struct path *path, struct file *file)
{

    sp_entry_leave();
    return -ENOENT;
}

/* The pinned Android16/6.12 do_readlinkat() sequence, with the path predicate
 * applied to the SAME lookup before the regular-file EINVAL gate. In
 * particular, getname/filename_lookup own the native lookup/error semantics,
 * empty names keep ENOENT, and ESTALE gets the native LOOKUP_REVAL retry. */
static __nocfi noinline int sp_readlink_body(int dfd, const char __user *pathname,
                                            char __user *buf, int bufsiz)
{
    struct path path;
    struct filename *name;
    unsigned int lookup_flags = LOOKUP_EMPTY;
    int error;

    if (bufsiz <= 0)
        return -EINVAL;
retry:
    name = sp_getname(pathname, lookup_flags);
    error = sp_lookup(dfd, name, lookup_flags, &path, NULL);
    if (unlikely(error)) {
        sp_putname(name);
        return error;
    }
    if (sus_path_inode_hidden(d_backing_inode(path.dentry))) {

        error = -ENOENT;
    } else if (d_is_symlink(path.dentry) ||
               d_backing_inode(path.dentry)->i_op->readlink) {
        error = sp_security_readlink(path.dentry);
        if (!error) {
            sp_touch_atime(&path);
            error = sp_vfs_readlink(path.dentry, buf, bufsiz);
        }
    } else {
        error = name->name[0] == '\0' ? -ENOENT : -EINVAL;
    }
    path_put(&path);
    sp_putname(name);
    if (retry_estale(error, lookup_flags)) {
        lookup_flags |= LOOKUP_REVAL;
        goto retry;
    }
    return error;
}

static int sp_readlink(int dfd, const char __user *pathname, char __user *buf, int bufsiz)
{
    int rc = sp_readlink_body(dfd, pathname, buf, bufsiz);
    sp_entry_leave();
    return rc;
}

static int sp_entry_pre(struct kprobe *probe, struct pt_regs *regs)
{
    void *replacement;

    if (!READ_ONCE(sp_entry_installed) || no_extra || sus_path_is_resolver() ||
        (!READ_ONCE(sus_path_count) && !hide_name[0]))
        return 0;
    if (probe == &sp_entry_probes[0]) {
        if (sp_iterate_bypass())
            return 0;
        replacement = sp_iterate;
    } else if (probe == &sp_entry_probes[1]) {
        const struct path *path = (const struct path *)regs->regs[0];
        struct file *file = (struct file *)regs->regs[1];
        if (!(file->f_flags & O_PATH) ||
            !sus_path_inode_hidden(d_backing_inode(path->dentry)))
            return 0;
        replacement = sp_opath_reject;
    } else if (probe == &sp_entry_probes[2]) {
        replacement = sp_readlink;
    } else if (probe == &sp_entry_probes[3]) {
        replacement = sp_getdents64;
    } else if (probe == &sp_entry_probes[4]) {
        replacement = sp_compat_getdents;
    } else {
        return 0;
    }
    atomic_inc(&sp_entry_callbacks);
    smp_mb__after_atomic();
    instruction_pointer_set(regs, (unsigned long)replacement);
    return 1;
}

static_assert(__same_type(typeof(&sp_iterate), typeof(&iterate_dir)));
static_assert(__same_type(typeof(&sp_dir_emit), typeof(((struct dir_context *)0)->actor)));
static_assert(__same_type(typeof(&sp_entry_pre), typeof(((struct kprobe *)0)->pre_handler)));

static void sp_entry_remove(void)
{
    int i;
    WRITE_ONCE(sp_entry_installed, false);
    for (i = ARRAY_SIZE(sp_entry_probes) - 1; i >= 0; i--) {
        if (sp_entry_armed[i]) {
            unregister_kprobe(&sp_entry_probes[i]);
            sp_entry_armed[i] = false;
        }
    }
    synchronize_rcu_tasks();
    wait_event(sp_entry_waitq, atomic_read(&sp_entry_callbacks) == 0);
    synchronize_rcu_tasks();
}

static int sp_entry_install(void)
{
    static const char *const names[] = {
        "iterate_dir", "vfs_open", "do_readlinkat",
        "__arm64_sys_getdents64", "__arm64_compat_sys_getdents",
    };
    unsigned long addrs[2];
    int i, rc;

    if (sp_entry_installed)
        return 0;
#define SP_BIND(var, name) do { \
    var = (typeof(var))ksu_resolve_symbol_for_functable_hook(name); \
    if (!var) return -ENOENT; \
} while (0)
    SP_BIND(sp_native_iterate, "iterate_dir");
    SP_BIND(sp_getname, "getname_flags");
    SP_BIND(sp_putname, "putname");
    SP_BIND(sp_lookup, "filename_lookup");
    SP_BIND(sp_security_readlink, "security_inode_readlink");
    SP_BIND(sp_touch_atime, "touch_atime");
    SP_BIND(sp_vfs_readlink, "vfs_readlink");
    SP_BIND(sp_fget, "fget");
    SP_BIND(sp_fput, "fput");
    SP_BIND(sp_filldir64, "filldir64");
    SP_BIND(sp_compat_filldir, "compat_filldir");
#undef SP_BIND
    for (i = 0; i < ARRAY_SIZE(names); i++) {
        /* A missing/ambiguous/inlined target is a load error, never reported
         * as complete coverage. Registration alone still needs phone hits. */
        if (ksu_find_symbol_all(names[i], addrs, ARRAY_SIZE(addrs)) != 1) {
            rc = -ENOENT;
            goto fail;
        }
        memset(&sp_entry_probes[i], 0, sizeof(sp_entry_probes[i]));
        sp_entry_probes[i].addr = (void *)addrs[0];
        sp_entry_probes[i].pre_handler = sp_entry_pre;
        rc = register_kprobe(&sp_entry_probes[i]);
        if (rc)
            goto fail;
        sp_entry_armed[i] = true;
    }
    WRITE_ONCE(sp_entry_installed, true);
    return 0;
fail:
    sp_entry_remove();
    return rc;
}
