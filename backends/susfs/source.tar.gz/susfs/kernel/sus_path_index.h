/* SPDX-License-Identifier: GPL-2.0 */
/* Included after sus_path_entry. All accesses hold sus_path_lock. Index only
 * resolved rules; the owning list retains ordering and pending-rule state.
 * Inode-only buckets preserve pointer, device and control-node type tiers. */
#define SUS_PATH_INDEX_SIZE 256
static struct sus_path_entry *sus_path_index[SUS_PATH_INDEX_SIZE];

static unsigned int sus_path_index_bucket(u64 ino)
{
    ino ^= ino >> 32;
    ino *= 0x9e3779b97f4a7c15ULL;
    return (unsigned int)(ino >> 56);
}

static void sus_path_index_add(struct sus_path_entry *e)
{
    unsigned int bucket;
    if (!e->inode)
        return;
    bucket = sus_path_index_bucket(e->ino);
    e->index_next = sus_path_index[bucket];
    sus_path_index[bucket] = e;
}

static void sus_path_index_del(struct sus_path_entry *e)
{
    struct sus_path_entry **slot = &sus_path_index[sus_path_index_bucket(e->ino)];
    while (*slot && *slot != e)
        slot = &(*slot)->index_next;
    if (*slot)
        *slot = e->index_next;
    e->index_next = NULL;
}
