/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * susfs_fp_hook.c - intercept syscalls by replacing a sys_call_table entry.
 *
 * Why this and not an inline hook
 * -------------------------------
 * sys_call_table[nr] holds a pointer to the kernel's CFI jump-table stub
 * (__arm64_sys_xxx.cfi_jt), and KernelSU reads that very array when it wants the
 * original behaviour (ksu_syscall_table[orig_nr](regs), see ksu_hook_faccessat).
 * Rewriting the instructions of such a wrapper therefore interferes with every
 * other caller of it - measured on this device as an unrecoverable
 *
 *     Internal error: Oops - FPAC: 0000000072000000
 *     pc : __arm64_sys_faccessat+0x2c4/0x848
 *     lr : ksu_hook_faccessat+0x44/0x58 [kernelsu]
 *
 * Replacing the table entry touches data only, so the whole chain stays as the
 * kernel built it:
 *
 *     invoke_syscall()          -> sys_call_table[nr]        (ours)
 *     sys_enter + dispatcher    -> ksu_syscall_table[nr]     (the same array)
 *     ksu_hook_faccessat()      -> our wrapper
 *     our wrapper (not hidden)  -> saved entry -> .cfi_jt stub -> real wrapper
 *
 * Nothing on that path has a rewritten instruction, so BTI, PAC, the CFI jump
 * table and LTO all remain untouched.
 *
 * The write itself reuses the fixmap primitive that the inline hook layer
 * already brought over from KernelSU/SukiSU (phys_from_virt + FIX_TEXT_POKE0 +
 * copy_to_kernel_nofault + stop_machine + d-cache flush): the table is data in
 * .rodata, so only the d-cache needs maintenance - never the i-cache.
 */

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/errno.h>
#include <linux/delay.h>
#include <linux/rcupdate.h>
#include <asm/unistd.h>

#include "patch_memory.h"
#include "symbol_resolver.h"
#include "susfs_log.h"
#include "susfs_fp_hook.h"

/* The BTI landing pad of an indirect call target: 'bti c' (an unallocated HINT
 * on cores without BTI, so checking for it is correct either way). */
#define SUSFS_ARM64_BTI_C	0xd503245fu
#define SUSFS_ARM64_BTI_JC	0xd50324dfu
#define SUSFS_ARM64_PACIASP	0xd503233fu
#define SUSFS_ARM64_PACIBSP	0xd503237fu

static susfs_syscall_fn_t *sys_call_table_ptr;
static susfs_syscall_fn_t *compat_sys_call_table_ptr;

/* Upper bound for an index into compat_sys_call_table.  It is NOT __NR_syscalls: the 32-bit
 * table is sized __NR_compat_syscalls (arch/arm64/include/asm/unistd.h:41), which exists only
 * with CONFIG_COMPAT - i.e. exactly when the table does.  The native constant is used as the
 * fallback for the check's own sake, never to index with. */
#ifdef __NR_compat_syscalls
#define SUSFS_FP_COMPAT_MAX_NR	__NR_compat_syscalls
#else
#define SUSFS_FP_COMPAT_MAX_NR	__NR_syscalls
#endif

/* The compat index of a hook, -1 when it has no 32-bit entry (nr_compat 0).  A negative value
 * is not a valid index and is refused by the caller, so it never reaches the table. */
static int fp_compat_nr(const struct susfs_fp_hook *h)
{
	return h->nr_compat ? h->nr_compat : -1;
}

/* One table patch, with the same ordering rule for both tables: the wrapper reads
 * its original out of the module slot, so the slot is published first and the
 * write is verified afterwards. */
static int fp_patch_entry(susfs_syscall_fn_t *table, int nr, const char *name,
                          susfs_syscall_fn_t wrapper)
{
    int err = ksu_patch_text(&table[nr], &wrapper, sizeof(wrapper),
                             KSU_PATCH_TEXT_FLUSH_DCACHE);
    if (err || READ_ONCE(table[nr]) != wrapper) {
        pr_warn("susfs_fp: %s: write failed or did not stick (%d)\n", name, err);
        return err ? err : -EIO;
    }
    return 0;
}

int susfs_fp_init(void)
{
	void *direct, *walked = NULL;

	if (sys_call_table_ptr)
		return 0;

	/* Both lookups, because they do not cover the same symbols: on 5.15
	 * find_kernel_symbol_exact() is kallsyms_lookup_name(), while
	 * ksu_resolve_symbol_for_functable_hook() also walks kallsyms_on_each_symbol -
	 * which is how KernelSU resolves this exact symbol.  Data symbols such as
	 * sys_call_table are the reason to keep both. */
	direct = (void *)find_kernel_symbol_exact("sys_call_table");
	sys_call_table_ptr = (susfs_syscall_fn_t *)direct;
	if (!sys_call_table_ptr) {
		walked = ksu_resolve_symbol_for_functable_hook("sys_call_table");
		sys_call_table_ptr = (susfs_syscall_fn_t *)walked;
	}

	if (!sys_call_table_ptr) {
		/* Keep the evidence in the log: direct lookup vs the kallsyms walk, on
		 * this symbol and on a known-good one of each kind. */
		pr_warn("susfs_fp: sys_call_table not found: direct=%px walk=%px "
			"(control: jiffies direct=%px, openat walk=%px)\n",
			direct, walked,
			(void *)find_kernel_symbol_exact("jiffies"),
			ksu_resolve_symbol_for_functable_hook("__arm64_sys_openat"));
		return -ENOENT;
	}

	pr_info("susfs_fp: sys_call_table at %px (entry 0 %px)\n",
		sys_call_table_ptr, (void *)READ_ONCE(sys_call_table_ptr[0]));

	/* Optional: only the hooks with a compat index (nr_compat) need it, and a kernel without
	 * the table just means those hooks stay native-only or cannot arm at all. */
	compat_sys_call_table_ptr =
		(susfs_syscall_fn_t *)find_kernel_symbol_exact("compat_sys_call_table");
	if (!compat_sys_call_table_ptr)
		compat_sys_call_table_ptr =
			(susfs_syscall_fn_t *)ksu_resolve_symbol_for_functable_hook("compat_sys_call_table");
	pr_info("susfs_fp: compat_sys_call_table at %px (%s)\n",
		compat_sys_call_table_ptr, compat_sys_call_table_ptr ? "ok" : "absent");
	return 0;
}

unsigned long susfs_fp_syscall_table(void)
{
	return (unsigned long)sys_call_table_ptr;
}

unsigned long susfs_fp_compat_syscall_table(void)
{
	return (unsigned long)compat_sys_call_table_ptr;
}

void susfs_fp_dump_entry(int nr, const char *sym)
{
	char cfi_name[128];
	unsigned long plain, cfi, resolved;

	if (!sys_call_table_ptr || nr < 0 || nr >= __NR_syscalls) {
		pr_warn("susfs_fp: dump: table %d or nr %d unusable\n", !!sys_call_table_ptr, nr);
		return;
	}

	plain = find_kernel_symbol_exact(sym);
	snprintf(cfi_name, sizeof(cfi_name), "%s.cfi_jt", sym);
	cfi = find_kernel_symbol_exact(cfi_name);
	resolved = (unsigned long)ksu_resolve_symbol_for_functable_hook(sym);

	pr_info("susfs_fp: nr %d table=%px plain=%px cfi_jt=%px resolved=%px -> %s\n",
		nr, (void *)READ_ONCE(sys_call_table_ptr[nr]),
		(void *)plain, (void *)cfi, (void *)resolved,
		(READ_ONCE(sys_call_table_ptr[nr]) == (susfs_syscall_fn_t)cfi) ? "cfi_jt match" :
		((READ_ONCE(sys_call_table_ptr[nr]) == (susfs_syscall_fn_t)plain) ? "plain match" : "neither"));
}

static bool fp_has_landing_pad(const void *fn);

void susfs_fp_dump_wrapper(const char *name, const void *fn)
{
	if (!fn) {
		pr_warn("susfs_fp: %s: no wrapper\n", name);
		return;
	}
	pr_info("susfs_fp: %s at %px first insn 0x%08x (%s)\n", name, fn,
		READ_ONCE(*(const u32 *)fn),
		fp_has_landing_pad(fn) ? "CALL LANDING PAD" : "NO LANDING PAD");
}

static bool fp_has_landing_pad(const void *fn)
{
	switch (READ_ONCE(*(const u32 *)fn)) {
	case SUSFS_ARM64_BTI_C:
	case SUSFS_ARM64_BTI_JC:
	case SUSFS_ARM64_PACIASP:
	case SUSFS_ARM64_PACIBSP:
		return true;
	default:
		return false;
	}
}

int susfs_fp_install(struct susfs_fp_hook *h)
{
    susfs_syscall_fn_t compat = h->compat_wrapper ?: h->wrapper;
    int cnr, err;

    if (h->installed)
        return 0;
    if (!sys_call_table_ptr) {
        err = susfs_fp_init();
        if (err)
            return err;
    }
    if (h->nr >= __NR_syscalls || h->nr_compat < 0 ||
        h->nr_compat >= SUSFS_FP_COMPAT_MAX_NR)
        return -EINVAL;
    cnr = fp_compat_nr(h);
    if (h->nr < 0 && cnr < 0)
        return -EINVAL;
    if (!h->wrapper || !fp_has_landing_pad((const void *)h->wrapper) ||
        (cnr >= 0 && (!compat || !fp_has_landing_pad((const void *)compat))))
        return -EINVAL;

    atomic_set(&h->active_callbacks, 0);
    init_waitqueue_head(&h->callback_waitq);
    if (h->nr >= 0) {
        h->orig = READ_ONCE(sys_call_table_ptr[h->nr]);
        if (!h->orig)
            return -ENOENT;
        if (h->orig_slot)
            WRITE_ONCE(*h->orig_slot, h->orig);
        smp_wmb();
        /* Track possible publication BEFORE a write that can fail after storing. */
        h->native_installed = h->installed = true;
        err = fp_patch_entry(sys_call_table_ptr, h->nr, h->name, h->wrapper);
        if (err)
            goto rollback;
    }
    if (cnr >= 0 && compat_sys_call_table_ptr) {
        h->orig_compat = READ_ONCE(compat_sys_call_table_ptr[cnr]);
        if (h->orig_compat) {
            if (h->orig_slot_compat)
                WRITE_ONCE(*h->orig_slot_compat, h->orig_compat);
            smp_wmb();
            h->compat_installed = h->installed = true;
            err = fp_patch_entry(compat_sys_call_table_ptr, cnr, h->name, compat);
            if (err)
                goto rollback;
        }
    }
    if (!h->installed)
        return -ENOENT;
    return 0;
rollback:
    /* Removal must prove restoration AND drain callbacks, even on failed init. */
    susfs_fp_remove(h);
    return err;
}

/* A foreign owner may still chain to our wrapper. Never overwrite it or free
 * our text until the chain is unwound back to the saved original. */
static void fp_restore_entry(susfs_syscall_fn_t *table, int nr,
                             susfs_syscall_fn_t wrapper,
                             susfs_syscall_fn_t original, bool *installed)
{
    susfs_syscall_fn_t entry;

    if (!*installed)
        return;
    entry = READ_ONCE(table[nr]);
    if (entry == original) {
        *installed = false;
        return;
    }
    if (entry != wrapper)
        return;
    ksu_patch_text(&table[nr], &original, sizeof(original),
                   KSU_PATCH_TEXT_FLUSH_DCACHE);
    if (READ_ONCE(table[nr]) == original)
        *installed = false;
}

void susfs_fp_remove(struct susfs_fp_hook *h)
{
    if (!h->installed)
        return;
    do {
        /* Each side is independent: a foreign native owner cannot skip compat. */
        fp_restore_entry(compat_sys_call_table_ptr, fp_compat_nr(h),
                          h->compat_wrapper ?: h->wrapper, h->orig_compat,
                          &h->compat_installed);
        fp_restore_entry(sys_call_table_ptr, h->nr, h->wrapper, h->orig,
                          &h->native_installed);
        if (!h->native_installed && !h->compat_installed)
            break;
        pr_warn_ratelimited("susfs_fp: %s: waiting for verified table restoration\n", h->name);
        msleep(100);
    } while (true);
    susfs_fp_drain(h);
    h->installed = false;
}

void susfs_fp_callback_enter(struct susfs_fp_hook *h)
{
    atomic_inc(&h->active_callbacks);
    smp_mb__after_atomic();
}

long susfs_fp_callback_return(struct susfs_fp_hook *h, long result)
{
    /* The caller evaluates its result (including the original syscall) first. */
    smp_mb__before_atomic();
    if (atomic_dec_and_test(&h->active_callbacks))
        wake_up_all(&h->callback_waitq);
    return result;
}

void susfs_fp_drain(struct susfs_fp_hook *h)
{
    /* First grace period covers CPUs that fetched the old table target but have
     * not entered yet. Counters span voluntary sleeps; the final grace period
     * covers wake_up_all() and the return tail after the last decrement. */
    synchronize_rcu();
    synchronize_rcu_tasks();
    wait_event(h->callback_waitq, atomic_read(&h->active_callbacks) == 0);
    synchronize_rcu_tasks();
}
