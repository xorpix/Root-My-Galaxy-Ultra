// SPDX-License-Identifier: GPL-2.0
/*
 * susfs_avc_spoof.c - hide the KernelSU su domain from SELinux AVC audit logs (SUSFS AVC_LOG_SPOOFING), LKM port: upstream
 * prints a priv_app context in place of the su domain, hiding the "denied { ... } tcontext=u:r:su:s0" lines that root-hiding
 * detectors grep for.  The su sid is the SOURCE of the denials that domain CAUSES ("denied { ... }
 * scontext=u:r:ksu:s0 ...") and the TARGET of denials against it, so BOTH the source and the
 * target sid are rewritten in place; the hooked function's own security_sid_to_context() then
 * emits the priv_app context for whichever end matched - equivalent to upstream's string swap.  The sids are resolved at init time (process context) via EXPORT_SYMBOL
 * security_secctx_to_secid(), with module_param overrides; interface is /proc/susfs_avc_spoof (write "1"/"0", read to query).
 */
#include <linux/module.h>
#include <linux/kprobes.h>
#include <linux/security.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/uaccess.h>
#include <linux/string.h>
#include <linux/cred.h>	/* current_uid(), control-node gate */
#include <linux/mutex.h>
#include "avc.h"	/* Real SELinux private prototype, checked below. */
#include "susfs_abi.h"
#include "susfs_log.h"
#include "susfs.h"	/* susfs_expose_proc */

/* module_param overrides for the two domains: the default su domain is the SukiSU variant ("ksu"), stock
 * KernelSU uses "su".  The sid is resolved at init time via security_secctx_to_secid(). */
static char avc_su_ctx[128] = "u:r:ksu:s0";
static char avc_priv_app_ctx[128] = "u:r:priv_app:s0:c512,c768";
module_param_string(avc_su_ctx, avc_su_ctx, sizeof(avc_su_ctx), 0644);
module_param_string(avc_priv_app_ctx, avc_priv_app_ctx, sizeof(avc_priv_app_ctx), 0644);

static u32 avc_su_sid;
static u32 avc_priv_app_sid;
static bool avc_spoof_enabled;
static bool avc_registered;
static bool avc_exiting; /* protected by avc_config_lock */
static DEFINE_MUTEX(avc_config_lock);
static int avc_last_error;

/* SELinux removed the leading state argument. On Android16/6.12 the target SID is x1 and the
 * source SID is x0 (one register ahead of the target in both ABIs); x2 is the object class.
 * Select only from fully checked types; an unfamiliar prototype must fail compilation instead
 * of corrupting a register. */
struct selinux_state;
typedef int (*avc_audit_nostate_t)(u32, u32, u16, u32, u32, u32,
				 int, struct common_audit_data *);
typedef int (*avc_audit_state_t)(struct selinux_state *, u32, u32, u16,
			       u32, u32, u32, int, struct common_audit_data *);
static_assert(__same_type(typeof(&slow_avc_audit), avc_audit_nostate_t) ||
	      __same_type(typeof(&slow_avc_audit), avc_audit_state_t),
	      "Unsupported slow_avc_audit ABI");
enum { avc_tsid_arg = __same_type(typeof(&slow_avc_audit), avc_audit_state_t) ? 2 : 1 };
/* The source SID sits one argument before the target in both prototypes: nostate passes
 * (ssid, tsid, ...) so ssid is arg 0; state passes (state, ssid, tsid, ...) so ssid is arg 1. */
enum { avc_ssid_arg = avc_tsid_arg - 1 };

/* Probe context: no allocation, sleeping or control mutex. Only the source and
 * target SID of an already selected audit may be changed; access decisions are untouched. */
static atomic_t avc_hit_count = ATOMIC_INIT(0);
static atomic_t avc_enter_count = ATOMIC_INIT(0);

static int avc_audit_post_pre(struct kprobe *kp, struct pt_regs *regs)
{
	bool hit = false;

	atomic_inc(&avc_enter_count);
	/* Either sid unresolved means no spoofing at all: avc_su_sid == 0 is a failed
	 * security_secctx_to_secid() (see init), and 0 is a real sid value here, so it must not match;
	 * writing 0 over a real sid would make the hooked function's own security_sid_to_context()
	 * fail and print "scontext=???"/"tcontext=???" - louder than the domain name this hides. */
	if (!READ_ONCE(avc_spoof_enabled) || !avc_su_sid || !avc_priv_app_sid)
		return 0;

	/* BOTH ends. The denials a detector greps for are the ones the su domain CAUSES -
	 * "denied { ... } scontext=u:r:ksu:s0" - and there the su sid is the SOURCE; rewriting the
	 * target alone left every one of those lines intact (upstream a5e7ba5). */
	if ((u32)regs->regs[avc_ssid_arg] == avc_su_sid) {
		regs->regs[avc_ssid_arg] = avc_priv_app_sid;
		hit = true;
	}
	if ((u32)regs->regs[avc_tsid_arg] == avc_su_sid) {
		regs->regs[avc_tsid_arg] = avc_priv_app_sid;
		hit = true;
	}

	if (hit)
		atomic_inc(&avc_hit_count);
	return 0;
}

static struct kprobe kp_avc = {
	.symbol_name = "slow_avc_audit",
	.pre_handler = avc_audit_post_pre,
};

static int avc_register(void)
{
	int rc;

	if (avc_exiting)
		return -ENODEV;
	if (avc_registered)
		return 0;
	/* unregister_kprobe retains KPROBE_FLAG_DISABLED in this object. Reset it
	 * and the resolved address before every new registration. */
	kp_avc.flags = 0;
	kp_avc.addr = NULL;
	rc = register_kprobe(&kp_avc);
	if (rc)
		return rc;
	avc_registered = true;
	SUSFS_LOGI("susfs_avc_spoof: hook installed (slow_avc_audit)\n");
	return 0;
}

static void avc_unregister(void)
{
	if (!avc_registered)
		return;
	unregister_kprobe(&kp_avc);
	avc_registered = false;
	SUSFS_LOGI("susfs_avc_spoof: hook removed\n");
}

static int avc_set_enabled(bool enabled)
{
	int rc = 0;

	mutex_lock(&avc_config_lock);
	if (avc_exiting) {
		rc = -ENODEV;
		goto out;
	}
	if (enabled) {
		if (!avc_su_sid || !avc_priv_app_sid)
			rc = -ENOENT;
		else
			rc = avc_register();
		if (!rc)
			WRITE_ONCE(avc_spoof_enabled, true);
	} else {
		WRITE_ONCE(avc_spoof_enabled, false);
		avc_unregister();
	}
out:
	avc_last_error = rc;
	mutex_unlock(&avc_config_lock);
	return rc;
}

static int avc_proc_show(struct seq_file *m, void *v)
{
	mutex_lock(&avc_config_lock);
	seq_printf(m, "%d (su_sid=%u priv_app_sid=%u enter=%d hits=%d registered=%d tsid_arg=%d abi_checked=1 checkpoint=18 last_error=%d)\n",
		   avc_spoof_enabled ? 1 : 0, avc_su_sid, avc_priv_app_sid,
		   atomic_read(&avc_enter_count), atomic_read(&avc_hit_count),
		   (int)avc_registered, avc_tsid_arg, avc_last_error);
	mutex_unlock(&avc_config_lock);
	return 0;
}

static int avc_proc_open(struct inode *inode, struct file *file)
{
	/* 0777 is deliberate (the ENOENT contract comes from sus_path's hidden set, not from the mode), so
	 * refuse non-root callers here too - see the note in susfs_enable_log.c's log_proc_open(). */
	if (current_uid().val != 0)
		return -ENOENT;
	return single_open(file, avc_proc_show, NULL);
}

static ssize_t avc_proc_write(struct file *file, const char __user *buf,
			      size_t len, loff_t *off)
{
	char value[2];
	int rc;

	if (current_uid().val != 0)
		return -ENOENT;

	if (len != 1 && len != 2)
		return -EINVAL;
	if (copy_from_user(value, buf, len))
		return -EFAULT;
	if ((value[0] != '0' && value[0] != '1') || (len == 2 && value[1] != '\n'))
		return -EINVAL;
	rc = avc_set_enabled(value[0] == '1');
	if (rc)
		return rc;
	return len;
}

static const struct proc_ops avc_proc_ops = {
	.proc_open = avc_proc_open,
	.proc_read = seq_read,
	.proc_write = avc_proc_write,
	.proc_lseek = seq_lseek,
	.proc_release = single_release,
};

static struct proc_dir_entry *avc_proc_entry;

int susfs_avc_spoof_init(void)
{
	int err;

	err = security_secctx_to_secid(avc_su_ctx, strlen(avc_su_ctx), &avc_su_sid);
	if (err) {
		pr_warn("avc_spoof: secctx_to_secid(%s) failed %d\n", avc_su_ctx, err);
		avc_su_sid = 0;
	}
	err = security_secctx_to_secid(avc_priv_app_ctx, strlen(avc_priv_app_ctx),
				       &avc_priv_app_sid);
	if (err) {
		pr_warn("avc_spoof: secctx_to_secid(%s) failed %d\n",
			avc_priv_app_ctx, err);
		avc_priv_app_sid = 0;
	}
	SUSFS_LOGI("avc_spoof: su_sid=%u (%s), priv_app_sid=%u (%s)\n",
		avc_su_sid, avc_su_ctx, avc_priv_app_sid, avc_priv_app_ctx);

	/* Only the /proc node is optional: avc_register() installs the hook whenever the feature is switched
	 * on, supercall included.  0777 so DAC passes and sus_path's LSM layer gets to answer ENOENT. */
	if (susfs_control_node_allowed()) {
		avc_proc_entry = proc_create("susfs_avc_spoof", 0777, NULL,
					     &avc_proc_ops);
		if (!avc_proc_entry)
			pr_warn("proc_create(susfs_avc_spoof) failed\n");
		else
			SUSFS_LOGI("susfs_avc_spoof: proc ready (/proc/susfs_avc_spoof)\n");
	} else {
		SUSFS_LOGI("susfs_avc_spoof: /proc node not created (expose_proc=%d lsm=%d)\n",
			(int)susfs_expose_proc, (int)sus_path_lsm_active());
	}
	return 0;
}

void susfs_avc_spoof_exit(void)
{
	/* Refuse late control calls before disarming, under the same mutex. */
	mutex_lock(&avc_config_lock);
	avc_exiting = true;
	WRITE_ONCE(avc_spoof_enabled, false);
	avc_unregister();
	mutex_unlock(&avc_config_lock);
	if (avc_proc_entry) {
		proc_remove(avc_proc_entry);
		avc_proc_entry = NULL;
	}
}

/* supercall: CMD_SUSFS_ENABLE_AVC_LOG_SPOOFING */
void susfs_avc_spoof_supercall(void __user **arg)
{
	struct st_susfs_avc_log_spoofing info = {0};

	if (copy_from_user(&info, (void __user *)*arg, sizeof(info))) {
		info.err = -EFAULT;
		goto out;
	}

	/* Check the raw byte before evaluating _Bool: other representations are
	 * invalid, and accepting them would conceal a malformed userspace payload. */
	if (*(unsigned char *)&info.enabled > 1) {
		info.err = -EINVAL;
		goto out;
	}
	info.err = avc_set_enabled(info.enabled);
	if (!info.err)
		SUSFS_LOGI("avc_spoof: %s (supercall)\n", info.enabled ? "enabled" : "disabled");
out:
	/* upstream writes back only ->err for input-type commands */
	if (copy_to_user(&((struct st_susfs_avc_log_spoofing __user *)*arg)->err,
			 &info.err, sizeof(info.err)))
		pr_warn("avc supercall copy_to_user failed\n");
}
