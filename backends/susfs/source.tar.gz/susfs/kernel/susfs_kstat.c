// SPDX-License-Identifier: GPL-2.0
/*
 * susfs_kstat.c - spoof kstat fields (SUSFS SUS_KSTAT feature), LKM port.
 *
 * Interface mirrors the original SUSFS userspace commands, one command per write to
 * /proc/susfs_kstat:
 *   add_sus_kstat <path> - store the CURRENT stat of <path> as the spoof target
 *       (ino/dev/times/blocks/blksize), flags = KSTAT_AUTO_SPOOF; use it BEFORE the path is
 *       bind-mounted/overlayed, then call update_sus_kstat.
 *   add_sus_kstat_statically <path> <ino> <dev> <nlink> <size> <atime> <atime_nsec> <mtime>
 *       <mtime_nsec> <ctime> <ctime_nsec> <blocks> <blksize> - set each field explicitly;
 *       "default" keeps the current value and does NOT spoof that field, and only non-default
 *       fields get their KSTAT_SPOOF_* flag set.
 *   update_sus_kstat <path> / update_sus_kstat_full_clone <path> - re-resolve <path> (after it was
 *       bind-mounted/overlayed) and update target_ino/target_dev only, spoofed values staying as
 *       previously added; the _full_clone form also raises KSTAT_SPOOF_NLINK|KSTAT_SPOOF_SIZE.
 *   del <path> - remove one rule by its target pathname;   clear - remove all rules.
 *
 * Hook strategy: ONE hook, the global sys_exit tracepoint (kstat_sys_exit()).  LTO on this GKI
 * inlines the whole stat chain (vfs_fstatat -> vfs_statx -> vfs_getattr -> cp_new_stat, and
 * vfs_fstat/do_statx -> cp_new_stat/cp_statx the same way), so no VFS-layer probe is ever hit:
 * measured on the 5.15 device, 120 000 app-uid newfstatat calls moved a vfs_getattr kretprobe's
 * counter by +15, i.e. noise - that kretprobe is deleted, not disabled.  What IS reliable is the
 * return of the syscall-table entry points, where the user buffer is fully written and
 * syscall_get_arguments() still returns the original args from the live pt_regs.  So the
 * tracepoint whitelists the syscall numbers that fill a user stat buffer and rewrites the buffer
 * through copy_to_user:
 *
 *   native 79 __NR_newfstatat -> struct stat, user buffer args[2]
 *   native 80 __NR_fstat      -> struct stat, user buffer args[1] (the fd-based one)
 *   native 291 __NR_statx     -> struct statx, buffer args[4], caller's mask args[3]
 *   AArch32 195/196/197/327 stat64/lstat64/fstat64/fstatat64 -> struct stat64
 *   AArch32 397 statx -> struct statx
 *   AArch32 106/107/108 stat/lstat/fstat -> struct compat_stat (counted as unsupported;
 *           this older layout has no rewriter yet - see below)
 * The caller's ABI is selected BEFORE comparing numbers: e.g. native 141 is getpriority,
 * whereas AArch32 141 is getdents.  Sharing a syscall implementation does not change the
 * original ABI number reported by syscall_get_nr().
 *
 * The SAME tracepoint and the same handler carry sus_path's dirent (getdents) rewrite - see
 * sus_path_dirent_filter() under the stat branch below.  One register_trace_sys_exit() call in the
 * module, one handler, one dispatch: the syscall number is fetched once and tested against the
 * whitelist, and only a whitelisted number pays for anything after that.  Field offsets are arm64
 * asm-generic struct stat / struct statx, derived with offsetof() (this file) and static_assert'ed
 * rather than hard-coded.
 */
#include <linux/module.h>
#include <linux/kprobes.h>
#include <linux/uaccess.h>
#include <linux/syscalls.h>
#include <linux/stat.h>
#include <linux/compat.h>
#include <linux/tracepoint.h>
#include <trace/events/syscalls.h>
#include <asm/syscall.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/kernel.h>
#include <linux/namei.h>
#include <linux/dcache.h>
#include <linux/kdev_t.h>
#include <linux/string.h>
#include <linux/cred.h>
#include <linux/version.h>	/* LINUX_VERSION_CODE: the inode ctime accessor */
#include "susfs_abi.h"
#include "susfs_log.h"
#include "susfs.h"	/* susfs_expose_proc, sus_path_dirent_filter() */
#include "ksu_umount_gate.h"	/* susfs_is_current_proc_umounted_app (issue #34) */

/* KSTAT_SPOOF_* bits live in susfs_abi.h (upstream declares them in susfs.h next to struct
 * st_susfs_sus_kstat).  KSTAT_AUTO_SPOOF* below are /proc-interface masks, not supercall ABI. */
#define KSTAT_AUTO_SPOOF (KSTAT_SPOOF_INO | KSTAT_SPOOF_DEV | \
	KSTAT_SPOOF_ATIME_TV_SEC | KSTAT_SPOOF_ATIME_TV_NSEC | \
	KSTAT_SPOOF_MTIME_TV_SEC | KSTAT_SPOOF_MTIME_TV_NSEC | \
	KSTAT_SPOOF_CTIME_TV_SEC | KSTAT_SPOOF_CTIME_TV_NSEC | \
	KSTAT_SPOOF_BLKSIZE | KSTAT_SPOOF_BLOCKS)
#define KSTAT_AUTO_SPOOF_FULL_CLONE (KSTAT_AUTO_SPOOF | \
	KSTAT_SPOOF_NLINK | KSTAT_SPOOF_SIZE)

#define SUS_KSTAT_MAX 32
/* Upstream's target_pathname is char[256]: a shorter buffer truncates a legal long path into a wrong rule. */
#define KSTAT_PATH_MAX 256

struct sus_kstat_entry {
	char target_pathname[KSTAT_PATH_MAX];
	unsigned long target_ino;
	/* dev stored ENCODED (new_encode_dev) so it matches the user statbuf st_dev field 1:1 on the tracepoint hot path. */
	dev_t target_dev;
	unsigned long spoofed_ino;
	unsigned long spoofed_dev;
	unsigned int spoofed_nlink;
	long long spoofed_size;
	long spoofed_atime_tv_sec;
	unsigned long spoofed_atime_tv_nsec;
	long spoofed_mtime_tv_sec;
	unsigned long spoofed_mtime_tv_nsec;
	long spoofed_ctime_tv_sec;
	unsigned long spoofed_ctime_tv_nsec;
	long long spoofed_blocks;
	long spoofed_blksize;
	unsigned int flags;
};

static struct sus_kstat_entry kstat_entries[SUS_KSTAT_MAX];
static int nkstat;
static DEFINE_MUTEX(kstat_lock);

/* Table locking, in two tiers.  kstat_lock (mutex) serialises WRITERS and the /proc read, because
 * writers resolve paths and that sleeps.  kstat_table_lock (spinlock) guards the table for the
 * READERS - the sys_exit tracepoint and the maps/smaps kretprobes, hot paths where kstat_lock
 * cannot be taken; a reader holds it only long enough to copy the matching entry out and must never
 * copy_to_user under it.  Rule: resolve first (sleeping, outside), then swap (non-sleeping, inside) -
 * publishing a slot before it is filled is a bug (an empty slot used to be visible as soon as nkstat
 * was bumped, before kern_path() had even run). */
static DEFINE_SPINLOCK(kstat_table_lock);

/* The part of an entry a reader needs, copied out under kstat_table_lock. */
struct sus_kstat_snapshot {
	unsigned long spoofed_ino;
	unsigned long spoofed_dev;
	unsigned int spoofed_nlink;
	long long spoofed_size;
	long spoofed_atime_tv_sec;
	unsigned long spoofed_atime_tv_nsec;
	long spoofed_mtime_tv_sec;
	unsigned long spoofed_mtime_tv_nsec;
	long spoofed_ctime_tv_sec;
	unsigned long spoofed_ctime_tv_nsec;
	long long spoofed_blocks;
	long spoofed_blksize;
	unsigned int flags;
};

static void kstat_snapshot(const struct sus_kstat_entry *e,
			   struct sus_kstat_snapshot *s)
{
	s->spoofed_ino = e->spoofed_ino;
	s->spoofed_dev = e->spoofed_dev;
	s->spoofed_nlink = e->spoofed_nlink;
	s->spoofed_size = e->spoofed_size;
	s->spoofed_atime_tv_sec = e->spoofed_atime_tv_sec;
	s->spoofed_atime_tv_nsec = e->spoofed_atime_tv_nsec;
	s->spoofed_mtime_tv_sec = e->spoofed_mtime_tv_sec;
	s->spoofed_mtime_tv_nsec = e->spoofed_mtime_tv_nsec;
	s->spoofed_ctime_tv_sec = e->spoofed_ctime_tv_sec;
	s->spoofed_ctime_tv_nsec = e->spoofed_ctime_tv_nsec;
	s->spoofed_blocks = e->spoofed_blocks;
	s->spoofed_blksize = e->spoofed_blksize;
	s->flags = e->flags;
}

/* arm64 asm-generic struct stat offsets (native 64-bit) */
#define ST_DEV_OFF          0
#define ST_INO_OFF          8
#define ST_NLINK_OFF        20
#define ST_SIZE_OFF         48
#define ST_BLKSIZE_OFF      56
#define ST_BLOCKS_OFF       64
#define ST_ATIME_OFF        72
#define ST_ATIME_NSEC_OFF   80
#define ST_MTIME_OFF        88
#define ST_MTIME_NSEC_OFF   96
#define ST_CTIME_OFF        104
#define ST_CTIME_NSEC_OFF   112

/* The numbers above are a uapi contract, checked at build time instead of trusted: arm64 uses the
 * generic layout (__ARCH_WANT_NEW_STAT), and a DDK header change that moved a member would
 * otherwise corrupt the caller's stat buffer instead of failing this build. */
static_assert(offsetof(struct stat, st_dev) == ST_DEV_OFF, "stat.st_dev");
static_assert(offsetof(struct stat, st_ino) == ST_INO_OFF, "stat.st_ino");
static_assert(offsetof(struct stat, st_nlink) == ST_NLINK_OFF, "stat.st_nlink");
static_assert(offsetof(struct stat, st_size) == ST_SIZE_OFF, "stat.st_size");
static_assert(offsetof(struct stat, st_blksize) == ST_BLKSIZE_OFF, "stat.st_blksize");
static_assert(offsetof(struct stat, st_blocks) == ST_BLOCKS_OFF, "stat.st_blocks");
static_assert(offsetof(struct stat, st_atime) == ST_ATIME_OFF, "stat.st_atime");
static_assert(offsetof(struct stat, st_mtime) == ST_MTIME_OFF, "stat.st_mtime");
static_assert(offsetof(struct stat, st_ctime) == ST_CTIME_OFF, "stat.st_ctime");

/* ---- the read gate ----
 *
 * Upstream gates every sus_kstat read on susfs_is_current_proc_umounted_app(), exactly
 * (TIF_PROC_UMOUNTED && current_uid().val >= 10000).  KernelSU's setuid_hook sets that flag only
 * when SUSFS integration is compiled into the kernel, and this device's kernel has none (zero susfs
 * symbols in kallsyms) - and the gate now asks KernelSU directly: susfs_is_current_proc_umounted_app()
 * resolves ksu_uid_should_umount() once at load (ksu_umount_gate.h, issue #34), so the old proxy no
 * longer spoofs for the manager and su-granted apps; with the symbol unresolved it keeps that proxy,
 * the same one sus_path keeps as its fallback.
 * Without it the spoofing is visible to root too, wider than upstream.  Writers (supercall, /proc)
 * are configuration and stay ungated. */
static bool susfs_kstat_gate_ok(void)
{
	return susfs_is_current_proc_umounted_app();
}

/* ---- table access ----
 * The *_table_* helpers are the ONLY places that modify kstat_entries or nkstat, each under
 * kstat_table_lock; their callers hold kstat_lock, making the index they pass stable. */

/* Cheapest possible gate for the READ paths: with nothing registered no lookup can match, which on
 * the sys_exit tracepoint saves the two copy_from_user() reads the spoofers do before matching, and
 * on the maps/smaps kprobes (still armed after a `clear`) saves an uncontended spinlock per VMA.
 * READ_ONCE is enough: nkstat is published only AFTER the entry it counts has been written, under
 * kstat_table_lock (kstat_table_append stores the entry, then bumps the count), so a stale non-zero
 * value only means work we used to do and a stale zero can cost at most the single read racing the
 * very first add; the authoritative test is the locked lookup.
 * sus_path uses the same idiom (READ_ONCE(sus_path_count)). */
static bool susfs_kstat_table_empty(void)
{
	return READ_ONCE(nkstat) == 0;
}

/* Hot-path lookup: match (ino, dev) and copy the entry out atomically w.r.t. the writers. */
static bool susfs_kstat_lookup(unsigned long ino, dev_t dev,
			       struct sus_kstat_snapshot *out)
{
	unsigned long flags;
	bool found = false;
	int i;

	spin_lock_irqsave(&kstat_table_lock, flags);
	for (i = 0; i < nkstat; i++) {
		if (kstat_entries[i].target_ino == ino &&
		    kstat_entries[i].target_dev == dev) {
			kstat_snapshot(&kstat_entries[i], out);
			found = true;
			break;
		}
	}
	spin_unlock_irqrestore(&kstat_table_lock, flags);
	return found;
}

/* Writer-side lookup by path: safe without the spinlock, since every caller holds kstat_lock. */
static struct sus_kstat_entry *susfs_kstat_find_by_path(const char *path)
{
	int i;

	for (i = 0; i < nkstat; i++)
		if (!strcmp(kstat_entries[i].target_pathname, path))
			return &kstat_entries[i];
	return NULL;
}

/* Append a fully-prepared entry; -ENOSPC when the table is full. */
static int kstat_table_append(const struct sus_kstat_entry *src)
{
	unsigned long flags;
	int idx = -1;

	spin_lock_irqsave(&kstat_table_lock, flags);
	if (nkstat < SUS_KSTAT_MAX) {
		idx = nkstat;
		kstat_entries[idx] = *src;
		nkstat = idx + 1;
	}
	spin_unlock_irqrestore(&kstat_table_lock, flags);
	return idx;
}

/* Replace a live entry wholesale: the reader sees old or new, never a mix of the two. */
static void kstat_table_put(int idx, const struct sus_kstat_entry *src)
{
	unsigned long flags;

	spin_lock_irqsave(&kstat_table_lock, flags);
	if (idx >= 0 && idx < nkstat)
		kstat_entries[idx] = *src;
	spin_unlock_irqrestore(&kstat_table_lock, flags);
}

/* Re-target an entry, and optionally raise its flags. */
static void kstat_table_retarget(int idx, unsigned long ino, dev_t dev,
				 unsigned int add_flags)
{
	unsigned long flags;

	spin_lock_irqsave(&kstat_table_lock, flags);
	if (idx >= 0 && idx < nkstat) {
		kstat_entries[idx].target_ino = ino;
		kstat_entries[idx].target_dev = dev;
		kstat_entries[idx].flags |= add_flags;
	}
	spin_unlock_irqrestore(&kstat_table_lock, flags);
}

/* Remove by index: move the last entry into the hole, under the lock so a reader never sees that move half-done. */
static void kstat_table_del(int idx)
{
	unsigned long flags;

	spin_lock_irqsave(&kstat_table_lock, flags);
	if (idx >= 0 && idx < nkstat) {
		nkstat--;
		if (idx != nkstat)
			kstat_entries[idx] = kstat_entries[nkstat];
	}
	spin_unlock_irqrestore(&kstat_table_lock, flags);
}

static void kstat_table_clear(void)
{
	unsigned long flags;

	spin_lock_irqsave(&kstat_table_lock, flags);
	nkstat = 0;
	spin_unlock_irqrestore(&kstat_table_lock, flags);
}

/* ---- /proc/<pid>/maps and smaps identity coverage ----
 * CP20's show_map_vma helper probe rewrote smaps but missed maps on BZIG.
 * Probe the two int (seq_file *, void *) .show callbacks instead: their helper
 * may be inlined, but both listing entry points remain observable. There is no
 * nested helper probe, so a header is never rewritten twice. Capture the count
 * before .show, then edit only its first newly appended header's dev/ino columns.
 * Earlier records, pathname text and smaps metrics cannot match.
 */
static bool kstat_buf_replace(struct seq_file *m, size_t start,
                              const char *old, size_t old_len,
                              const char *new, size_t new_len)
{
	char *buf = m->buf;
	size_t count = m->count, end = start, pos = start;
	int field;

	if (!old_len || !new_len || start >= count || count >= m->size)
		return false;
	while (end < count && buf[end] != '\n')
		end++;
	/* Skip range, permissions and offset, each separated by spaces. */
	for (field = 0; field < 3; field++) {
		while (pos < end && buf[pos] != ' ')
			pos++;
		while (pos < end && buf[pos] == ' ')
			pos++;
	}
	if (pos >= end || old_len >= end - pos ||
	    memcmp(buf + pos, old, old_len) || buf[pos + old_len] != ' ')
		return false;
	if (new_len > old_len && new_len - old_len >= m->size - count) {
		/* Force seq_file to retry with room rather than emit the real identity. */
		m->count = m->size;
		return false;
	}
	if (new_len != old_len)
		memmove(buf + pos + new_len, buf + pos + old_len, count - (pos + old_len));
	memcpy(buf + pos, new, new_len);
	m->count = count - old_len + new_len;
	return true;
}

struct kstat_map_args {
	struct seq_file *m;
	struct vm_area_struct *vma;
	char *buf;
	size_t start;
	unsigned int route;
};

static atomic_t n_kstat_map_hits = ATOMIC_INIT(0);
static atomic_t n_kstat_map_rewrites = ATOMIC_INIT(0);
static atomic_t n_kstat_map_routes[2] = { ATOMIC_INIT(0), ATOMIC_INIT(0) };

static int kstat_map_show_entry(struct kretprobe_instance *ri, struct pt_regs *regs,
                                unsigned int route)
{
	struct kstat_map_args *a = (struct kstat_map_args *)ri->data;

	if (susfs_kstat_table_empty() || !susfs_kstat_gate_ok())
		return 1;
	a->m = (struct seq_file *)regs->regs[0];
	a->vma = (struct vm_area_struct *)regs->regs[1];
	if (!susfs_ptr_plausible(a->m) || !susfs_ptr_plausible(a->vma))
		return 1;
	a->buf = a->m->buf;
	a->start = a->m->count;
	a->route = route;
	return 0;
}

static int kstat_maps_entry(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	return kstat_map_show_entry(ri, regs, 0);
}

static int kstat_smaps_entry(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	return kstat_map_show_entry(ri, regs, 1);
}

static int kstat_map_show_ret(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	const struct kstat_map_args *a = (const struct kstat_map_args *)ri->data;
	struct seq_file *m = a->m;
	struct vm_area_struct *vma = a->vma;
	struct sus_kstat_snapshot snap;
	struct inode *inode;
	char old[48], new[48];
	unsigned int major, minor;
	int old_len, new_len;

	if (regs->regs[0] || susfs_kstat_table_empty())
		return 0;
	if (!susfs_ptr_plausible(m) || !susfs_ptr_plausible(vma) ||
	    !m->buf || m->buf != a->buf || a->start >= m->count ||
	    m->count >= m->size || !vma->vm_file)
		return 0;
	inode = file_inode(vma->vm_file);
	if (!inode || !susfs_kstat_gate_ok())
		return 0;
	if (!susfs_kstat_lookup(inode->i_ino,
	                       new_encode_dev(inode->i_sb->s_dev), &snap))
		return 0;
	if (!(snap.flags & (KSTAT_SPOOF_INO | KSTAT_SPOOF_DEV)))
		return 0;
	atomic_inc(&n_kstat_map_hits);
	old_len = scnprintf(old, sizeof(old), "%02x:%02x %lu",
	                    (unsigned int)MAJOR(inode->i_sb->s_dev),
	                    (unsigned int)MINOR(inode->i_sb->s_dev),
	                    (unsigned long)inode->i_ino);
	if (snap.flags & KSTAT_SPOOF_DEV) {
		unsigned int enc = (unsigned int)snap.spoofed_dev;
		/* Inverse of new_encode_dev(), including the high minor bits. */
		major = (enc & 0xfff00u) >> 8;
		minor = (enc & 0xffu) | ((enc >> 12) & 0xfff00u);
	} else {
		major = (unsigned int)MAJOR(inode->i_sb->s_dev);
		minor = (unsigned int)MINOR(inode->i_sb->s_dev);
	}
	new_len = scnprintf(new, sizeof(new), "%02x:%02x %lu", major, minor,
	                    (snap.flags & KSTAT_SPOOF_INO)
	                    ? snap.spoofed_ino : (unsigned long)inode->i_ino);
	/* Retain the name column when the replacement gets shorter. */
	while (new_len < old_len && new_len < (int)sizeof(new) - 1)
		new[new_len++] = ' ';
	if (old_len > 0 && new_len > 0 &&
	    kstat_buf_replace(m, a->start, old, (size_t)old_len, new, (size_t)new_len)) {
		atomic_inc(&n_kstat_map_rewrites);
		atomic_inc(&n_kstat_map_routes[a->route]);
	}
	return 0;
}

static struct kretprobe krp_kstat_maps = {
	.kp.symbol_name = "show_map",
	.entry_handler = kstat_maps_entry,
	.handler = kstat_map_show_ret,
	.data_size = sizeof(struct kstat_map_args),
	.maxactive = 64,
};

static struct kretprobe krp_kstat_smaps = {
	.kp.symbol_name = "show_smap",
	.entry_handler = kstat_smaps_entry,
	.handler = kstat_map_show_ret,
	.data_size = sizeof(struct kstat_map_args),
	.maxactive = 64,
};

static bool kstat_maps_registered;
static DEFINE_MUTEX(kstat_maps_ctl_lock);
static bool kstat_maps_exiting;

/* Called with the rule-management mutex held, before publishing any rule. */
static int kstat_maps_arm(void)
{
	int rc;

	mutex_lock(&kstat_maps_ctl_lock);
	if (kstat_maps_exiting) {
		rc = -ENODEV;
		goto out;
	}
	if (kstat_maps_registered) {
		rc = 0;
		goto out;
	}
	krp_kstat_maps.kp.addr = NULL;
	krp_kstat_maps.kp.flags = 0;
	rc = register_kretprobe(&krp_kstat_maps);
	if (rc)
		goto out;
	krp_kstat_smaps.kp.addr = NULL;
	krp_kstat_smaps.kp.flags = 0;
	rc = register_kretprobe(&krp_kstat_smaps);
	if (rc) {
		unregister_kretprobe(&krp_kstat_maps);
		goto out;
	}
	kstat_maps_registered = true;
	SUSFS_LOGI("susfs_kstat: maps/smaps .show hooks armed\n");
	rc = 0;
out:
	mutex_unlock(&kstat_maps_ctl_lock);
	return rc;
}

static void kstat_maps_disarm(void)
{
	/* Only called at exit. Close re-arming before the final disarm. */
	mutex_lock(&kstat_maps_ctl_lock);
	kstat_maps_exiting = true;
	if (kstat_maps_registered) {
		unregister_kretprobe(&krp_kstat_smaps);
		unregister_kretprobe(&krp_kstat_maps);
		kstat_maps_registered = false;
	}
	mutex_unlock(&kstat_maps_ctl_lock);
}

/* ---- per-syscall observability ----
 *
 * Every whitelisted number gets its own line of counters, and every early-out is counted with the
 * reason it happened.  "The rule is registered" and "the rule was reached" are different claims -
 * a false "the feature is broken" report was already produced once by reading a counter that could
 * not fire - so the numbers below are what turns "it did not work" into one of: not this number,
 * the buffer was NULL, no rule, gate (not an app), the lookup did not match, or a uaccess fault.
 *
 * The increments sit INSIDE the per-number handlers, i.e. after the whitelist test: an ordinary
 * syscall (getpid, read, ...) never reaches them - it pays the (now unconditional) number compare
 * and nothing else.  atomic_t on purpose: several CPUs can update each counter concurrently. */
struct kstat_call_counters {
	atomic_t calls;		/* this number returned 0: it reached the statbuf code */
	atomic_t ret_err;	/* this number returned -errno */
	atomic_t no_buf;	/* statbuf argument was NULL */
	atomic_t rewrite;	/* the buffer really changed */
	atomic_t miss_empty;	/* no rule registered at all */
	atomic_t miss_gate;	/* gate: not an app process KernelSU would umount modules for */
	atomic_t miss_lookup;	/* the (ino,dev) key matched no rule */
	atomic_t match_noflag;	/* matched, but this buffer has no field we impersonate */
	atomic_t uaccess;	/* copy_from_user/copy_to_user failed */
	atomic_t narrow;	/* requested value does not fit the legacy compat field */
};

#define KSTAT_COUNTERS(nm)						\
	static struct kstat_call_counters cnt_##nm = {			\
		.calls = ATOMIC_INIT(0), .ret_err = ATOMIC_INIT(0),	\
		.no_buf = ATOMIC_INIT(0), .rewrite = ATOMIC_INIT(0),	\
		.miss_empty = ATOMIC_INIT(0), .miss_gate = ATOMIC_INIT(0),\
		.miss_lookup = ATOMIC_INIT(0), .match_noflag = ATOMIC_INIT(0),\
		.uaccess = ATOMIC_INIT(0), .narrow = ATOMIC_INIT(0),	\
	}

/* Separate counters for each ABI and syscall number. Legacy compat_stat uses its own layout. */
KSTAT_COUNTERS(nfstatat);
KSTAT_COUNTERS(nfstat);
KSTAT_COUNTERS(statx);
KSTAT_COUNTERS(fstatat64);
KSTAT_COUNTERS(stat64);
KSTAT_COUNTERS(lstat64);
KSTAT_COUNTERS(fstat64);
KSTAT_COUNTERS(compat_statx);
KSTAT_COUNTERS(compat_stat);
KSTAT_COUNTERS(compat_lstat);
KSTAT_COUNTERS(compat_fstat);
/* Retained diagnostic ABI. No supported syscall enters the unlisted counter. */
#define KSTAT_UNLISTED_SEEN	8

static atomic_t n_kstat_unlisted = ATOMIC_INIT(0);
static atomic_t kstat_unlisted_next = ATOMIC_INIT(0);
static long kstat_unlisted_seen[KSTAT_UNLISTED_SEEN];

static void __maybe_unused kstat_note_unlisted(long nr)
{
	unsigned int slot;

	atomic_inc(&n_kstat_unlisted);
	slot = (unsigned int)atomic_inc_return(&kstat_unlisted_next) - 1U;
	WRITE_ONCE(kstat_unlisted_seen[slot % KSTAT_UNLISTED_SEEN], nr);
}

/* The whitelist table itself (kstat_nr_table) is defined further down, after the syscall-number
 * constants it is built from: __NR_* come from the uapi headers, but the AArch32 numbers are
 * spelled out in this file next to the struct stat64 layout they belong to, so the table has to
 * come after them or it would reference names that do not exist yet.  The /proc report lists
 * the same constants and counter sets used by the dispatcher. */

/* The dispatch state for one call.  Passed by pointer into the helpers so a call site never
 * repeats the counter bookkeeping, and typed counters cannot be wired to the wrong line.
 * `compat` is the one thing a helper cannot work out from its counter set: on a 32-bit task the
 * user buffer is a zero-extended u32 and has to go through compat_ptr() first.
 * Defined here - before the helpers, and independent of the whitelist table, which is built
 * further down from the syscall-number constants that live next to the AArch32 struct layouts. */
struct kstat_call_state {
	struct kstat_call_counters *cnt;
	bool compat;
};

/* Rewrite the requested fields of the native user statbuf.  Returns true when the buffer was
 * really changed, so the caller can count "matched" from "rewrote". */
static bool susfs_kstat_spoof_statbuf(struct kstat_call_state *st, unsigned long statbuf)
{
	/* Snapshot, not a pointer into the table: a concurrent writer must not be able to retarget the
	 * entry between the match and the copy_to_user below, which must not run under a spinlock. */
	struct sus_kstat_snapshot snap;
	const struct sus_kstat_snapshot *e = &snap;
	unsigned long ino = 0, dev = 0;
	unsigned long v;
	unsigned int v32;
	long long v64;
	long sl;
	bool rewrote = false;

	if (susfs_kstat_table_empty()) {
		atomic_inc(&st->cnt->miss_empty);
		return false;
	}
	if (!susfs_kstat_gate_ok()) {
		atomic_inc(&st->cnt->miss_gate);
		return false;
	}

	if (copy_from_user(&ino, (void __user *)(statbuf + ST_INO_OFF), sizeof(ino))) {
		atomic_inc(&st->cnt->uaccess);
		return false;
	}
	if (copy_from_user(&dev, (void __user *)(statbuf + ST_DEV_OFF), sizeof(dev))) {
		atomic_inc(&st->cnt->uaccess);
		return false;
	}

	if (!susfs_kstat_lookup(ino, dev, &snap)) {
		atomic_inc(&st->cnt->miss_lookup);
		return false;
	}

	if (e->flags & KSTAT_SPOOF_INO) {
		v = e->spoofed_ino;
		if (copy_to_user((void __user *)(statbuf + ST_INO_OFF), &v, sizeof(v))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_DEV) {
		v = e->spoofed_dev;
		if (copy_to_user((void __user *)(statbuf + ST_DEV_OFF), &v, sizeof(v))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_NLINK) {
		v32 = e->spoofed_nlink;
		if (copy_to_user((void __user *)(statbuf + ST_NLINK_OFF), &v32, sizeof(v32))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_SIZE) {
		v64 = e->spoofed_size;
		if (copy_to_user((void __user *)(statbuf + ST_SIZE_OFF), &v64, sizeof(v64))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_BLKSIZE) {
		v32 = (unsigned int)e->spoofed_blksize;
		if (copy_to_user((void __user *)(statbuf + ST_BLKSIZE_OFF), &v32, sizeof(v32))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_BLOCKS) {
		v64 = e->spoofed_blocks;
		if (copy_to_user((void __user *)(statbuf + ST_BLOCKS_OFF), &v64, sizeof(v64))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_ATIME_TV_SEC) {
		sl = e->spoofed_atime_tv_sec;
		if (copy_to_user((void __user *)(statbuf + ST_ATIME_OFF), &sl, sizeof(sl))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_ATIME_TV_NSEC) {
		v = e->spoofed_atime_tv_nsec;
		if (copy_to_user((void __user *)(statbuf + ST_ATIME_NSEC_OFF), &v, sizeof(v))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_MTIME_TV_SEC) {
		sl = e->spoofed_mtime_tv_sec;
		if (copy_to_user((void __user *)(statbuf + ST_MTIME_OFF), &sl, sizeof(sl))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_MTIME_TV_NSEC) {
		v = e->spoofed_mtime_tv_nsec;
		if (copy_to_user((void __user *)(statbuf + ST_MTIME_NSEC_OFF), &v, sizeof(v))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_CTIME_TV_SEC) {
		sl = e->spoofed_ctime_tv_sec;
		if (copy_to_user((void __user *)(statbuf + ST_CTIME_OFF), &sl, sizeof(sl))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_CTIME_TV_NSEC) {
		v = e->spoofed_ctime_tv_nsec;
		if (copy_to_user((void __user *)(statbuf + ST_CTIME_NSEC_OFF), &v, sizeof(v))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}

	if (!rewrote)
		atomic_inc(&st->cnt->match_noflag);
	else
		atomic_inc(&st->cnt->rewrite);
	return rewrote;
}

/* AArch32 (compat) statbuf layouts.  There are TWO, and which one a syscall fills is decided by
 * its NUMBER, not by the caller being 32-bit:
 *   __NR_stat64 195, __NR_lstat64 196, __NR_fstat64 197, __NR_fstatat64 327 -> struct stat64
 *       (arch/arm64/include/asm/stat.h), filled by cp_new_stat64() via SYSCALL_DEFINE2(stat64)/
 *       (lstat64)/(fstat64) and SYSCALL_DEFINE4(fstatat64) (fs/stat.c, __ARCH_WANT_COMPAT_STAT64);
 *       this struct is NOT struct compat_stat.  All four are handled below (the first three keep
 *       statbuf in args[1], fstatat64 in args[2]).
 *   __NR_stat 106, __NR_lstat 107, __NR_fstat 108 -> struct compat_stat
 *       (arch/arm64/include/asm/compat.h) via cp_compat_stat().  They ARE mapped in this tree's
 *       arch/arm64/include/asm/unistd32.h (checked: 106 -> compat_sys_newstat, 107 -> newlstat,
 *       108 -> newfstat). They use separate compat_stat offsets and width checks below;
 *       interpreting these buffers as stat64 would corrupt unrelated fields.
 *       AArch32 statx(397) continues to use the fixed-width statx layout.
 *
 * ALIGNMENT (these numbers were established twice): compat_u64/compat_s64 are
 * __attribute__((aligned(4))) only when CONFIG_COMPAT_FOR_U64_ALIGNMENT is set
 * (include/asm-generic/compat.h), and only the 32-bit arm architecture selects it - so on this
 * arm64 kernel the plain `typedef s64 compat_s64;` applies, u64 members keep natural 8-byte
 * alignment, and st_size is at +48 (not +44), st_ino at +96 (not +88).  A 4-byte-aligned read is
 * not a silent near-miss - measured on device with tools/susfs_compat_stat, a 6-byte file reported
 * size=25769803776 = 6 << 32 (low half from padding, high half from the value).  The offsets below
 * are what that client and the kernel agree on. */
#define STAT64_ST_DEV_OFF       0	/* compat_u64 */
#define STAT64_ST_BROKEN_INO_OFF 12	/* compat_ulong_t __st_ino (one of the two ino fields) */
#define STAT64_ST_NLINK_OFF     20	/* compat_uint_t */
#define STAT64_ST_SIZE_OFF      48	/* compat_s64 */
#define STAT64_ST_BLKSIZE_OFF   56	/* compat_ulong_t */
#define STAT64_ST_BLOCKS_OFF    64	/* compat_u64 */
#define STAT64_ST_ATIME_OFF     72
#define STAT64_ST_ATIME_NSEC_OFF 76
#define STAT64_ST_MTIME_OFF     80
#define STAT64_ST_MTIME_NSEC_OFF 84
#define STAT64_ST_CTIME_OFF     88
#define STAT64_ST_CTIME_NSEC_OFF 92
#define STAT64_ST_INO_OFF       96	/* compat_u64 st_ino (also written; the KEY is read from +12) */
#define STAT64_ST_SIZE          104

/* struct compat_stat (the AArch32 stat()/lstat()/fstat() layout, 106/107/108).  Unlike the struct
 * stat64 block above these are taken from the kernel's OWN type (linux/compat.h -> asm/compat.h),
 * so a layout drift in any of the eight build variants fails the build instead of mis-writing a
 * user buffer.  The numbers are identical on 5.15 and 6.6 (checked field by field); the asserts
 * below are what keeps that true for 6.12/6.18 too.
 *
 * Field widths are the reason this needs its own write path and not a re-read of the stat64 one:
 *   st_dev u32 (new_encode_dev, so the same key as every other family), st_ino u32, st_mode u16,
 *   st_nlink u16, st_uid/st_gid u16, st_rdev u32, st_size/st_blksize/st_blocks s32 (compat_off_t),
 *   st_atime/st_mtime/st_ctime s32 (old_time32_t) and their _nsec u32 (compat_ulong_t).
 * cp_compat_stat() (fs/stat.c, identical in 5.15 and 6.6) writes exactly those, and it *refuses*
 * three of them instead of truncating: an ino or nlink that does not fit its 32/16 bits, and a size
 * above MAX_NON_LFS, all answer -EOVERFLOW.  The write-back below follows the same rule (skip the
 * field, count it in `narrow`) rather than writing a value the kernel itself would never have put
 * there.  st_blksize/st_blocks/the timestamps are plain assignments in the kernel, so those are
 * written at their own width like it does. */
#define COMPAT_STAT_ST_DEV_OFF		((int)offsetof(struct compat_stat, st_dev))
#define COMPAT_STAT_ST_INO_OFF		((int)offsetof(struct compat_stat, st_ino))
#define COMPAT_STAT_ST_NLINK_OFF	((int)offsetof(struct compat_stat, st_nlink))
#define COMPAT_STAT_ST_SIZE_OFF		((int)offsetof(struct compat_stat, st_size))
#define COMPAT_STAT_ST_BLKSIZE_OFF	((int)offsetof(struct compat_stat, st_blksize))
#define COMPAT_STAT_ST_BLOCKS_OFF	((int)offsetof(struct compat_stat, st_blocks))
#define COMPAT_STAT_ST_ATIME_OFF	((int)offsetof(struct compat_stat, st_atime))
#define COMPAT_STAT_ST_ATIME_NSEC_OFF	((int)offsetof(struct compat_stat, st_atime_nsec))
#define COMPAT_STAT_ST_MTIME_OFF	((int)offsetof(struct compat_stat, st_mtime))
#define COMPAT_STAT_ST_MTIME_NSEC_OFF	((int)offsetof(struct compat_stat, st_mtime_nsec))
#define COMPAT_STAT_ST_CTIME_OFF	((int)offsetof(struct compat_stat, st_ctime))
#define COMPAT_STAT_ST_CTIME_NSEC_OFF	((int)offsetof(struct compat_stat, st_ctime_nsec))

static_assert(offsetof(struct compat_stat, st_dev) == 0, "compat_stat.st_dev");
static_assert(offsetof(struct compat_stat, st_ino) == 4, "compat_stat.st_ino");
static_assert(offsetof(struct compat_stat, st_mode) == 8, "compat_stat.st_mode");
static_assert(offsetof(struct compat_stat, st_nlink) == 10, "compat_stat.st_nlink");
static_assert(offsetof(struct compat_stat, st_rdev) == 16, "compat_stat.st_rdev");
static_assert(offsetof(struct compat_stat, st_size) == 20, "compat_stat.st_size");
static_assert(offsetof(struct compat_stat, st_blksize) == 24, "compat_stat.st_blksize");
static_assert(offsetof(struct compat_stat, st_blocks) == 28, "compat_stat.st_blocks");
static_assert(offsetof(struct compat_stat, st_atime) == 32, "compat_stat.st_atime");
static_assert(offsetof(struct compat_stat, st_atime_nsec) == 36, "compat_stat.st_atime_nsec");
static_assert(offsetof(struct compat_stat, st_mtime) == 40, "compat_stat.st_mtime");
static_assert(offsetof(struct compat_stat, st_mtime_nsec) == 44, "compat_stat.st_mtime_nsec");
static_assert(offsetof(struct compat_stat, st_ctime) == 48, "compat_stat.st_ctime");
static_assert(offsetof(struct compat_stat, st_ctime_nsec) == 52, "compat_stat.st_ctime_nsec");
static_assert(sizeof(struct compat_stat) == 64, "compat_stat size");
/* The widths the write-back has to respect (see the note above): if any of these ever changed, the
 * `narrow` decisions below would silently become wrong. */
static_assert(sizeof(((struct compat_stat *)0)->st_dev) == 4, "compat_stat.st_dev width");
static_assert(sizeof(((struct compat_stat *)0)->st_ino) == 4, "compat_stat.st_ino width");
static_assert(sizeof(((struct compat_stat *)0)->st_nlink) == 2, "compat_stat.st_nlink width");
static_assert(sizeof(((struct compat_stat *)0)->st_size) == 4, "compat_stat.st_size width");
static_assert(sizeof(((struct compat_stat *)0)->st_blksize) == 4, "compat_stat.st_blksize width");
static_assert(sizeof(((struct compat_stat *)0)->st_blocks) == 4, "compat_stat.st_blocks width");
static_assert(sizeof(((struct compat_stat *)0)->st_atime) == 4, "compat_stat.st_atime width");
static_assert(sizeof(((struct compat_stat *)0)->st_atime_nsec) == 4, "compat_stat.st_atime_nsec width");

/* ARM EABI syscall numbers that fill struct stat64 (arch/arm64/include/asm/unistd32.h; the
 * statbuf argument position is from fs/stat.c's COMPAT_SYSCALL_DEFINE2/4). */
#define COMPAT_FSTATAT64_NR	327	/* fstatat64(dfd, path, statbuf, flag) */
#define COMPAT_STAT64_NR	195	/* stat64(path, statbuf) */
#define COMPAT_LSTAT64_NR	196	/* lstat64(path, statbuf) */
#define COMPAT_FSTAT64_NR	197	/* fstat64(fd, statbuf) */
#define COMPAT_STATX_NR		397	/* statx(dfd, path, flags, mask, statxbuf) */
#define COMPAT_STAT_NR		106	/* stat(path, struct compat_stat *) */
#define COMPAT_LSTAT_NR		107
#define COMPAT_FSTAT_NR		108

/* The listing (getdents) numbers sus_path's rewrite answers for.  Spelled out rather than taken
 * from asm/unistd.h, which is unreachable in this build: native getdents64 is 61
 * (include/uapi/asm-generic/unistd.h), and the AArch32 table (arch/arm64/include/asm/unistd32.h)
 * maps 217 to the SAME native body while 141 is its own compat body.  Kept here next to the
 * dispatcher that tests them, in the file that owns the tracepoint. */
#define KSTAT_NR_GETDENTS64	61
#define COMPAT_GETDENTS64_NR	217
#define COMPAT_GETDENTS_NR	141

/* ---- the whitelist as data ----
 *
 * Defined here, after the numbers above: it is built from the same constants the dispatcher
 * compares against, so a number cannot be handled by one and missing from the other, and /proc's
 * report reads this one list. */
struct kstat_nr_entry {
	long nr;
	const char *name;
	struct kstat_call_counters *cnt;
};

/* The dispatch state (struct kstat_call_state) and the helpers are defined above; the table
 * itself is here because it is built from the numbers below. */
static struct kstat_nr_entry kstat_nr_table[] = {
	{ __NR_newfstatat, "newfstatat", &cnt_nfstatat },
	{ __NR_fstat,      "fstat",      &cnt_nfstat },
	{ __NR_statx,      "statx",      &cnt_statx },
	{ COMPAT_FSTATAT64_NR, "fstatat64/compat", &cnt_fstatat64 },
	{ COMPAT_STAT64_NR,    "stat64/compat",    &cnt_stat64 },
	{ COMPAT_LSTAT64_NR,   "lstat64/compat",   &cnt_lstat64 },
	{ COMPAT_FSTAT64_NR,   "fstat64/compat",   &cnt_fstat64 },
	{ COMPAT_STATX_NR,     "statx/compat",     &cnt_compat_statx },
	{ COMPAT_STAT_NR,      "stat/compat",      &cnt_compat_stat },
	{ COMPAT_LSTAT_NR,     "lstat/compat",     &cnt_compat_lstat },
	{ COMPAT_FSTAT_NR,     "fstat/compat",     &cnt_compat_fstat },
};

/* compat (32-bit) statbuf: struct stat64 (see above) - the layout all four handled syscalls use. */
static bool susfs_kstat_spoof_compat_statbuf(struct kstat_call_state *st, unsigned long statbuf)
{
	struct sus_kstat_snapshot snap;
	const struct sus_kstat_snapshot *e = &snap;
	unsigned long long v64;
	unsigned int ino = 0, dev = 0;
	unsigned int v32;
	int v;
	bool rewrote = false;

	if (susfs_kstat_table_empty()) {
		atomic_inc(&st->cnt->miss_empty);
		return false;
	}
	if (!susfs_kstat_gate_ok()) {
		atomic_inc(&st->cnt->miss_gate);
		return false;
	}

	/* Key lookup on what the kernel ACTUALLY filled: __st_ino at +12.  stat64 carries the
	 * STAT64_HAS_BROKEN_ST_INO marker (arch/arm64/include/asm/stat.h), so cp_new_stat64() writes
	 * __st_ino and leaves st_ino (+96) alone - reading the key from +96 would compare against
	 * whatever the caller's buffer held and never match.  Both fields are written when spoofing, so
	 * a libc that synthesises st_ino from __st_ino and one that reads st_ino directly both see the
	 * spoofed value. */
	if (copy_from_user(&ino, (void __user *)(statbuf + STAT64_ST_BROKEN_INO_OFF), sizeof(ino))) {
		atomic_inc(&st->cnt->uaccess);
		return false;
	}
	if (copy_from_user(&dev, (void __user *)(statbuf + STAT64_ST_DEV_OFF), sizeof(dev))) {
		atomic_inc(&st->cnt->uaccess);
		return false;
	}
	if (!susfs_kstat_lookup(ino, dev, &snap)) {
		atomic_inc(&st->cnt->miss_lookup);
		return false;
	}

	if (e->flags & KSTAT_SPOOF_INO) {
		v32 = (unsigned int)e->spoofed_ino;
		if (copy_to_user((void __user *)(statbuf + STAT64_ST_BROKEN_INO_OFF), &v32, sizeof(v32))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		v64 = (unsigned long long)e->spoofed_ino;
		if (copy_to_user((void __user *)(statbuf + STAT64_ST_INO_OFF), &v64, sizeof(v64))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_DEV) {
		v64 = (unsigned long long)e->spoofed_dev;
		if (copy_to_user((void __user *)(statbuf + STAT64_ST_DEV_OFF), &v64, sizeof(v64))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_NLINK) {
		v32 = (unsigned int)e->spoofed_nlink;
		if (copy_to_user((void __user *)(statbuf + STAT64_ST_NLINK_OFF), &v32, sizeof(v32))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_SIZE) {
		v64 = (unsigned long long)e->spoofed_size;
		if (copy_to_user((void __user *)(statbuf + STAT64_ST_SIZE_OFF), &v64, sizeof(v64))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_BLKSIZE) {
		v32 = (unsigned int)e->spoofed_blksize;
		if (copy_to_user((void __user *)(statbuf + STAT64_ST_BLKSIZE_OFF), &v32, sizeof(v32))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_BLOCKS) {
		v64 = (unsigned long long)e->spoofed_blocks;
		if (copy_to_user((void __user *)(statbuf + STAT64_ST_BLOCKS_OFF), &v64, sizeof(v64))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_ATIME_TV_SEC) {
		v = (int)e->spoofed_atime_tv_sec;
		if (copy_to_user((void __user *)(statbuf + STAT64_ST_ATIME_OFF), &v, sizeof(v))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_ATIME_TV_NSEC) {
		v32 = (unsigned int)e->spoofed_atime_tv_nsec;
		if (copy_to_user((void __user *)(statbuf + STAT64_ST_ATIME_NSEC_OFF), &v32, sizeof(v32))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_MTIME_TV_SEC) {
		v = (int)e->spoofed_mtime_tv_sec;
		if (copy_to_user((void __user *)(statbuf + STAT64_ST_MTIME_OFF), &v, sizeof(v))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_MTIME_TV_NSEC) {
		v32 = (unsigned int)e->spoofed_mtime_tv_nsec;
		if (copy_to_user((void __user *)(statbuf + STAT64_ST_MTIME_NSEC_OFF), &v32, sizeof(v32))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_CTIME_TV_SEC) {
		v = (int)e->spoofed_ctime_tv_sec;
		if (copy_to_user((void __user *)(statbuf + STAT64_ST_CTIME_OFF), &v, sizeof(v))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_CTIME_TV_NSEC) {
		v32 = (unsigned int)e->spoofed_ctime_tv_nsec;
		if (copy_to_user((void __user *)(statbuf + STAT64_ST_CTIME_NSEC_OFF), &v32, sizeof(v32))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}

	if (!rewrote)
		atomic_inc(&st->cnt->match_noflag);
	else
		atomic_inc(&st->cnt->rewrite);
	return rewrote;
}

/* ---- statx(2): a different struct, and a MASK contract ----
 *
 * struct statx (include/uapi/linux/stat.h) is not struct stat and not struct stat64: the offsets
 * come from offsetof() rather than being spelled out, because a wrong offset here corrupts the
 * caller's buffer instead of failing - and the static_asserts below make such a change a build
 * failure.  Timestamp seconds are s64, nanoseconds are u32 and the device pair is u32/u32.
 *
 * Preserve the existing request-mask OR returned-mask contract. A rule selects the fields to
 * spoof and each masked field also requires its effective UAPI bit. The returned stx_mask itself
 * is left unchanged. The pinned vfs_getattr_nosec() fills STATX_BASIC_STATS, including fields
 * that a narrow inode-only or size-only request did not ask for.
 * stx_blksize has no mask bit in this UAPI and is written whenever the rule selects it.
 * cp_statx() always writes the device pair, which has no field bit; its rewrite requires the
 * rule's DEV flag and any effective basic-stat bit. Unselected fields and reserved bytes retain
 * the kernel's values. Root gating and snapshot locking precede every user-buffer write.
 *
 * The four STATX_F_* names below are just names for the UAPI bits that gate each field, so a write
 * site reads as "this field, under its own bit" without the bit's spelling repeated. */
static bool susfs_kstat_spoof_compat_stat(struct kstat_call_state *st, unsigned long statbuf)
{
	struct sus_kstat_snapshot snap;
	const struct sus_kstat_snapshot *e = &snap;
	unsigned int ino = 0, dev = 0, v32;
	unsigned short v16;
	int v;
	bool rewrote = false;

	if (susfs_kstat_table_empty()) {
		atomic_inc(&st->cnt->miss_empty);
		return false;
	}
	if (!susfs_kstat_gate_ok()) {
		atomic_inc(&st->cnt->miss_gate);
		return false;
	}

	if (copy_from_user(&ino, (void __user *)(statbuf + COMPAT_STAT_ST_INO_OFF), sizeof(ino))) {
		atomic_inc(&st->cnt->uaccess);
		return false;
	}
	if (copy_from_user(&dev, (void __user *)(statbuf + COMPAT_STAT_ST_DEV_OFF), sizeof(dev))) {
		atomic_inc(&st->cnt->uaccess);
		return false;
	}
	if (!susfs_kstat_lookup(ino, dev, &snap)) {
		atomic_inc(&st->cnt->miss_lookup);
		return false;
	}

	if (e->flags & KSTAT_SPOOF_INO) {
		if (e->spoofed_ino > 0xffffffffUL) {
			atomic_inc(&st->cnt->narrow);
		} else {
			v32 = (unsigned int)e->spoofed_ino;
			if (copy_to_user((void __user *)(statbuf + COMPAT_STAT_ST_INO_OFF), &v32, sizeof(v32))) {
				atomic_inc(&st->cnt->uaccess);
				return false;
			}
			rewrote = true;
		}
	}
	if (e->flags & KSTAT_SPOOF_DEV) {
		/* new_encode_dev() of a dev_t is a u32 by construction: always representable. */
		v32 = (unsigned int)e->spoofed_dev;
		if (copy_to_user((void __user *)(statbuf + COMPAT_STAT_ST_DEV_OFF), &v32, sizeof(v32))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_NLINK) {
		if (e->spoofed_nlink > 0xffffU) {
			atomic_inc(&st->cnt->narrow);
		} else {
			v16 = (unsigned short)e->spoofed_nlink;
			if (copy_to_user((void __user *)(statbuf + COMPAT_STAT_ST_NLINK_OFF), &v16, sizeof(v16))) {
				atomic_inc(&st->cnt->uaccess);
				return false;
			}
			rewrote = true;
		}
	}
	if (e->flags & KSTAT_SPOOF_SIZE) {
		if (e->spoofed_size < 0 || e->spoofed_size > 0x7fffffffLL) {
			atomic_inc(&st->cnt->narrow);
		} else {
			v = (int)e->spoofed_size;
			if (copy_to_user((void __user *)(statbuf + COMPAT_STAT_ST_SIZE_OFF), &v, sizeof(v))) {
				atomic_inc(&st->cnt->uaccess);
				return false;
			}
			rewrote = true;
		}
	}
	if (e->flags & KSTAT_SPOOF_BLKSIZE) {
		v = (int)e->spoofed_blksize;
		if (copy_to_user((void __user *)(statbuf + COMPAT_STAT_ST_BLKSIZE_OFF), &v, sizeof(v))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_BLOCKS) {
		v = (int)e->spoofed_blocks;
		if (copy_to_user((void __user *)(statbuf + COMPAT_STAT_ST_BLOCKS_OFF), &v, sizeof(v))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_ATIME_TV_SEC) {
		v = (int)e->spoofed_atime_tv_sec;
		if (copy_to_user((void __user *)(statbuf + COMPAT_STAT_ST_ATIME_OFF), &v, sizeof(v))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_ATIME_TV_NSEC) {
		v32 = (unsigned int)e->spoofed_atime_tv_nsec;
		if (copy_to_user((void __user *)(statbuf + COMPAT_STAT_ST_ATIME_NSEC_OFF), &v32, sizeof(v32))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_MTIME_TV_SEC) {
		v = (int)e->spoofed_mtime_tv_sec;
		if (copy_to_user((void __user *)(statbuf + COMPAT_STAT_ST_MTIME_OFF), &v, sizeof(v))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_MTIME_TV_NSEC) {
		v32 = (unsigned int)e->spoofed_mtime_tv_nsec;
		if (copy_to_user((void __user *)(statbuf + COMPAT_STAT_ST_MTIME_NSEC_OFF), &v32, sizeof(v32))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_CTIME_TV_SEC) {
		v = (int)e->spoofed_ctime_tv_sec;
		if (copy_to_user((void __user *)(statbuf + COMPAT_STAT_ST_CTIME_OFF), &v, sizeof(v))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_CTIME_TV_NSEC) {
		v32 = (unsigned int)e->spoofed_ctime_tv_nsec;
		if (copy_to_user((void __user *)(statbuf + COMPAT_STAT_ST_CTIME_NSEC_OFF), &v32, sizeof(v32))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}

	if (!rewrote)
		atomic_inc(&st->cnt->match_noflag);
	else
		atomic_inc(&st->cnt->rewrite);
	return rewrote;
}

#define STATX_F_INO		STATX_INO
#define STATX_F_NLINK		STATX_NLINK
#define STATX_F_SIZE		STATX_SIZE
#define STATX_F_BLOCKS		STATX_BLOCKS

struct susfs_statx_offs {
	unsigned short dev_major, dev_minor, ino, nlink, size, blksize, blocks;
	unsigned short atime_sec, atime_nsec, mtime_sec, mtime_nsec,
		       ctime_sec, ctime_nsec, mask;
};

static const struct susfs_statx_offs kstat_statx_offs = {
	.dev_major = offsetof(struct statx, stx_dev_major),
	.dev_minor = offsetof(struct statx, stx_dev_minor),
	.ino = offsetof(struct statx, stx_ino),
	.nlink = offsetof(struct statx, stx_nlink),
	.size = offsetof(struct statx, stx_size),
	.blksize = offsetof(struct statx, stx_blksize),
	.blocks = offsetof(struct statx, stx_blocks),
	.atime_sec = offsetof(struct statx, stx_atime) + offsetof(struct statx_timestamp, tv_sec),
	.atime_nsec = offsetof(struct statx, stx_atime) + offsetof(struct statx_timestamp, tv_nsec),
	.mtime_sec = offsetof(struct statx, stx_mtime) + offsetof(struct statx_timestamp, tv_sec),
	.mtime_nsec = offsetof(struct statx, stx_mtime) + offsetof(struct statx_timestamp, tv_nsec),
	.ctime_sec = offsetof(struct statx, stx_ctime) + offsetof(struct statx_timestamp, tv_sec),
	.ctime_nsec = offsetof(struct statx, stx_ctime) + offsetof(struct statx_timestamp, tv_nsec),
	.mask = offsetof(struct statx, stx_mask),
};

/* A wrong offset here is the whole failure mode: an assert per field, not one for the struct.
 * The numbers were confirmed against the real layout twice - once by these asserts in CI, and once
 * by a host-side copy of the same structs (dist/statx_offs.c, not part of the build), because a
 * wrong offset CORRUPTS the caller's buffer instead of failing anything. */
static_assert(offsetof(struct statx, stx_mask) == 0x00, "statx.stx_mask");
static_assert(offsetof(struct statx, stx_blksize) == 0x04, "statx.stx_blksize");
static_assert(offsetof(struct statx, stx_attributes) == 0x08, "statx.stx_attributes");
static_assert(offsetof(struct statx, stx_nlink) == 0x10, "statx.stx_nlink");
static_assert(offsetof(struct statx, stx_ino) == 0x20, "statx.stx_ino");
static_assert(offsetof(struct statx, stx_size) == 0x28, "statx.stx_size");
static_assert(offsetof(struct statx, stx_blocks) == 0x30, "statx.stx_blocks");
static_assert(offsetof(struct statx, stx_atime) == 0x40, "statx.stx_atime");
static_assert(offsetof(struct statx, stx_btime) == 0x50, "statx.stx_btime");
static_assert(offsetof(struct statx, stx_ctime) == 0x60, "statx.stx_ctime");
static_assert(offsetof(struct statx, stx_mtime) == 0x70, "statx.stx_mtime");
/* statx carries separate major/minor values. Rules use new_encode_dev(), as struct stat does.
 * Both directions must convert the pair, rather than treating the major as an encoded dev. */
static_assert(offsetof(struct statx, stx_dev_major) == 0x88, "statx.stx_dev_major");
static_assert(offsetof(struct statx, stx_dev_minor) == 0x8c, "statx.stx_dev_minor");
static_assert(offsetof(struct statx, stx_mnt_id) == 0x90, "statx.stx_mnt_id");
static_assert(sizeof(struct statx) == 256, "statx size");
static_assert(sizeof(((struct statx *)0)->stx_ino) == 8, "statx stx_ino is u64");
static_assert(sizeof(((struct statx *)0)->stx_size) == 8, "statx stx_size is u64");
static_assert(sizeof(((struct statx *)0)->stx_dev_major) == 4, "statx dev major is u32");
static_assert(sizeof(((struct statx *)0)->stx_dev_minor) == 4, "statx dev minor is u32");
static_assert(offsetof(struct statx_timestamp, tv_sec) == 0, "statx timestamp seconds");
static_assert(offsetof(struct statx_timestamp, tv_nsec) == 8, "statx timestamp nanoseconds");
static_assert(sizeof(((struct statx_timestamp *)0)->tv_sec) == 8, "statx timestamp seconds are s64");
static_assert(sizeof(((struct statx_timestamp *)0)->tv_nsec) == 4, "statx timestamp nanoseconds are u32");

/* Read a field of the buffer, write the spoofed value back only when the mask carries the field. */
#define STATX_FIELD_U64(off, val, mbit)						\
	do {									\
		if (eff & (mbit)) {						\
			u64 __v = (u64)(val);					\
										\
			if (copy_to_user((void __user *)(sbuf + (off)), &__v,	\
					 sizeof(__v))) {			\
				atomic_inc(&st->cnt->uaccess);			\
				return false;					\
			}							\
			rewrote = true;						\
		}								\
	} while (0)

#define STATX_FIELD_S64(off, val, mbit)						\
	do {									\
		if (eff & (mbit)) {						\
			s64 __v = (s64)(val);					\
										\
			if (copy_to_user((void __user *)(sbuf + (off)), &__v,	\
					 sizeof(__v))) {			\
				atomic_inc(&st->cnt->uaccess);			\
				return false;					\
			}							\
			rewrote = true;						\
		}								\
	} while (0)

#define STATX_FIELD_U32(off, val, mbit)						\
	do {									\
		if (eff & (mbit)) {						\
			u32 __v = (u32)(val);					\
										\
			if (copy_to_user((void __user *)(sbuf + (off)), &__v,	\
					 sizeof(__v))) {			\
				atomic_inc(&st->cnt->uaccess);			\
				return false;					\
			}							\
			rewrote = true;						\
		}								\
	} while (0)

/* returns true when the buffer was really changed */
static bool susfs_kstat_spoof_statx(struct kstat_call_state *st, unsigned long sbuf,
				    u32 req_mask)
{
	const struct susfs_statx_offs *o = &kstat_statx_offs;
	struct sus_kstat_snapshot snap;
	const struct sus_kstat_snapshot *e = &snap;
	unsigned long ino = 0;
	dev_t dev;
	u32 dev_major = 0, dev_minor = 0;
	u32 buf_mask = 0, eff;
	bool rewrote = false;

	if (susfs_kstat_table_empty()) {
		atomic_inc(&st->cnt->miss_empty);
		return false;
	}
	if (!susfs_kstat_gate_ok()) {
		atomic_inc(&st->cnt->miss_gate);
		return false;
	}

	/* Convert cp_statx()'s major/minor pair to the encoded device used by the rule table. */
	if (copy_from_user(&ino, (void __user *)(sbuf + o->ino), sizeof(ino))) {
		atomic_inc(&st->cnt->uaccess);
		return false;
	}
	if (copy_from_user(&dev_major, (void __user *)(sbuf + o->dev_major), sizeof(dev_major))) {
		atomic_inc(&st->cnt->uaccess);
		return false;
	}
	if (copy_from_user(&dev_minor, (void __user *)(sbuf + o->dev_minor), sizeof(dev_minor))) {
		atomic_inc(&st->cnt->uaccess);
		return false;
	}
	if (copy_from_user(&buf_mask, (void __user *)(sbuf + o->mask), sizeof(buf_mask))) {
		atomic_inc(&st->cnt->uaccess);
		return false;
	}

	dev = new_encode_dev(MKDEV(dev_major, dev_minor));
	if (!susfs_kstat_lookup(ino, dev, &snap)) {
		atomic_inc(&st->cnt->miss_lookup);
		return false;
	}

	eff = req_mask | buf_mask;

	if (e->flags & KSTAT_SPOOF_INO)
		STATX_FIELD_U64(o->ino, e->spoofed_ino, STATX_F_INO);
	if (e->flags & KSTAT_SPOOF_NLINK)
		STATX_FIELD_U32(o->nlink, e->spoofed_nlink, STATX_F_NLINK);
	if (e->flags & KSTAT_SPOOF_SIZE)
		STATX_FIELD_U64(o->size, e->spoofed_size, STATX_F_SIZE);
	if (e->flags & KSTAT_SPOOF_BLOCKS)
		STATX_FIELD_U64(o->blocks, e->spoofed_blocks, STATX_F_BLOCKS);
	/* Unconditional by design - see the mask note above the offset table: no mask bit covers
	 * stx_blksize on this kernel, while cp_statx() always fills it. */
	if (e->flags & KSTAT_SPOOF_BLKSIZE) {
		s32 v = (s32)e->spoofed_blksize;

		if (copy_to_user((void __user *)(sbuf + o->blksize), &v, sizeof(v))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}
	if (e->flags & KSTAT_SPOOF_ATIME_TV_SEC)
		STATX_FIELD_S64(o->atime_sec, e->spoofed_atime_tv_sec, STATX_ATIME);
	if (e->flags & KSTAT_SPOOF_ATIME_TV_NSEC)
		STATX_FIELD_U32(o->atime_nsec, e->spoofed_atime_tv_nsec, STATX_ATIME);
	if (e->flags & KSTAT_SPOOF_MTIME_TV_SEC)
		STATX_FIELD_S64(o->mtime_sec, e->spoofed_mtime_tv_sec, STATX_MTIME);
	if (e->flags & KSTAT_SPOOF_MTIME_TV_NSEC)
		STATX_FIELD_U32(o->mtime_nsec, e->spoofed_mtime_tv_nsec, STATX_MTIME);
	if (e->flags & KSTAT_SPOOF_CTIME_TV_SEC)
		STATX_FIELD_S64(o->ctime_sec, e->spoofed_ctime_tv_sec, STATX_CTIME);
	if (e->flags & KSTAT_SPOOF_CTIME_TV_NSEC)
		STATX_FIELD_U32(o->ctime_nsec, e->spoofed_ctime_tv_nsec, STATX_CTIME);
	/* The device pair: stx_dev_major/minor are always written by cp_statx() and have no mask bit,
	 * so the condition is "the rule spoofs dev" AND "this call fills the basic set at all" - the
	 * second half is what keeps a caller that asked for nothing in particular from getting a
	 * spoofed dev out of a buffer it does not otherwise trust. */
	if ((e->flags & KSTAT_SPOOF_DEV) && (eff & STATX_BASIC_STATS)) {
		dev_t decoded = new_decode_dev((u32)e->spoofed_dev);
		u32 maj = MAJOR(decoded);
		u32 min = MINOR(decoded);

		if (copy_to_user((void __user *)(sbuf + o->dev_major), &maj, sizeof(maj))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		if (copy_to_user((void __user *)(sbuf + o->dev_minor), &min, sizeof(min))) {
			atomic_inc(&st->cnt->uaccess);
			return false;
		}
		rewrote = true;
	}

	/* Nothing to raise: vfs_getattr_nosec() sets STATX_BASIC_STATS on this kernel, so the buffer's
	 * mask already names every field written above - and the two fields that are written without a
	 * mask bit (stx_blksize, stx_dev) have no bit to raise.  Re-writing the mask is therefore
	 * deliberately NOT done: a mask write is one more chance to corrupt the caller's buffer for no
	 * gain.  The consequence, stated plainly because it is the sort of thing a reviewer should
	 * check: this rewriter can only ever produce a buffer whose mask is the kernel's own. */
	if (!rewrote) {
		atomic_inc(&st->cnt->match_noflag);
		return false;
	}

	atomic_inc(&st->cnt->rewrite);
	return true;
}

/* ---- the ONE sys_exit tracepoint in this module ----
 * Select the task ABI before interpreting a syscall number or touching its arguments.
 * Native and AArch32 numbers overlap but describe different operations.  The original
 * number survives even where both tables call the same implementation (statx/getdents64).
 * Unrelated syscalls pay only comparisons: no argument reads, counters, or user accesses.
 * This tracepoint cannot sleep; the rewriters own their locking and uaccess handling. */
static void kstat_sys_exit(void *data, struct pt_regs *regs, long ret)
{
	enum { KSTAT_NATIVE_STAT, KSTAT_COMPAT_STAT64, KSTAT_COMPAT_STAT, KSTAT_STATX } layout;
	unsigned long args[6], statbuf;
	struct kstat_call_counters *c;
	struct kstat_call_state st;
	long nr = syscall_get_nr(current, regs);
	bool compat = is_compat_task();
	unsigned int buf_arg;

	if ((!compat && nr == KSTAT_NR_GETDENTS64) ||
	    (compat && (nr == COMPAT_GETDENTS64_NR || nr == COMPAT_GETDENTS_NR))) {
		long rc;

		syscall_get_arguments(current, regs, args);
		rc = sus_path_dirent_filter(nr,
			compat ? (unsigned long)compat_ptr((u32)args[1]) : args[1], ret);
		if (rc != ret)
			syscall_set_return_value(current, regs, 0, rc);
		return;
	}

	if (compat) {
		layout = KSTAT_COMPAT_STAT64;
		buf_arg = 1;
		switch (nr) {
		case COMPAT_FSTATAT64_NR:
			c = &cnt_fstatat64;
			buf_arg = 2;
			break;
		case COMPAT_STAT64_NR:
			c = &cnt_stat64;
			break;
		case COMPAT_LSTAT64_NR:
			c = &cnt_lstat64;
			break;
		case COMPAT_FSTAT64_NR:
			c = &cnt_fstat64;
			break;
		case COMPAT_STATX_NR:
			c = &cnt_compat_statx;
			layout = KSTAT_STATX;
			buf_arg = 4;
			break;
		case COMPAT_STAT_NR:
			c = &cnt_compat_stat;
			layout = KSTAT_COMPAT_STAT;
			break;
		case COMPAT_LSTAT_NR:
			c = &cnt_compat_lstat;
			layout = KSTAT_COMPAT_STAT;
			break;
		case COMPAT_FSTAT_NR:
			c = &cnt_compat_fstat;
			layout = KSTAT_COMPAT_STAT;
			break;
		default:
			return;
		}
	} else {
		layout = KSTAT_NATIVE_STAT;
		buf_arg = 2;
		switch (nr) {
		case __NR_newfstatat:
			c = &cnt_nfstatat;
			break;
		case __NR_fstat:
			c = &cnt_nfstat;
			buf_arg = 1;
			break;
		case __NR_statx:
			c = &cnt_statx;
			layout = KSTAT_STATX;
			buf_arg = 4;
			break;
		default:
			return;
		}
	}

	if (ret != 0) {
		atomic_inc(&c->ret_err);
		return;
	}
	atomic_inc(&c->calls);
	st.cnt = c;
	st.compat = compat;
	syscall_get_arguments(current, regs, args);
	statbuf = compat ? (unsigned long)compat_ptr((u32)args[buf_arg]) : args[buf_arg];
	if (!statbuf) {
		atomic_inc(&c->no_buf);
		return;
	}

	/* sys_exit runs with preemption disabled. Keep all stat-buffer accesses non-faulting. */
	pagefault_disable();
	switch (layout) {
	case KSTAT_NATIVE_STAT:
		susfs_kstat_spoof_statbuf(&st, statbuf);
		break;
	case KSTAT_COMPAT_STAT64:
		susfs_kstat_spoof_compat_statbuf(&st, statbuf);
		break;
	case KSTAT_COMPAT_STAT:
		susfs_kstat_spoof_compat_stat(&st, statbuf);
		break;
	case KSTAT_STATX:
		susfs_kstat_spoof_statx(&st, statbuf, (u32)args[3]);
		break;
	}
	pagefault_enable();
}

/* NO vfs_getattr kretprobe here any more, and neither is the function that used to rewrite the
 * KERNEL struct kstat for it.  Both removals are measured, not aesthetic: the whole stat chain is
 * inlined by LTO on this GKI, so the probe was hit by 15 of 120 000 app-uid newfstatat calls
 * (noise, and its gattr_spoofs counter read 0 for every one of them) while costing a brk trap per
 * call that did reach it.  fstat() and statx() are whitelisted in the tracepoint above now, so the
 * fallback had no job left: the maps rewrite below edits the already-formatted line from the same
 * snapshot and never needed the kernel-kstat rewriter.
 * The "/proc/susfs_kstat" line that printed that probe's two counters is gone with it; in its place
 * are the per-syscall-number counters of the tracepoint, which cannot stay at 0 for a syscall that
 * is really being issued (see kstat_proc_show()). */

/* ---- path resolution + rule management (original SUSFS semantics) ---- */

/* resolve <path> to its CURRENT (ino, encoded dev).  Sleeps - never call it with kstat_table_lock held. */
static int susfs_kstat_resolve(const char *path, unsigned long *ino, dev_t *dev)
{
	struct path p;
	struct inode *inode;
	int err;

	err = kern_path(path, 0, &p);
	if (err)
		return err;
	inode = d_backing_inode(p.dentry);
	if (!inode) {
		path_put(&p);
		return -ENOENT;
	}
	*ino = inode->i_ino;
	*dev = new_encode_dev(inode->i_sb->s_dev);
	path_put(&p);
	return 0;
}

/* resolve <path> and fill the spoofed_* fields with its CURRENT stat (the generic_fillattr
 * mapping).  Fills a DETACHED entry only: callers build here, then commit through one of the
 * kstat_table_* helpers, so nothing half-built is ever visible to a reader. */
static int susfs_kstat_fill_from_path(struct sus_kstat_entry *e, const char *path)
{
	struct path p;
	struct inode *inode;
	int err;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 6, 0)
	/* 6.6 renamed the inode field to __i_ctime and marked it private ("use inode_*_ctime
	 * accessors!"), so reading it stopped compiling: "no member named 'i_ctime' in 'struct inode'".
	 * inode_get_ctime() returns the very same struct timespec64 by value; i_atime/i_mtime were NOT
	 * renamed in 6.6, so those two keep being read directly. */
	struct timespec64 ctime;
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
	/* Same story for atime/mtime, one move later: v6.11 replaced the `struct timespec64
	 * i_atime/i_mtime` fields of struct inode with the split `time64_t i_atime_sec/i_mtime_sec` +
	 * `u32 i_atime_nsec/i_mtime_nsec` (in the trees built here: android16-6.12
	 * include/linux/fs.h:669-674; android15-6.6 still has the old `struct timespec64 i_atime` at
	 * :664), so those two stopped compiling the same way.  inode_get_atime()/inode_get_mtime()
	 * reassemble the very same struct timespec64 by value (fs.h:1616-1622, :1651-1657), which is
	 * what the < 6.12 branch below reads directly.  The gate is on 6.12 rather than on 6.11
	 * because 6.11 is not a GKI kernel: the trees this module is built for are 6.6 (old fields)
	 * and 6.12/6.18 (accessors), and an untested 6.7-6.11 kernel is not something this claims. */
	struct timespec64 atime, mtime;
#endif

	err = kern_path(path, 0, &p);
	if (err)
		return err;
	inode = d_backing_inode(p.dentry);
	if (!inode) {
		path_put(&p);
		return -ENOENT;
	}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 6, 0)
	ctime = inode_get_ctime(inode);
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
	atime = inode_get_atime(inode);
	mtime = inode_get_mtime(inode);
#endif

	e->target_ino = inode->i_ino;
	e->target_dev = new_encode_dev(inode->i_sb->s_dev);
	e->spoofed_ino = inode->i_ino;
	e->spoofed_dev = new_encode_dev(inode->i_sb->s_dev);
	e->spoofed_nlink = inode->i_nlink;
	e->spoofed_size = inode->i_size;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
	e->spoofed_atime_tv_sec = atime.tv_sec;
	e->spoofed_atime_tv_nsec = atime.tv_nsec;
	e->spoofed_mtime_tv_sec = mtime.tv_sec;
	e->spoofed_mtime_tv_nsec = mtime.tv_nsec;
#else
	e->spoofed_atime_tv_sec = inode->i_atime.tv_sec;
	e->spoofed_atime_tv_nsec = inode->i_atime.tv_nsec;
	e->spoofed_mtime_tv_sec = inode->i_mtime.tv_sec;
	e->spoofed_mtime_tv_nsec = inode->i_mtime.tv_nsec;
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 6, 0)
	e->spoofed_ctime_tv_sec = ctime.tv_sec;
	e->spoofed_ctime_tv_nsec = ctime.tv_nsec;
#else
	e->spoofed_ctime_tv_sec = inode->i_ctime.tv_sec;
	e->spoofed_ctime_tv_nsec = inode->i_ctime.tv_nsec;
#endif
	e->spoofed_blocks = inode->i_blocks;
	e->spoofed_blksize = 1 << inode->i_blkbits;

	path_put(&p);
	return 0;
}

/* re-resolve only target_ino/target_dev; spoofed values stay untouched.  Resolve first (sleeping),
 * then re-target under the lock: a reader sees the old pair or the new pair, never ino-of-B with
 * dev-of-A. */
static int susfs_kstat_update(const char *path, bool full_clone)
{
	struct sus_kstat_entry *e;
	unsigned long ino;
	dev_t dev;
	int err;

	e = susfs_kstat_find_by_path(path);
	if (!e)
		return -ENOENT;
	err = susfs_kstat_resolve(path, &ino, &dev);
	if (err)
		return err;
	kstat_table_retarget((int)(e - kstat_entries), ino, dev,
			     full_clone ? KSTAT_AUTO_SPOOF_FULL_CLONE
					: KSTAT_AUTO_SPOOF);
	return 0;
}

/* add/update a rule from its pathname; kstat_lock held */
static int susfs_kstat_add(const char *path)
{
	struct sus_kstat_entry tmp;
	struct sus_kstat_entry *e;
	int err, idx;

	if (strlen(path) >= KSTAT_PATH_MAX)
		return -ENAMETOOLONG;

	e = susfs_kstat_find_by_path(path);

	memset(&tmp, 0, sizeof(tmp));
	err = susfs_kstat_fill_from_path(&tmp, path);
	if (err)
		return err;
	strscpy(tmp.target_pathname, path, KSTAT_PATH_MAX);
	tmp.flags = KSTAT_AUTO_SPOOF;

	if (e) {
		kstat_table_put((int)(e - kstat_entries), &tmp);
		return 0;
	}
	idx = kstat_table_append(&tmp);
	return idx < 0 ? -ENOSPC : 0;
}

static void susfs_kstat_del(const char *path)
{
	struct sus_kstat_entry *e = susfs_kstat_find_by_path(path);

	if (!e)
		return;
	kstat_table_del((int)(e - kstat_entries));
}

/* parse "default" -> *is_default=true, else parse signed 64-bit int */
static int parse_override(const char *tok, bool *is_default, long long *val)
{
	if (!strcmp(tok, "default")) {
		*is_default = true;
		return 0;
	}
	*is_default = false;
	return kstrtoll(tok, 10, val);
}

/* add_sus_kstat_statically: 12 fields follow the path, each a number or "default". */
static int susfs_kstat_add_statically(char **argv, int argc)
{
	struct sus_kstat_entry tmp;
	struct sus_kstat_entry *e;
	long long val;
	bool dflt;
	int err, i, idx;
	/* field index -> flag and setter, ordered as the CLI:
	 * ino dev nlink size atime atime_nsec mtime mtime_nsec
	 * ctime ctime_nsec blocks blksize */
	static const unsigned int f_flags[12] = {
		KSTAT_SPOOF_INO, KSTAT_SPOOF_DEV, KSTAT_SPOOF_NLINK,
		KSTAT_SPOOF_SIZE, KSTAT_SPOOF_ATIME_TV_SEC,
		KSTAT_SPOOF_ATIME_TV_NSEC, KSTAT_SPOOF_MTIME_TV_SEC,
		KSTAT_SPOOF_MTIME_TV_NSEC, KSTAT_SPOOF_CTIME_TV_SEC,
		KSTAT_SPOOF_CTIME_TV_NSEC, KSTAT_SPOOF_BLOCKS,
		KSTAT_SPOOF_BLKSIZE,
	};
	const char *path = argv[1];

	/* argv[2 + i] below reaches argv[13], so this needs argv[14]: assert it here and not only at
	 * the call site, whose `argc == 14` check is against a 16-slot argv. */
	if (argc < 2 + (int)ARRAY_SIZE(f_flags))
		return -EINVAL;

	if (strlen(path) >= KSTAT_PATH_MAX)
		return -ENAMETOOLONG;

	e = susfs_kstat_find_by_path(path);

	memset(&tmp, 0, sizeof(tmp));
	/* start from the CURRENT stat; non-default fields override it */
	err = susfs_kstat_fill_from_path(&tmp, path);
	if (err)
		return err;
	strscpy(tmp.target_pathname, path, KSTAT_PATH_MAX);
	tmp.flags = 0;

	for (i = 0; i < 12; i++) {
		err = parse_override(argv[2 + i], &dflt, &val);
		if (err)
			return err;
		if (dflt)
			continue;
		tmp.flags |= f_flags[i];
		switch (i) {
		case 0: tmp.spoofed_ino = (unsigned long)val; break;
		case 1: tmp.spoofed_dev = (unsigned long)val; break;
		case 2: tmp.spoofed_nlink = (unsigned int)val; break;
		case 3: tmp.spoofed_size = val; break;
		case 4: tmp.spoofed_atime_tv_sec = (long)val; break;
		case 5: tmp.spoofed_atime_tv_nsec = (unsigned long)val; break;
		case 6: tmp.spoofed_mtime_tv_sec = (long)val; break;
		case 7: tmp.spoofed_mtime_tv_nsec = (unsigned long)val; break;
		case 8: tmp.spoofed_ctime_tv_sec = (long)val; break;
		case 9: tmp.spoofed_ctime_tv_nsec = (unsigned long)val; break;
		case 10: tmp.spoofed_blocks = val; break;
		case 11: tmp.spoofed_blksize = (long)val; break;
		}
	}

	if (e) {
		kstat_table_put((int)(e - kstat_entries), &tmp);
		return 0;
	}
	idx = kstat_table_append(&tmp);
	return idx < 0 ? -ENOSPC : 0;
}

/* statically-add from the supercall ABI struct (is_statically=1): copy the caller's 12 spoofed
 * fields + flags verbatim; resolve target ino/dev here. */
static int susfs_kstat_add_statically_abi(struct st_susfs_sus_kstat *info)
{
	struct sus_kstat_entry tmp;
	struct sus_kstat_entry *e;
	int err, idx;

	e = susfs_kstat_find_by_path(info->target_pathname);

	memset(&tmp, 0, sizeof(tmp));
	err = susfs_kstat_fill_from_path(&tmp, info->target_pathname);
	if (err)
		return err;
	strscpy(tmp.target_pathname, info->target_pathname, KSTAT_PATH_MAX);

	tmp.spoofed_ino = info->spoofed_ino;
	tmp.spoofed_dev = info->spoofed_dev;
	tmp.spoofed_nlink = info->spoofed_nlink;
	tmp.spoofed_size = info->spoofed_size;
	tmp.spoofed_atime_tv_sec = info->spoofed_atime_tv_sec;
	tmp.spoofed_atime_tv_nsec = info->spoofed_atime_tv_nsec;
	tmp.spoofed_mtime_tv_sec = info->spoofed_mtime_tv_sec;
	tmp.spoofed_mtime_tv_nsec = info->spoofed_mtime_tv_nsec;
	tmp.spoofed_ctime_tv_sec = info->spoofed_ctime_tv_sec;
	tmp.spoofed_ctime_tv_nsec = info->spoofed_ctime_tv_nsec;
	tmp.spoofed_blocks = info->spoofed_blocks;
	tmp.spoofed_blksize = info->spoofed_blksize;
	tmp.flags = info->flags;

	if (e) {
		kstat_table_put((int)(e - kstat_entries), &tmp);
		return 0;
	}
	idx = kstat_table_append(&tmp);
	return idx < 0 ? -ENOSPC : 0;
}

/* supercall: CMD_SUSFS_ADD_SUS_KSTAT / UPDATE / STATICALLY */
void susfs_kstat_supercall(unsigned int cmd, void __user **arg)
{
	struct st_susfs_sus_kstat info = {0};
	int err = -EINVAL;

	if (copy_from_user(&info, (void __user *)*arg, sizeof(info))) {
		info.err = -EFAULT;
		goto out;
	}

	/* All three commands key on target_pathname, and a caller may fill all 256 bytes of that field -
	 * reject an unterminated one before any strlen() or kern_path() can walk off our stack copy. */
	if (!susfs_abi_path_ok(info.target_pathname, sizeof(info.target_pathname))) {
		info.err = -ENAMETOOLONG;
		goto out;
	}

	mutex_lock(&kstat_lock);
	err = kstat_maps_arm();
	if (err)
		goto unlock;
	err = -EINVAL;
	switch (cmd) {
	case CMD_SUSFS_ADD_SUS_KSTAT:
		err = susfs_kstat_add(info.target_pathname);
		break;
	case CMD_SUSFS_ADD_SUS_KSTAT_STATICALLY:
		err = susfs_kstat_add_statically_abi(&info);
		break;
	case CMD_SUSFS_UPDATE_SUS_KSTAT:
		err = susfs_kstat_update(info.target_pathname, false);
		break;
	}
unlock:
	mutex_unlock(&kstat_lock);
	info.err = err;
out:
	/* Upstream (fs/susfs.c susfs_add_sus_kstat) writes back ONLY the err field for this
	 * input-type command, never the whole struct: copying the full struct back would overrun a
	 * caller whose own struct is smaller/differently laid out (the prebuilt ksu_susfs tool) and
	 * corrupt its stack - match upstream exactly. */
	if (copy_to_user(&((struct st_susfs_sus_kstat __user *)*arg)->err,
			 &info.err, sizeof(info.err)))
		pr_warn("kstat supercall copy_to_user failed\n");
}

/* ---- /proc/susfs_kstat: runtime rule management ---- */
static int kstat_proc_show(struct seq_file *m, void *v);
static int kstat_proc_open(struct inode *inode, struct file *file);
static ssize_t kstat_proc_write(struct file *file, const char __user *buf,
                                size_t len, loff_t *off);

static const struct proc_ops kstat_proc_ops = {
	.proc_open = kstat_proc_open,
	.proc_read = seq_read,
	.proc_write = kstat_proc_write,
	.proc_lseek = seq_lseek,
	.proc_release = single_release,
};

static struct proc_dir_entry *kstat_proc_entry;

static bool kstat_tp_registered;

int susfs_kstat_init(void)
{
	int rc;

	/* The ONE tracepoint of this module, armed UNCONDITIONALLY, and that is not cosmetic: the
	 * supercall interface (CMD_SUSFS_ADD_SUS_KSTAT) can install rules with no /proc node at all,
	 * so skipping registration when expose_proc=0 silently turned the whole feature into a no-op -
	 * rules accepted, never applied.  expose_proc decides whether the node exists, nothing else.
	 * This registration carries both features that need a syscall return: kstat's stat rewrite and
	 * sus_path's dirent rewrite, which is why the registration is not conditional on either
	 * feature's own rules. */
	rc = register_trace_sys_exit(kstat_sys_exit, NULL);
	if (rc) {
		pr_err("register_trace_sys_exit failed %d - refusing partial load\n", rc);
		return rc;
	}
	kstat_tp_registered = true;

	/* 0777 is deliberate, not an oversight.  inode_permission() runs the DAC check BEFORE
	 * security_inode_permission(), so a node the app cannot open hands it EACCES - "this exists,
	 * you may not read it" - instead of the ENOENT sus_path is supposed to produce.  0777 lets DAC
	 * pass and leaves the answer to sus_path's LSM layer, which then becomes the ONLY thing
	 * between an app and a world-writable control node - so without that layer the node is not
	 * created at all, see susfs_control_node_allowed(). */
	if (susfs_control_node_allowed()) {
		kstat_proc_entry = proc_create("susfs_kstat", 0777, NULL,
					       &kstat_proc_ops);
		if (!kstat_proc_entry)
			pr_warn("proc_create(susfs_kstat) failed\n");
	} else {
		SUSFS_LOGI("susfs_kstat: /proc node not created (expose_proc=%d lsm=%d)\n",
			(int)susfs_expose_proc, (int)sus_path_lsm_active());
	}

	/* Says which mechanism carries what: this line alone answers "is the listing filter armed",
	 * now that no probe of its own exists to report. */
	SUSFS_LOGI("kstat armed: %d rules (sys_exit tp=%d proc=%d); stat rewrite + sus_path dirent rewrite ride that one tracepoint\n",
		nkstat, kstat_tp_registered, kstat_proc_entry != NULL);
	return 0;
}

void susfs_kstat_exit(void)
{
	kstat_maps_disarm();
	/* Order matters on unload: this tracepoint calls into sus_path (sus_path_dirent_filter()),
	 * and sus_path_exit() frees that layer's scratch buffer.  The layer table in susfs_main.c
	 * tears down in the reverse of its arming order, so kstat's exit runs AFTER sus_path's -
	 * the tracepoint is therefore removed only once nothing needs it.  tracepoint_synchronize_
	 * unregister() waits out any handler already running, so no call can be in flight past it. */
	if (kstat_tp_registered) {
		unregister_trace_sys_exit(kstat_sys_exit, NULL);
		tracepoint_synchronize_unregister();
		kstat_tp_registered = false;
	}
	if (kstat_proc_entry) {
		proc_remove(kstat_proc_entry);
		kstat_proc_entry = NULL;
	}
	kstat_table_clear();
}

static int kstat_proc_show(struct seq_file *m, void *v)
{
	int i;

	mutex_lock(&kstat_lock);
	if (nkstat == 0) {
		seq_puts(m, "(empty)\n");
	} else {
		for (i = 0; i < nkstat; i++) {
			struct sus_kstat_entry *e = &kstat_entries[i];

			seq_printf(m,
				"%s ino=%lu dev=%lu flags=0x%x"
				" [ino=%lu dev=%lu nlink=%u size=%lld"
				" atime=%ld.%lu mtime=%ld.%lu ctime=%ld.%lu"
				" blocks=%lld blksize=%ld]\n",
				e->target_pathname, e->target_ino,
				(unsigned long)e->target_dev, e->flags,
				e->spoofed_ino, e->spoofed_dev, e->spoofed_nlink,
				e->spoofed_size,
				e->spoofed_atime_tv_sec, e->spoofed_atime_tv_nsec,
				e->spoofed_mtime_tv_sec, e->spoofed_mtime_tv_nsec,
				e->spoofed_ctime_tv_sec, e->spoofed_ctime_tv_nsec,
				e->spoofed_blocks, e->spoofed_blksize);
		}
	}
	mutex_unlock(&kstat_lock);
	seq_puts(m, "statx: checkpoint=20 device_pair=1 dev_bits=32 time_bits=64\n");
	/* "armed" is not "fired": the maps hook has to be readable the same way the other feature
	 * hooks are, or a rewrite that never happens looks identical to one that works. */
	seq_printf(m, "maps: armed=%d hits=%d rewrites=%d\n",
		   kstat_maps_registered, atomic_read(&n_kstat_map_hits),
		   atomic_read(&n_kstat_map_rewrites));
	seq_printf(m, "map_identity: checkpoint=21 routes=2 maps=%d smaps=%d missed=%d/%d\n",
		   atomic_read(&n_kstat_map_routes[0]), atomic_read(&n_kstat_map_routes[1]),
		   READ_ONCE(krp_kstat_maps.nmissed), READ_ONCE(krp_kstat_smaps.nmissed));

	/* ---- the tracepoint's per-number counters ----
	 *
	 * One line per whitelisted syscall number.  `ok` is the number of calls that reached the
	 * rewriter (i.e. returned 0), and the reasons a call did not rewrite anything: `err` (the call
	 * returned -errno), `nobuf` (a NULL statbuf argument), `empty` (no rule registered - the
	 * expected value for an idle module), `gate` (not an app KernelSU would umount modules for), `lookup` (no rule
	 * matched the (ino, dev) the kernel just wrote), `noflag` (a rule MATCHED but its flags have
	 * nothing to say about this buffer - e.g. add_sus_kstat, which does not spoof size/nlink, so
	 * `rw` stays 0 while `lookup` does not move), `uacc` (a uaccess fault) and `rw` (the number of
	 * calls that really changed the buffer).  A number that stays at zero through a run that
	 * issues that syscall means the number the process used is not the one this module
	 * whitelisted - which is exactly the class of mistake this block exists to catch, and which
	 * the kernel symbol table alone cannot rule out. */
	{
		unsigned int i;

		for (i = 0; i < ARRAY_SIZE(kstat_nr_table); i++) {
			struct kstat_call_counters *c = kstat_nr_table[i].cnt;

			/* Atomic reads, no lock: the printout is a snapshot, and a torn value would
			 * only mean a number read a few calls ago. */
			seq_printf(m,
				   "stat nr %-16s (%ld): ok=%d rw=%d | err=%d nobuf=%d empty=%d gate=%d lookup=%d noflag=%d uacc=%d narrow=%d\n",
				   kstat_nr_table[i].name, kstat_nr_table[i].nr,
				   atomic_read(&c->calls), atomic_read(&c->rewrite),
				   atomic_read(&c->ret_err), atomic_read(&c->no_buf),
				   atomic_read(&c->miss_empty), atomic_read(&c->miss_gate),
				   atomic_read(&c->miss_lookup), atomic_read(&c->match_noflag),
				   atomic_read(&c->uaccess), atomic_read(&c->narrow));
		}
		seq_printf(m, "stat unlisted-nr hits=%d (unsupported legacy AArch32 stat 106/107/108: last %d seen: %ld %ld %ld %ld %ld %ld %ld %ld)\n",
			   atomic_read(&n_kstat_unlisted), (int)KSTAT_UNLISTED_SEEN,
			   READ_ONCE(kstat_unlisted_seen[0]), READ_ONCE(kstat_unlisted_seen[1]),
			   READ_ONCE(kstat_unlisted_seen[2]), READ_ONCE(kstat_unlisted_seen[3]),
			   READ_ONCE(kstat_unlisted_seen[4]), READ_ONCE(kstat_unlisted_seen[5]),
			   READ_ONCE(kstat_unlisted_seen[6]), READ_ONCE(kstat_unlisted_seen[7]));
	}

	/* sus_path's dirent layer prints its own counters: they belong to that file, and the number
	 * comparisons live here - the two views are next to each other so "which layer ran" is one
	 * read, not two files. */
	{
		char line[512];
		int n = sus_path_dirent_stat_line(line, sizeof(line));

		if (n > 0)
			seq_write(m, line, min_t(int, n, (int)sizeof(line) - 1));
	}
	return 0;
}

static int kstat_proc_open(struct inode *inode, struct file *file)
{
	/* root-only, like kstat_proc_open() above - 0777 is deliberate (see susfs_kstat_init()) */
	if (current_uid().val != 0)
		return -ENOENT;
	return single_open(file, kstat_proc_show, NULL);
}

static int split_ws(char *buf, char **argv, int max)
{
	int argc = 0;
	char *p = buf;

	while (argc < max) {
		while (*p == ' ' || *p == '\t' || *p == '\n')
			p++;
		if (*p == '\0')
			break;
		argv[argc++] = p;
		while (*p && *p != ' ' && *p != '\t' && *p != '\n')
			p++;
		if (*p)
			*p++ = '\0';
	}
	return argc;
}

static ssize_t kstat_proc_write(struct file *file, const char __user *buf,
                                size_t len, loff_t *off)
{
	char cmd[768];
	char *argv[16];
	int argc, err;

	/* Same gate as kstat_proc_open(): open() alone is not enough - an fd opened by root and
	 * handed on would keep working, which is why the sibling files check both. */
	if (current_uid().val != 0)
		return -ENOENT;

	if (len >= sizeof(cmd))
		len = sizeof(cmd) - 1;
	if (copy_from_user(cmd, buf, len))
		return -EFAULT;
	cmd[len] = 0;

	argc = split_ws(cmd, argv, 16);
	if (argc == 0)
		return len;

	mutex_lock(&kstat_lock);
	err = -EINVAL;
	if (!strcmp(argv[0], "add_sus_kstat") ||
	    !strcmp(argv[0], "add_sus_kstat_statically") ||
	    !strcmp(argv[0], "update_sus_kstat") ||
	    !strcmp(argv[0], "update_sus_kstat_full_clone")) {
		err = kstat_maps_arm();
		if (err)
			goto unlock;
	}
	err = -EINVAL;

	if (!strcmp(argv[0], "add_sus_kstat") && argc == 2)
		err = susfs_kstat_add(argv[1]);
	else if (!strcmp(argv[0], "add_sus_kstat_statically") && argc == 14)
		err = susfs_kstat_add_statically(argv, argc);
	else if (!strcmp(argv[0], "update_sus_kstat") && argc == 2)
		err = susfs_kstat_update(argv[1], false);
	else if (!strcmp(argv[0], "update_sus_kstat_full_clone") && argc == 2)
		err = susfs_kstat_update(argv[1], true);
	else if (!strcmp(argv[0], "del") && argc == 2) {
		susfs_kstat_del(argv[1]);
		err = 0;
	} else if (!strcmp(argv[0], "clear")) {
		kstat_table_clear();
		err = 0;
	}

unlock:
	mutex_unlock(&kstat_lock);

	if (err) {
		pr_warn("kstat proc write '%s' -> err %d\n", argv[0], err);
		/* Reported to the writer: a command that did not take effect must not look like a
		 * successful full write.  Success still returns len, so callers that expect a complete
		 * write keep working. */
		return err;
	}
	return len;
}
