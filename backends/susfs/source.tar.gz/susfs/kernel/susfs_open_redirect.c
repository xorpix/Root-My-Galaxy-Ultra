// SPDX-License-Identifier: GPL-2.0
/*
 * susfs_open_redirect.c - redirect open of a target path to another path (SUSFS OPEN_REDIRECT feature), LKM port.
 * Forward direction: not here any more.  path_openat / do_sys_openat2 / do_filp_open are LTO-inlined into the syscall
 * entry, so none can be kprobed, and the only out-of-line symbol on the user-open path (vfs_open(file)) sits at the
 * inode layer, where the name is already gone - a swap there has to pin a dentry and a mount per rule, which then
 * blocks umount.  Redirection is done one level up instead, at the syscall entry, by susfs_or_entry.c (wrapper
 * replacement; see that file header).  Nothing here holds a struct path any more: a rule keeps (target_ino,
 * target_dev, target_igen), the spoofed kstatfs snapshot and the two pathnames, and the entry hook resolves the name
 * it was given.
 *
 * Because nothing is pinned, numbers are all that identify a rule's files: a filesystem may reuse an inode number
 * after a file is deleted, so every match also compares i_generation (the same field NFS export handles use; a
 * filesystem that does not maintain it reports 0 and such a filesystem only weakens, it does not break).
 * A deleted rule hands its slot back (or_reclaim_slot): the readers wait out one RCU grace period while the fields
 * keep their meaning under the `dead` flag, and only then the slot is cleared and returned to the free list - so the
 * rewrite path no longer spends one of the 64 slots per add, it keeps the same slot.
 * uid_scheme: enum UID_SCHEME (susfs.h, via susfs_abi.h), all five values with upstream's predicates
 * (susfs.c:941-964); two of the five need state an LKM cannot read - see or_uid_matches() / or_in_su_domain().
 * Reverse disguise: upstream registers TWO hash entries per rule (susfs.c:844-863), the second with
 * reversed_lookup_only = true and the two pathnames swapped, and every "where did this file come from" reporter answers
 * from it - readlink (patch:510-548), /proc/<pid>/fd links (patch:1062-1083), fdinfo (patch:1145-1217), maps
 * (patch:1257-1288), vfs_statfs (patch:2038-2056).  Gate: SUSFS_IS_INODE_OPEN_REDIRECT (susfs_def.h:148-151)
 * = inode flag *and* susfs_is_current_proc_umounted_app(), never the rule's uid_scheme.
 * Reachability: none of those five reporters is reachable from an LKM here, so the reverse side re-points the
 * surfaces that ARE reachable in each direction: d_path() and vfs_statfs() get kretprobes that rewrite their return
 * value (the entry copies what it needs under rcu_read_lock into per-instance data, the return handler applies it),
 * and the two listing faces that have no shared helper rewrite the line the kernel already formatted.
 * Never silent: registration outcome and hit counts are logged and shown by /proc/susfs_open_redirect, because
 * registering only proves the symbol exists - this feature has hit that wall twice (show_vma_header_prefix, then
 * __d_path: both registered, both stayed at 0).
 *
 * /proc/susfs_open_redirect: add_open_redirect <target> <redirected> <uid_scheme> | del <target> | clear
 */
#include <linux/module.h>
#include <linux/kprobes.h>
#include <linux/fs.h>
#include <linux/cred.h>
#include <linux/namei.h>
#include <linux/dcache.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/uaccess.h>
#include <linux/rcupdate.h>	/* rcu_read_lock() around every entry-table consumer */
#include <linux/statfs.h>	/* struct kstatfs (the reverse statfs face) */
#include "mount.h"		/* fs/mount.h: real_mount() -> mnt_id */
#include <linux/atomic.h>	/* reverse-disguise hit counters */
#include <linux/mm.h>		/* struct vm_area_struct (the maps reverse face) */
#include <linux/kdev_t.h>	/* MAJOR/MINOR, to render dev:ino the way proc does */
#include <linux/kernel.h>	/* scnprintf, for the same rendering */
#include <linux/find.h>		/* find_next_bit, for the batched clear */
#include <linux/security.h>	/* security_secctx_to_secid */
#include "susfs_abi.h"
#include "susfs_log.h"
#include "susfs.h"		/* SUSFS_OR_PATH_MAX, susfs_open_redirect_active() */
#include "symbol_resolver.h"	/* find_kernel_symbol_exact */
#include "ksu_umount_gate.h"	/* susfs_is_current_proc_umounted[_app] (issue #34) */
#include "susfs_or_entry.h"	/* susfs_or_entry_armed(), init/exit of the name layer */

#define SUS_OR_MAX 64
/* The pathname widths are single-housed in susfs.h as SUSFS_OR_PATH_MAX: the ABI fields are char[256] (upstream's
 * st_susfs_open_redirect), and matching that width stops a legal long path from being truncated into a rule for a
 * different path. */

/* UID_SCHEME lives in susfs_abi.h, mirroring upstream susfs.h, where the enum sits next to the ABI structs. */

/* FUSE is the one filesystem upstream refuses outright (susfs.c:824-829): the daemon resolves the name itself, so a
 * kernel-side swap does nothing or makes the request happen twice.  susfs_def.h:49-51 carries the constant for the same
 * reason: neither <linux/magic.h> (absent from this tree) nor <uapi/linux/magic.h> defines it; fs/fuse/fuse_i.h does. */
#ifndef FUSE_SUPER_MAGIC
#define FUSE_SUPER_MAGIC 0x65735546
#endif


/* SELinux context of the su/ksu domain, resolved to a sid at init.  Upstream gets the sid from KernelSU itself
 * (susfs_set_sid(KERNEL_SU_CONTEXT, &susfs_ksu_sid), 10_enable_susfs_for_ksu.patch:2496); an LKM has to resolve the
 * string.  "u:r:ksu:s0" is the SukiSU variant this device runs (KERNEL_SU_DOMAIN "ksu"), stock KernelSU uses
 * "u:r:su:s0" - override with susfs_guard_lkm.or_su_ctx.  Kept separate from sus_mount's su_ctx and avc_spoof's
 * avc_su_ctx: parameters are per name, and defaulting to the wrong domain must not change other features' gating. */
static char or_su_ctx[128] = "u:r:ksu:s0";
module_param_string(or_su_ctx, or_su_ctx, sizeof(or_su_ctx), 0400);

static u32 or_su_sid;

/* security_cred_getsecid() is an EXPORT_SYMBOL, but GKI's module symbol list is not guaranteed to
 * carry it, so it is resolved in kallsyms like sus_mount.c does.  The wrapper needs __nocfi: kCFI
 * validates the type hash at a call through a function pointer. */
static void (*or_cred_getsecid)(const struct cred *cred, u32 *secid);

/* Resolve the unexported snapshot call at init; refuse rules without it. */
static int (*or_vfs_statfs_fn)(const struct path *path, struct kstatfs *buf);

static __nocfi noinline int or_statfs_snapshot(const struct path *path, struct kstatfs *buf)
{
	if (!or_vfs_statfs_fn)
		return -EOPNOTSUPP;
	return or_vfs_statfs_fn(path, buf);
}

/* Nothing in this entry holds a reference: a rule identifies files by numbers (ino, dev, and i_generation where the
 * filesystem maintains it), the spoofed kstatfs snapshot and the two pathnames - no dentry, no mount, no struct path.
 * That is what lets a filesystem be torn down under a running rule instead of waiting for it. */
struct sus_or_entry {
	char target_pathname[SUSFS_OR_PATH_MAX];
	char redirected_pathname[SUSFS_OR_PATH_MAX];
	unsigned long target_ino;
	dev_t target_dev;
	/* Reverse direction: the redirected inode is the lookup key, and the target's numbers are what
	 * the reporters above show instead.  i_generation is the same field NFS's export key uses: it
	 * invalidates an inode number a filesystem handed out twice. */
	unsigned long redirected_ino;
	dev_t redirected_dev;
	unsigned int redirected_igen;
	unsigned int target_igen;
	/* Reverse direction, second number: fdinfo also prints mnt_id, and for the redirected file that is the mount the
	 * redirection really opened - which can differ from the target's (e.g. /system/etc/hosts vs
	 * /data/local/tmp/hosts).  Cached at add time: the reporter has only numbers to work with. */
	unsigned long target_mnt_id;
	/* Cached at add time with the target's own vfs_statfs (the reverse statfs face answers reads
	 * of the redirected file with it). */
	struct kstatfs spoofed_kstatfs;
	int uid_scheme;
	/* Set while the slot is being rewritten or has been deleted.  The reader checks this with
	 * READ_ONCE and the writer clears it LAST, so false means the rest of the entry is complete. */
	bool dead;
};

static struct sus_or_entry or_entries[SUS_OR_MAX];
static int nor;
/* Slots that a deleted or rewritten rule handed back, taken again starting with the most recent handback.  A rewrite
 * takes ONE slot from here instead of spending a fresh one, so a table that keeps being rewritten keeps nor at its
 * high-water mark - 9b27112. */
static unsigned int or_free[SUS_OR_MAX];
static unsigned int or_free_n;
/* Number of LIVE rules (never more than the live slots).  The /proc "(empty)" gate, the wrappers'
 * fast path and or_add's capacity check all read it, because each wants one load and not a loop. */
unsigned int susfs_open_redirect_rules;
static DEFINE_MUTEX(or_lock);

/* Reverse-disguise bookkeeping.  The counters are the only way to tell a hook that never fires from one that fires and
 * matches nothing: a kprobe registers against a symbol's out-of-line copy, which GKI's full LTO may leave with no live
 * call sites (AUDIT_FINDINGS.md: five probes registered, zero hits). */
static atomic_t or_rev_dpath_hits = ATOMIC_INIT(0);
static atomic_t or_rev_statfs_hits = ATOMIC_INIT(0);

/* No release path: nothing in an entry is a reference, and a pointer a slow reader still holds only
 * ever points at module-static memory.  A handed-back slot keeps `dead` through the grace period
 * or_reclaim_slot() waits out and beyond: while it sits on the free list the flag stays true, so no
 * lookup reaches its fields, and the next or_add() refills them before lowering the flag again. */

static void or_resolve_su_sid(void)
{
	int err;

	if (or_su_sid)
		return;
	if (!or_su_ctx[0])
		return;
	err = security_secctx_to_secid(or_su_ctx, strlen(or_su_ctx), &or_su_sid);
	if (err) {
		pr_warn("open_redirect: secctx_to_secid(%s) failed %d\n",
			or_su_ctx, err);
		or_su_sid = 0;
		return;
	}
	SUSFS_LOGI("open_redirect: su ctx \"%s\" -> sid %u (stock KernelSU uses \"u:r:su:s0\", override with susfs_guard_lkm.or_su_ctx)\n",
		or_su_ctx, or_su_sid);
}

/* Upstream susfs_is_current_ksu_domain() = (current_sid() == susfs_ksu_sid) (10_enable_susfs_for_ksu.patch:2484-2486);
 * current_sid() lives in SELinux's private objsec.h, so the LSM-agnostic security_cred_getsecid() is used instead. */
static __nocfi bool or_in_su_domain(void)
{
	u32 sid = 0;

	/* Unresolved symbol or unresolvable context: "not su" would be a guess, and for schemes 1/2 that guess redirects
	 * the very process the rule exists to spare.  or_add() refuses those schemes instead. */
	if (!or_cred_getsecid || !or_su_sid)
		return false;
	/* interrupt context: reading current->cred and walking the (static) LSM hook list never sleeps. */
	or_cred_getsecid(current_cred(), &sid);
	return sid == or_su_sid;
}

/* Upstream's reverse-disguise gate, verbatim in shape: SUSFS_IS_INODE_OPEN_REDIRECT (susfs_def.h:148-151) = flag bit AND
 * susfs_is_current_proc_umounted_app().  TIF_PROC_UMOUNTED is set by the SUSFS-patched KernelSU, which this kernel does not
 * have, so the app half is KernelSU's own ksu_uid_should_umount() answer (ksu_umount_gate.h, issue #34) rather than the
 * `uid >= 10000` proxy that also covered the manager and su-granted apps. */
static bool or_reverse_visible(void)
{
	return susfs_is_current_proc_umounted_app();
}

/* uid_scheme decision, mirroring upstream's switch in susfs_open_redirect_spoof_do_sys_openat() (susfs.c:941-964). */
static bool or_uid_matches(int scheme)
{
	switch (scheme) {
	case UID_NON_APP_PROC:			/* susfs.c:942-945 */
		return current_uid().val % 100000 < 10000;
	case UID_ROOT_PROC_EXCEPT_SU_PROC:	/* susfs.c:946-949 */
		return current_uid().val == 0 && !or_in_su_domain();
	case UID_NON_SU_PROC:			/* susfs.c:950-953 */
		return !or_in_su_domain();
	case UID_UMOUNTED_APP_PROC:		/* susfs.c:954-957 */
		/* Upstream: TIF_PROC_UMOUNTED && uid >= 10000 (susfs_def.h:122-125).  The flag is set
		 * by the SUSFS-patched KernelSU and this kernel has no such patch, so the same
		 * question is put to KernelSU by uid instead (ksu_umount_gate.h, issue #34).  What
		 * that substitution cannot reproduce is the flag's per-THREAD grain: a process of an
		 * umounted uid that was not forked from zygote answers yes here and no upstream. */
		return susfs_is_current_proc_umounted_app();
	case UID_UMOUNTED_PROC:			/* susfs.c:958-961 */
		/* Upstream: TIF_PROC_UMOUNTED alone, with no uid condition at all - which is how it
		 * covers init-derived processes.  Same substitution as above, and the uid half is
		 * deliberately NOT added here: that is the whole difference between this scheme and
		 * the one above. */
		return susfs_is_current_proc_umounted();
	default:				/* susfs.c:962-963 */
		return false;
	}
}

static struct sus_or_entry *or_find_by_path(const char *target)
{
	int i;

	for (i = 0; i < READ_ONCE(nor); i++) {
		if (READ_ONCE(or_entries[i].dead))
			continue;
		if (!strcmp(or_entries[i].target_pathname, target))
			return &or_entries[i];
	}
	return NULL;
}

/* Forward direction, keyed on the target file's numbers.  The generation is what keeps a reused
 * inode number from matching a rule that was written for the file that had it before (a filesystem
 * that does not maintain the field reports 0 everywhere, and such a filesystem only weakens: a
 * rule there can survive a number reuse). */
static struct sus_or_entry *or_find_by_inode(unsigned long ino, dev_t dev, unsigned int gen)
{
	int i;

	for (i = 0; i < READ_ONCE(nor); i++) {
		/* dead is cleared LAST by the writer, so skipping dead entries also skips any entry whose
		 * fields are still being written. */
		if (READ_ONCE(or_entries[i].dead))
			continue;
		smp_rmb();
		if (or_entries[i].target_ino == ino &&
		    or_entries[i].target_dev == dev &&
		    or_entries[i].target_igen == gen)
			return &or_entries[i];
	}
	return NULL;
}

/* The name-layer entry hook asks this one, with the path the caller is about to open: true when a live
 * rule redirects that inode, in which case the rule's redirect target has been copied into `buf`.
 *
 * The copy happens under rcu_read_lock and is mandatory, not politeness: a slot is recycled once a
 * grace period has passed after the rule was deleted (or_reclaim_slot()), so a pointer into an
 * entry may not be used after the lookup returns.  A name that does not fit leaves buf alone and
 * counts as "no rule" - the caller then runs the original syscall, which is always correct.
 * The uid_scheme decision (or_uid_matches) happens inside the same lock: it can only fail the
 * match, where upstream leaves the lookup loop entirely for the same reason (susfs.c:945/949/953/
 * 957/961). */
bool susfs_open_redirect_match_path(const struct path *path, char *buf, size_t buflen)
{
	struct inode *inode;
	struct sus_or_entry *e = NULL;

	if (!susfs_open_redirect_active() || IS_ERR_OR_NULL(path) || !path->dentry)
		return false;
	inode = d_inode(path->dentry);
	if (!inode)
		return false;

	rcu_read_lock();
	e = or_find_by_inode(inode->i_ino, inode->i_sb->s_dev, inode->i_generation);
	if (e && !or_uid_matches(e->uid_scheme))
		e = NULL;
	if (e) {
		/* strscpy() reports the length it copied; 0 is impossible for a rule written by
		 * or_add() (which rejects unterminated names) and a negative return is a name that
		 * does not fit - both count as "no rule". */
		if (strscpy(buf, e->redirected_pathname, buflen) <= 0)
			e = NULL;
	}
	rcu_read_unlock();
	return e != NULL;
}

/* Reverse direction: keyed on the redirected (really opened) inode, published like or_find_by_inode().
 * Copy-and-use consumers call it under rcu_read_lock, because the grace period is what keeps the
 * fields they copy out readable; the match itself only needs the dead-flag discipline above. */
static struct sus_or_entry *or_find_by_redirected_inode(unsigned long ino, dev_t dev,
							unsigned int gen)
{
	int i;

	for (i = 0; i < READ_ONCE(nor); i++) {
		if (READ_ONCE(or_entries[i].dead))
			continue;
		smp_rmb();
		if (or_entries[i].redirected_ino == ino &&
		    or_entries[i].redirected_dev == dev &&
		    or_entries[i].redirected_igen == gen)
			return &or_entries[i];
	}
	return NULL;
}

/* Reverse direction for the one caller that has only numbers: /proc/<pid>/fdinfo/N prints "mnt_id:\t<i>" and "ino:\t<j>"
 * for the file an fd points at and no device, so this lookup is by ino alone; two rules sharing that ino refuses to
 * answer (a missed disguise beats disguising an unrelated file).  On success: the target's ino and mount id (0 unknown).
 * Copying the two numbers out happens under rcu_read_lock like every other copy-and-use consumer of a
 * rule: the caller holds no lock of its own, and a grace period is what guarantees the numbers it
 * copies are not the stale ones of a slot that is being handed back. */
bool susfs_open_redirect_spoof_ids(unsigned long ino, unsigned long *out_ino,
				   unsigned long *out_mnt_id)
{
	struct sus_or_entry *e = NULL;
	int i, hits = 0;

	if (!ino || !out_ino || !or_reverse_visible())
		return false;

	rcu_read_lock();
	for (i = 0; i < READ_ONCE(nor); i++) {
		if (READ_ONCE(or_entries[i].dead))
			continue;
		smp_rmb();
		if (or_entries[i].redirected_ino != ino)
			continue;
		e = &or_entries[i];
		if (++hits > 1) {
			rcu_read_unlock();
			return false;
		}
	}
	if (hits != 1) {
		rcu_read_unlock();
		return false;
	}
	*out_ino = e->target_ino;
	if (out_mnt_id)
		*out_mnt_id = e->target_mnt_id;
	rcu_read_unlock();
	return true;
}

/* Is `target` another rule's redirected path?  Upstream refuses to touch such a name (susfs.c:867-881): that name
 * belongs to the reverse entry of an existing rule, and replacing it would silently break that rule's disguise. */
static bool or_is_redirected_path(const char *target)
{
	int i;

	for (i = 0; i < READ_ONCE(nor); i++) {
		if (READ_ONCE(or_entries[i].dead))
			continue;
		if (!strcmp(or_entries[i].redirected_pathname, target))
			return true;
	}
	return false;
}

/* ---- forward: not here any more ----
 * path_openat / do_sys_openat2 / do_filp_open are LTO-inlined into the syscall entry, so none can be probed, and vfs_open
 * sits below the name resolution - see the file header for the full version.  On this fork the wrappers are owned by
 * susfs_or_entry.c itself and attach through the same susfs_fp_hook layer create_gate uses; the O_PATH answer is
 * sus_path's own LSM layer, which every filp_open() (ours included) flows through by construction, so there is no
 * post-check of the fd to install. */

/* ---- reverse: d_path(path, buf, buflen) ----
 * Covers readlink("/proc/<pid>/fd/N"): proc_pid_readlink() -> do_proc_readlink() -> d_path(&path, tmp, PAGE_SIZE)
 * (fs/proc/base.c, upstream: patch:1062-1083).  Upstream answers from the reversed LOOKUP half of the rule table (its
 * two hash entries per rule) and the rule's target pathname becomes what readlink returns.  A kretprobe cannot swap a
 * struct path it does not own, so the ENTRY handler stages the rule's target pathname and the caller buffer while the
 * entry is still a valid read (rcu_read_lock), and the RETURN handler writes the string over the kernel's answer.
 * Divergence: upstream replays the literal string given at add time, while d_path() renders the canonical name of the
 * file in the *reader's* namespace - a rule registered through a symlink (or another mount namespace) can read back
 * differently.
 * The /proc/<pid>/maps NAME column is NOT here: show_map_vma() prints it with seq_file_path() -> seq_path(), which calls
 * __d_path() directly, never d_path() (fs/seq_file.c); a probe on __d_path registers cleanly and never fires here (full
 * LTO inlines the primitive; measured dpath_seq=0 while the maps line still named the redirected file), so the name is
 * rewritten out of the already-printed line - see or_maps_ret(). */
struct or_dpath_args {
	char *buf;
	size_t buflen;
	/* The rule's redirect target, copied out under rcu_read_lock in the entry handler: a grace
	 * period may hand the slot back right after the entry returns, so the return handler must
	 * not read the entry again. */
	char target[SUSFS_OR_PATH_MAX];
	/* What d_path's callers pass is a kernel-side scratch buffer (do_proc_readlink: kmalloc'd);
	 * NULL when the entry dropped out. */
	bool hit;
};

static int or_dpath_entry(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	struct or_dpath_args *a = (struct or_dpath_args *)ri->data;
	const struct path *path = (const struct path *)regs->regs[0];
	struct inode *inode;
	struct sus_or_entry *e;

	a->hit = false;
	a->buf = NULL;
	if (!READ_ONCE(nor) || IS_ERR_OR_NULL(path) || !path->dentry)
		return 0;
	if (!or_reverse_visible())
		return 0;
	inode = d_backing_inode(path->dentry);
	if (!inode)
		return 0;

	rcu_read_lock();
	e = or_find_by_redirected_inode(inode->i_ino, inode->i_sb->s_dev,
					inode->i_generation);
	if (!e) {
		rcu_read_unlock();
		return 0;
	}
	a->buf = (char *)regs->regs[1];
	a->buflen = (size_t)regs->regs[2];
	if (!a->buf || !a->buflen || !susfs_ptr_plausible(a->buf)) {
		a->buf = NULL;
		rcu_read_unlock();
		return 0;
	}
	/* The name is copied here, not in the return probe: the entry could be rewritten or deleted
	 * between the two, and this copy is what the caller's buffer will be filled from, so it has
	 * to be one consistent moment. */
	if (strscpy(a->target, e->target_pathname, sizeof(a->target)) <= 0) {
		rcu_read_unlock();
		return 0;
	}
	rcu_read_unlock();

	a->hit = true;
	atomic_inc(&or_rev_dpath_hits);
	return 0;
}

static int or_dpath_ret(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	const struct or_dpath_args *a = (const struct or_dpath_args *)ri->data;

	/* The kernel refused the readlink (or answered with an error pointer): its answer stands. */
	if (!a->hit || !a->buf || IS_ERR_VALUE(regs->regs[0]))
		return 0;
	if (strnlen(a->target, a->buflen) >= a->buflen)
		return 0;
	strscpy(a->buf, a->target, a->buflen);
	/* d_path() returns a pointer INTO buf (the copy of the name it made there); a caller that
	 * treats the return as the string must still see the target, so the return value moves to
	 * the start of the rewritten copy. */
	regs->regs[0] = (unsigned long)a->buf;
	return 0;
}

static struct kretprobe kr_or_dpath = {
	.kp.symbol_name = "d_path",
	.entry_handler = or_dpath_entry,
	.handler = or_dpath_ret,
	.data_size = sizeof(struct or_dpath_args),
	.maxactive = 16,
};


/* ---- reverse: vfs_statfs(path, buf) ----
 * Upstream answers statfs()/fstatfs() of the redirected file with the target's kstatfs snapshot (susfs.c:1029-1046,
 * taken with vfs_statfs() at add time, susfs.c:851).  Same shape as the readlink face: the ENTRY stages the snapshot
 * while the matched rule is still readable, the RETURN replaces the kernel's answer with it - both so the numbers
 * never lag the snapshot behind the rule they belong to. */
struct or_statfs_args {
	struct kstatfs *buf;
	/* the rewritten answer, copied from the rule while the entry is being read */
	struct kstatfs kstatfs;
	bool hit;
};

static int or_statfs_entry(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	const struct path *path = (const struct path *)regs->regs[0];
	struct or_statfs_args *a = (struct or_statfs_args *)ri->data;
	struct inode *inode;
	struct sus_or_entry *e;

	a->hit = false;
	a->buf = NULL;
	if (!READ_ONCE(nor) || IS_ERR_OR_NULL(path) || !path->dentry)
		return 0;
	if (!or_reverse_visible())
		return 0;
	inode = d_backing_inode(path->dentry);
	if (!inode)
		return 0;

	rcu_read_lock();
	e = or_find_by_redirected_inode(inode->i_ino, inode->i_sb->s_dev,
					inode->i_generation);
	if (!e) {
		rcu_read_unlock();
		return 0;
	}
	a->buf = (struct kstatfs *)regs->regs[1];
	if (!a->buf || !susfs_ptr_plausible(a->buf)) {
		rcu_read_unlock();
		return 0;
	}
	/* The snapshot is copied here as well, not in the return probe: the entry could be rewritten in between, and the
	 * copy is what the caller's buffer will be filled from, so it has to be one consistent moment. */
	a->kstatfs = e->spoofed_kstatfs;
	rcu_read_unlock();
	a->hit = true;
	atomic_inc(&or_rev_statfs_hits);
	return 0;
}

static int or_statfs_ret(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	const struct or_statfs_args *a = (const struct or_statfs_args *)ri->data;

	if (!a->hit || !a->buf || (long)regs->regs[0] != 0)
		return 0;		/* the kernel refused the statfs: its answer stands */
	*a->buf = a->kstatfs;
	return 0;
}

static struct kretprobe kr_or_vfs_statfs = {
	.kp.symbol_name = "vfs_statfs",
	.entry_handler = or_statfs_entry,
	.handler = or_statfs_ret,
	.data_size = sizeof(struct or_statfs_args),
	.maxactive = 16,
};

/* ---- reverse face 3: maps/smaps listing callbacks ----
 * CP21's show_map_vma probe missed maps on BZIG after the formatter was
 * inlined. Probe show_map and show_smap directly, without a nested helper
 * probe. Capture the buffer/count before .show and edit only its new header.
 * Earlier rows, offsets, pathname substrings and smaps metrics cannot match.
 */
static atomic_t or_rev_maps_hits = ATOMIC_INIT(0);
static atomic_t or_rev_maps_rewrites = ATOMIC_INIT(0);
static atomic_t or_rev_maps_names = ATOMIC_INIT(0);
static atomic_t or_maps_routes[2] = { ATOMIC_INIT(0), ATOMIC_INIT(0) };

struct or_maps_args {
	struct seq_file *m;
	struct vm_area_struct *vma;
	char *buf;
	size_t start;
	unsigned int route;
};

static int or_maps_show_entry(struct kretprobe_instance *ri, struct pt_regs *regs,
			      unsigned int route)
{
	struct or_maps_args *a = (struct or_maps_args *)ri->data;

	if (!or_reverse_visible())
		return 1;
	a->m = (struct seq_file *)regs->regs[0];
	a->vma = (struct vm_area_struct *)regs->regs[1];
	if (!susfs_ptr_plausible(a->m) || !susfs_ptr_plausible(a->vma))
		return 1;
	a->buf = a->m->buf;
	a->start = a->m->count;
	a->route = route;
	return 0;
}

static int or_maps_entry(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	return or_maps_show_entry(ri, regs, 0);
}

static int or_smaps_entry(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	return or_maps_show_entry(ri, regs, 1);
}

static bool or_maps_replace(struct seq_file *m, size_t pos, size_t old_len,
			    const char *new, size_t new_len)
{
	size_t count = m->count;

	if (!old_len || !new_len || pos > count || old_len > count - pos ||
	    count >= m->size)
		return false;
	if (new_len > old_len && new_len - old_len >= m->size - count) {
		/* Retry the seq output with room; do not emit a partial real identity. */
		m->count = m->size;
		return false;
	}
	if (new_len != old_len)
		memmove(m->buf + pos + new_len, m->buf + pos + old_len,
			count - (pos + old_len));
	memcpy(m->buf + pos, new, new_len);
	m->count = count - old_len + new_len;
	return true;
}

static int or_maps_ret(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	const struct or_maps_args *a = (const struct or_maps_args *)ri->data;
	struct seq_file *m = a->m;
	struct vm_area_struct *vma = a->vma;
	struct inode *inode;
	struct sus_or_entry *e;
	char old[48], new[48];
	size_t pos, end, rlen, tlen;
	int old_len, new_len, field;

	if (regs->regs[0] || !susfs_ptr_plausible(m) ||
	    !susfs_ptr_plausible(vma) || !m->buf || m->buf != a->buf ||
	    a->start >= m->count || m->count >= m->size || !vma->vm_file ||
	    !or_reverse_visible())
		return 0;
	inode = file_inode(vma->vm_file);
	if (!inode || !inode->i_sb)
		return 0;
	/* The find AND every later read from the matched entry (the dev:ino pair, then the two
	 * pathnames for the name fallback) run inside one rcu read section: a handed-back slot is
	 * cleared only after a grace period, so holding the lock across these reads is what keeps
	 * them from racing a reclaim.  or_maps_replace() only rewrites the already-emitted seq
	 * buffer in place (no allocation, no sleep), so the whole edit is safe under rcu. */
	rcu_read_lock();
	e = or_find_by_redirected_inode(inode->i_ino, inode->i_sb->s_dev,
					inode->i_generation);
	if (!e)
		goto out;
	atomic_inc(&or_rev_maps_hits);
	old_len = scnprintf(old, sizeof(old), "%02x:%02x %lu",
		(unsigned int)MAJOR(inode->i_sb->s_dev),
		(unsigned int)MINOR(inode->i_sb->s_dev),
		(unsigned long)inode->i_ino);
	new_len = scnprintf(new, sizeof(new), "%02x:%02x %lu",
		(unsigned int)MAJOR(e->target_dev),
		(unsigned int)MINOR(e->target_dev),
		(unsigned long)e->target_ino);
	while (new_len < old_len && new_len < (int)sizeof(new) - 1)
		new[new_len++] = ' ';
	pos = end = a->start;
	while (end < m->count && m->buf[end] != '\n')
		end++;
	for (field = 0; field < 3; field++) {
		while (pos < end && m->buf[pos] != ' ')
			pos++;
		while (pos < end && m->buf[pos] == ' ')
			pos++;
	}
	if (old_len <= 0 || new_len <= 0 || pos >= end ||
	    (size_t)old_len >= end - pos ||
	    memcmp(m->buf + pos, old, (size_t)old_len) ||
	    m->buf[pos + old_len] != ' ')
		goto out;
	if (!or_maps_replace(m, pos, (size_t)old_len, new, (size_t)new_len))
		goto out;
	atomic_inc(&or_rev_maps_rewrites);
	atomic_inc(&or_maps_routes[a->route]);
	end = end - (size_t)old_len + (size_t)new_len;
	pos += (size_t)new_len;
	while (pos < end && (m->buf[pos] == ' ' || m->buf[pos] == '\t'))
		pos++;
	rlen = strlen(e->redirected_pathname);
	tlen = strlen(e->target_pathname);
	/* d_path may already have disguised the name. A fallback changes only
	 * the exact registered name, retaining a possible kernel deleted suffix. */
	if (rlen && tlen && pos < end && rlen <= end - pos &&
	    !memcmp(m->buf + pos, e->redirected_pathname, rlen) &&
	    (rlen == end - pos || (end - pos - rlen == 10 &&
	     !memcmp(m->buf + pos + rlen, " (deleted)", 10))) &&
	    or_maps_replace(m, pos, rlen, e->target_pathname, tlen))
		atomic_inc(&or_rev_maps_names);
out:
	rcu_read_unlock();
	return 0;
}

static struct kretprobe kr_or_maps = {
	.kp.symbol_name = "show_map",
	.entry_handler = or_maps_entry,
	.handler = or_maps_ret,
	.data_size = sizeof(struct or_maps_args),
	.maxactive = 64,
};
static struct kretprobe kr_or_smaps = {
	.kp.symbol_name = "show_smap",
	.entry_handler = or_smaps_entry,
	.handler = or_maps_ret,
	.data_size = sizeof(struct or_maps_args),
	.maxactive = 64,
};
static bool or_maps_registered;

static int or_maps_arm(void)
{
	int rc;

	if (or_maps_registered)
		return 0;
	kr_or_maps.kp.addr = NULL;
	kr_or_maps.kp.flags = 0;
	rc = register_kretprobe(&kr_or_maps);
	if (rc)
		return rc;
	kr_or_smaps.kp.addr = NULL;
	kr_or_smaps.kp.flags = 0;
	rc = register_kretprobe(&kr_or_smaps);
	if (rc) {
		unregister_kretprobe(&kr_or_maps);
		return rc;
	}
	or_maps_registered = true;
	return 0;
}

static void or_maps_disarm(void)
{
	if (!or_maps_registered)
		return;
	unregister_kretprobe(&kr_or_smaps);
	unregister_kretprobe(&kr_or_maps);
	or_maps_registered = false;
}

static int or_maps_stat_get(char *buf, const struct kernel_param *kp)
{
	return scnprintf(buf, PAGE_SIZE,
		"checkpoint=22 routes=2 ready=%d maps=%d smaps=%d missed=%d/%d\n",
		or_maps_registered, atomic_read(&or_maps_routes[0]),
		atomic_read(&or_maps_routes[1]),
		kr_or_maps.nmissed, kr_or_smaps.nmissed);
}
static const struct kernel_param_ops or_maps_stat_ops = { .get = or_maps_stat_get };
module_param_cb(redirect_map_stat, &or_maps_stat_ops, NULL, 0444);

/* ---- reverse face 4: /proc/<pid>/fdinfo/N ----
 * fdinfo prints "ino:\t<i>" for the file an fd points at - for a rule, the REDIRECTED one - so a detector holding an fd
 * on the target is handed the inode of the file the redirection really opened.  Upstream rewrites it in the same function
 * it rewrites mnt_id in (susfs_open_redirect_spoof_seq_show, patch:1171-1200).
 * It belongs to THIS feature, not to sus_mount's: it has to fire as soon as one rule exists, whether or not the
 * mount-hiding switch is on.  Measured with the first version (a sus_mount seq_show kretprobe, registered only when that
 * feature is enabled): with a rule present and hide off, fdinfo kept naming the redirected inode and the probe had
 * entry=0.  fdinfo has no device column, so the lookup is by ino alone and refuses when two rules share a redirected ino;
 * state is per-instance (ri->data) because seq_show() may sleep in seq_printf() and the task can migrate CPUs. */
static atomic_t or_rev_fdinfo_hits = ATOMIC_INIT(0);
static atomic_t or_rev_fdinfo_rewrites = ATOMIC_INIT(0);

static int or_fdinfo_entry(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	struct seq_file **slot = (struct seq_file **)ri->data;

	if (!or_reverse_visible() || !susfs_ptr_plausible((void *)regs->regs[0]))
		return 1;
	*slot = (struct seq_file *)regs->regs[0];
	return 0;
}

/* Find `label` in the already formatted buffer and parse the decimal that follows it; false when
 * the label is absent or has no digits. */
static bool or_fdinfo_find_dec(struct seq_file *m, const char *label, size_t label_len,
			       size_t *out_pos, size_t *out_len, unsigned long *out_val)
{
	char *buf = m->buf;
	size_t count = m->count, i, pos = 0, len = 0;
	unsigned long v = 0;

	if (!buf || !label_len || count >= m->size || label_len >= count)
		return false;
	for (i = 0; i < count - label_len; i++) {
		if ((i == 0 || buf[i - 1] == '\n') && !memcmp(buf + i, label, label_len)) {
			pos = i + label_len;
			break;
		}
	}
	if (!pos)
		return false;
	while (pos + len < count &&
	       buf[pos + len] >= '0' && buf[pos + len] <= '9') {
		unsigned long digit = (unsigned long)(buf[pos + len] - '0');

		if (v > (~0UL - digit) / 10)
			return false;
		v = v * 10 + digit;
		len++;
	}
	if (!len || pos + len >= count || buf[pos + len] != '\n')
		return false;
	*out_pos = pos;
	*out_len = len;
	*out_val = v;
	return true;
}

/* Write new_val over the len digits at pos, growing or shrinking as needed.  The replacement can be LONGER (measured:
 * 926498 -> 10166500 was refused by an earlier shrink-only version, so the hook reported hits with zero rewrites);
 * growing needs room in the seq_file buffer, and without room the line is left alone rather than truncated. */
static bool or_fdinfo_write_dec(struct seq_file *m, size_t pos, size_t len,
				unsigned long new_val)
{
	char digits[3 * sizeof(unsigned long)];
	size_t count = m->count, i, n = 0;
	unsigned long v = new_val;

	if (!m->buf || count >= m->size || pos > count || !len || len > count - pos)
		return false;
	do {
		digits[n++] = (char)('0' + v % 10);
		v /= 10;
	} while (v);
	if (n > len && n - len >= m->size - count)
		return false;
	for (i = 0; i < n / 2; i++) {
		char t = digits[i];

		digits[i] = digits[n - 1 - i];
		digits[n - 1 - i] = t;
	}
	if (n != len)
		memmove(m->buf + pos + n, m->buf + pos + len, count - (pos + len));
	memcpy(m->buf + pos, digits, n);
	m->count = count - len + n;
	return true;
}

static int or_fdinfo_ret(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	struct seq_file *m = *(struct seq_file **)ri->data;
	size_t pos, len;
	unsigned long old = 0, new_ino = 0, new_mnt = 0;
	int rewrites = 0;

	if (!m || (long)regs_return_value(regs) != 0)
		return 0;
	if (!m->buf || !m->count || m->count >= m->size)
		return 0;
	if (!or_reverse_visible())
		return 0;
	/* Several unrelated static functions have this name.  Only fdinfo output belongs
	 * to this hook; the proc file reference pins these dentries for the callback. */
	if (!m->file || !m->file->f_path.dentry ||
	    !m->file->f_path.dentry->d_parent ||
	    strcmp(m->file->f_path.dentry->d_parent->d_name.name, "fdinfo"))
		return 0;

	atomic_inc(&or_rev_fdinfo_hits);

	/* The ino is the rule's key and the same rule knows the target's mount id, so one lookup answers both lines.  ino
	 * first: it sits after mnt_id in the line, so shrinking or growing it cannot move that one. */
	if (or_fdinfo_find_dec(m, "ino:\t", 5, &pos, &len, &old) &&
	    old && susfs_open_redirect_spoof_ids(old, &new_ino, &new_mnt) &&
	    new_ino != old && or_fdinfo_write_dec(m, pos, len, new_ino))
		rewrites++;

	/* mnt_id, when a rule matched.  sus_mount rewrites this same label from ITS table and both probes are on the same
	 * function, so for an fd that is both "inside a hidden mount" and "the redirected file" the two return handlers race
	 * for which id wins - cosmetic (both are ids the caller could have been shown), and invisible in either module alone. */
	if (new_mnt && or_fdinfo_find_dec(m, "mnt_id:\t", 8, &pos, &len, &old) &&
	    old != new_mnt && or_fdinfo_write_dec(m, pos, len, new_mnt))
		rewrites++;

	if (rewrites)
		atomic_inc(&or_rev_fdinfo_rewrites);
	return 0;
}

/* seq_show is a duplicate static symbol on newer GKI kernels.  A symbol-name probe
 * selects one match, which need not be fs/proc/fd.c's callback.  Enumerate the exact
 * vmlinux matches just as sus_mount does and let the file check above select fdinfo. */
#define OR_FDINFO_MAX 8
static struct kretprobe kr_or_fdinfo[OR_FDINFO_MAX];
static int or_fdinfo_probes;
static int or_fdinfo_candidates;
static bool or_fdinfo_registered;

static void or_fdinfo_disarm(void);

static int or_fdinfo_arm(void)
{
	unsigned long addrs[OR_FDINFO_MAX];
	int i, rc;

	if (or_fdinfo_registered)
		return 0;
	or_fdinfo_candidates = ksu_find_symbol_all("seq_show", addrs, OR_FDINFO_MAX);
	if (or_fdinfo_candidates <= 0) {
		or_fdinfo_candidates = 0;
		return -ENOENT;
	}
	for (i = 0; i < or_fdinfo_candidates; i++) {
		struct kretprobe *kr = &kr_or_fdinfo[i];

		/* unregister leaves kprobe internals populated: reset the slot before rearming. */
		memset(kr, 0, sizeof(*kr));
		kr->kp.addr = (void *)addrs[i];
		kr->entry_handler = or_fdinfo_entry;
		kr->handler = or_fdinfo_ret;
		kr->data_size = sizeof(struct seq_file *);
		kr->maxactive = 16;
		rc = register_kretprobe(kr);
		if (rc) {
			pr_warn("open_redirect: register_kretprobe(seq_show candidate %d) failed %d\n", i, rc);
			kr->kp.addr = NULL;
			continue;
		}
		or_fdinfo_probes++;
	}
	if (or_fdinfo_probes != or_fdinfo_candidates) {
		or_fdinfo_disarm();
		return -EIO;
	}
	or_fdinfo_registered = true;
	SUSFS_LOGI("susfs_open_redirect: fdinfo hooked on %d/%d seq_show symbol(s)\n",
		   or_fdinfo_probes, or_fdinfo_candidates);
	return 0;
}

static void or_fdinfo_disarm(void)
{
	int i;

	for (i = 0; i < OR_FDINFO_MAX; i++) {
		if (kr_or_fdinfo[i].kp.addr) {
			unregister_kretprobe(&kr_or_fdinfo[i]);
			kr_or_fdinfo[i].kp.addr = NULL;
		}
	}
	or_fdinfo_probes = 0;
	or_fdinfo_candidates = 0;
	or_fdinfo_registered = false;
}

static bool or_registered;
static bool or_dpath_registered;
static bool or_statfs_registered;
/* Set by susfs_open_redirect_exit() while it holds or_lock; registration refuses afterwards.  The /proc node carries
 * no module reference, so exit has to close everything itself, and the guard is what keeps a concurrent rule write
 * from arming a hook the exit is already past. */
static bool or_exiting;

/* The forward direction is the name layer: susfs_or_entry.c's wrappers replace the five open syscall
 * entries, and the table here is what they ask.  The rule line in /proc is only worth a rule when
 * it can actually fire, so registration refuses while the layer is unarmed - a rule that cannot
 * fire silently does nothing while looking configured, which is worse than no rule. */
static int or_register(void)
{
	if (or_exiting)
		return -ENODEV;
	if (!susfs_or_entry_armed())
		return -ENODEV;
	if (or_registered)
		return 0;
	or_registered = true;
	SUSFS_LOGI("susfs_open_redirect: forward direction is the name layer (armed)\n");
	return 0;
}

/* Require every reverse hook before publishing a rule. Registration still does
 * not prove LTO reachability; the diagnostic hit counters remain necessary. */
static int or_register_reverse(void)
{
	int rc;

	if (or_exiting)
		return -ENODEV;

	if (!or_dpath_registered) {
		kr_or_dpath.kp.addr = NULL;
		kr_or_dpath.kp.flags = 0;
		rc = register_kretprobe(&kr_or_dpath);
		if (rc) {
			kr_or_dpath.kp.addr = NULL;
			pr_warn("open_redirect: register_kretprobe(d_path) failed %d - readlink not disguised (or already inlined)\n",
				rc);
		} else {
			or_dpath_registered = true;
			SUSFS_LOGI("susfs_open_redirect: reverse hook installed (d_path kretprobe)\n");
		}
	}

	if (!or_statfs_registered) {
		kr_or_vfs_statfs.kp.addr = NULL;
		kr_or_vfs_statfs.kp.flags = 0;
		rc = register_kretprobe(&kr_or_vfs_statfs);
		if (rc) {
			kr_or_vfs_statfs.kp.addr = NULL;
			pr_warn("open_redirect: register_kretprobe(vfs_statfs) failed %d - statfs not disguised (or already inlined)\n",
				rc);
		} else {
			or_statfs_registered = true;
			SUSFS_LOGI("susfs_open_redirect: reverse hook installed (vfs_statfs kretprobe)\n");
		}
	}
	rc = or_maps_arm();
	if (rc)
		pr_warn("open_redirect: maps/smaps listing registration failed %d\n", rc);
	if (!or_fdinfo_registered) {
		rc = or_fdinfo_arm();
		if (rc)
			pr_warn("open_redirect: register_kretprobe(seq_show) failed %d - fdinfo names the redirected inode\n",
				rc);
	}
	return or_dpath_registered && or_statfs_registered &&
	       or_maps_registered && or_fdinfo_registered ? 0 : -EOPNOTSUPP;
}

/* Caller holds or_lock; exit closes registration under this same lock. */
static void or_unregister(void)
{
	or_fdinfo_disarm();
	or_maps_disarm();
	if (or_statfs_registered) {
		unregister_kretprobe(&kr_or_vfs_statfs);
		or_statfs_registered = false;
	}
	if (or_dpath_registered) {
		unregister_kretprobe(&kr_or_dpath);
		or_dpath_registered = false;
	}

	/* Nothing left to take down for the forward direction here: it lives in susfs_or_entry.c and is
	 * unwound by susfs_or_entry_exit() before this file's teardown starts. */
	if (!or_registered)
		return;
	or_registered = false;
	SUSFS_LOGI("susfs_open_redirect: hooks removed\n");
}

/* ---- /proc/susfs_open_redirect ---- */
static int or_proc_show(struct seq_file *m, void *v);
static int or_proc_open(struct inode *inode, struct file *file);
static ssize_t or_proc_write(struct file *file, const char __user *buf,
			     size_t len, loff_t *off);

static const struct proc_ops or_proc_ops = {
	.proc_open = or_proc_open,
	.proc_read = seq_read,
	.proc_write = or_proc_write,
	.proc_lseek = seq_lseek,
	.proc_release = single_release,
};

static struct proc_dir_entry *or_proc_entry;

int susfs_open_redirect_init(void)
{
	int i;

	/* Never reachable in practice (the layer table runs init once), but a slot with stale fields
	 * from a failed partial load must not be reachable as a rule: BSS zeroes `dead`, which a
	 * reader would read as "live entry" on any non-zero nor. */
	for (i = 0; i < SUS_OR_MAX; i++)
		WRITE_ONCE(or_entries[i].dead, true);

	or_cred_getsecid =
		(void *)find_kernel_symbol_exact("security_cred_getsecid");
	if (!or_cred_getsecid)
		pr_warn("open_redirect: security_cred_getsecid not found - schemes 1/2 will be refused\n");
	or_resolve_su_sid();

	/* The reverse statfs face answers with the snapshot that or_add() took; without the symbol
	 * the snapshot stays zeroed, and statfs of the redirected file would report an empty
	 * filesystem on this fork (upstream answers from its own kstatfs cache; it always has the
	 * call available). */
	or_vfs_statfs_fn = (void *)find_kernel_symbol_exact("vfs_statfs");
	if (!or_vfs_statfs_fn)
		pr_warn("open_redirect: vfs_statfs not found - redirect rules will be refused\n");

	/* Forward direction = the name layer's syscall-entry wrappers (susfs_or_entry.c).  Best effort,
	 * on purpose: the layer is optional where the symbols are, refuses rules while it is unarmed,
	 * and logs one line per missing piece instead of letting any failure fail the module. */
	(void)susfs_or_entry_init();

	/* Only the /proc node is optional.  The reverse hooks are registered by or_add() - i.e. by the supercall as well -
	 * so this gate must never return early and skip other work.  0777 so DAC passes and sus_path's LSM layer answers ENOENT;
	 * without that layer the node would be world-writable, so it is not created at all (see susfs_kstat_init()). */
	if (susfs_control_node_allowed()) {
		or_proc_entry = proc_create("susfs_open_redirect", 0777, NULL,
					    &or_proc_ops);
		if (!or_proc_entry)
			pr_warn("proc_create(susfs_open_redirect) failed\n");
	} else {
		SUSFS_LOGI("susfs_open_redirect: /proc node not created (expose_proc=%d lsm=%d)\n",
			(int)susfs_expose_proc, (int)sus_path_lsm_active());
	}

	SUSFS_LOGI("susfs_open_redirect: %d rules (forward %s, proc %d)\n",
		susfs_open_redirect_rules,
		susfs_or_entry_armed() ? "armed" : "unavailable",
		or_proc_entry != NULL);
	return susfs_or_entry_armed() && or_vfs_statfs_fn ? 0 : -EOPNOTSUPP;
}

void susfs_open_redirect_exit(void)
{
	int i;

	/* The name layer down FIRST: its wrappers read the rule table, and no wrapper that survives
	 * in flight may find one of these consumers that is going away underneath it. */
	susfs_or_entry_exit();

	mutex_lock(&or_lock);
	or_exiting = true;
	or_unregister();
	mutex_unlock(&or_lock);
	if (or_proc_entry) {
		proc_remove(or_proc_entry);
		or_proc_entry = NULL;
	}

	/* No references to release, so teardown is just: dead everywhere, counters zeroed, and the
	 * free list forgotten.  Slots a reader is still inside stay dead-flagged rather than handed
	 * back - nor keeps counting them so nothing below walks a slot twice. */
	for (i = 0; i < nor; i++)
		WRITE_ONCE(or_entries[i].dead, true);
	smp_wmb();
	nor = 0;
	or_free_n = 0;
	WRITE_ONCE(susfs_open_redirect_rules, 0);
}

static int or_proc_show(struct seq_file *m, void *v)
{
	int i;

	mutex_lock(&or_lock);
	if (!susfs_open_redirect_rules) {
		seq_puts(m, "(empty)\n");
	} else {
		for (i = 0; i < READ_ONCE(nor); i++) {
			if (READ_ONCE(or_entries[i].dead))
				continue;
			seq_printf(m, "%s -> %s uid=%d (ino=%lu dev=%lu mnt=%lu | rev: ino=%lu dev=%lu)\n",
				   or_entries[i].target_pathname,
				   or_entries[i].redirected_pathname,
				   or_entries[i].uid_scheme,
				   or_entries[i].target_ino,
				   (unsigned long)or_entries[i].target_dev,
				   or_entries[i].target_mnt_id,
				   or_entries[i].redirected_ino,
				   (unsigned long)or_entries[i].redirected_dev);
		}
	}
	/* "armed" is not "asked": a hook whose counter stays 0 across a real read means GKI inlined its call sites
	 * and that surface is NOT disguised - hence the counters below (fdinfo's surface and provenance are in the face-4
	 * block above).  mnt_id is NOT rewritten here: that id belongs to sus_mount's table.  The first number is this
	 * module's own forward layer (susfs_or_entry_armed() - the native openat/openat2 wrapper pair), not this file's
	 * registration flag: the rule lines above are only answered by callers when it holds. */
	seq_printf(m, "hooks: open=%d dpath=%d statfs=%d maps=%d fdinfo=%d | rev hits: dpath=%d statfs=%d maps=%d/%d/%d fdinfo=%d/%d | su_sid=%u | fdinfo_probes=%d/%d\n",
		   susfs_or_entry_armed(), or_dpath_registered, or_statfs_registered,
		   or_maps_registered, or_fdinfo_registered,
		   atomic_read(&or_rev_dpath_hits),
		   atomic_read(&or_rev_statfs_hits),
		   atomic_read(&or_rev_maps_hits),
		   atomic_read(&or_rev_maps_rewrites),
		   atomic_read(&or_rev_maps_names),
		   atomic_read(&or_rev_fdinfo_hits),
		   atomic_read(&or_rev_fdinfo_rewrites),
		   or_su_sid, or_fdinfo_probes, or_fdinfo_candidates);
	mutex_unlock(&or_lock);
	return 0;
}

static int or_proc_open(struct inode *inode, struct file *file)
{
	/* 0777 is deliberate (the ENOENT contract comes from sus_path's hidden set, not from the mode), so refuse non-root
	 * callers here too - see the note in susfs_enable_log.c's log_proc_open(). */
	if (current_uid().val != 0)
		return -ENOENT;
	return single_open(file, or_proc_show, NULL);
}

static int split_ws(char *buf, char **argv, int max)
{
	int argc = 0;
	char *p = buf;

	while (argc < max) {
		while (*p == ' ' || *p == '\t' || *p == '\n')
			p++;
		if (*p == '\0')
			break;
		argv[argc++] = p;
		while (*p && *p != ' ' && *p != '\t' && *p != '\n')
			p++;
		if (*p)
			*p++ = '\0';
	}
	return argc;
}

static void or_reclaim_slot(struct sus_or_entry *e);

static int or_add(const char *target, const char *redirected, int scheme)
{
	struct sus_or_entry *e;
	struct path tp, rp;
	struct inode *ti, *ri;
	struct kstatfs spoofed_kstatfs;
	int rc;

	/* upstream susfs.c:792-796 */
	if (scheme < UID_NON_APP_PROC || scheme > UID_UMOUNTED_PROC)
		return -EINVAL;

	/* Both come from char[256] ABI fields (supercall) or a NUL-terminated command buffer (proc write); reject the
	 * unterminated case instead of letting strcmp()/kern_path() read past the struct or truncate a path into a rule. */
	if (!susfs_abi_path_ok(target, SUSFS_OR_PATH_MAX) ||
	    !susfs_abi_path_ok(redirected, SUSFS_OR_PATH_MAX))
		return -ENAMETOOLONG;

	rc = kern_path(target, LOOKUP_FOLLOW, &tp);
	if (rc)
		return rc;

	/* Upstream takes the target's kstatfs snapshot AT ADD TIME (susfs.c:851) for the reverse statfs face: rules hold
	 * no reference on the target, but the snapshot belongs to the rule as configured so the disguise survives the
	 * same filesystem churn that numbers alone survive.  Zeroed first: a refused call (no symbol resolved, an
	 * unreadable file) leaves the rule answering an empty filesystem rather than the redirected file's real
	 * numbers, which is the direction least likely to leak. */
	memset(&spoofed_kstatfs, 0, sizeof(spoofed_kstatfs));
	rc = or_statfs_snapshot(&tp, &spoofed_kstatfs);
	if (rc) {
		path_put(&tp);
		return rc;
	}

	ti = d_backing_inode(tp.dentry);
	if (!ti) {
		path_put(&tp);
		return -ENOENT;
	}

	/* resolve redirected (numbers and names are what the rule keeps; nothing here pins) */
	rc = kern_path(redirected, LOOKUP_FOLLOW, &rp);
	if (rc) {
		path_put(&tp);
		return rc;
	}
	ri = d_backing_inode(rp.dentry);
	if (!ri) {
		path_put(&rp);
		path_put(&tp);
		return -ENOENT;
	}

	/* upstream susfs.c:824-829 - FUSE is refused outright, on either side, and rejecting is the whole handling: no
	 * silent rewrite, no partial rule.  (d_sb is the dentry's superblock: what upstream reads through inode->i_sb.) */
	if (tp.dentry->d_sb->s_magic == FUSE_SUPER_MAGIC ||
	    rp.dentry->d_sb->s_magic == FUSE_SUPER_MAGIC) {
		pr_warn("open_redirect: FUSE fs is not supported for open_redirect feature\n");
		path_put(&rp);
		path_put(&tp);
		return -EINVAL;
	}

	/* Schemes 1 and 2 are decisions about the KernelSU su domain.  Upstream always has that sid (KernelSU hands it
	 * over at setuid-hook setup), an LKM resolves the context itself - and if it does not resolve, "not in su domain"
	 * is true for the su process too, i.e. the one process the rule exists to spare would be redirected.  Refuse. */
	if (scheme == UID_ROOT_PROC_EXCEPT_SU_PROC ||
	    scheme == UID_NON_SU_PROC) {
		or_resolve_su_sid();
		if (!or_su_sid) {
			pr_warn("open_redirect: scheme %d needs a resolvable su domain - set or_su_ctx=u:r:su:s0 (currently \"%s\")\n",
				scheme, or_su_ctx);
			path_put(&rp);
			path_put(&tp);
			return -EOPNOTSUPP;
		}
	}

	/* The name layer is armed BEFORE any rule is written: wrappers ask the table, so a rule must
	 * never be added while the layer that answers it cannot. */
	rc = or_register();
	if (rc) {
		path_put(&rp);
		path_put(&tp);
		pr_warn("open_redirect: hook registration failed %d\n", rc);
		return rc;
	}
	rc = or_register_reverse();
	if (rc) {
		path_put(&rp);
		path_put(&tp);
		return rc;
	}

	/* upstream susfs.c:867-881: a name that another rule already uses as its redirected path belongs to that rule's
	 * reverse entry and must not be taken over. */
	e = or_find_by_path(target);
	if (!e && or_is_redirected_path(target)) {
		pr_warn("open_redirect: '%s' cannot be added because it is used for reversed lookup only\n",
			target);
		path_put(&rp);
		path_put(&tp);
		return -EINVAL;
	}

	/* 9b27112: a rewrite hands the SAME slot back and re-takes it below, so a full table still
	 * accepts a rewrite of its own rule; only a NEW rule needs a slot that does not exist. */
	if (!e && !or_free_n && nor >= SUS_OR_MAX) {
		path_put(&rp);
		path_put(&tp);
		return -ENOSPC;
	}

	if (e) {
		/* Rewriting a rule: raise `dead`, wait out the readers, clear the fields, return the
		 * slot - the rewrite re-claims it before returning.  Readers keep a consistent old
		 * rule for the whole wait; the flag is what they key off. */
		or_reclaim_slot(e);
		e = NULL;
	} else {
		/* One more LIVE rule (the /proc "(empty)" gate and the wrappers' fast path read
		 * this; or_del() and clear take it back). */
		WRITE_ONCE(susfs_open_redirect_rules,
			   susfs_open_redirect_rules + 1);
	}

	/* Take the slot: from the free list when one exists (release order, newest back), from the
	 * never-used tail of the array otherwise. */
	if (or_free_n) {
		/* A free-list slot was left dead by or_release_slot(), so it is already outside the
		 * reader discipline. */
		e = &or_entries[or_free[--or_free_n]];
	} else {
		/* A never-used tail slot is BSS-zero, i.e. dead == false: raise dead and publish the
		 * larger nor only after, so a reader that observes the new count also observes the slot
		 * skipped while it is filled below. */
		e = &or_entries[nor];
		WRITE_ONCE(e->dead, true);
		smp_wmb();
		WRITE_ONCE(nor, nor + 1);
	}

	/* Keep the slot outside the reader count until every field is ready. */
	WRITE_ONCE(e->dead, true);
	smp_wmb();
	strscpy(e->target_pathname, target, SUSFS_OR_PATH_MAX);

	strscpy(e->redirected_pathname, redirected, SUSFS_OR_PATH_MAX);
	e->target_ino = ti->i_ino;
	e->target_dev = ti->i_sb->s_dev;
	e->target_igen = ti->i_generation;
	e->redirected_ino = ri->i_ino;
	e->redirected_dev = ri->i_sb->s_dev;
	e->redirected_igen = ri->i_generation;
	e->target_mnt_id = (unsigned long)real_mount(tp.mnt)->mnt_id;
	e->spoofed_kstatfs = spoofed_kstatfs;
	e->uid_scheme = scheme;
	smp_wmb();
	WRITE_ONCE(e->dead, false);	/* publish last: readers key off this */

	/* Both parsed paths are dropped right here: the entry keeps the numbers and the snapshot, and
	 * the names as strings, so the rule holds nothing that a filesystem teardown would wait for. */
	path_put(&rp);
	path_put(&tp);
	return 0;
}

/* The second half of a reclaim, without the wait: clear a slot that nobody can be looking at any more
 * and put it back on the free list.  Split out so or_clear_all() can pay for one grace period for all
 * the rules it drops instead of one each.
 *
 * The caller MUST have raised `dead` and waited a grace period before calling this: the flag is what
 * keeps a reader that started before the flag-change from being inside the entry while its fields
 * are cleared, and the wait is the kernel's guarantee about exactly those readers. */
static void or_release_slot(struct sus_or_entry *e)
{
	int idx = e - or_entries;

	WARN_ON_ONCE(idx < 0 || idx >= SUS_OR_MAX);
	WARN_ON_ONCE(!READ_ONCE(e->dead));
	WARN_ON_ONCE(or_free_n >= SUS_OR_MAX);
	memset(e, 0, sizeof(*e));
	/* memset zeroed the flag too; the handed-back slot stays dead (the next add sets it again
	 * before refilling). */
	WRITE_ONCE(e->dead, true);
	or_free[or_free_n++] = idx;
}

/* The first half of a reclaim: raise `dead` (so every lookup past this point skips the slot), wait
 * out the readers that were already looking, and only then clear.  A rewrite calls this on the old
 * rule and then re-takes the SAME slot from the free list - the cost of a rewrite stops being "one
 * slot of the 64 spent per add". */
static void or_reclaim_slot(struct sus_or_entry *e)
{
	WRITE_ONCE(e->dead, true);
	smp_wmb();
	synchronize_rcu();
	or_release_slot(e);
}

/* A grace period per rule would make a `clear` of a full table pay 64 waits; mark everything dead
 * first (one bitmask, for the ones that came back), pay ONE grace period for all of them, and
 * release the marked slots into the free list before returning.  Readers key off the flag, so a
 * reader that started after the flags but before the wait sees an empty table, and everything else
 * has the same guarantee as the single-rule path. */
static void or_clear_all(void)
{
	unsigned long live;
	int i;

	BUILD_BUG_ON(SUS_OR_MAX > BITS_PER_LONG);
	live = 0;
	for (i = 0; i < READ_ONCE(nor); i++) {
		if (READ_ONCE(or_entries[i].dead))
			continue;
		WRITE_ONCE(or_entries[i].dead, true);
		__set_bit(i, &live);
	}
	smp_wmb();
	WRITE_ONCE(susfs_open_redirect_rules, 0);
	synchronize_rcu();
	i = -1;
	while ((i = find_next_bit(&live, SUS_OR_MAX, i + 1)) < SUS_OR_MAX)
		or_release_slot(&or_entries[i]);
}

static void or_del(const char *target)
{
	struct sus_or_entry *e;

	e = or_find_by_path(target);
	if (!e || READ_ONCE(e->dead))
		return;

	/* The old shape left the slot dead forever (and a reader a NULL-dereference oops away from
	 * the cleared fields).  Now: dead first, the readers wait out, and the whole slot goes back
	 * to the free list - a subsequent add fills it exactly like a fresh one, including its
	 * generation, so the fields a slow pointer reaches are either this rule's (still complete:
	 * the clearing happens after every pre-flag reader has left) or a fresh rule's. */
	or_reclaim_slot(e);
	/* Only the rules whose target path matches are dropped; the reverse entry is not a separate object here, so it
	 * goes with the rule by definition. */
	if (susfs_open_redirect_rules)
		susfs_open_redirect_rules--;
}

/* Slots are never compacted (that array move was itself part of the race).  The reverse hooks stay registered for the
 * whole module lifetime: unregistering and re-registering them was observed to leave the hook silently gone after a burst
 * of add/del cycles, while an empty rule table already makes the lookups miss - so staying registered costs nothing.
 * The forward direction is the name layer's syscall entries (susfs_or_entry.c), which come down at exit by the same
 * principle: they belong to the module's lifetime, not to the rule table's occupancy. */

static ssize_t or_proc_write(struct file *file, const char __user *buf,
			     size_t len, loff_t *off)
{
	char cmd[640];
	char *argv[8];
	int argc, err;
	long scheme;

	/* Same gate as or_proc_open(): an fd opened before the opener dropped privileges must not become a way in. */
	if (current_uid().val != 0)
		return -ENOENT;

	if (len >= sizeof(cmd))
		len = sizeof(cmd) - 1;
	if (copy_from_user(cmd, buf, len))
		return -EFAULT;
	cmd[len] = 0;

	argc = split_ws(cmd, argv, 8);
	if (argc == 0)
		return len;

	mutex_lock(&or_lock);
	err = -EINVAL;

	if (!strcmp(argv[0], "add_open_redirect") && argc == 4) {
		if (kstrtol(argv[3], 10, &scheme))
			err = -EINVAL;
		else
			err = or_add(argv[1], argv[2], (int)scheme);
	} else if (!strcmp(argv[0], "del") && argc == 2) {
		or_del(argv[1]);
		err = 0;
	} else if (!strcmp(argv[0], "clear")) {
		/* One grace period for the whole table (or_del() one at a time was paying one per
		 * rule - see or_clear_all()). */
		or_clear_all();
		err = 0;
	}

	mutex_unlock(&or_lock);

	if (err) {
		pr_warn("open_redirect proc write '%s' -> err %d\n", argv[0], err);
		return err;	/* surface the failure; success keeps returning len */
	}
	return len;
}

/* supercall: CMD_SUSFS_ADD_OPEN_REDIRECT */
void susfs_open_redirect_supercall(void __user **arg)
{
	struct st_susfs_open_redirect info = {0};
	int err;

	if (copy_from_user(&info, (void __user *)*arg, sizeof(info))) {
		info.err = -EFAULT;
		goto out;
	}

	mutex_lock(&or_lock);
	err = or_add(info.target_pathname, info.redirected_pathname,
		     info.uid_scheme);
	mutex_unlock(&or_lock);
	info.err = err;
out:
	/* upstream writes back only ->err for input-type commands */
	if (copy_to_user(&((struct st_susfs_open_redirect __user *)*arg)->err,
			 &info.err, sizeof(info.err)))
		pr_warn("open_redirect supercall copy_to_user failed\n");
}
