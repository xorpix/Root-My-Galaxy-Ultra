// SPDX-License-Identifier: GPL-2.0
/* Samsung may protect committed credentials and keep their reference counts
 * outside struct cred. Generic GKI get_cred()/put_cred() must therefore never
 * be emitted by this module for the registering task's credential object.
 *
 * Own an unmodified copy created by the running kernel's prepare_creds().
 * Only native override/revert/abort APIs touch that copy. Refcounts below
 * belong to our separately allocated wrapper, not to struct cred. The last
 * wrapper reference can go only after every borrower has reverted, so abort
 * never runs while the prepared credential is installed on a resolver. */
#include <linux/slab.h>
#include <linux/refcount.h>
#include <linux/atomic.h>
#include "sus_path_creds.h"

struct sus_path_cred {
    refcount_t refs;
    struct cred *cred;
};

static atomic_t live_contexts = ATOMIC_INIT(0);

struct sus_path_cred *sus_path_cred_prepare(void)
{
    struct sus_path_cred *ctx = kzalloc(sizeof(*ctx), GFP_KERNEL);

    if (!ctx)
        return NULL;
    ctx->cred = prepare_creds();
    if (!ctx->cred) {
        kfree(ctx);
        return NULL;
    }
    refcount_set(&ctx->refs, 1);
    atomic_inc(&live_contexts);
    return ctx;
}

void sus_path_cred_get(struct sus_path_cred *ctx)
{
    if (ctx)
        refcount_inc(&ctx->refs);
}

void sus_path_cred_put(struct sus_path_cred *ctx)
{
    if (!ctx || !refcount_dec_and_test(&ctx->refs))
        return;
    /* This is our prepare_creds() ownership reference, never a reference to a
     * committed caller cred. All native override references are reverted. */
    abort_creds(ctx->cred);
    atomic_dec(&live_contexts);
    kfree(ctx);
}

const struct cred *sus_path_cred_override(struct sus_path_cred *ctx)
{
    return ctx ? override_creds(ctx->cred) : NULL;
}

void sus_path_cred_revert(const struct cred *saved)
{
    if (saved)
        revert_creds(saved);
}

bool sus_path_cred_active(void)
{
    return atomic_read(&live_contexts) != 0;
}

int sus_path_cred_count(void)
{
    return atomic_read(&live_contexts);
}
