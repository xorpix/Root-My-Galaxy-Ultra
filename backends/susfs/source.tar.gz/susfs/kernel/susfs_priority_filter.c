// SPDX-License-Identifier: GPL-2.0
/*
 * Samsung adaptation of inforcqb/susfs4ksu-for-lkm PR #158, d55749105bea.
 * Hide configured app IDs from the four priority-by-UID queries/updates.
 *
 * Configuration is transactional and uses the root caller's existing credentials.
 * No credential/security blob is edited, and no path, mount or cred is retained.
 * Native and compat entries have separate originals and complete FP lifetimes.
 * All entries must install before this optional feature accepts configuration.
 * Empty configuration is the default; the priority fast path never allocates.
 */
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/cred.h>
#include <linux/user_namespace.h>
#include <linux/namei.h>
#include <linux/fs.h>
#include <linux/path.h>
#include <linux/slab.h>
#include <linux/bitmap.h>
#include <linux/rcupdate.h>
#include <linux/mutex.h>
#include <linux/string.h>
#include <linux/ctype.h>
#include <linux/uaccess.h>
#include <linux/resource.h>
#include <linux/ioprio.h>
#include <asm/unistd.h>
#include <asm/ptrace.h>

#include "susfs.h"
#include "susfs_abi.h"
#include "susfs_fp_hook.h"
#include "symbol_resolver.h"
#include "ksu_umount_gate.h"

#define PRIO_FIRST_APP 10000U
#define PRIO_LAST_APP  19999U
#define PRIO_APP_COUNT (PRIO_LAST_APP - PRIO_FIRST_APP + 1)
#define COMPAT_GETPRIORITY_NR 96
#define COMPAT_SETPRIORITY_NR 97
#define COMPAT_IOPRIO_SET_NR 314
#define COMPAT_IOPRIO_GET_NR 315

enum prio_operation { PRIO_GET, PRIO_SET, PRIO_IOGET, PRIO_IOSET, PRIO_OP_COUNT };

struct prio_uid_rules {
    unsigned long bits[BITS_TO_LONGS(PRIO_APP_COUNT)];
    unsigned int count;
};

static struct prio_uid_rules __rcu *prio_rules;
static DEFINE_MUTEX(prio_config_lock);
static bool prio_ready;
static unsigned int prio_count;
static unsigned long prio_generation;
static int (*prio_check_cap_fn)(int ioprio);
static_assert(__same_type(typeof(prio_check_cap_fn), typeof(&ioprio_check_cap)));
static struct susfs_fp_hook prio_hooks[PRIO_OP_COUNT];

static bool prio_should_hide_user(int which, int who, int user_class)
{
    struct prio_uid_rules *rules;
    uid_t caller = current_uid().val, target, appid, caller_appid;
    bool hidden = false;

    if (!READ_ONCE(prio_ready) || !READ_ONCE(prio_count) ||
        which != user_class || who <= 0 ||
        current_user_ns() != &init_user_ns ||
        uid_eq(current_euid(), GLOBAL_ROOT_UID))
        return false;
    caller_appid = caller % SUSFS_PER_USER_RANGE;
    /* Exclude system/shell in EVERY Android user, while retaining upstream's
     * app-space boundary. SDK sandboxes (20000+) and app-zygote children
     * (90000+) must not bypass filtering through a narrower caller range. */
    if (caller_appid < PRIO_FIRST_APP)
        return false;
    target = (uid_t)who;
    appid = target % SUSFS_PER_USER_RANGE;
    if (appid < PRIO_FIRST_APP || appid > PRIO_LAST_APP || appid == caller_appid ||
        !susfs_is_current_proc_umounted_app())
        return false;
    rcu_read_lock();
    rules = rcu_dereference(prio_rules);
    if (rules)
        hidden = test_bit(appid - PRIO_FIRST_APP, rules->bits);
    rcu_read_unlock();
    return hidden;
}

static __nocfi noinline long prio_dispatch(const struct pt_regs *regs,
                                          susfs_syscall_fn_t original,
                                          enum prio_operation operation)
{
    int user_class = operation == PRIO_IOGET || operation == PRIO_IOSET ?
        IOPRIO_WHO_USER : PRIO_USER;
    int rc;

    if (!original)
        return -ENOSYS;
    if (!prio_should_hide_user((int)regs->regs[0], (int)regs->regs[1], user_class))
        return original(regs);
    if (operation == PRIO_IOSET) {
        /* Linux validates the priority/capabilities BEFORE looking up a UID.
         * Keep those errors; returning ESRCH first creates a new detection signal. */
        rc = prio_check_cap_fn((int)regs->regs[2]);
        if (rc)
            return rc;
    }
    return -ESRCH;
}

#define PRIO_WRAPPER(name, slot, operation) \
static susfs_syscall_fn_t slot; \
static __nocfi noinline long name(const struct pt_regs *regs) \
{ \
    susfs_fp_callback_enter(&prio_hooks[operation]); \
    return susfs_fp_callback_return(&prio_hooks[operation], \
        prio_dispatch(regs, READ_ONCE(slot), operation)); \
}

PRIO_WRAPPER(prio_wrap_getpriority, prio_orig_getpriority, PRIO_GET)
PRIO_WRAPPER(prio_wrap_setpriority, prio_orig_setpriority, PRIO_SET)
PRIO_WRAPPER(prio_wrap_ioprio_get, prio_orig_ioprio_get, PRIO_IOGET)
PRIO_WRAPPER(prio_wrap_ioprio_set, prio_orig_ioprio_set, PRIO_IOSET)
PRIO_WRAPPER(prio_wrap_compat_getpriority, prio_orig_compat_getpriority, PRIO_GET)
PRIO_WRAPPER(prio_wrap_compat_setpriority, prio_orig_compat_setpriority, PRIO_SET)
PRIO_WRAPPER(prio_wrap_compat_ioprio_get, prio_orig_compat_ioprio_get, PRIO_IOGET)
PRIO_WRAPPER(prio_wrap_compat_ioprio_set, prio_orig_compat_ioprio_set, PRIO_IOSET)

static struct susfs_fp_hook prio_hooks[PRIO_OP_COUNT] = {
    { .nr = __NR_getpriority, .nr_compat = COMPAT_GETPRIORITY_NR,
      .name = "priority/getpriority", .sym = "__arm64_sys_getpriority",
      .wrapper = prio_wrap_getpriority, .orig_slot = &prio_orig_getpriority,
      .compat_wrapper = prio_wrap_compat_getpriority, .orig_slot_compat = &prio_orig_compat_getpriority },
    { .nr = __NR_setpriority, .nr_compat = COMPAT_SETPRIORITY_NR,
      .name = "priority/setpriority", .sym = "__arm64_sys_setpriority",
      .wrapper = prio_wrap_setpriority, .orig_slot = &prio_orig_setpriority,
      .compat_wrapper = prio_wrap_compat_setpriority, .orig_slot_compat = &prio_orig_compat_setpriority },
    { .nr = __NR_ioprio_get, .nr_compat = COMPAT_IOPRIO_GET_NR,
      .name = "priority/ioprio_get", .sym = "__arm64_sys_ioprio_get",
      .wrapper = prio_wrap_ioprio_get, .orig_slot = &prio_orig_ioprio_get,
      .compat_wrapper = prio_wrap_compat_ioprio_get, .orig_slot_compat = &prio_orig_compat_ioprio_get },
    { .nr = __NR_ioprio_set, .nr_compat = COMPAT_IOPRIO_SET_NR,
      .name = "priority/ioprio_set", .sym = "__arm64_sys_ioprio_set",
      .wrapper = prio_wrap_ioprio_set, .orig_slot = &prio_orig_ioprio_set,
      .compat_wrapper = prio_wrap_compat_ioprio_set, .orig_slot_compat = &prio_orig_compat_ioprio_set },
};

static bool prio_package_valid(const char *package)
{
    const unsigned char *p = (const unsigned char *)package;
    bool segment_start = true;
    size_t length = strlen(package);

    if (!length || length > NAME_MAX)
        return false;
    for (; *p; p++) {
        if (*p == '.') {
            if (segment_start)
                return false;
            segment_start = true;
        } else {
            if (!(isalpha(*p) || *p == '_' || (!segment_start && isdigit(*p))))
                return false;
            segment_start = false;
        }
    }
    return !segment_start;
}

static int prio_resolve_uid(const char *package, uid_t *uid)
{
    char pathname[sizeof("/data/data/") + NAME_MAX];
    struct path path;
    struct inode *inode;
    int rc;

    if (!prio_package_valid(package))
        return -EINVAL;
    if (snprintf(pathname, sizeof(pathname), "/data/data/%s", package) >= sizeof(pathname))
        return -ENAMETOOLONG;
    rc = kern_path(pathname, LOOKUP_FOLLOW, &path);
    if (rc)
        return rc;
    inode = d_backing_inode(path.dentry);
    if (!inode || !S_ISDIR(inode->i_mode))
        rc = -ENOTDIR;
    else {
        *uid = from_kuid(&init_user_ns, inode->i_uid);
        if (*uid < PRIO_FIRST_APP || *uid > PRIO_LAST_APP)
            rc = -ERANGE;
    }
    path_put(&path);
    return rc;
}

static int prio_build_rules(char *packages, struct prio_uid_rules *rules)
{
    char *cursor = packages, *token;
    unsigned int parsed = 0;

    while ((token = strsep(&cursor, ",")) != NULL) {
        uid_t uid;
        int rc;

        token = strim(token);
        if (!*token)
            continue;
        rc = prio_resolve_uid(token, &uid);
        if (rc)
            return rc;
        if (!test_and_set_bit(uid - PRIO_FIRST_APP, rules->bits))
            rules->count++;
        if (!(++parsed & 63))
            cond_resched();
    }
    return 0;
}

static int prio_replace_rules(char *packages)
{
    struct prio_uid_rules *next, *previous;
    int rc;

    if (!uid_eq(current_euid(), GLOBAL_ROOT_UID) || current_user_ns() != &init_user_ns)
        return -EPERM;
    next = kzalloc(sizeof(*next), GFP_KERNEL);
    if (!next)
        return -ENOMEM;
    rc = prio_build_rules(packages, next);
    if (rc)
        goto out;
    mutex_lock(&prio_config_lock);
    if (!prio_ready) {
        rc = -ENODEV;
        mutex_unlock(&prio_config_lock);
        goto out;
    }
    previous = rcu_dereference_protected(prio_rules, lockdep_is_held(&prio_config_lock));
    rcu_assign_pointer(prio_rules, next->count ? next : NULL);
    WRITE_ONCE(prio_count, next->count);
    prio_generation++;
    if (next->count)
        next = NULL;
    mutex_unlock(&prio_config_lock);
    if (previous) {
        synchronize_rcu();
        kfree(previous);
    }
out:
    kfree(next);
    return rc;
}

void susfs_priority_filter_supercall(void __user **arg)
{
    struct st_susfs_priority_uid_filter *info;
    int rc;

    info = kvzalloc(sizeof(*info), GFP_KERNEL);
    if (!info) {
        rc = -ENOMEM;
        goto reply;
    }
    if (copy_from_user(info, *arg, sizeof(*info)))
        rc = -EFAULT;
    else if (strnlen(info->app_strings, sizeof(info->app_strings)) == sizeof(info->app_strings))
        rc = -EINVAL;
    else
        rc = prio_replace_rules(info->app_strings);
    kvfree(info);
reply:
    if (copy_to_user(&((struct st_susfs_priority_uid_filter __user *)*arg)->err,
                     &rc, sizeof(rc)))
        pr_warn("priority_filter: cannot return command result\n");
}

static int prio_status_show(char *buf, const struct kernel_param *kp)
{
    int length;

    mutex_lock(&prio_config_lock);
    length = scnprintf(buf, PAGE_SIZE, "ready=%u configured=%u generation=%lu\n",
                       prio_ready ? 1 : 0, prio_count, prio_generation);
    mutex_unlock(&prio_config_lock);
    return length;
}

static const struct kernel_param_ops prio_status_ops = { .get = prio_status_show };
module_param_cb(priority_filter, &prio_status_ops, NULL, 0400);

void susfs_priority_filter_exit(void)
{
    struct prio_uid_rules *previous;
    int i;

    mutex_lock(&prio_config_lock);
    WRITE_ONCE(prio_ready, false);
    previous = rcu_dereference_protected(prio_rules, lockdep_is_held(&prio_config_lock));
    rcu_assign_pointer(prio_rules, NULL);
    WRITE_ONCE(prio_count, 0);
    mutex_unlock(&prio_config_lock);
    for (i = PRIO_OP_COUNT - 1; i >= 0; i--)
        susfs_fp_remove(&prio_hooks[i]);
    synchronize_rcu();
    kfree(previous);
    prio_check_cap_fn = NULL;
}

int susfs_priority_filter_init(void)
{
    int i, rc;

    prio_check_cap_fn = (void *)find_kernel_symbol_exact("ioprio_check_cap");
    if (!prio_check_cap_fn)
        return -EOPNOTSUPP;
    for (i = 0; i < PRIO_OP_COUNT; i++) {
        rc = susfs_fp_install(&prio_hooks[i]);
        if (rc)
            goto rollback;
        if (IS_ENABLED(CONFIG_COMPAT) && !prio_hooks[i].compat_installed) {
            rc = -EOPNOTSUPP;
            goto rollback;
        }
    }
    mutex_lock(&prio_config_lock);
    WRITE_ONCE(prio_ready, true);
    mutex_unlock(&prio_config_lock);
    return 0;
rollback:
    susfs_priority_filter_exit();
    return rc;
}
