// SPDX-License-Identifier: GPL-2.0
/*
 * Samsung adaptation of inforcqb/susfs4ksu-for-lkm PR #158, d55749105bea.
 * Hide configured app IDs from the four priority-by-UID queries/updates.
 *
 * Configuration is transactional and uses the root caller's existing credentials.
 * No credential/security blob is edited, and no path, mount or cred is retained.
 * Native and compat table entries have separate originals and complete lifetimes.
 * A refused write can use verified shared entry probes, also with full draining.
 * Complete coverage must install before this optional feature accepts configuration.
 * Empty configuration is the default; the priority fast path never allocates.
 */
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/cred.h>
#include <linux/user_namespace.h>
#include <linux/namei.h>
#include <linux/fs.h>
#include <linux/path.h>
#include <linux/slab.h>
#include <linux/bitmap.h>
#include <linux/rcupdate.h>
#include <linux/mutex.h>
#include <linux/string.h>
#include <linux/ctype.h>
#include <linux/uaccess.h>
#include <linux/resource.h>
#include <linux/ioprio.h>
#include <linux/kprobes.h>
#include <asm/unistd.h>
#include <asm/ptrace.h>

#include "susfs.h"
#include "susfs_abi.h"
#include "susfs_fp_hook.h"
#include "susfs_kprobe.h"
#include "symbol_resolver.h"
#include "ksu_umount_gate.h"

#define PRIO_FIRST_APP 10000U
#define PRIO_LAST_APP  19999U
#define PRIO_APP_COUNT (PRIO_LAST_APP - PRIO_FIRST_APP + 1)
#define COMPAT_GETPRIORITY_NR 96
#define COMPAT_SETPRIORITY_NR 97
#define COMPAT_IOPRIO_SET_NR 314
#define COMPAT_IOPRIO_GET_NR 315

enum prio_operation { PRIO_GET, PRIO_SET, PRIO_IOGET, PRIO_IOSET, PRIO_OP_COUNT };

struct prio_uid_rules {
    unsigned long bits[BITS_TO_LONGS(PRIO_APP_COUNT)];
    unsigned int count;
    bool automatic;
    uid_t own_appid;
};

static struct prio_uid_rules __rcu *prio_rules;
static DEFINE_MUTEX(prio_config_lock);
static bool prio_ready;
static bool prio_enabled;
static bool prio_boot_auto;
static int prio_boot_appid;
module_param_named(priority_auto_root, prio_boot_auto, bool, 0400);
module_param_named(priority_appid, prio_boot_appid, int, 0400);

static unsigned int prio_count;
static unsigned long prio_generation;
static int (*prio_check_cap_fn)(int ioprio);
static_assert(__same_type(typeof(prio_check_cap_fn), typeof(&ioprio_check_cap)));
static struct susfs_fp_hook prio_hooks[PRIO_OP_COUNT];
/* Tracks registered entry probes so partial installation can be drained. */
static unsigned int prio_probe_mask;

static bool prio_should_hide_user(int which, int who, int user_class)
{
    struct prio_uid_rules *rules;
    uid_t caller = current_uid().val, target, appid, caller_appid;
    bool hidden = false;

    if (!READ_ONCE(prio_ready) || !READ_ONCE(prio_enabled) ||
        which != user_class || who <= 0 ||
        current_user_ns() != &init_user_ns ||
        uid_eq(current_euid(), GLOBAL_ROOT_UID))
        return false;
    caller_appid = caller % SUSFS_PER_USER_RANGE;
    /* Exclude system/shell in EVERY Android user, while retaining upstream's
     * app-space boundary. SDK sandboxes (20000+) and app-zygote children
     * (90000+) must not bypass filtering through a narrower caller range. */
    if (caller_appid < PRIO_FIRST_APP)
        return false;
    target = (uid_t)who;
    appid = target % SUSFS_PER_USER_RANGE;
    if (appid < PRIO_FIRST_APP || appid > PRIO_LAST_APP || appid == caller_appid ||
        !susfs_is_current_proc_umounted_app())
        return false;
    rcu_read_lock();
    rules = rcu_dereference(prio_rules);
    if (rules) {
        hidden = test_bit(appid - PRIO_FIRST_APP, rules->bits);
        if (!hidden && rules->automatic)
            hidden = appid == rules->own_appid || susfs_ksu_uid_granted_root(target);
    }
    rcu_read_unlock();
    return hidden;
}

static __nocfi noinline bool prio_filter_result(const struct pt_regs *regs,
                               enum prio_operation operation, long *result)
{
    int user_class = operation == PRIO_IOGET || operation == PRIO_IOSET ?
        IOPRIO_WHO_USER : PRIO_USER;
    int rc;

    if (!prio_should_hide_user((int)regs->regs[0], (int)regs->regs[1], user_class))
        return false;
    if (operation == PRIO_IOSET) {
        /* Linux validates the priority/capabilities BEFORE looking up a UID.
         * Keep those errors; returning ESRCH first creates a new detection signal. */
        rc = prio_check_cap_fn((int)regs->regs[2]);
        if (rc) {
            *result = rc;
            return true;
        }
    }
    *result = -ESRCH;
    return true;
}

static __nocfi noinline long prio_dispatch(const struct pt_regs *regs,
                                          susfs_syscall_fn_t original,
                                          enum prio_operation operation)
{
    long result;

    if (!original)
        return -ENOSYS;
    return prio_filter_result(regs, operation, &result) ? result : original(regs);
}

#define PRIO_WRAPPER(name, slot, operation) \
static susfs_syscall_fn_t slot; \
static __nocfi noinline long name(const struct pt_regs *regs) \
{ \
    susfs_fp_callback_enter(&prio_hooks[operation]); \
    return susfs_fp_callback_return(&prio_hooks[operation], \
        prio_dispatch(regs, READ_ONCE(slot), operation)); \
}

PRIO_WRAPPER(prio_wrap_getpriority, prio_orig_getpriority, PRIO_GET)
PRIO_WRAPPER(prio_wrap_setpriority, prio_orig_setpriority, PRIO_SET)
PRIO_WRAPPER(prio_wrap_ioprio_get, prio_orig_ioprio_get, PRIO_IOGET)
PRIO_WRAPPER(prio_wrap_ioprio_set, prio_orig_ioprio_set, PRIO_IOSET)
PRIO_WRAPPER(prio_wrap_compat_getpriority, prio_orig_compat_getpriority, PRIO_GET)
PRIO_WRAPPER(prio_wrap_compat_setpriority, prio_orig_compat_setpriority, PRIO_SET)
PRIO_WRAPPER(prio_wrap_compat_ioprio_get, prio_orig_compat_ioprio_get, PRIO_IOGET)
PRIO_WRAPPER(prio_wrap_compat_ioprio_set, prio_orig_compat_ioprio_set, PRIO_IOSET)

static struct susfs_fp_hook prio_hooks[PRIO_OP_COUNT] = {
    { .nr = __NR_getpriority, .nr_compat = COMPAT_GETPRIORITY_NR,
      .name = "priority/getpriority", .sym = "__arm64_sys_getpriority",
      .wrapper = prio_wrap_getpriority, .orig_slot = &prio_orig_getpriority,
      .compat_wrapper = prio_wrap_compat_getpriority, .orig_slot_compat = &prio_orig_compat_getpriority },
    { .nr = __NR_setpriority, .nr_compat = COMPAT_SETPRIORITY_NR,
      .name = "priority/setpriority", .sym = "__arm64_sys_setpriority",
      .wrapper = prio_wrap_setpriority, .orig_slot = &prio_orig_setpriority,
      .compat_wrapper = prio_wrap_compat_setpriority, .orig_slot_compat = &prio_orig_compat_setpriority },
    { .nr = __NR_ioprio_get, .nr_compat = COMPAT_IOPRIO_GET_NR,
      .name = "priority/ioprio_get", .sym = "__arm64_sys_ioprio_get",
      .wrapper = prio_wrap_ioprio_get, .orig_slot = &prio_orig_ioprio_get,
      .compat_wrapper = prio_wrap_compat_ioprio_get, .orig_slot_compat = &prio_orig_compat_ioprio_get },
    { .nr = __NR_ioprio_set, .nr_compat = COMPAT_IOPRIO_SET_NR,
      .name = "priority/ioprio_set", .sym = "__arm64_sys_ioprio_set",
      .wrapper = prio_wrap_ioprio_set, .orig_slot = &prio_orig_ioprio_set,
      .compat_wrapper = prio_wrap_compat_ioprio_set, .orig_slot_compat = &prio_orig_compat_ioprio_set },
};

/* Samsung RKP can refuse the data-only table write. Use the kernel's supported
 * probe mechanism only after that exact failure and verified table restoration.
 * The handler never calls an original syscall or sleeps: it either leaves the
 * complete frame alone or returns the same filtered result before PAC executes.
 */
static int prio_probe_pre(struct pt_regs *regs, enum prio_operation operation)
{
    const struct pt_regs *syscall_regs = (const void *)regs->regs[0];
    long result;
    bool handled;

    susfs_fp_callback_enter(&prio_hooks[operation]);
    handled = prio_filter_result(syscall_regs, operation, &result);
    if (handled) {
        regs->pc = regs->regs[30];
        regs->regs[0] = result;
    }
    return susfs_fp_callback_return(&prio_hooks[operation], handled ? 1 : 0);
}

#define PRIO_PROBE_PRE(name, operation) \
static int name(struct kprobe *kp, struct pt_regs *regs) \
{ \
    return prio_probe_pre(regs, operation); \
}
PRIO_PROBE_PRE(prio_pre_getpriority, PRIO_GET)
PRIO_PROBE_PRE(prio_pre_setpriority, PRIO_SET)
PRIO_PROBE_PRE(prio_pre_ioprio_get, PRIO_IOGET)
PRIO_PROBE_PRE(prio_pre_ioprio_set, PRIO_IOSET)

/* A post handler prevents jump optimization, which ignores a pre handler's PC
 * redirection. Unregister drains this handler; Tasks RCU covers return tails. */
static void prio_probe_post(struct kprobe *kp, struct pt_regs *regs,
                            unsigned long flags)
{
}

static struct kprobe prio_probes[PRIO_OP_COUNT] = {
    { .pre_handler = prio_pre_getpriority, .post_handler = prio_probe_post },
    { .pre_handler = prio_pre_setpriority, .post_handler = prio_probe_post },
    { .pre_handler = prio_pre_ioprio_get, .post_handler = prio_probe_post },
    { .pre_handler = prio_pre_ioprio_set, .post_handler = prio_probe_post },
};

static int prio_probe_target(int operation, unsigned long *address)
{
    const struct susfs_fp_hook *hook = &prio_hooks[operation];
    const unsigned long *native = (const void *)susfs_fp_syscall_table();
    const unsigned long *compat = (const void *)susfs_fp_compat_syscall_table();
    unsigned long entry, compat_entry;
    u32 instruction;

    if (IS_ENABLED(CONFIG_ARM64_BTI_KERNEL))
        return -EOPNOTSUPP;
    if (!native || (IS_ENABLED(CONFIG_COMPAT) && !compat))
        return -ENOENT;
    if (copy_from_kernel_nofault(&entry, &native[hook->nr], sizeof(entry)))
        return -EFAULT;
    if (!ksu_symbol_is_start(entry, hook->sym))
        return -EOPNOTSUPP; /* no foreign hook, interior address or CFI stub */
    if (IS_ENABLED(CONFIG_COMPAT)) {
        if (copy_from_kernel_nofault(&compat_entry, &compat[hook->nr_compat],
                                     sizeof(compat_entry)))
            return -EFAULT;
        /* These four int-only syscalls share their entry on this Samsung
         * kernel. Reject a different ABI implementation rather than lose it. */
        if (compat_entry != entry)
            return -EOPNOTSUPP;
    }
    if (copy_from_kernel_nofault(&instruction, (const void *)entry,
                                 sizeof(instruction)))
        return -EFAULT;
    if (instruction == 0xd503245fU || instruction == 0xd50324dfU)
        return -EOPNOTSUPP; /* never replace a BTI call landing pad */
    *address = entry;
    return 0;
}

static void prio_remove_probes(void)
{
    unsigned int armed = prio_probe_mask;
    int i;

    for (i = PRIO_OP_COUNT - 1; i >= 0; i--) {
        if (armed & (1U << i)) {
            unregister_kprobe(&prio_probes[i]);
            susfs_kp_forget_addr(&prio_probes[i]);
        }
    }
    WRITE_ONCE(prio_probe_mask, 0);
    for (i = 0; i < PRIO_OP_COUNT; i++)
        if (armed & (1U << i))
            susfs_fp_drain(&prio_hooks[i]);
}

static int prio_install_probes(void)
{
    unsigned long targets[PRIO_OP_COUNT], checked;
    int i, rc;

    /* The failed table attempt may not have reached all four counters. */
    for (i = 0; i < PRIO_OP_COUNT; i++) {
        atomic_set(&prio_hooks[i].active_callbacks, 0);
        init_waitqueue_head(&prio_hooks[i].callback_waitq);
    }
    for (i = 0; i < PRIO_OP_COUNT; i++) {
        rc = prio_probe_target(i, &targets[i]);
        if (rc)
            return rc;
    }
    for (i = 0; i < PRIO_OP_COUNT; i++) {
        prio_probes[i].symbol_name = NULL;
        prio_probes[i].addr = (kprobe_opcode_t *)targets[i];
        prio_probes[i].flags = 0;
        rc = register_kprobe(&prio_probes[i]);
        if (rc) {
            susfs_kp_forget_addr(&prio_probes[i]);
            return rc;
        }
        WRITE_ONCE(prio_probe_mask, prio_probe_mask | (1U << i));
    }
    /* A changed/foreign table during registration must not silently bypass
     * the probes. All four entries must still prove both ABIs before ready. */
    for (i = 0; i < PRIO_OP_COUNT; i++) {
        rc = prio_probe_target(i, &checked);
        if (rc || checked != targets[i])
            return rc ? rc : -EAGAIN;
    }
    return 0;
}

static bool prio_package_valid(const char *package)
{
    const unsigned char *p = (const unsigned char *)package;
    bool segment_start = true;
    size_t length = strlen(package);

    if (!length || length > NAME_MAX)
        return false;
    for (; *p; p++) {
        if (*p == '.') {
            if (segment_start)
                return false;
            segment_start = true;
        } else {
            if (!(isalpha(*p) || *p == '_' || (!segment_start && isdigit(*p))))
                return false;
            segment_start = false;
        }
    }
    return !segment_start;
}

static int prio_resolve_uid(const char *package, uid_t *uid)
{
    char pathname[sizeof("/data/data/") + NAME_MAX];
    struct path path;
    struct inode *inode;
    int rc;

    if (!prio_package_valid(package))
        return -EINVAL;
    if (snprintf(pathname, sizeof(pathname), "/data/data/%s", package) >= sizeof(pathname))
        return -ENAMETOOLONG;
    rc = kern_path(pathname, LOOKUP_FOLLOW, &path);
    if (rc)
        return rc;
    inode = d_backing_inode(path.dentry);
    if (!inode || !S_ISDIR(inode->i_mode))
        rc = -ENOTDIR;
    else {
        *uid = from_kuid(&init_user_ns, inode->i_uid);
        if (*uid < PRIO_FIRST_APP || *uid > PRIO_LAST_APP)
            rc = -ERANGE;
    }
    path_put(&path);
    return rc;
}

static int prio_build_rules(char *packages, struct prio_uid_rules *rules)
{
    char *cursor = packages, *token;
    unsigned int parsed = 0;

    while ((token = strsep(&cursor, ",")) != NULL) {
        uid_t uid;
        int rc;

        token = strim(token);
        if (!*token)
            continue;
        rc = prio_resolve_uid(token, &uid);
        if (rc)
            return rc;
        if (!test_and_set_bit(uid - PRIO_FIRST_APP, rules->bits))
            rules->count++;
        if (!(++parsed & 63))
            cond_resched();
    }
    return 0;
}

/* Takes ownership of next and the held mutex. Never read published next after
 * unlocking: another writer can already have retired it. */
static void prio_commit_locked(struct prio_uid_rules *next, struct prio_uid_rules *previous)
{
    bool active = next->count || next->automatic;

    rcu_assign_pointer(prio_rules, active ? next : NULL);
    WRITE_ONCE(prio_count, next->count);
    WRITE_ONCE(prio_enabled, active);
    prio_generation++;
    if (next->count || next->automatic)
        next = NULL;
    mutex_unlock(&prio_config_lock);
    if (previous) {
        synchronize_rcu();
        kfree(previous);
    }
    kfree(next);
}

static int prio_replace_rules(char *packages)
{
    struct prio_uid_rules *next, *previous;
    int rc;

    if (!uid_eq(current_euid(), GLOBAL_ROOT_UID) || current_user_ns() != &init_user_ns)
        return -EPERM;
    next = kzalloc(sizeof(*next), GFP_KERNEL);
    if (!next)
        return -ENOMEM;
    rc = prio_build_rules(packages, next);
    if (rc)
        goto out;
    mutex_lock(&prio_config_lock);
    if (!prio_ready) {
        rc = -ENODEV;
        mutex_unlock(&prio_config_lock);
        goto out;
    }
    previous = rcu_dereference_protected(prio_rules, lockdep_is_held(&prio_config_lock));
    if (previous) {
        next->automatic = previous->automatic;
        next->own_appid = previous->own_appid;
    }
    prio_commit_locked(next, previous);
    return 0;
out:
    kfree(next);
    return rc;
}

static int prio_set_automatic(u32 enabled, u32 own_appid)
{
    struct prio_uid_rules *next, *previous;
    int rc = 0;

    if (!uid_eq(current_euid(), GLOBAL_ROOT_UID) || current_user_ns() != &init_user_ns)
        return -EPERM;
    if (enabled > 1 || (enabled ? own_appid < PRIO_FIRST_APP || own_appid > PRIO_LAST_APP : own_appid != 0))
        return -EINVAL;
    if (enabled && !susfs_ksu_root_available())
        return -EOPNOTSUPP;
    next = kzalloc(sizeof(*next), GFP_KERNEL);
    if (!next)
        return -ENOMEM;
    mutex_lock(&prio_config_lock);
    if (!prio_ready) {
        rc = -ENODEV;
        goto unlock;
    }
    previous = rcu_dereference_protected(prio_rules, lockdep_is_held(&prio_config_lock));
    if ((!previous && !enabled) || (previous && previous->automatic == !!enabled && previous->own_appid == own_appid))
        goto unlock;
    if (previous) {
        memcpy(next->bits, previous->bits, sizeof(next->bits));
        next->count = previous->count;
    }
    next->automatic = !!enabled;
    next->own_appid = own_appid;
    prio_commit_locked(next, previous);
    return 0;
unlock:
    mutex_unlock(&prio_config_lock);
    kfree(next);
    return rc;
}

void susfs_priority_auto_supercall(void __user **arg)
{
    struct st_rmgu_susfs_auto_root_apps info;
    int rc;

    if (copy_from_user(&info, *arg, sizeof(info)))
        rc = -EFAULT;
    else
        rc = prio_set_automatic(info.enabled, info.own_appid);
    if (copy_to_user(&((struct st_rmgu_susfs_auto_root_apps __user *)*arg)->err, &rc, sizeof(rc)))
        pr_warn("priority_filter: cannot return automatic selection result\n");
}

void susfs_priority_filter_supercall(void __user **arg)
{
    struct st_susfs_priority_uid_filter *info;
    int rc;

    info = kvzalloc(sizeof(*info), GFP_KERNEL);
    if (!info) {
        rc = -ENOMEM;
        goto reply;
    }
    if (copy_from_user(info, *arg, sizeof(*info)))
        rc = -EFAULT;
    else if (strnlen(info->app_strings, sizeof(info->app_strings)) == sizeof(info->app_strings))
        rc = -EINVAL;
    else
        rc = prio_replace_rules(info->app_strings);
    kvfree(info);
reply:
    if (copy_to_user(&((struct st_susfs_priority_uid_filter __user *)*arg)->err,
                     &rc, sizeof(rc)))
        pr_warn("priority_filter: cannot return command result\n");
}

static int prio_status_show(char *buf, const struct kernel_param *kp)
{
    int length;

    mutex_lock(&prio_config_lock);
    {
        struct prio_uid_rules *rules = rcu_dereference_protected(prio_rules, lockdep_is_held(&prio_config_lock));
        length = scnprintf(buf, PAGE_SIZE,
            "ready=%u configured=%u generation=%lu automatic=%u own_appid=%u root_lookup=%u\n",
            prio_ready ? 1 : 0, prio_count, prio_generation,
            rules && rules->automatic ? 1 : 0, rules ? rules->own_appid : 0,
            susfs_ksu_root_available() ? 1 : 0);
    }
    mutex_unlock(&prio_config_lock);
    return length;
}

static const struct kernel_param_ops prio_status_ops = { .get = prio_status_show };
module_param_cb(priority_filter, &prio_status_ops, NULL, 0400);

void susfs_priority_filter_exit(void)
{
    struct prio_uid_rules *previous;
    int i;

    mutex_lock(&prio_config_lock);
    WRITE_ONCE(prio_ready, false);
    previous = rcu_dereference_protected(prio_rules, lockdep_is_held(&prio_config_lock));
    rcu_assign_pointer(prio_rules, NULL);
    WRITE_ONCE(prio_count, 0);
    WRITE_ONCE(prio_enabled, false);
    mutex_unlock(&prio_config_lock);
    prio_remove_probes();
    for (i = PRIO_OP_COUNT - 1; i >= 0; i--)
        susfs_fp_remove(&prio_hooks[i]);
    synchronize_rcu();
    kfree(previous);
    prio_check_cap_fn = NULL;
}

int susfs_priority_filter_init(void)
{
    int i, rc;
    prio_check_cap_fn = (void *)find_kernel_symbol_exact("ioprio_check_cap");
    if (!prio_check_cap_fn) {
        return -EOPNOTSUPP;
    }
    for (i = 0; i < PRIO_OP_COUNT; i++) {
        rc = susfs_fp_install(&prio_hooks[i]);
        if (rc) {
            if (rc == -EFAULT) {
                /* remove() returns only after both tables are restored and
                 * published callbacks have drained. No forced RKP writes. */
                for (i = PRIO_OP_COUNT - 1; i >= 0; i--)
                    susfs_fp_remove(&prio_hooks[i]);
                rc = prio_install_probes();
                if (!rc)
                    goto ready;
            }
            goto rollback;
        }
        if (IS_ENABLED(CONFIG_COMPAT) && !prio_hooks[i].compat_installed) {
            rc = -EOPNOTSUPP;
            goto rollback;
        }
    }
ready:
    mutex_lock(&prio_config_lock);
    WRITE_ONCE(prio_ready, true);
    mutex_unlock(&prio_config_lock);
    if (prio_boot_auto) {
        rc = prio_set_automatic(1, prio_boot_appid);
        if (rc)
            pr_warn("priority_filter: automatic boot selection unavailable (%d)\n", rc);
    }
    return 0;
rollback:
    susfs_priority_filter_exit();
    return rc;
}
