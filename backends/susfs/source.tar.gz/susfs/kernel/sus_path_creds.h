/* SPDX-License-Identifier: GPL-2.0 */
#ifndef SUS_PATH_CREDS_H
#define SUS_PATH_CREDS_H

#include <linux/cred.h>

struct sus_path_cred;

/* prepare_creds() copies the registering task's subjective credentials without
 * modifying them. The pending rule owns the initial wrapper reference. */
struct sus_path_cred *sus_path_cred_prepare(void);
/* The caller must already own a wrapper reference or hold sus_path_lock while
 * borrowing a pending rule's reference. No struct cred field is touched here. */
void sus_path_cred_get(struct sus_path_cred *ctx);
void sus_path_cred_put(struct sus_path_cred *ctx);
const struct cred *sus_path_cred_override(struct sus_path_cred *ctx);
void sus_path_cred_revert(const struct cred *saved);
bool sus_path_cred_active(void);
int sus_path_cred_count(void);

#endif
