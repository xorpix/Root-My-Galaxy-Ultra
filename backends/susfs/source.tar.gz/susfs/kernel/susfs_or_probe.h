/* SPDX-License-Identifier: GPL-2.0 */
/* Private fallback for or_entry when Samsung refuses syscall-table writes.
 * Included after the five existing wrappers and their hook descriptors. */
#ifndef SUSFS_OR_PROBE_H
#define SUSFS_OR_PROBE_H

struct or_entry_probe {
	struct kprobe kp;
	unsigned long target;
	int native_kind;
	int compat_kind;
	bool registered;
};

static struct or_entry_probe or_entry_probes[SUSFS_OR_ENTRY_KIND_COUNT];
static int or_entry_probe_count;
static bool or_entry_probe_active;

/* Original-call markers live on the calling task's stack. The bucket lock
 * protects lookup/removal, but is never held across the original syscall.
 * No allocation, task_struct modification, CPU affinity or shared bypass flag
 * is needed, even if the original sleeps or a kretprobe changes its LR. */
#define OR_BYPASS_BITS 5
struct or_original_call {
	struct hlist_node node;
	struct task_struct *task;
	const struct pt_regs *regs;
	int kind;
};
struct or_bypass_bucket {
	raw_spinlock_t lock;
	struct hlist_head calls;
};
static struct or_bypass_bucket or_bypass_buckets[1U << OR_BYPASS_BITS];

static bool or_probe_is_original(const struct pt_regs *regs, int kind)
{
	struct or_bypass_bucket *bucket = &or_bypass_buckets[hash_ptr(current, OR_BYPASS_BITS)];
	struct or_original_call *call;
	unsigned long flags;
	bool found = false;

	raw_spin_lock_irqsave(&bucket->lock, flags);
	hlist_for_each_entry(call, &bucket->calls, node) {
		if (call->task == current && call->regs == regs && call->kind == kind) {
			found = true;
			break;
		}
	}
	raw_spin_unlock_irqrestore(&bucket->lock, flags);
	return found;
}

static __nocfi noinline long or_entry_original(const struct pt_regs *regs,
					      int kind, susfs_syscall_fn_t original)
{
	struct or_bypass_bucket *bucket;
	struct or_original_call call = { .task = current, .regs = regs, .kind = kind };
	unsigned long flags;
	long result;

	if (!READ_ONCE(or_entry_probe_active))
		return original(regs);
	bucket = &or_bypass_buckets[hash_ptr(current, OR_BYPASS_BITS)];
	raw_spin_lock_irqsave(&bucket->lock, flags);
	hlist_add_head(&call.node, &bucket->calls);
	raw_spin_unlock_irqrestore(&bucket->lock, flags);
	result = original(regs);
	raw_spin_lock_irqsave(&bucket->lock, flags);
	hlist_del(&call.node);
	raw_spin_unlock_irqrestore(&bucket->lock, flags);
	return result;
}

/* A reference acquired BEFORE the probe publishes this PC closes the gap
 * between unregister and the first instruction of the normal wrapper. The
 * existing wrapper owns a second, independently balanced reference. */
#define OR_PROBE_ADAPTER(name, wrapper, kind) \
static __nocfi noinline long name(const struct pt_regs *regs) \
{ \
	return susfs_fp_callback_return(&or_hooks[kind], wrapper(regs)); \
}
OR_PROBE_ADAPTER(or_probe_wrap_openat, or_wrap_openat, SUSFS_OR_ENTRY_OPENAT)
OR_PROBE_ADAPTER(or_probe_wrap_openat2, or_wrap_openat2, SUSFS_OR_ENTRY_OPENAT2)
OR_PROBE_ADAPTER(or_probe_wrap_compat_open, or_wrap_compat_open, SUSFS_OR_ENTRY_COMPAT_OPEN)
OR_PROBE_ADAPTER(or_probe_wrap_compat_openat, or_wrap_compat_openat, SUSFS_OR_ENTRY_COMPAT_OPENAT)
OR_PROBE_ADAPTER(or_probe_wrap_compat_openat2, or_wrap_compat_openat2, SUSFS_OR_ENTRY_COMPAT_OPENAT2)
#undef OR_PROBE_ADAPTER

static const susfs_syscall_fn_t or_probe_wrappers[] = {
	or_probe_wrap_openat, or_probe_wrap_openat2, or_probe_wrap_compat_open,
	or_probe_wrap_compat_openat, or_probe_wrap_compat_openat2,
};

static int or_entry_probe_pre(struct kprobe *kp, struct pt_regs *regs)
{
	struct or_entry_probe *probe = container_of(kp, struct or_entry_probe, kp);
	int kind;

	if (!smp_load_acquire(&or_entry_ready) || !READ_ONCE(or_entry_probe_active) ||
	    !susfs_open_redirect_active())
		return 0;
	kind = is_compat_task() ? probe->compat_kind : probe->native_kind;
	if (kind < 0 || kind >= SUSFS_OR_ENTRY_KIND_COUNT)
		return 0;
	if (or_probe_is_original((const void *)regs->regs[0], kind))
		return 0;
	susfs_fp_callback_enter(&or_hooks[kind]);
	regs->pc = (unsigned long)or_probe_wrappers[kind];
	return 1;
}

/* Keep PC changes effective on architectures that support optimized probes. */
static void or_entry_probe_post(struct kprobe *kp, struct pt_regs *regs,
				 unsigned long flags)
{
}

static int or_entry_probe_target(int kind, unsigned long *address, bool inspect_instruction)
{
	const struct susfs_fp_hook *hook = &or_hooks[kind];
	const unsigned long *table;
	unsigned long entry;
	u32 instruction;
	int nr;

	/* No callback may replace a BTI landing pad or run after PAC/prologue
	 * instructions. This fallback is deliberately narrower than table hooks. */
	if (IS_ENABLED(CONFIG_ARM64_BTI_KERNEL))
		return -EOPNOTSUPP;
	table = (const void *)(hook->nr >= 0 ? susfs_fp_syscall_table() :
					 susfs_fp_compat_syscall_table());
	nr = hook->nr >= 0 ? hook->nr : hook->nr_compat;
	if (!table)
		return -ENOENT;
	if (copy_from_kernel_nofault(&entry, &table[nr], sizeof(entry)))
		return -EFAULT;
	if (!ksu_symbol_is_start(entry, hook->sym))
		return -EOPNOTSUPP;
	if (!inspect_instruction) {
		*address = entry;
		return 0;
	}
	if (copy_from_kernel_nofault(&instruction, (const void *)entry, sizeof(instruction)))
		return -EFAULT;
	if (instruction == 0xd503245fU || instruction == 0xd50324dfU ||
	    (instruction & 0xffe0001fU) == 0xd4200000U)
		return -EOPNOTSUPP;
	*address = entry;
	return 0;
}

static void or_entry_probe_stop(void)
{
	int i;

	WRITE_ONCE(or_entry_probe_active, false);
	for (i = or_entry_probe_count - 1; i >= 0; i--) {
		if (!or_entry_probes[i].registered)
			continue;
		unregister_kprobe(&or_entry_probes[i].kp);
		susfs_kp_forget_addr(&or_entry_probes[i].kp);
		or_entry_probes[i].registered = false;
	}
	/* Unregister closes handler entry; references acquired there also cover
	 * wrappers still sleeping or not yet reached after exception return. */
	for (i = 0; i < (int)ARRAY_SIZE(or_hooks); i++)
		susfs_fp_drain(&or_hooks[i]);
	or_entry_probe_count = 0;
}

static int or_entry_probe_start(void)
{
	unsigned long targets[SUSFS_OR_ENTRY_KIND_COUNT], checked;
	int required = IS_ENABLED(CONFIG_COMPAT) ? SUSFS_OR_ENTRY_KIND_COUNT : 2;
	int i, j, rc;

	/* Called only after every attempted table hook was restored and drained. */
	for (i = 0; i < (int)ARRAY_SIZE(or_bypass_buckets); i++) {
		raw_spin_lock_init(&or_bypass_buckets[i].lock);
		INIT_HLIST_HEAD(&or_bypass_buckets[i].calls);
	}
	for (i = 0; i < (int)ARRAY_SIZE(or_hooks); i++) {
		atomic_set(&or_hooks[i].active_callbacks, 0);
		init_waitqueue_head(&or_hooks[i].callback_waitq);
	}
	for (i = 0; i < required; i++) {
		rc = or_entry_probe_target(i, &targets[i], true);
		if (rc)
			return rc;
	}
	memset(or_entry_probes, 0, sizeof(or_entry_probes));
	or_entry_probe_count = 0;
	for (i = 0; i < required; i++) {
		struct or_entry_probe *probe;
		int *kind;

		for (j = 0; j < or_entry_probe_count; j++)
			if (or_entry_probes[j].target == targets[i])
				break;
		probe = &or_entry_probes[j];
		if (j == or_entry_probe_count) {
			or_entry_probe_count++;
			probe->target = targets[i];
			probe->native_kind = probe->compat_kind = -1;
		}
		kind = or_hooks[i].nr >= 0 ? &probe->native_kind : &probe->compat_kind;
		if (*kind >= 0 && *kind != i) {
			rc = -EOPNOTSUPP;
			goto fail;
		}
		*kind = i;
		if (or_hooks[i].nr >= 0)
			WRITE_ONCE(*or_hooks[i].orig_slot, (susfs_syscall_fn_t)targets[i]);
		else
			WRITE_ONCE(*or_hooks[i].orig_slot_compat, (susfs_syscall_fn_t)targets[i]);
	}
	for (i = 0; i < or_entry_probe_count; i++) {
		struct or_entry_probe *probe = &or_entry_probes[i];

		probe->kp.addr = (kprobe_opcode_t *)probe->target;
		probe->kp.pre_handler = or_entry_probe_pre;
		probe->kp.post_handler = or_entry_probe_post;
		rc = register_kprobe(&probe->kp);
		if (rc) {
			susfs_kp_forget_addr(&probe->kp);
			goto fail;
		}
		probe->registered = true;
		if ((unsigned long)probe->kp.addr != probe->target) {
			rc = -EOPNOTSUPP;
			goto fail;
		}
	}
	/* Recheck every ABI's actual table slot after registration. An intervening
	 * foreign hook must not leave this feature advertised but unreachable. */
	for (i = 0; i < required; i++) {
		rc = or_entry_probe_target(i, &checked, false);
		if (rc || checked != targets[i]) {
			rc = rc ? rc : -EAGAIN;
			goto fail;
		}
	}
	WRITE_ONCE(or_entry_probe_active, true);
	return 0;
fail:
	or_entry_probe_stop();
	return rc;
}

#endif
