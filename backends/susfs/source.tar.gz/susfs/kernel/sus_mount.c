// SPDX-License-Identifier: GPL-2.0
/*
 * sus_mount.c - coherent mount visibility for non-su SELinux domains.
 *
 * Recognize real upstream KSU-range IDs, configured source/mountpoint prefixes,
 * exact KSU overlay sources, module bind roots, and overlay backing paths. Remember
 * (s_dev, root inode) for namespace copies without holding inode references.
 * Keep kernel IDs untouched, and map hidden IDs to a visible ancestor in
 * mountinfo, fdinfo and statx. cleanup_mnt retires mappings before ID reuse;
 * generic_shutdown_super invalidates filesystem identities before dev reuse.
 * A hidden overlay's statfs uses its actual EROFS lower path, with no cached
 * statistics, pathname lookup, or new persistent filesystem references.
 */
#include <linux/module.h>
#include <linux/kprobes.h>
#include <linux/fs.h>
#include <linux/seq_file.h>
#include <linux/stat.h>     /* struct statx (stx_mnt_id) */
#include <linux/uaccess.h>
#include <linux/sched.h>
#include <linux/cred.h>
#include <linux/nsproxy.h>
#include <linux/percpu.h>
#include <linux/rcupdate.h>
#include <linux/spinlock.h>
#include <linux/slab.h>
#include <linux/mm.h>		/* kvmalloc()/kvfree() for the keep-list staging buffers */
#include <linux/string.h>
#include <linux/list.h>
#include <linux/hashtable.h>
#include <linux/namei.h>
#include <linux/magic.h>
#include <linux/err.h>
#include <linux/errno.h>    /* -ENOSYS/-ENOENT/-ENOMEM used by the scan result */
#include <linux/dcache.h>   /* d_path() - called through a resolved symbol */
#include <linux/limits.h>   /* PATH_MAX, INT_MAX (via vdso/limits.h) */
#include <linux/security.h> /* security_secctx_to_secid() */
#include <linux/proc_fs.h>  /* proc_create() for /proc/susfs_hide_mounts */
#include <linux/version.h>  /* LINUX_VERSION_CODE / KERNEL_VERSION: nothing else here
                             * pulled version.h in, and -Werror=undef turned the
                             * version gates below into hard errors when it was missing */
#include <linux/rbtree.h>   /* >= 6.12: ns->mounts is an rb-tree, not a list */
#include <linux/rwsem.h>    /* >= 6.12: namespace_sem is a struct rw_semaphore */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
#include <linux/workqueue.h> /* >= 6.12: the deferred walk of a cloned namespace */
#endif
#include "mount.h"      /* fs/mount.h: struct mount + struct mnt_namespace + real_mount() */
#include "symbol_resolver.h"
#include "susfs_abi.h"
#include "susfs_log.h"
#include "susfs_control.h"
#include "susfs.h"	/* module-wide declarations */

/* ---- the "which mounts are ours" prefix list: state ----
 * Up here, not next to the control surface further down, because mount_stat() between
 * the two reports the list length and the rescan count - and declaring it below its
 * first use would be a compile error, not a style issue. */
#define SUS_MOUNT_KEEP_MAX 64
#define SUS_MOUNT_KEEP_LEN 128
#define SUS_MOUNT_KEEP_CMDLINE (SUS_MOUNT_KEEP_MAX * (SUS_MOUNT_KEEP_LEN + 2) + 32)

static char mount_keep[SUS_MOUNT_KEEP_MAX][SUS_MOUNT_KEEP_LEN] = { "/data/adb/" };
static int n_mount_keep = 1;
static DEFINE_MUTEX(sus_mount_config_lock);
static bool sus_mount_exiting;
static DEFINE_SPINLOCK(mount_keep_lock);
static const char *const mount_keep_default = "/data/adb/";
static atomic_t n_keep_rescans = ATOMIC_INIT(0);

/* All three mount-table hooks are required. A failed registration rolls back
 * the entire feature; a completed enable has 3/3, and a disabled feature 0/3. */
static int n_show_probes;

#define DEFAULT_KSU_MNT_ID 2000000000ULL

/* min_mnt_id is a raw ulong tunable: 0/1 would make EVERY mount line match the
 * threshold, hiding all of /proc/mounts, /proc/<pid>/mountinfo and mountstats from
 * every process, su included.  Below this it is clamped back to DEFAULT_KSU_MNT_ID. */
#define SUS_MOUNT_MIN_SANE_MNT_ID 1000

/* Hard bound on the mount-namespace walk.  A concurrent umount_tree() does
 * list_del_init() on the entry it removes, which makes that node point at
 * itself, so an unbounded list_for_each() can spin forever if it lands on it. */
#define SUS_MOUNT_MAX_SCAN 65536

/* Recognize IDs assigned by upstream SUSFS without allocating or changing IDs. */
#define SUS_MOUNT_KSU_ID_MIN ((unsigned int)DEFAULT_KSU_MNT_ID)

static unsigned long param_min_mnt_id = DEFAULT_KSU_MNT_ID;
module_param_named(min_mnt_id, param_min_mnt_id, ulong, 0400);

/* P2-12: SELinux context of the su/ksu domain, resolved to a sid at init.  Keep in sync
 * with susfs_avc_spoof.c's avc_su_ctx ("u:r:ksu:s0", the SukiSU variant; stock KernelSU
 * is "u:r:su:s0", override with susfs_guard_lkm.su_ctx=u:r:su:s0). */
static char param_su_ctx[128] = "u:r:ksu:s0";
module_param_string(su_ctx, param_su_ctx, sizeof(param_su_ctx), 0400);

static u32 su_sid;

/* security_cred_getsecid() is EXPORT_SYMBOL in security/security.c, but GKI's symbol
 * list is not guaranteed to carry it for modules, so it is resolved from kallsyms like
 * the other optional symbols this LKM uses. */
static void (*pfn_security_cred_getsecid)(const struct cred *cred, u32 *secid);
static char *(*pfn_d_path)(const struct path *path, char *buf, int buflen);
static char *(*pfn_dentry_path_raw)(const struct dentry *dentry, char *buf, int buflen);
static void (*pfn_ovl_path_lower)(struct dentry *dentry, struct path *path);
static void (*pfn_ovl_path_upper)(struct dentry *dentry, struct path *path);
static dev_t mount_data_dev;
static bool mount_data_dev_valid;
static bool sus_mount_path_is_ours(const char *s);

static void sus_mount_refresh_data_dev(void)
{
    struct path path;

    if (kern_path("/data", LOOKUP_FOLLOW, &path))
        return;
    WRITE_ONCE(mount_data_dev, path.dentry->d_sb->s_dev);
    WRITE_ONCE(mount_data_dev_valid, true);
    path_put(&path);
}

/* Check the actual /data filesystem, not a similar path on another device.
 * Reserve room for /data before dentry_path_raw's returned string. This works
 * for a bind root and for an overlay's borrowed upper/lower path, even in a
 * namespace that cannot reach /data/adb by pathname. No allocation or lookup
 * is allowed here: mount-table and statfs probes run in atomic context.
 * Overlong paths are left unmatched, never truncated into a false match. */
static __nocfi bool sus_mount_data_backing(struct dentry *dentry)
{
    char buf[256];
    char *root;

    if (!dentry || !dentry->d_sb || !READ_ONCE(mount_data_dev_valid) ||
        dentry->d_sb->s_dev != READ_ONCE(mount_data_dev) ||
        !pfn_dentry_path_raw)
        return false;
    root = pfn_dentry_path_raw(dentry, buf + 5, sizeof(buf) - 5);
    if (IS_ERR_OR_NULL(root) || root[0] != '/' || !root[1])
        return false;
    /* Preserve the existing module-root rule even after custom prefixes change. */
    if (!strncmp(root, "/adb/modules/", sizeof("/adb/modules/") - 1))
        return true;
    root -= 5;
    memcpy(root, "/data", 5);
    return sus_mount_path_is_ours(root);
}

/* One backing-path decision for every visibility surface, independent of the
 * text a particular /proc file happens to print. Overlay owns these borrowed
 * paths while the caller holds its mount/root. Inspect each upper and the
 * top-lower chain, bounded to four layers; do not depend on private ovl_fs
 * layouts or walk arbitrary lower-layer arrays. Unresolved helpers simply
 * leave this additional recognition unavailable. */
static __nocfi bool sus_mount_builtin(struct mount *r)
{
    struct path path;
    int depth;

    if (!r || !r->mnt.mnt_sb || !r->mnt.mnt_root)
        return false;
    if (r->mnt_devname && !strcmp(r->mnt_devname, "KSU") &&
        r->mnt.mnt_sb->s_magic == OVERLAYFS_SUPER_MAGIC)
        return true;
    if (sus_mount_data_backing(r->mnt.mnt_root))
        return true;
    path.mnt = &r->mnt;
    path.dentry = r->mnt.mnt_root;
    for (depth = 0; depth < 4; depth++) {
        struct path next = {0};

        if (!path.dentry->d_sb ||
            path.dentry->d_sb->s_magic != OVERLAYFS_SUPER_MAGIC)
            break;
        if (pfn_ovl_path_upper) {
            pfn_ovl_path_upper(path.dentry, &next);
            if (next.mnt && sus_mount_data_backing(next.dentry))
                return true;
        }
        if (!pfn_ovl_path_lower)
            break;
        next = (struct path){0};
        pfn_ovl_path_lower(path.dentry, &next);
        if (!next.mnt || !next.dentry ||
            (next.mnt == path.mnt && next.dentry == path.dentry))
            break;
        if (sus_mount_data_backing(next.dentry))
            return true;
        path = next;
    }
    return false;
}

/* __nocfi on every function that reaches a resolved kernel symbol through a function
 * pointer: kCFI validates the type hash at such a call site and panics with
 * "CFI failure (target: ...)" otherwise - measured on this device, so these wrappers
 * keep the attribute. */
static __nocfi bool sus_mount_is_su_domain(void)
{
    u32 sid = 0;

    /* Unresolved symbol or an unresolvable su context: we cannot tell su apart,
     * so nothing is exempted (hide from every process) - loud in the init log. */
    if (!pfn_security_cred_getsecid || !su_sid)
        return false;
    /* kprobe pre_handler runs on the probed task with preemption disabled:
     * reading current->cred and the LSM hook list never sleeps. */
    pfn_security_cred_getsecid(current_cred(), &sid);
    return sid == su_sid;
}

static __nocfi char *sus_mount_d_path(const struct path *path, char *buf, int buflen)
{
    if (!pfn_d_path)
        return ERR_PTR(-ENOSYS);
    return pfn_d_path(path, buf, buflen);
}

/* Effective threshold: clamped on every read too, because the sysfs knob can be
 * written at any time (init/enable also write the clamped value back). */
static unsigned long sus_mount_min_mnt_id(void)
{
    if (param_min_mnt_id < SUS_MOUNT_MIN_SANE_MNT_ID)
        return DEFAULT_KSU_MNT_ID;
    return param_min_mnt_id;
}

/* Declared up here because the new hooks' stat node reports it (it is otherwise
 * set by sus_mount_register() further down). */
static bool mount_registered;

/* ---- fdinfo/statx use the same visible ancestor as mountinfo ----
 * Numeric-only entries: no mount, superblock or inode reference is retained.
 * Retire at cleanup_mnt before the mount ID is freed, and at superblock shutdown
 * before the device number is recycled. Ordinary mount reads also discard a
 * stale mapping defensively. The hash grows past the old 64-slot limit without
 * allocating in a sleeping context inside a probe.
 */
#define SUS_MOUNT_IDMAP_BITS 10
/* Atomic allocation is bounded and failures are observable. Dead namespace
 * clones are retired by cleanup_mnt, before the allocator can reuse their IDs. */
#define SUS_MOUNT_IDMAP_MAX 8192

struct sus_mount_idmap_entry {
    struct hlist_node node;
    int sus_id;
    int shown_id;
    dev_t s_dev;
};

static DEFINE_HASHTABLE(mount_idmap, SUS_MOUNT_IDMAP_BITS);
static int n_idmap, n_idmap_peak;
static DEFINE_SPINLOCK(idmap_lock);
static atomic_t n_idmap_recycled = ATOMIC_INIT(0);
static atomic_t n_idmap_dropped_dev = ATOMIC_INIT(0);
static atomic_t n_idmap_freed = ATOMIC_INIT(0);
static atomic_t n_idmap_full = ATOMIC_INIT(0);
static atomic_t n_idmap_allocfail = ATOMIC_INIT(0);
static atomic_t n_fdinfo_hits = ATOMIC_INIT(0);
static atomic_t n_fdinfo_rewrites = ATOMIC_INIT(0);
static atomic_t n_statx_hits = ATOMIC_INIT(0);
static atomic_t n_statx_rewrites = ATOMIC_INIT(0);

static bool sus_mount_idmap_add(int sus_id, int shown_id, dev_t s_dev)
{
    struct sus_mount_idmap_entry *entry, *new;
    unsigned long flags;

    if (sus_id <= 0 || shown_id <= 0)
        return false;
    spin_lock_irqsave(&idmap_lock, flags);
    hash_for_each_possible(mount_idmap, entry, node, sus_id) {
        if (entry->sus_id != sus_id)
            continue;
        entry->shown_id = shown_id;
        entry->s_dev = s_dev;
        spin_unlock_irqrestore(&idmap_lock, flags);
        return true;
    }
    spin_unlock_irqrestore(&idmap_lock, flags);
    new = kmalloc(sizeof(*new), GFP_ATOMIC);
    if (!new) {
        atomic_inc(&n_idmap_allocfail);
        return false;
    }
    new->sus_id = sus_id;
    new->shown_id = shown_id;
    new->s_dev = s_dev;
    spin_lock_irqsave(&idmap_lock, flags);
    /* Another reader may have learned it while allocation was in progress. */
    hash_for_each_possible(mount_idmap, entry, node, sus_id) {
        if (entry->sus_id != sus_id)
            continue;
        entry->shown_id = shown_id;
        entry->s_dev = s_dev;
        spin_unlock_irqrestore(&idmap_lock, flags);
        kfree(new);
        return true;
    }
    if (n_idmap == SUS_MOUNT_IDMAP_MAX) {
        /* Silent truncation is a "registered but not effective" failure; say it once. */
        if (atomic_inc_return(&n_idmap_full) == 1)
            pr_warn("sus_mount: mount-id map full (%d), a marked mount's shown-id mapping was not learned\n",
                    SUS_MOUNT_IDMAP_MAX);
        spin_unlock_irqrestore(&idmap_lock, flags);
        kfree(new);
        return false;
    }
    hash_add(mount_idmap, &new->node, sus_id);
    n_idmap++;
    if (n_idmap > n_idmap_peak)
        n_idmap_peak = n_idmap;
    spin_unlock_irqrestore(&idmap_lock, flags);
    return true;
}

static void sus_mount_idmap_drop_dev(dev_t s_dev)
{
    struct sus_mount_idmap_entry *entry;
    struct hlist_node *tmp;
    unsigned long flags;
    int bucket;

    spin_lock_irqsave(&idmap_lock, flags);
    hash_for_each_safe(mount_idmap, bucket, tmp, entry, node) {
        if (entry->s_dev != s_dev)
            continue;
        hash_del(&entry->node);
        kfree(entry);
        n_idmap--;
        atomic_inc(&n_idmap_dropped_dev);
    }
    spin_unlock_irqrestore(&idmap_lock, flags);
}

static void sus_mount_idmap_drop(int sus_id)
{
    struct sus_mount_idmap_entry *entry;
    unsigned long flags;

    if (sus_id <= 0)
        return;
    spin_lock_irqsave(&idmap_lock, flags);
    hash_for_each_possible(mount_idmap, entry, node, sus_id) {
        if (entry->sus_id != sus_id)
            continue;
        hash_del(&entry->node);
        kfree(entry);
        n_idmap--;
        atomic_inc(&n_idmap_recycled);
        break;
    }
    spin_unlock_irqrestore(&idmap_lock, flags);
}

static int sus_mount_shown_for(int sus_id)
{
    struct sus_mount_idmap_entry *entry;
    unsigned long flags;
    int shown = 0;

    if (sus_id <= 0)
        return 0;
    spin_lock_irqsave(&idmap_lock, flags);
    hash_for_each_possible(mount_idmap, entry, node, sus_id) {
        if (entry->sus_id == sus_id) {
            shown = entry->shown_id;
            break;
        }
    }
    spin_unlock_irqrestore(&idmap_lock, flags);
    return shown;
}

static void sus_mount_idmap_clear(void)
{
    struct sus_mount_idmap_entry *entry;
    struct hlist_node *tmp;
    unsigned long flags;
    int bucket;

    spin_lock_irqsave(&idmap_lock, flags);
    hash_for_each_safe(mount_idmap, bucket, tmp, entry, node) {
        hash_del(&entry->node);
        kfree(entry);
    }
    n_idmap = 0;
    spin_unlock_irqrestore(&idmap_lock, flags);
}

/* No reader can acquire this mount now; its ID is still allocated here. */
static int sus_mount_free_pre(struct kprobe *kp, struct pt_regs *regs)
{
    struct mount *r = (struct mount *)regs->regs[0];

    if (r && sus_mount_shown_for(r->mnt_id)) {
        sus_mount_idmap_drop(r->mnt_id);
        atomic_inc(&n_idmap_freed);
    }
    return 0;
}

static struct kprobe kp_mnt_free = {
    .symbol_name = "cleanup_mnt",
    .pre_handler = sus_mount_free_pre,
};
static bool kp_mnt_free_ok;

/* ---- "is this mount one of ours", by IDENTITY and not only by id ----
 *
 * The id test is a property of ONE mount object in ONE namespace, and the id only
 * exists because the marking scan put it there: a KSU mount inside the app/zygote
 * namespace carries whatever id the stock allocator gave it (measured: the
 * meta-overlayfs mount is 2000000000 in the init namespace and 1111 in the
 * zygote's), so the id test hid the line in one view and left it in the other - the
 * app's own mount table, the one a checker reads.
 *
 * So the scan remembers what survives a namespace boundary (the mount OBJECT does not, its
 * filesystem does): s_dev + root ino, exact and cheap, because the root dentry is shared by
 * every mount of a superblock and a second tmpfs has its own root inode.  The NUMBER is
 * stored, not the dentry pointer: a held pointer would need dget() - pinning dentry and inode
 * past the superblock's shutdown, measured: rmmod of that build dput()'d it and panicked in
 * shmem_evict_inode, "Oops: Fatal exception" - or be used unlocked after the mount is gone.
 * A source name is not an identity: a bind mount and its /data parent both have
 * mnt_devname="/dev/block/dm-81" on the tested Samsung kernel.  Matching that
 * string hid /data as well as the selected bind, so its replacement mount ID no
 * longer named a visible row.  Source-prefix selection stays in
 * sus_mount_path_is_ours(); this fallback requires BOTH s_dev and mount-root ino.
 *
 * Only mounts the scan ACCEPTS are recorded, so this never widens into "hide anything that
 * looks similar".  A record is valid only while its filesystem is mounted, and its keys are
 * reusable: measured, a tmpfs mounted/recorded/unmounted by this test left s_dev 0:304 and
 * root inode 1 behind and the very next tmpfs got both, i.e. a stale record hid an unrelated
 * filesystem - hence the kprobe on generic_shutdown_super() that drops every record whose
 * s_dev is going away. */
#define SUS_MOUNT_DEVNAME_MAX 64
#define SUS_MOUNT_IDENT_MAX 32
/* Defined with the scan helpers further down; the identity test needs it here. */
static bool sus_mount_path_is_ours(const char *s);

struct sus_mount_ident {
    dev_t s_dev;
    unsigned long root_ino;	/* 0 = free slot */
    /* Diagnostic only; never use a shared or truncated source name to match. */
    char devname[SUS_MOUNT_DEVNAME_MAX];
};

static struct sus_mount_ident mount_ident[SUS_MOUNT_IDENT_MAX];
static int n_ident;
static DEFINE_SPINLOCK(ident_lock);
static atomic_t n_ident_hits = ATOMIC_INIT(0);		/* hidden by identity, not by id */
static atomic_t n_ident_learned = ATOMIC_INIT(0);	/* ids learned while hiding */
static atomic_t n_ident_full = ATOMIC_INIT(0);		/* records that found no slot */
static atomic_t n_ident_dropped_dev = ATOMIC_INIT(0);	/* records dropped at sb teardown */
static atomic_t n_sb_down = ATOMIC_INIT(0);		/* superblocks seen shut down */

static int mount_dbg;
module_param_named(mount_dbg, mount_dbg, int, 0644);
/* Diagnostic: name the fields the identity test compares, for the first few mounts the
 * hook sees, so "why did identity not match" is answerable from dmesg instead of guessed. */
static atomic_t n_dbg_logged = ATOMIC_INIT(0);

/* Process context.  Takes no reference on anything (see the note above): the
 * record is three numbers and a string, so a record whose mount is long gone costs
 * nothing and cannot keep a filesystem alive. */
static void sus_mount_ident_add(struct mount *r)
{
    const char *devname = r->mnt_devname;
    struct dentry *root = r->mnt.mnt_root;
    unsigned long ino;
    unsigned long flags;
    int i, slot = -1;

    if (!root || !root->d_inode)
        return;
    ino = root->d_inode->i_ino;
    if (!ino)
        return;

    spin_lock_irqsave(&ident_lock, flags);
    /* Re-check under the lock so two scans cannot both append; a re-enable finds them here. */
    for (i = 0; i < n_ident; i++) {
        if (mount_ident[i].s_dev == r->mnt.mnt_sb->s_dev &&
            mount_ident[i].root_ino == ino)
            goto out;
        if (!mount_ident[i].root_ino && slot < 0)
            slot = i;
    }
    if (slot < 0) {
        if (n_ident >= SUS_MOUNT_IDENT_MAX) {
            /* Silent truncation is a "registered but not effective" failure; say it once. */
            if (atomic_inc_return(&n_ident_full) == 1)
                pr_warn("sus_mount: identity table full (%d), %s is NOT recognised in other namespaces\n",
                        SUS_MOUNT_IDENT_MAX,
                        devname ? devname : "(no devname)");
            goto out;
        }
        slot = n_ident;
        smp_store_release(&n_ident, n_ident + 1);
    }
    {
        struct sus_mount_ident *e = &mount_ident[slot];

        e->s_dev = r->mnt.mnt_sb->s_dev;
        strscpy(e->devname, devname ? devname : "(no devname)", sizeof(e->devname));
        if (mount_dbg)
            SUSFS_LOGI("sus_mount: ident[%d] s_dev=%u root_ino=%lu devname=%s\n",
                    slot, (unsigned int)e->s_dev, ino,
                    e->devname);
        /* Set LAST: root_ino != 0 is what makes the record live for the readers. */
        smp_store_release(&e->root_ino, ino);
    }
out:
    spin_unlock_irqrestore(&ident_lock, flags);
}

/* Interrupt-context safe (kprobe pre_handler): read-only, no sleeping. */
static bool sus_mount_ident_match(struct mount *r)
{
    struct dentry *root = r->mnt.mnt_root;
    unsigned long ino = (root && root->d_inode) ? root->d_inode->i_ino : 0;
    unsigned long flags;
    bool found = false;
    int i;

    if (!ino)
        return false;
    /* The inode/device pair must remain one record across slot reuse. */
    spin_lock_irqsave(&ident_lock, flags);
    for (i = 0; i < n_ident; i++) {
        const struct sus_mount_ident *e = &mount_ident[i];
        if (e->root_ino == ino && e->s_dev == r->mnt.mnt_sb->s_dev) {
            found = true;
            break;
        }
    }
    spin_unlock_irqrestore(&ident_lock, flags);
    return found;
}

/**
 * sus_mount_ident_drop_dev() - forget every record that lived on @s_dev
 *
 * From a kprobe on generic_shutdown_super(): without it a record outlives its filesystem,
 * and the numbers it is keyed by are recyclable (measured above), so a stale record hides
 * an unrelated filesystem.  Process context, takes only our own spinlock, never sleeps.
 */
static void sus_mount_ident_drop_dev(dev_t s_dev)
{
    unsigned long flags;
    int i;

    spin_lock_irqsave(&ident_lock, flags);
    for (i = 0; i < n_ident; i++) {
        if (smp_load_acquire(&mount_ident[i].root_ino) && mount_ident[i].s_dev == s_dev) {
            smp_store_release(&mount_ident[i].root_ino, 0);
            atomic_inc(&n_ident_dropped_dev);
        }
    }
    spin_unlock_irqrestore(&ident_lock, flags);
}

/* generic_shutdown_super(struct super_block *sb) - fs/super.c, EXPORT_SYMBOL, so
 * it is a real function in kallsyms and not an inlined call site.  Runs before the
 * device number is handed back (free_anon_bdev()/blkdev_put() happen in
 * kill_anon_super()/kill_block_super() after this returns), so a record cannot
 * survive into the window where a new filesystem holds the same s_dev. */
static int sus_mount_sb_down_pre(struct kprobe *kp, struct pt_regs *regs)
{
    struct super_block *sb = (struct super_block *)regs->regs[0];

    atomic_inc(&n_sb_down);
    if (!sb)
        return 0;
    sus_mount_ident_drop_dev(sb->s_dev);
    sus_mount_idmap_drop_dev(sb->s_dev);
    if (READ_ONCE(mount_data_dev_valid) && sb->s_dev == READ_ONCE(mount_data_dev))
        WRITE_ONCE(mount_data_dev_valid, false);
    return 0;
}

static struct kprobe kp_sb_down = {
    .symbol_name = "generic_shutdown_super",
    .pre_handler = sus_mount_sb_down_pre,
};
static bool kp_sb_down_ok;

/* Shared classification: upstream IDs, configured sources, real backing paths,
 * then recorded device/root identities for namespace copies. */
static bool sus_mount_is_ours(struct mount *r)
{
    if ((unsigned int)r->mnt_id >= SUS_MOUNT_KSU_ID_MIN)
        return true;
    if (sus_mount_path_is_ours(r->mnt_devname))
        return true;
    if (sus_mount_builtin(r))
        return true;
    return sus_mount_ident_match(r);
}

/* The id the caller is allowed to see for a mount we hide: the first ancestor
 * that is not ours.  Starts at the PARENT when the mount itself is not in the id
 * range, because an identity-recognised mount keeps a normal id and would
 * otherwise report its own (hidden) number. */
static int sus_mount_shown_id_from(struct mount *mnt)
{
    if (mnt && (unsigned int)mnt->mnt_id < SUS_MOUNT_KSU_ID_MIN)
        mnt = mnt->mnt_parent;
    while (mnt && mnt->mnt_parent && mnt != mnt->mnt_parent &&
           sus_mount_is_ours(mnt))
        mnt = mnt->mnt_parent;
    return mnt ? (int)mnt->mnt_id : 0;
}

/* Remember the id -> shown-id pair for a mount we are about to hide, so the
 * fdinfo/statx faces rewrite the very same id the app would otherwise see.  The
 * hide hooks are the only place that has a mount pointer in an app's namespace,
 * so learning here is what keeps "the line is gone" and "the number in fdinfo
 * names a line that exists" consistent for namespaces the scan never saw. */
static bool sus_mount_note_id(struct mount *r)
{
    int shown;

    if (sus_mount_shown_for((int)r->mnt_id))
        return true;
    shown = sus_mount_shown_id_from(r);
    if (shown > 0 && shown != (int)r->mnt_id) {
        if (!sus_mount_idmap_add((int)r->mnt_id, shown, r->mnt.mnt_sb->s_dev))
            return false;
        atomic_inc(&n_ident_learned);
        return true;
    }
    return false;
}

/* ---- namespaces created AFTER the enable ----
 *
 * Marking does NOT travel: clone_mnt() copies every mount through alloc_vfsmnt() ->
 * mnt_alloc_id() (fs/namespace.c:1282/309/238 on 6.12), so a namespace copied by
 * fork/unshare gets BRAND NEW ids - measured: the copy of a marked mount has no 2e9 id.
 * Hiding still works (identity is namespace independent), but the fdinfo/statx face needs
 * an id, and the table only learns one when somebody READS a mount table: a process that
 * opens a file in the new namespace and reads /proc/self/fdinfo/N first gets an id its own
 * mountinfo does not list (measured: mnt_id=29127, listed_in_my_mountinfo=0) until the
 * first mount-table read makes it consistent (29117, listed=1).  Upstream assigns the big
 * id at mount creation, so its copy is marked from the start.
 *
 * On < 6.12 that tree is walked right here (see sus_mount_learn_ns below).  On >= 6.12 it
 * is NOT walked here, because the mount collection is an rb-tree that may only be walked
 * under namespace_sem - a sleeping rwsem this probe cannot take with preemption disabled -
 * and "the namespace is fresh, so nothing else can touch it" is not a proof about that
 * tree: copy_mnt_ns() passes neither CL_PRIVATE nor CL_SLAVE, so the copy of a SHARED
 * mount stays a propagation peer, and another task can insert into the very tree we would
 * be walking (under namespace_sem alone).  The >= 6.12 probe therefore only RECORDS the
 * namespace; a work item walks it later in process context under namespace_sem for read,
 * exactly like the marking scan, with the same refuse-and-log when that lock cannot be
 * resolved.  This trap once panicked the device when it walked a live namespace, and the
 * flags check below (no CLONE_NEWNS -> the CURRENT namespace, the plain fork path) is what
 * keeps the deferred path from being handed one. */
static atomic_t n_clone_walks = ATOMIC_INIT(0);
static atomic_t n_clone_learned = ATOMIC_INIT(0);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
static atomic_t n_clone_queued = ATOMIC_INIT(0);
static atomic_t n_clone_dropped = ATOMIC_INIT(0);
static atomic_t n_clone_refused_logged = ATOMIC_INIT(0);
#endif

/* ---- how one iterates the mounts of a namespace, per kernel version ----
 *
 * < 6.12: a plain `struct list_head list` of every mount (mnt_list) under ns_lock, with a
 * fake "cursor" mount (MNT_CURSOR) anchored in it that has to be skipped.  >= 6.12: the
 * list, ns_lock and MNT_CURSOR are GONE - mounts live in `struct rb_root mounts` keyed on
 * mnt_id_unique, the kernel's own iterator takes namespace_sem for read and walks
 * rb_next(&mnt->mnt_node) (fs/namespace.c m_start()/m_next()/m_stop(); fs/mount.h:
 * "Protected by namespace_sem"), and the cursor test becomes mnt_ns_attached().
 * namespace_sem is `static DECLARE_RWSEM(namespace_sem)` in fs/namespace.c, so it is
 * resolved BY NAME at load time (KALLSYMS_ALL, set in both GKI defconfigs); if it cannot be
 * resolved the walk REFUSES to run - an unlocked rb-tree walk of a namespace another task
 * is mounting into is a torn tree, and reading it lockless panics the device.  Refusing
 * costs the marking (and says so), never memory.
 *
 * The lock may SLEEP (down_read), so it is process context only - which is why the
 * kretprobe path (sus_mount_learn_ns) walks without it and relies on the namespace being
 * private instead. */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
static struct rw_semaphore *sus_mount_namespace_sem;

static bool sus_mount_ns_walk_begin(void)
{
    if (!sus_mount_namespace_sem)
        return false;
    down_read(sus_mount_namespace_sem);
    return true;
}

static void sus_mount_ns_walk_end(void)
{
    up_read(sus_mount_namespace_sem);
}

#define SUS_MOUNT_ITER_TYPE		struct rb_node *
#define SUS_MOUNT_ITER_FOR(ns, it)	for ((it) = rb_first(&(ns)->mounts); (it); (it) = rb_next(it))
#define SUS_MOUNT_ITER_MOUNT(it)	rb_entry((it), struct mount, mnt_node)
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 13, 0)
#define SUS_MOUNT_MNT_NOT_IN_NS(r, ns)	((r)->mnt_ns != (ns) || !mnt_ns_attached(r))
#else
/* 6.12 has the rb-tree (and MNT_ONRB) but not the helper: mnt_ns_attached() arrived in 6.13,
 * where its body is exactly this test.  Using it unguarded made a plain 6.12 tree an implicit
 * declaration, so the first 6.12 build either failed or linked against nothing. */
#define SUS_MOUNT_MNT_NOT_IN_NS(r, ns)	((r)->mnt_ns != (ns) || RB_EMPTY_NODE(&(r)->mnt_node))
#endif
#else
static bool sus_mount_ns_walk_begin(void)
{
    return true;	/* the caller takes ns_lock instead */
}

static void sus_mount_ns_walk_end(void)
{
}

#define SUS_MOUNT_ITER_TYPE		struct list_head *
#define SUS_MOUNT_ITER_FOR(ns, it)	for ((it) = (ns)->list.next; (it) != &(ns)->list; (it) = (it)->next)
#define SUS_MOUNT_ITER_MOUNT(it)	list_entry((it), struct mount, mnt_list)
#define SUS_MOUNT_MNT_NOT_IN_NS(r, ns)	((r)->mnt_ns != (ns) || ((r)->mnt.mnt_flags & MNT_CURSOR))
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 12, 0)
/* Immediate walk for < 6.12, where the namespace has a spinlock. */
static void sus_mount_learn_ns(struct mnt_namespace *ns)
{
    SUS_MOUNT_ITER_TYPE pos;
    struct mount *r;
    int learned = 0;

    spin_lock(&ns->ns_lock);
    SUS_MOUNT_ITER_FOR(ns, pos) {
        int shown;

        r = SUS_MOUNT_ITER_MOUNT(pos);
        if (SUS_MOUNT_MNT_NOT_IN_NS(r, ns))
            continue;
        if (!sus_mount_is_ours(r))
            continue;
        if (sus_mount_shown_for((int)r->mnt_id))
            continue;
        shown = sus_mount_shown_id_from(r);
        if (shown > 0 && shown != (int)r->mnt_id) {
            if (sus_mount_idmap_add((int)r->mnt_id, shown, r->mnt.mnt_sb->s_dev))
                learned++;
        }
    }
    spin_unlock(&ns->ns_lock);
    atomic_inc(&n_clone_walks);
    if (learned)
        atomic_add(learned, &n_clone_learned);
}
#else
/* ---- >= 6.12: record the namespace in the probe, walk it in the worker ----
 *
 * The recorded pointer is kept alive with the kernel's own get_mnt_ns() (fs/mount.h, an
 * inline - no symbol needed) and released with put_mnt_ns() (a global in fs/namespace.c,
 * resolved by name at init).  Both halves are load-bearing: the task that cloned the
 * namespace can exit and drop the last reference before the worker runs, and put_mnt_ns()
 * must be called with no read lock held because on 6.18 it takes namespace_sem for write
 * itself.  If put_mnt_ns cannot be resolved nothing is queued at all - a reference we
 * could not drop would be a leak and a walk without one a use-after-free.
 *
 * The ring is fixed size and drops on overflow (counted): the probe may not allocate, and
 * a dropped namespace only means its ids are learned by a later scan instead. */
#define SUS_MOUNT_LEARN_RING 16
static struct mnt_namespace *sus_mount_learn_ring[SUS_MOUNT_LEARN_RING];
static unsigned int sus_mount_learn_head, sus_mount_learn_tail;
static DEFINE_SPINLOCK(sus_mount_learn_lock);
static void (*pfn_put_mnt_ns)(struct mnt_namespace *ns);
static void sus_mount_learn_work(struct work_struct *w);
static DECLARE_WORK(sus_mount_learn_wq, sus_mount_learn_work);

/* Every call through a resolved kernel symbol sits inside a __nocfi function (kCFI checks
 * the type hash at an indirect call site, and an out-of-tree module's hash for a kernel
 * prototype does not match), and that function is itself called DIRECTLY so it needs no
 * hash of its own - the work item below is called indirectly by the workqueue and so must
 * keep its hash, which is why the put goes through here instead. */
static __nocfi void sus_mount_put_mnt_ns(struct mnt_namespace *ns)
{
    pfn_put_mnt_ns(ns);
}

/* One recorded namespace, or NULL when the ring is empty. */
static struct mnt_namespace *sus_mount_learn_pop(void)
{
    unsigned long flags;
    struct mnt_namespace *ns;

    spin_lock_irqsave(&sus_mount_learn_lock, flags);
    if (sus_mount_learn_head == sus_mount_learn_tail) {
        spin_unlock_irqrestore(&sus_mount_learn_lock, flags);
        return NULL;
    }
    ns = sus_mount_learn_ring[sus_mount_learn_tail];
    sus_mount_learn_ring[sus_mount_learn_tail] = NULL;
    sus_mount_learn_tail = (sus_mount_learn_tail + 1) % SUS_MOUNT_LEARN_RING;
    spin_unlock_irqrestore(&sus_mount_learn_lock, flags);
    return ns;
}

/* The walk, in process context: namespace_sem for read, and the same protocol the marking
 * scan uses (rcu_read_lock + the iteration bound), because a namespace that was private
 * when it was recorded is a live one by the time this runs. */
static int sus_mount_learn_ns_walk(struct mnt_namespace *ns)
{
    SUS_MOUNT_ITER_TYPE pos;
    unsigned int seen = 0;
    int learned = 0;

    if (!sus_mount_ns_walk_begin())
        return -ENOSYS;

    rcu_read_lock();
    SUS_MOUNT_ITER_FOR(ns, pos) {
        struct mount *r;
        int shown;

        if (seen++ >= SUS_MOUNT_MAX_SCAN)
            break;
        r = SUS_MOUNT_ITER_MOUNT(pos);
        if (SUS_MOUNT_MNT_NOT_IN_NS(r, ns))
            continue;
        if (!sus_mount_is_ours(r))
            continue;
        if (sus_mount_shown_for((int)r->mnt_id))
            continue;
        shown = sus_mount_shown_id_from(r);
        if (shown > 0 && shown != (int)r->mnt_id) {
            if (sus_mount_idmap_add((int)r->mnt_id, shown, r->mnt.mnt_sb->s_dev))
                learned++;
        }
    }
    rcu_read_unlock();
    sus_mount_ns_walk_end();
    return learned;
}

static void sus_mount_learn_work(struct work_struct *w)
{
    struct mnt_namespace *ns;

    while ((ns = sus_mount_learn_pop()) != NULL) {
        int learned = sus_mount_learn_ns_walk(ns);

        if (learned == -ENOSYS && !atomic_xchg(&n_clone_refused_logged, 1))
            pr_warn("sus_mount: namespace_sem could not be resolved at load time - refusing to walk a cloned namespace without the lock the kernel's own mount-table iterator holds (that namespace's ids stay unlearned)\n");
        atomic_inc(&n_clone_walks);
        if (learned > 0)
            atomic_add(learned, &n_clone_learned);
        /* After sus_mount_ns_walk_end(): see the note above about 6.18. */
        sus_mount_put_mnt_ns(ns);
    }
}

/* Called from the copy_mnt_ns return probe: no allocation, no sleeping. */
static void sus_mount_defer_learn_ns(struct mnt_namespace *ns)
{
    unsigned int next;
    unsigned long flags;

    if (!pfn_put_mnt_ns) {
        atomic_inc(&n_clone_dropped);
        return;
    }
    get_mnt_ns(ns);

    spin_lock_irqsave(&sus_mount_learn_lock, flags);
    next = (sus_mount_learn_head + 1) % SUS_MOUNT_LEARN_RING;
    if (next == sus_mount_learn_tail) {
        spin_unlock_irqrestore(&sus_mount_learn_lock, flags);
        sus_mount_put_mnt_ns(ns);
        atomic_inc(&n_clone_dropped);
        return;
    }
    sus_mount_learn_ring[sus_mount_learn_head] = ns;
    sus_mount_learn_head = next;
    spin_unlock_irqrestore(&sus_mount_learn_lock, flags);

    atomic_inc(&n_clone_queued);
    schedule_work(&sus_mount_learn_wq);
}

/* Unload path: the probe is unregistered first (so nothing new is queued), then the worker
 * is waited out, then whatever is still recorded is released - the worker cannot see an
 * entry queued after its last pop. */
static void sus_mount_learn_stop(void)
{
    struct mnt_namespace *ns;

    cancel_work_sync(&sus_mount_learn_wq);
    while ((ns = sus_mount_learn_pop()) != NULL)
        sus_mount_put_mnt_ns(ns);
}
#endif

struct sus_mount_clone_state {
    unsigned long flags;
};

static int sus_mount_clone_entry(struct kretprobe_instance *ri, struct pt_regs *regs)
{
    struct sus_mount_clone_state *st = (struct sus_mount_clone_state *)ri->data;

    st->flags = regs->regs[0];
    return 0;
}

static int sus_mount_clone_ret(struct kretprobe_instance *ri, struct pt_regs *regs)
{
    struct sus_mount_clone_state *st = (struct sus_mount_clone_state *)ri->data;
    struct mnt_namespace *ns = (struct mnt_namespace *)regs_return_value(regs);

    if (!(st->flags & CLONE_NEWNS))
        return 0;			/* plain fork: the current namespace, not a copy */
    if (IS_ERR_OR_NULL(ns))
        return 0;
#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 12, 0)
    sus_mount_learn_ns(ns);
#else
    sus_mount_defer_learn_ns(ns);
#endif
    return 0;
}

/* copy_mnt_ns() is not static (fs/namespace.c:3424) and is on every namespace
 * creation path (fork with CLONE_NEWNS, unshare, clone3). */
static struct kretprobe kr_clone_ns = {
    .kp.symbol_name = "copy_mnt_ns",
    .entry_handler = sus_mount_clone_entry,
    .handler = sus_mount_clone_ret,
    .data_size = sizeof(struct sus_mount_clone_state),
    .maxactive = 16,
};
static bool kr_clone_ns_ok;

/* ---- mounts that appear AFTER the enable ----
 *
 * The scan runs once, on the current namespace: a filesystem mounted later - the ordinary
 * case for a module image installed while the phone is up - carried no marked id and no
 * recorded identity, so nothing hid it in ANY namespace (measured before this hook existed:
 * visible to a non-su reader in the init namespace and in a fresh clone).
 *
 * attach_recursive_mnt() is the one function every mount path goes through - exactly two
 * callers, graft_tree() (mount(2)/fsmount and do_loopback binds) and do_move_mount() (a
 * move) - so one kretprobe covers all of them.  Identity is recorded and not an id: it is
 * what the hide hooks compare, needs no allocation and is namespace independent, whereas a
 * KSU-range id needs ida_alloc_range(GFP_KERNEL) and a kprobe handler must not sleep.  The
 * shown id is learned at the RETURN (mnt_parent/mnt_mountpoint exist then), and the
 * acceptance rule is the scan's, so this cannot widen what is hidden - a bind of an already
 * recorded filesystem needs no record at all. */
#define SUS_MOUNT_NEWMNT_PATH_MAX 256

static atomic_t n_newmnt_seen = ATOMIC_INIT(0);
static atomic_t n_newmnt_recorded = ATOMIC_INIT(0);
static atomic_t n_newmnt_pathfail = ATOMIC_INIT(0);

struct sus_mount_newmnt_state {
    struct mount *m;
};

static int sus_mount_newmnt_entry(struct kretprobe_instance *ri, struct pt_regs *regs)
{
    struct sus_mount_newmnt_state *st = (struct sus_mount_newmnt_state *)ri->data;

    st->m = (struct mount *)regs->regs[0];	/* source_mnt */
    return 0;
}

/* The scan's rule, verbatim: a devname anchored at /data/adb, or a mountpoint under
 * /data/adb.  @buf is the caller's, small on purpose - this runs from a kretprobe
 * handler, where a PATH_MAX stack buffer would be a stack overflow waiting to happen,
 * and the mountpoints this rule accepts are short (/data/adb/modules/<name>/mnt). */
static bool sus_mount_should_record(struct mount *r, char *buf, int buflen, char **why)
{
    struct path p;
    char *dp;

    if (sus_mount_builtin(r)) {
        *why = "module backing";
        return true;
    }
    if (sus_mount_path_is_ours(r->mnt_devname)) {
        *why = "devname";
        return true;
    }
    if (!pfn_d_path)
        return false;
    p.mnt = &r->mnt;
    p.dentry = r->mnt.mnt_root;
    dp = sus_mount_d_path(&p, buf, buflen);
    if (IS_ERR_OR_NULL(dp)) {
        atomic_inc(&n_newmnt_pathfail);
        return false;
    }
    if (sus_mount_path_is_ours(dp)) {
        *why = dp;
        return true;
    }
    return false;
}

static int sus_mount_newmnt_ret(struct kretprobe_instance *ri, struct pt_regs *regs)
{
    struct sus_mount_newmnt_state *st = (struct sus_mount_newmnt_state *)ri->data;
    struct mount *r = st->m;
    char buf[SUS_MOUNT_NEWMNT_PATH_MAX];
    char *why = NULL;

    if (!susfs_ptr_plausible(r) || (long)regs_return_value(regs) != 0)
        return 0;			/* the attach failed: nothing was mounted */
    atomic_inc(&n_newmnt_seen);
    /* A successful attach leaves the mount with a parent; without one there is no
     * mountpoint path to test and no parent chain for the shown id. */
    if (!r->mnt_parent || r->mnt_parent == r)
        return 0;
    if (!sus_mount_should_record(r, buf, sizeof(buf), &why))
        return 0;

    sus_mount_ident_add(r);
    sus_mount_note_id(r);
    atomic_inc(&n_newmnt_recorded);
    SUSFS_LOGI("sus_mount: learned mount at %s (mnt_id %d, devname %s)\n",
            why, r->mnt_id, r->mnt_devname ? r->mnt_devname : "none");
    return 0;
}

static struct kretprobe kr_newmnt = {
    .kp.symbol_name = "attach_recursive_mnt",
    .entry_handler = sus_mount_newmnt_entry,
    .handler = sus_mount_newmnt_ret,
    .data_size = sizeof(struct sus_mount_newmnt_state),
    .maxactive = 16,
};
static bool kr_newmnt_ok;

/* ---- /proc/<pid>/fdinfo/N ----
 *
 * fs/proc/fd.c:seq_show() formats pos/flags/mnt_id/ino into the seq_file buffer and
 * returns; a kprobe cannot see the mnt_id (a local), but it can read the text already in
 * m->buf at return time: find the label, parse the decimal after it, replace it with the id
 * the app is supposed to see.  The replacement is never longer (a shown id is a normal,
 * small one), so the buffer is only shortened.  Works whether the kernel formats the line
 * with one seq_printf (AOSP 5.15) or with seq_put_decimal_ull() - both leave
 * "mnt_id:\t<digits>" in the buffer at return. */
#define SUS_MOUNT_MNTID_LABEL		"mnt_id:\t"
#define SUS_MOUNT_MNTID_LABEL_LEN	8

/* Per-instance state for the kretprobes below (fdinfo + the two statx landing points), in
 * ri->data and NOT in per-CPU storage: seq_show() formats through seq_printf(), whose
 * seq_buf_alloc() is GFP_KERNEL and can sleep, so with CONFIG_PREEMPT=y the task can resume
 * on another CPU where a per-CPU slot would hold NULL or a seq_file of an unrelated /proc
 * read that the return handler would then memmove into.  A kretprobe instance is per-task
 * (the getdents64 filter in sus_path.c does the same), and one struct serves all of them
 * because the fields are disjoint. */
struct sus_mount_kretprobe_state {
    struct seq_file *m;		/* fdinfo: the seq_file being filled */
    unsigned long ubuf;		/* statx: the caller's struct statx __user * */
    char where;			/* statx: 's' = __arm64_sys_statx, 'd' = do_statx */
};

static atomic_t n_fdinfo_entry = ATOMIC_INIT(0);
static atomic_t n_fdinfo_nolabel = ATOMIC_INIT(0);

static int sus_mount_fdinfo_entry(struct kretprobe_instance *ri, struct pt_regs *regs)
{
    struct sus_mount_kretprobe_state *st = (struct sus_mount_kretprobe_state *)ri->data;

    atomic_inc(&n_fdinfo_entry);
    /* Not dereferenced here - the return handler checks it - but an implausible
     * value means this kretprobe sits on a function that does not take a seq_file,
     * and the rewrite below would then read an unrelated object. */
    st->m = susfs_ptr_plausible((void *)regs->regs[0])
               ? (struct seq_file *)regs->regs[0] : NULL;
    return 0;
}

/* Replaces the decimal after the mnt_id label in the seq_file's already formatted buffer
 * when the id has a disguise in sus_mount's table (KSU-range id -> host id).  The
 * replacement never grows, so m->count stays consistent.  The other half of the fdinfo line
 * (the ino) belongs to open_redirect's own kretprobe, which must fire whether or not this
 * feature's hide switch is on. */
static bool sus_mount_fdinfo_replace_mntid(struct seq_file *m)
{
    char *buf = m->buf, digits[12];
    size_t count = m->count, i, pos = 0, len = 0, n = 0;
    unsigned long old = 0;
    int shown;
    unsigned int v;

    for (i = 0; i + SUS_MOUNT_MNTID_LABEL_LEN < count; i++) {
        if (!memcmp(buf + i, SUS_MOUNT_MNTID_LABEL, SUS_MOUNT_MNTID_LABEL_LEN)) {
            pos = i + SUS_MOUNT_MNTID_LABEL_LEN;
            break;
        }
    }
    if (!pos)
        return false;

    while (pos + len < count && len < 10 &&
           buf[pos + len] >= '0' && buf[pos + len] <= '9') {
        old = old * 10 + (unsigned long)(buf[pos + len] - '0');
        len++;
    }
    if (!len)
        return false;

    shown = sus_mount_shown_for((int)old);
    if (shown <= 0)
        return false;

    v = (unsigned int)shown;
    while (v) {
        digits[n++] = (char)('0' + v % 10);
        v /= 10;
    }
    if (!n)
        return false;
    /* In practice a KSU-range id is replaced by a small host id, so this shrinks -
     * but the room check is here so a rule with an unexpectedly long host id
     * cannot overwrite past the seq_file buffer. */
    if (n > len && count + (n - len) >= m->size)
        return false;
    for (i = 0; i < n / 2; i++) {
        char t = digits[i];

        digits[i] = digits[n - 1 - i];
        digits[n - 1 - i] = t;
    }
    if (n != len)
        memmove(buf + pos + n, buf + pos + len, count - (pos + len));
    memcpy(buf + pos, digits, n);
    m->count = count - len + n;
    return true;
}

static int sus_mount_fdinfo_ret(struct kretprobe_instance *ri, struct pt_regs *regs)
{
    struct sus_mount_kretprobe_state *st = (struct sus_mount_kretprobe_state *)ri->data;
    struct seq_file *m = st->m;

    if (!m || (long)regs_return_value(regs) != 0)
        return 0;
    if (!m->buf || !m->count)
        return 0;
    /* Only fdinfo's own file is rewritten, and above 5.15 this probe sits on ALL FOUR
     * functions named seq_show (see the note at kr_fdinfo[]): the file being read is
     * m->file, and /proc/<pid>/fdinfo/<fd> (and .../task/<tid>/fdinfo/<fd>) has a dentry
     * whose parent is named "fdinfo".  The mnt_id label test below already makes the scan a
     * no-op for another file, so this only keeps it off other files' buffers. */
    if (!m->file || !m->file->f_path.dentry || !m->file->f_path.dentry->d_parent ||
        strcmp(m->file->f_path.dentry->d_parent->d_name.name, "fdinfo") != 0) {
        atomic_inc(&n_fdinfo_nolabel);
        return 0;
    }
    /* The su/ksu domain keeps seeing its own mounts' real ids, exactly like the
     * mount-line skip above. */
    if (sus_mount_is_su_domain())
        return 0;

    atomic_inc(&n_fdinfo_hits);

    if (sus_mount_fdinfo_replace_mntid(m))
        atomic_inc(&n_fdinfo_rewrites);
    else
        atomic_inc(&n_fdinfo_nolabel);
    return 0;
}

/* fs/proc/fd.c's fdinfo callback is registered through single_open(file, seq_show, inode), so
 * no table holds its address - and the name is NOT unique above 5.15: the DDK trees have four
 * symbols called exactly `seq_show` on android14-6.1 / android15-6.6 / android16-6.12 /
 * android17-6.18, and one on 5.10/5.15.  register_kprobe(.symbol_name=...) attaches to
 * whichever kallsyms lists first, which is how the fdinfo rewrite silently stopped working on
 * those kernels (mountinfo showed the disguised id while /proc/<pid>/fdinfo/N printed the real
 * one - a one-file oracle).  So: enumerate every match and hook all of them; the return
 * handler decides by the file it sees, which makes an unrelated seq_show cost one scan and
 * change nothing. */
#define SUS_MOUNT_FDINFO_MAX 8

static struct kretprobe kr_fdinfo[SUS_MOUNT_FDINFO_MAX];
static int n_fdinfo_probes;
static bool kr_fdinfo_ok;

static int sus_mount_fdinfo_arm(void)
{
    unsigned long addrs[SUS_MOUNT_FDINFO_MAX];
    int i, n;

    n = ksu_find_symbol_all("seq_show", addrs, SUS_MOUNT_FDINFO_MAX);
    if (n <= 0) {
        pr_warn("sus_mount: seq_show not resolved - fdinfo keeps printing the real mnt_id\n");
        return -ENOENT;
    }
    for (i = 0; i < n; i++) {
        struct kretprobe *kr = &kr_fdinfo[i];
        int rc;

        kr->kp.addr = (void *)addrs[i];
        /* unregister leaves KPROBE_FLAG_DISABLED set even after removing the
         * probe.  A later registration accepts that bit and stays inactive. */
        kr->kp.flags = 0;
        kr->entry_handler = sus_mount_fdinfo_entry;
        kr->handler = sus_mount_fdinfo_ret;
        kr->data_size = sizeof(struct sus_mount_kretprobe_state);
        kr->maxactive = 16;
        rc = register_kretprobe(kr);
        if (rc) {
            pr_warn("sus_mount: register_kretprobe(seq_show @%px) failed %d\n", (void *)addrs[i], rc);
            kr->kp.addr = NULL;
            continue;
        }
        n_fdinfo_probes++;
    }
    if (!n_fdinfo_probes)
        return -EINVAL;
    SUSFS_LOGI("sus_mount: fdinfo hooked on %d/%d seq_show symbol(s)\n", n_fdinfo_probes, n);
    kr_fdinfo_ok = true;
    return 0;
}

static void sus_mount_fdinfo_disarm(void)
{
    int i;

    for (i = 0; i < SUS_MOUNT_FDINFO_MAX; i++) {
        if (!kr_fdinfo[i].kp.addr)
            continue;
        unregister_kretprobe(&kr_fdinfo[i]);
        kr_fdinfo[i].kp.addr = NULL;
    }
    n_fdinfo_probes = 0;
    kr_fdinfo_ok = false;
}

/* ---- statx(2): stx_mnt_id ----
 *
 * vfs_statx() fills stat->mnt_id right after the getattr callback, so the only place a
 * kprobe can change it is the uapi struct the syscall is about to copy out: entry (take the
 * user pointer) plus return (rewrite if the call succeeded).  Two landing points, because
 * "the wrapper is in kallsyms" says nothing about who is really called: __arm64_sys_statx is
 * the syscall entry, do_statx what it delegates to.  The rewrite is idempotent (a rewritten
 * id is not in the table), so arming both is safe, and which one fires is reported
 * separately.
 *
 * They do NOT read the same register: __arm64_sys_statx is `asmlinkage long
 * __arm64_sys_statx(const struct pt_regs *)`
 * (arch/arm64/include/asm/syscall_wrapper.h), so its buffer is
 * ((struct pt_regs *)regs->regs[0])->regs[4] - reading regs->regs[4] directly works only
 * because the dispatcher leaves x1..x7 untouched, the reason the reboot handler in
 * susfs_supercall.c goes through PT_REAL_REGS.  do_statx(int dfd, const char __user
 * *filename, unsigned flags, unsigned int mask, struct statx __user *buffer) is an ordinary
 * function, so x4 IS the buffer. */
static atomic_t n_statx_entry = ATOMIC_INIT(0);
static atomic_t n_statx_ret = ATOMIC_INIT(0);
static atomic_t n_statx_nobuf = ATOMIC_INIT(0);
static atomic_t n_statx_err = ATOMIC_INIT(0);
static atomic_t n_statx_copyfail = ATOMIC_INIT(0);
static atomic_t n_statx_nomap = ATOMIC_INIT(0);

static int sus_mount_statx_entry_sys(struct kretprobe_instance *ri, struct pt_regs *regs)
{
    struct sus_mount_kretprobe_state *st = (struct sus_mount_kretprobe_state *)ri->data;
    const struct pt_regs *uregs = (const struct pt_regs *)regs->regs[0];

    atomic_inc(&n_statx_entry);
    st->where = 's';
    st->ubuf = uregs ? (unsigned long)uregs->regs[4] : 0;
    return 0;
}

static int sus_mount_statx_entry_do(struct kretprobe_instance *ri, struct pt_regs *regs)
{
    struct sus_mount_kretprobe_state *st = (struct sus_mount_kretprobe_state *)ri->data;

    atomic_inc(&n_statx_entry);
    st->where = 'd';
    st->ubuf = regs->regs[4];
    return 0;
}

static int sus_mount_statx_ret(struct kretprobe_instance *ri, struct pt_regs *regs)
{
    struct sus_mount_kretprobe_state *st = (struct sus_mount_kretprobe_state *)ri->data;
    unsigned long ubuf = st->ubuf;
    u64 id = 0, shown;
    int new_id;

    atomic_inc(&n_statx_ret);
    if ((long)regs_return_value(regs) != 0) {
        atomic_inc(&n_statx_err);
        return 0;
    }
    if (!ubuf) {
        /* Named, because "which landing point had no pointer" is the difference
         * between a wrong register and a wrong understanding of the call. */
        atomic_inc(&n_statx_nobuf);
        pr_info_ratelimited("sus_mount: statx landing point %c had no buffer\n",
                            st->where);
        return 0;
    }
    if (sus_mount_is_su_domain())
        return 0;

    atomic_inc(&n_statx_hits);
    if (copy_from_user(&id, (void __user *)(ubuf + offsetof(struct statx, stx_mnt_id)),
                       sizeof(id))) {
        atomic_inc(&n_statx_copyfail);
        return 0;
    }
    new_id = sus_mount_shown_for((int)id);
    if (new_id <= 0) {
        atomic_inc(&n_statx_nomap);
        return 0;
    }
    shown = (u64)new_id;
    if (copy_to_user((void __user *)(ubuf + offsetof(struct statx, stx_mnt_id)),
                     &shown, sizeof(shown))) {
        atomic_inc(&n_statx_copyfail);
        return 0;
    }
    atomic_inc(&n_statx_rewrites);
    return 0;
}

static struct kretprobe kr_statx = {
    .kp.symbol_name = "__arm64_sys_statx",
    .entry_handler = sus_mount_statx_entry_sys,
    .handler = sus_mount_statx_ret,
    .data_size = sizeof(struct sus_mount_kretprobe_state),
    .maxactive = 16,
};
static bool kr_statx_ok;

static struct kretprobe kr_statx_do = {
    .kp.symbol_name = "do_statx",
    .entry_handler = sus_mount_statx_entry_do,
    .handler = sus_mount_statx_ret,
    .data_size = sizeof(struct sus_mount_kretprobe_state),
    .maxactive = 16,
};
static bool kr_statx_do_ok;

/* Borrow the lower path while the caller holds the overlay dentry/mount. The
 * overlay superblock owns its lower mount until that call finishes. No get/put,
 * sleeping lookup, or filesystem callback runs in this entry handler. */
/* EROFS on-disk magic; older GKI does not expose it in linux/magic.h. */
#define SUS_MOUNT_EROFS_MAGIC 0xE0F5E1E2UL
struct sus_mount_statfs_state {
    struct path lower;
};
static atomic_t n_statfs_routed = ATOMIC_INIT(0);
static atomic_t n_statfs_nolower = ATOMIC_INIT(0);
static atomic_t n_statfs_ok = ATOMIC_INIT(0);
static atomic_t n_statfs_err = ATOMIC_INIT(0);

static __nocfi bool sus_mount_erofs_lower(const struct path *path, struct path *lower)
{
    struct path next = *path;
    int depth;

    if (!pfn_ovl_path_lower)
        return false;
    for (depth = 0; depth < 4; depth++) {
        struct path prev = next;

        pfn_ovl_path_lower(prev.dentry, &next);
        if (!next.mnt || !next.dentry || !next.dentry->d_sb ||
            (next.mnt == prev.mnt && next.dentry == prev.dentry))
            return false;
        if (next.dentry->d_sb->s_magic == SUS_MOUNT_EROFS_MAGIC) {
            *lower = next;
            return true;
        }
        if (next.dentry->d_sb->s_magic != OVERLAYFS_SUPER_MAGIC)
            return false;
    }
    return false;
}

static int sus_mount_statfs_entry(struct kretprobe_instance *ri, struct pt_regs *regs)
{
    const struct path *path = (const struct path *)regs->regs[0];
    struct sus_mount_statfs_state *st = (void *)ri->data;

    if (sus_mount_is_su_domain() || !path || !path->mnt || !path->dentry ||
        !path->dentry->d_sb || path->dentry->d_sb->s_magic != OVERLAYFS_SUPER_MAGIC ||
        !sus_mount_is_ours(real_mount(path->mnt)))
        return 1;
    if (!sus_mount_erofs_lower(path, &st->lower)) {
        atomic_inc(&n_statfs_nolower);
        return 1;
    }
    /* The original vfs_statfs runs in process context against this lower path:
     * preserve its security check, full live kstatfs, flags, and error result. */
    regs->regs[0] = (unsigned long)&st->lower;
    atomic_inc(&n_statfs_routed);
    return 0;
}

static int sus_mount_statfs_ret(struct kretprobe_instance *ri, struct pt_regs *regs)
{
    if ((long)regs_return_value(regs))
        atomic_inc(&n_statfs_err);
    else
        atomic_inc(&n_statfs_ok);
    return 0;
}

static struct kretprobe kr_statfs = {
    .kp.symbol_name = "vfs_statfs",
    .entry_handler = sus_mount_statfs_entry,
    .handler = sus_mount_statfs_ret,
    .data_size = sizeof(struct sus_mount_statfs_state),
    .maxactive = 64,
};
static bool kr_statfs_ok;

/* Live entries, not slots: after an invalidation the slot is free but the slot
 * count stays where it was, and a diagnostic that reads "idmap=6" while only two
 * entries are usable is the kind of number this project keeps catching. */
static int sus_mount_idmap_live(void)
{
    return READ_ONCE(n_idmap);
}

static int sus_mount_ident_live(void)
{
    unsigned long flags;
    int i, live = 0;

    spin_lock_irqsave(&ident_lock, flags);
    for (i = 0; i < READ_ONCE(n_ident); i++)
        if (smp_load_acquire(&mount_ident[i].root_ino))
            live++;
    spin_unlock_irqrestore(&ident_lock, flags);
    return live;
}

/* Reachability/effect counters, one line per hook: "installed" says nothing about
 * whether the rewrite ever happened. */
static int sus_mount_stat_show(char *buf, const struct kernel_param *kp)
{
    return scnprintf(buf, PAGE_SIZE,
                     "idmap=%d/%d (live/peak limit=%d)  ident=%d/%d  hide=%d su_domain=%d\n"
                     "show_probes=%d/3 (show_vfsstat/show_mountinfo/show_vfsmnt)\n"
                     "ident: hits=%d learned_ids=%d full=%d dropped_dev=%d\n"
                     "idmap: retired=%d dropped_dev=%d freed=%d full=%d allocfail=%d (free_probe=%d)\n"
                     "sb: down=%d (probe=%d)\n"
                     "clone: walks=%d learned=%d (probe=%d)\n"
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
                     "clone_defer: queued=%d dropped=%d\n"
#endif
                     "newmount: seen=%d recorded=%d pathfail=%d (probe=%d)\n"
                     "keep: prefixes=%d rescans=%d\n"
                     "fdinfo: probes=%d entry=%d hits=%d rewrites=%d nolabel=%d\n"
                     "statx: entry=%d ret=%d hits=%d rewrites=%d nobuf=%d err=%d copyfail=%d nomap=%d "
                     "(sys=%d do=%d)\n"
                     "statfs: routed=%d ok=%d err=%d nolower=%d missed=%d (probe=%d lower=%d)\n"
                     "backing: data=%d raw=%d upper=%d lower=%d\n",
                     sus_mount_idmap_live(), READ_ONCE(n_idmap_peak), SUS_MOUNT_IDMAP_MAX,
                     sus_mount_ident_live(), READ_ONCE(n_ident), mount_registered,
                     (int)sus_mount_is_su_domain(),
                     n_show_probes,
                     atomic_read(&n_ident_hits), atomic_read(&n_ident_learned),
                     atomic_read(&n_ident_full),
                     atomic_read(&n_ident_dropped_dev),
                     atomic_read(&n_idmap_recycled),
                     atomic_read(&n_idmap_dropped_dev),
                     atomic_read(&n_idmap_freed), atomic_read(&n_idmap_full),
                     atomic_read(&n_idmap_allocfail), (int)kp_mnt_free_ok,
                     atomic_read(&n_sb_down), (int)kp_sb_down_ok,
                     atomic_read(&n_clone_walks), atomic_read(&n_clone_learned),
                     (int)kr_clone_ns_ok,
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
                     atomic_read(&n_clone_queued), atomic_read(&n_clone_dropped),
#endif
                     atomic_read(&n_newmnt_seen), atomic_read(&n_newmnt_recorded),
                     atomic_read(&n_newmnt_pathfail), (int)kr_newmnt_ok,
                     n_mount_keep, atomic_read(&n_keep_rescans),
                     n_fdinfo_probes,
                     atomic_read(&n_fdinfo_entry), atomic_read(&n_fdinfo_hits),
                     atomic_read(&n_fdinfo_rewrites),
                     atomic_read(&n_fdinfo_nolabel),
                     atomic_read(&n_statx_entry), atomic_read(&n_statx_ret),
                     atomic_read(&n_statx_hits), atomic_read(&n_statx_rewrites),
                     atomic_read(&n_statx_nobuf), atomic_read(&n_statx_err),
                     atomic_read(&n_statx_copyfail), atomic_read(&n_statx_nomap),
                     (int)kr_statx_ok, (int)kr_statx_do_ok,
                     atomic_read(&n_statfs_routed), atomic_read(&n_statfs_ok),
                     atomic_read(&n_statfs_err), atomic_read(&n_statfs_nolower),
                     READ_ONCE(kr_statfs.nmissed), (int)kr_statfs_ok, !!pfn_ovl_path_lower,
                     (int)READ_ONCE(mount_data_dev_valid), !!pfn_dentry_path_raw,
                     !!pfn_ovl_path_upper, !!pfn_ovl_path_lower);
}
static const struct kernel_param_ops sus_mount_stat_ops = {
    .get = sus_mount_stat_show,
};
module_param_cb(mount_stat, &sus_mount_stat_ops, NULL, 0400);

static int sus_mount_show_pre(struct kprobe *kp, struct pt_regs *regs)
{
    struct vfsmount *mnt = (struct vfsmount *)regs->regs[1];
    struct mount *r;

    if (!susfs_ptr_plausible(mnt))
        return 0;
    r = real_mount(mnt);
    /* Cheap path first, and NOT only the id: a KSU mount in a namespace the
     * marking scan never reached (the zygote's, hence every app's) keeps a normal
     * id - see the identity note above sus_mount_is_ours(). */
    if (!sus_mount_is_ours(r)) {
        /* This mount is not ours but carries this id right now, which is proof the
         * id was recycled if we ever learned it (see the idmap note above). */
        sus_mount_idmap_drop((int)r->mnt_id);
        /* mount_dbg: say why - the id, s_dev, root dentry and source are exactly
         * what sus_mount_is_ours() compared. */
        if (mount_dbg && atomic_inc_return(&n_dbg_logged) <= 40)
            SUSFS_LOGI("sus_mount: hook: NOT ours id=%d s_dev=%u root=%px devname=%s\n",
                    r->mnt_id, (unsigned int)r->mnt.mnt_sb->s_dev,
                    r->mnt.mnt_root, r->mnt_devname ? r->mnt_devname : "none");
        return 0;
    }
    /* P2-12 domain gate, upstream patch:1561-1585: the su/ksu domain is not
     * touched at all, it must be able to see its own mounts. */
    if (sus_mount_is_su_domain())
        return 0;
    if (!sus_mount_note_id(r))
        return 0;
    atomic_inc(&n_ident_hits);
    regs->pc = regs->regs[30];   /* skip this mount line */
    /* These show_* callbacks return int and x0 still holds seq_file*.
     * seq_read() treats a negative return as a hard error, so a stray high
     * bit here would break the whole read; upstream's equivalent site
     * explicitly returns 0. */
    regs->regs[0] = 0;
    return 1;
}

static struct kprobe kp_vfsstat = {
    .symbol_name = "show_vfsstat",
    .pre_handler = sus_mount_show_pre,
};

static struct kprobe kp_mountinfo = {
    .symbol_name = "show_mountinfo",
    .pre_handler = sus_mount_show_pre,
};

/* /proc/mounts and /proc/<pid>/mounts go through show_vfsmnt - a DIFFERENT
 * function from show_vfsstat (which serves mountstats).  Missing this hook left
 * /proc/mounts completely unhidden while mountinfo was filtered.  Upstream hooks
 * all three (patch:1402 susfs_show_vfsmnt, :1439 susfs_show_mountinfo, :1504
 * susfs_show_vfsstat). */
static struct kprobe kp_vfsmnt = {
    .symbol_name = "show_vfsmnt",
    .pre_handler = sus_mount_show_pre,
};

/* The three of them as one list, plus what is armed.  Registration and teardown both
 * go through this: with independent registration (see sus_mount_register()) an
 * unregister of a probe that never armed is not a no-op, so teardown must ask. */
#define SUS_MOUNT_SHOW_N 3
static struct kprobe *const sus_mount_show_probes[SUS_MOUNT_SHOW_N] = {
    &kp_vfsstat, &kp_mountinfo, &kp_vfsmnt,
};
static const char *const sus_mount_show_names[SUS_MOUNT_SHOW_N] = {
    "show_vfsstat", "show_mountinfo", "show_vfsmnt",
};
static bool sus_mount_show_armed[SUS_MOUNT_SHOW_N];

/* ---- which mounts count as "ours" ----
 *
 * One test, used by both the enable-time scan and the mount-time hook so the two cannot
 * drift: ours when the source string (mnt_devname) or the mountpoint path starts with one of
 * the PREFIXES below.  Runtime configurable - it used to be a hardcoded "/data/adb/"
 * (KernelSU's module store), which never matched a container (proot/chroot) mounting
 * tmpfs/proc/sysfs/devpts at, say, /data/local/tmp/ubuntu2/dev (see the command surface
 * below).  Anchored (strncmp), never a substring search: a devname such as
 * "/mnt/media_rw/x/data/adb/y" is not a KernelSU mount, and matching those hid unrelated
 * mounts (measured: a mount whose source was "x/data/adb/y" disappeared for non-su readers).
 * Changing the list rescans the current namespace, so an already-mounted path is picked up
 * without re-enabling (later ones come from the attach_recursive_mnt hook); entries recorded
 * before a change stay recorded - the list decides what is accepted from now on, not what is
 * already known. */

/* Interrupt/kprobe safe: read-only, no allocation. */
static bool sus_mount_path_is_ours(const char *s)
{
    unsigned long flags;
    bool hit = false;
    int i;

    if (!s)
        return false;

    spin_lock_irqsave(&mount_keep_lock, flags);
    for (i = 0; i < n_mount_keep; i++) {
        size_t len = strlen(mount_keep[i]);
        bool path = mount_keep[i][0] == '/';

        /* Include the directory itself; retain non-path source-prefix rules. */
        while (path && len > 1 && mount_keep[i][len - 1] == '/')
            len--;
        if (len && !strncmp(s, mount_keep[i], len) &&
            (!path || len == 1 || !s[len] || s[len] == '/')) {
            hit = true;
            break;
        }
    }
    spin_unlock_irqrestore(&mount_keep_lock, flags);
    return hit;
}

/* Process-context refresh; the release-specific namespace iterator is above.
 * No mount ID allocation or modification is needed for identity-based hiding. */
static int sus_mount_refresh(void);	/* changing the list rescans */

static int sus_mount_keep_parse(const char *val, char dst[][SUS_MOUNT_KEEP_LEN], int max)
{
	const char *p = val;
	int n = 0;
	while (*p) {
		char *tok;
		int len;

		while (*p == ' ' || *p == ',' || *p == '\t' || *p == '\n' || *p == '\r')
			p++;
		if (!*p)
			break;
		tok = (char *)p;
		while (*p && *p != ' ' && *p != ',' && *p != '\t' && *p != '\n' && *p != '\r')
			p++;
		len = (int)(p - tok);
		if (len <= 0)
			continue;
		if (len >= SUS_MOUNT_KEEP_LEN)
			return -ENAMETOOLONG;
		if (n >= max)
			return -ENOSPC;
		memcpy(dst[n], tok, len);
		dst[n][len] = '\0';
		n++;
	}
	return n;
}

static void sus_mount_keep_commit(char dst[][SUS_MOUNT_KEEP_LEN], int n)
{
	unsigned long flags;

	spin_lock_irqsave(&mount_keep_lock, flags);
	memset(mount_keep, 0, sizeof(mount_keep));
	memcpy(mount_keep, dst, (size_t)n * SUS_MOUNT_KEEP_LEN);
	n_mount_keep = n;
	spin_unlock_irqrestore(&mount_keep_lock, flags);
}

static void sus_mount_keep_rescan(void)
{
	int rc;

	if (!mount_registered)
		return;		/* nothing is armed yet; the scan at enable will do it */
	rc = sus_mount_refresh();
	atomic_inc(&n_keep_rescans);
	SUSFS_LOGI("sus_mount: rescanned after a list change: %d mount(s) recorded (rc=%d)\n",
			rc, rc < 0 ? rc : 0);
}

/* Commands, same shape as the hide_modules node: add <prefix> | del <prefix> |
 * set <prefix>... | reset | clear.  `reset` restores the built-in default (/data/adb/);
 * `clear` leaves no prefix at all, which stops NEW mounts from being accepted while the KSU
 * mounts stay hidden by their ids; @bare_list is for the insmod form of the parameter only.
 *
 * The two staging buffers used to be locals, which made this frame 2192 bytes and 6.6
 * rejects that outright - "error: stack frame size (2192) exceeds limit (2048) in
 * 'sus_mount_keep_command' [-Werror,-Wframe-larger-than]", and -Wframe-larger-than is an
 * error in the 6.6 GKI build.  They are kvmalloc'd instead: every caller here is a proc/sysfs
 * write handler or module_param setter, i.e. process context that may sleep, so GFP_KERNEL is
 * safe.  The command semantics are unchanged - the early returns now go through @out. */
static int sus_mount_keep_command_impl(const char *val, bool bare_list)
{
	char *cmd;
	char (*staged)[SUS_MOUNT_KEEP_LEN];
	const char *arg;
	int i, n;
	int rc = 0;

	cmd = kvmalloc(SUS_MOUNT_KEEP_CMDLINE, GFP_KERNEL);
	staged = kvmalloc_array(SUS_MOUNT_KEEP_MAX, SUS_MOUNT_KEEP_LEN, GFP_KERNEL);
	if (!cmd || !staged) {
		kvfree(cmd);
		kvfree(staged);
		return -ENOMEM;
	}

	if (strscpy(cmd, val, SUS_MOUNT_KEEP_CMDLINE) < 0) {
		rc = -E2BIG;
		goto out;
	}
	for (i = (int)strlen(cmd) - 1; i >= 0 && (cmd[i] == '\n' || cmd[i] == '\r' || cmd[i] == ' '); i--)
		cmd[i] = '\0';

	if (!strcmp(cmd, "reset")) {
		strscpy(staged[0], mount_keep_default, SUS_MOUNT_KEEP_LEN);
		sus_mount_keep_commit(staged, 1);
		sus_mount_keep_rescan();
		SUSFS_LOGI("sus_mount: prefix list reset to the default\n");
		goto out;
	}
	if (!strcmp(cmd, "clear")) {
		sus_mount_keep_commit(staged, 0);
		SUSFS_LOGI("sus_mount: prefix list cleared (no new mount is accepted by path)\n");
		goto out;
	}
	if (!strncmp(cmd, "set ", 4)) {
		n = sus_mount_keep_parse(cmd + 4, staged, SUS_MOUNT_KEEP_MAX);
		if (n < 0) {
			rc = n;
			goto out;
		}
		sus_mount_keep_commit(staged, n);
		sus_mount_keep_rescan();
		SUSFS_LOGI("sus_mount: prefix list set to %d entr(ies)\n", n);
		goto out;
	}
	if (!strncmp(cmd, "add ", 4) || !strncmp(cmd, "del ", 4)) {
		bool adding = (cmd[0] == 'a');

		arg = cmd + 4;
		while (*arg == ' ')
			arg++;
		if (!*arg || strlen(arg) >= SUS_MOUNT_KEEP_LEN) {
			rc = -EINVAL;
			goto out;
		}

		spin_lock(&mount_keep_lock);
		n = n_mount_keep;
		if (n > SUS_MOUNT_KEEP_MAX)
			n = SUS_MOUNT_KEEP_MAX;
		memcpy(staged, mount_keep, (size_t)n * SUS_MOUNT_KEEP_LEN);
		spin_unlock(&mount_keep_lock);

		{
			bool found = false;

			for (i = 0; i < n; i++) {
				if (strcmp(staged[i], arg))
					continue;
				found = true;
				if (adding)
					goto out;
				memmove(&staged[i], &staged[i + 1],
					(size_t)(n - i - 1) * SUS_MOUNT_KEEP_LEN);
				n--;
				break;
			}
			if (adding) {
				if (found)
					goto out;
				if (n >= SUS_MOUNT_KEEP_MAX) {
					rc = -ENOSPC;
					goto out;
				}
				strscpy(staged[n], arg, SUS_MOUNT_KEEP_LEN);
				n++;
			} else if (!found) {
				rc = -ENOENT;
				goto out;
			}
		}
		sus_mount_keep_commit(staged, n);
		sus_mount_keep_rescan();
		SUSFS_LOGI("sus_mount: %s %s -> %d prefix(es)\n", adding ? "add" : "del", arg, n);
		goto out;
	}

	if (!bare_list) {
		rc = -EINVAL;
		goto out;
	}
	n = sus_mount_keep_parse(cmd, staged, SUS_MOUNT_KEEP_MAX);
	if (n < 0) {
		rc = n;
		goto out;
	}
	sus_mount_keep_commit(staged, n);
	sus_mount_keep_rescan();
	SUSFS_LOGI("sus_mount: prefix list set to %d entr(ies)\n", n);

out:
	kvfree(staged);
	kvfree(cmd);
	return rc;
}

static int sus_mount_keep_command(const char *val, bool bare_list)
{
    int rc = susfs_control_get();

    if (rc)
        return rc;
    mutex_lock(&sus_mount_config_lock);
    rc = sus_mount_exiting ? -ENODEV :
        sus_mount_keep_command_impl(val, bare_list);
    mutex_unlock(&sus_mount_config_lock);
    susfs_control_put();
    return rc;
}

/* Take one coherent list snapshot before formatting. Proc can show all 64;
 * the bounded sysfs view emits only whole prefixes and a whole cut notice. */
static int sus_mount_keep_format(char *buf, size_t size)
{
    char (*snapshot)[SUS_MOUNT_KEEP_LEN];
    static const char cut[] = "\n(truncated)\n";
    unsigned long flags;
    int n = 0, count, i;

    if (!size)
        return 0;
    snapshot = kvmalloc_array(SUS_MOUNT_KEEP_MAX, SUS_MOUNT_KEEP_LEN, GFP_KERNEL);
    if (!snapshot)
        return -ENOMEM;
    spin_lock_irqsave(&mount_keep_lock, flags);
    count = n_mount_keep;
    memcpy(snapshot, mount_keep, (size_t)count * SUS_MOUNT_KEEP_LEN);
    spin_unlock_irqrestore(&mount_keep_lock, flags);
    n += scnprintf(buf + n, size - n,
        "mount prefixes: %d/%d, rescans=%d, recorded=%d, hidden_by_identity=%d, learned_ids=%d\n",
        count, SUS_MOUNT_KEEP_MAX, atomic_read(&n_keep_rescans),
        atomic_read(&n_newmnt_recorded), atomic_read(&n_ident_hits),
        atomic_read(&n_ident_learned));
    n += scnprintf(buf + n, size - n, "prefixes:");
    for (i = 0; i < count; i++) {
        size_t len = strlen(snapshot[i]);
        if (len + 1 + sizeof(cut) > size - n) {
            if (sizeof(cut) <= size - n)
                n += scnprintf(buf + n, size - n, "%s", cut);
            goto out;
        }
        n += scnprintf(buf + n, size - n, " %s", snapshot[i]);
    }
    if (!count)
        n += scnprintf(buf + n, size - n, " (none - only KSU-range ids are hidden)");
    n += scnprintf(buf + n, size - n, "\n");
out:
    kvfree(snapshot);
    return n;
}

static int sus_mount_keep_param_set(const char *val, const struct kernel_param *kp)
{
	return sus_mount_keep_command(val, true);
}

static int sus_mount_keep_param_get(char *buf, const struct kernel_param *kp)
{
	return sus_mount_keep_format(buf, PAGE_SIZE);
}

static const struct kernel_param_ops sus_mount_keep_ops = {
	.get = sus_mount_keep_param_get,
	.set = sus_mount_keep_param_set,
};
/* 0600: root only; the whole directory is inside the one hide_modules hides. */
module_param_cb(hide_mounts, &sus_mount_keep_ops, NULL, 0600);

static int sus_mount_keep_proc_show(struct seq_file *m, void *v)
{
    size_t size = SUS_MOUNT_KEEP_CMDLINE + 256;
    char *buf = kvmalloc(size, GFP_KERNEL);
    int n;

    if (!buf)
        return -ENOMEM;
    n = sus_mount_keep_format(buf, size);
    if (n >= 0)
        seq_write(m, buf, n);
    kvfree(buf);
    return n < 0 ? n : 0;
}

static int sus_mount_keep_proc_open(struct inode *inode, struct file *file)
{
	/* 0777 node + this check, like every other control node: a restrictive mode would
	 * answer EACCES (advertising that the node exists) before sus_path could answer
	 * ENOENT. */
	if (current_uid().val != 0)
		return -ENOENT;
	return single_open(file, sus_mount_keep_proc_show, NULL);
}

static ssize_t sus_mount_keep_proc_write(struct file *file, const char __user *buf,
                                         size_t len, loff_t *off)
{
    char *cmd;
    int rc;

    if (current_uid().val != 0)
        return -ENOENT;
    if (!len)
        return 0;
    if (len >= SUS_MOUNT_KEEP_CMDLINE)
        return -EINVAL;
    cmd = kvmalloc(len + 1, GFP_KERNEL);
    if (!cmd)
        return -ENOMEM;
    if (copy_from_user(cmd, buf, len)) {
        kvfree(cmd);
        return -EFAULT;
    }
    cmd[len] = '\0';
    rc = sus_mount_keep_command(cmd, false);
    kvfree(cmd);
    return rc ? rc : len;
}

static const struct proc_ops sus_mount_keep_proc_ops = {
	.proc_open = sus_mount_keep_proc_open,
	.proc_read = seq_read,
	.proc_write = sus_mount_keep_proc_write,
	.proc_lseek = seq_lseek,
	.proc_release = single_release,
};

static struct proc_dir_entry *sus_mount_keep_entry;

/* Keep the kernel's mount IDs intact. Identity matching already covers copies
 * in other namespaces; replacing IDs here leaked their original allocations
 * and made an eight-ID batch limit the scan's coverage. */
static int sus_mount_scan_ns(struct mnt_namespace *ns, char *buf)
{
    SUS_MOUNT_ITER_TYPE pos;
    unsigned int seen = 0;
    int recorded = 0;

    if (!sus_mount_ns_walk_begin())
        return -ENOSYS;
    rcu_read_lock();
#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 12, 0)
    spin_lock(&ns->ns_lock);
#endif
    SUS_MOUNT_ITER_FOR(ns, pos) {
        struct mount *r;
        char *why = NULL;

        if (seen++ >= SUS_MOUNT_MAX_SCAN)
            break;
        r = SUS_MOUNT_ITER_MOUNT(pos);
        if (SUS_MOUNT_MNT_NOT_IN_NS(r, ns))
            continue;
        if ((unsigned int)r->mnt_id < SUS_MOUNT_KSU_ID_MIN &&
            !sus_mount_should_record(r, buf, PATH_MAX, &why))
            continue;
        sus_mount_ident_add(r);
        if (sus_mount_note_id(r))
            recorded++;
    }
#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 12, 0)
    spin_unlock(&ns->ns_lock);
#endif
    rcu_read_unlock();
    sus_mount_ns_walk_end();
    if (seen > SUS_MOUNT_MAX_SCAN)
        pr_warn("sus_mount: namespace scan capped at %d mounts\n", SUS_MOUNT_MAX_SCAN);
    return recorded;
}

static int sus_mount_refresh(void)
{
    char *buf;
    int recorded;

    if (!current->nsproxy || !current->nsproxy->mnt_ns)
        return -ENOENT;
    sus_mount_refresh_data_dev();
    buf = kmalloc(PATH_MAX, GFP_KERNEL);
    if (!buf)
        return -ENOMEM;
    recorded = sus_mount_scan_ns(current->nsproxy->mnt_ns, buf);
    kfree(buf);
    SUSFS_LOGI("sus_mount: scan recorded %d mounts without changing kernel IDs\n", recorded);
    return recorded;
}

int susfs_sus_mount_init(void)
{
    int err;

    pfn_security_cred_getsecid =
        (void *)find_kernel_symbol_exact("security_cred_getsecid");
    pfn_d_path = (void *)find_kernel_symbol_exact("d_path");
    pfn_dentry_path_raw = (void *)find_kernel_symbol_exact("dentry_path_raw");
    pfn_ovl_path_lower = (void *)find_kernel_symbol_exact("ovl_path_lower");
    pfn_ovl_path_upper = (void *)find_kernel_symbol_exact("ovl_path_upper");
    sus_mount_refresh_data_dev();
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
    /* >= 6.12 has no ns_lock: the per-namespace mount collection is an rb-tree and the
     * only lock that makes it walkable is namespace_sem, the same one the kernel's own
     * /proc/mounts iterator takes for read (fs/namespace.c m_start()/m_stop()).  It is
     * `static DECLARE_RWSEM(namespace_sem)` there, so it is not an exported symbol -
     * resolved by name, which works because GKI sets
     * CONFIG_KALLSYMS_ALL.  A NULL here turns the scan into a refusal, never into an
     * unlocked walk of a tree another task is rotating. */
    sus_mount_namespace_sem = (struct rw_semaphore *)find_kernel_symbol_exact("namespace_sem");
    /* put_mnt_ns() releases the reference the copy_mnt_ns probe takes on the namespace it
     * records (see the deferred walk above).  It is a global in fs/namespace.c, so
     * KALLSYMS has it; without it nothing is queued, which is the fail-closed direction -
     * the ids of a namespace created after the enable are then only picked up by a later
     * scan. */
    pfn_put_mnt_ns = (void *)find_kernel_symbol_exact("put_mnt_ns");
#endif

    err = security_secctx_to_secid(param_su_ctx, strlen(param_su_ctx), &su_sid);
    if (err) {
        pr_warn("sus_mount: secctx_to_secid(%s) failed %d\n", param_su_ctx, err);
        su_sid = 0;
    }

    if (param_min_mnt_id < SUS_MOUNT_MIN_SANE_MNT_ID) {
        pr_warn("sus_mount: min_mnt_id=%lu is below %d, clamping to %llu\n",
                param_min_mnt_id, SUS_MOUNT_MIN_SANE_MNT_ID, DEFAULT_KSU_MNT_ID);
        param_min_mnt_id = DEFAULT_KSU_MNT_ID;
    }

    SUSFS_LOGI("sus_mount: su ctx \"%s\" -> sid %u (stock KernelSU uses \"u:r:su:s0\", override with susfs_guard_lkm.su_ctx)\n",
            param_su_ctx, su_sid);
    if (!pfn_security_cred_getsecid)
        pr_warn("sus_mount: security_cred_getsecid not found - no su-domain gating, KSU mounts will be hidden from EVERY process including su\n");
    if (!pfn_d_path)
        pr_warn("sus_mount: d_path not found - mountpoint prefixes cannot be checked\n");
    if (!pfn_ovl_path_upper || !pfn_ovl_path_lower)
        pr_warn("sus_mount: overlay backing helpers upper=%d lower=%d; unresolved paths cannot extend mount recognition\n",
                !!pfn_ovl_path_upper, !!pfn_ovl_path_lower);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
    if (!sus_mount_namespace_sem)
        pr_warn("sus_mount: namespace_sem not found - the namespace scan will refuse to walk, so mount hiding cannot be enabled\n");
    if (!pfn_put_mnt_ns)
        pr_warn("sus_mount: put_mnt_ns not found - a namespace cloned after the enable is not recorded, so its mounts' ids are only learned by a later scan\n");
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
    if (!sus_mount_namespace_sem || !pfn_put_mnt_ns)
        return -ENOENT;
#endif

    /* Match upstream's boot-local activation policy: stay off until enabled. */
    SUSFS_LOGI("sus_mount: disabled by default (enable via CMD_SUSFS_HIDE_SUS_MNTS_FOR_NON_SU_PROCS)\n");

    /* Which mounts count as ours, before anything looks at them: the built-in default
     * is KernelSU's module store.  The list is runtime configurable (hide_mounts /
     * /proc/susfs_hide_mounts) - a container at /data/local/tmp/ubuntu2 needs its own
     * prefix to be hidden at all. */


    if (susfs_control_node_allowed()) {
        sus_mount_keep_entry = proc_create("susfs_hide_mounts", 0777, NULL,
                           &sus_mount_keep_proc_ops);
        if (!sus_mount_keep_entry)
            pr_warn("sus_mount: proc_create(susfs_hide_mounts) failed - runtime prefix control unavailable, use the hide_mounts parameter\n");
    } else {
        SUSFS_LOGI("sus_mount: /proc/susfs_hide_mounts not created (expose_proc=%d lsm=%d)\n",
                (int)susfs_expose_proc, (int)sus_path_lsm_active());
    }
    return 0;
}

/* One unregister path for both callers (module exit and the disable supercall):
 * two copies drifted apart once already in this project, leaving a hook armed
 * after "disabled". */
static void sus_mount_unregister(void)
{
    int i;

    if (!mount_registered)
        return;
    /* Per probe: with independent registration the list can be partial, and
     * unregister_kprobe() on a probe that never armed walks lists it is not on. */
    for (i = 0; i < SUS_MOUNT_SHOW_N; i++) {
        if (!sus_mount_show_armed[i])
            continue;
        unregister_kprobe(sus_mount_show_probes[i]);
        sus_mount_show_armed[i] = false;
    }
    n_show_probes = 0;
    if (kr_fdinfo_ok)
        sus_mount_fdinfo_disarm();
    if (kr_statx_ok) {
        unregister_kretprobe(&kr_statx);
        kr_statx_ok = false;
    }
    if (kr_statx_do_ok) {
        unregister_kretprobe(&kr_statx_do);
        kr_statx_do_ok = false;
    }
    if (kr_statfs_ok) {
        unregister_kretprobe(&kr_statfs);
        kr_statfs_ok = false;
    }
    if (kr_clone_ns_ok) {
        unregister_kretprobe(&kr_clone_ns);
        kr_clone_ns_ok = false;
    }
    if (kr_newmnt_ok) {
        unregister_kretprobe(&kr_newmnt);
        kr_newmnt_ok = false;
    }
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
    sus_mount_learn_stop();
#endif
    if (kp_mnt_free_ok) {
        unregister_kprobe(&kp_mnt_free);
        kp_mnt_free_ok = false;
    }
    if (kp_sb_down_ok) {
        unregister_kprobe(&kp_sb_down);
        kp_sb_down_ok = false;
    }
    memset(mount_ident, 0, sizeof(mount_ident));
    WRITE_ONCE(n_ident, 0);
    sus_mount_idmap_clear();
    mount_registered = false;
}

void susfs_sus_mount_exit(void)
{
    mutex_lock(&sus_mount_config_lock);
    sus_mount_exiting = true;
    mutex_unlock(&sus_mount_config_lock);
    /* A proc handler may need the control mutex while proc_remove drains it. */
    if (sus_mount_keep_entry) {
        proc_remove(sus_mount_keep_entry);
        sus_mount_keep_entry = NULL;
    }
    mutex_lock(&sus_mount_config_lock);
    sus_mount_unregister();
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
    sus_mount_learn_stop();
#endif
    memset(mount_ident, 0, sizeof(mount_ident));
    WRITE_ONCE(n_ident, 0);
    sus_mount_idmap_clear();
    mutex_unlock(&sus_mount_config_lock);
}

/* register_*probe() resolves symbol_name into kp.addr.  Successful unregister
 * retains that address AND KPROBE_FLAG_DISABLED.  Registering both address and
 * name returns -EINVAL; keeping the disabled bit instead succeeds without an
 * active breakpoint.  Reset both inputs before each attempt, including retries
 * after a failed arm.
 * Only unregistered name-based probes use these helpers; fdinfo's explicitly
 * addressed seq_show probes keep their separate registration path. */
static int sus_mount_register_named_kprobe(struct kprobe *kp)
{
    kp->addr = NULL;
    kp->flags = 0;
    return register_kprobe(kp);
}

static int sus_mount_register_named_kretprobe(struct kretprobe *kr)
{
    kr->kp.addr = NULL;
    kr->kp.flags = 0;
    return register_kretprobe(kr);
}

static int sus_mount_register(void)
{
    int rc, i;

    if (mount_registered)
        return 0;

    /* Refuse enabling without invalidators for both recyclable key types. */
    rc = sus_mount_register_named_kprobe(&kp_sb_down);
    if (rc) {
        pr_warn("sus_mount: generic_shutdown_super hook failed %d; refusing mount hiding\n", rc);
        return rc;
    }
    kp_sb_down_ok = true;
    rc = sus_mount_register_named_kprobe(&kp_mnt_free);
    if (rc) {
        unregister_kprobe(&kp_sb_down);
        kp_sb_down_ok = false;
        pr_warn("sus_mount: cleanup_mnt hook failed %d; refusing mount hiding\n", rc);
        return rc;
    }
    kp_mnt_free_ok = true;
    mount_registered = true;

    /* Each hook covers a different file. Incomplete coverage exposes different
     * mount sets, so roll back every hook on the first failure. Keep the exact
     * hook name and errno in the diagnostic instead of a generic enable error.
     * Registration is sequential, not an atomic multi-hook operation. */
    for (i = 0; i < SUS_MOUNT_SHOW_N; i++) {
        rc = sus_mount_register_named_kprobe(sus_mount_show_probes[i]);
        if (rc) {
            pr_warn("sus_mount: register_kprobe(%s) failed %d - rolling back mount hiding; all three table hooks are required\n",
                    sus_mount_show_names[i], rc);
            sus_mount_unregister();
            return rc;
        }
        sus_mount_show_armed[i] = true;
        n_show_probes++;
    }
    /* The two id rewrites are optional on their own: without them the mount
     * lines are still hidden, so a missing symbol must not take the rest down -
     * but each failure is named, because it leaves the ids visible in exactly
     * the place upstream rewrites them. */
    rc = sus_mount_fdinfo_arm();
    if (rc)
        pr_warn("sus_mount: the fdinfo probe could not be armed %d - /proc/<pid>/fdinfo keeps printing the real mnt_id\n", rc);
    rc = sus_mount_register_named_kretprobe(&kr_statx);
    if (rc) {
        pr_warn("sus_mount: register_kretprobe(__arm64_sys_statx) failed %d - statx keeps returning the real stx_mnt_id\n", rc);
    } else {
        kr_statx_ok = true;
    }
    rc = sus_mount_register_named_kretprobe(&kr_statx_do);
    if (rc) {
        pr_warn("sus_mount: register_kretprobe(do_statx) failed %d - the second statx landing point is not armed\n", rc);
    } else {
        kr_statx_do_ok = true;
    }
    rc = sus_mount_register_named_kretprobe(&kr_statfs);
    if (rc)
        pr_warn("sus_mount: vfs_statfs hook failed %d - hidden overlays retain their filesystem statistics\n", rc);
    else
        kr_statfs_ok = true;
    /* Optional as well: without it a namespace copied after the enable keeps
     * working for the mount TABLE (identity hides the lines) but fdinfo/statx stay
     * inconsistent until somebody reads a mount table in that namespace. */
    rc = sus_mount_register_named_kretprobe(&kr_clone_ns);
    if (rc)
        pr_warn("sus_mount: register_kretprobe(copy_mnt_ns) failed %d - ids of mounts in a namespace copied later are only learned when its mount table is read\n",
                rc);
    else
        kr_clone_ns_ok = true;
    /* And the mount-time registration, which is what covers a filesystem mounted while
     * the module is already up (see the note above kr_newmnt).  Also optional in the
     * sense that hiding keeps working for everything the scan saw - but without it a
     * mount that appears later is not hidden anywhere, so a failure is reported. */
    rc = sus_mount_register_named_kretprobe(&kr_newmnt);
    if (rc)
        pr_warn("sus_mount: register_kretprobe(attach_recursive_mnt) failed %d - a mount created after the enable is NOT hidden (not marked, no identity recorded)\n",
                rc);
    else
        kr_newmnt_ok = true;
    mount_registered = true;
    return 0;
}

/* supercall: CMD_SUSFS_HIDE_SUS_MNTS_FOR_NON_SU_PROCS */
static void susfs_sus_mount_supercall_impl(void __user **arg)
{
    struct st_susfs_hide_sus_mnts_for_non_su_procs info = {0};
    int rc;

    if (copy_from_user(&info, (void __user *)*arg, sizeof(info))) {
        info.err = -EFAULT;
        goto out;
    }

    if (info.enabled) {
        rc = sus_mount_register();
        if (rc) {
            info.err = rc;
            goto out;
        }
        /* Populate identities and ID mappings for mounts that predate enabling. */
        rc = sus_mount_refresh();
        if (rc < 0) {
            pr_warn("sus_mount: scan on enable failed %d - disabling hooks and reporting the failure to userspace\n",
                    rc);
            sus_mount_unregister();
            info.err = rc;
            goto out;
        }
    } else if (mount_registered) {
        sus_mount_unregister();
    }
    info.err = 0;
    SUSFS_LOGI("sus_mount: %s (supercall)\n", info.enabled ? "hide" : "unhide");
out:
    /* upstream writes back only ->err for input-type commands */
    if (copy_to_user(&((struct st_susfs_hide_sus_mnts_for_non_su_procs __user *)*arg)->err,
                     &info.err, sizeof(info.err)))
        pr_warn("sus_mount supercall copy_to_user failed\n");
}

void susfs_sus_mount_supercall(void __user **arg)
{
    int rc = susfs_control_get();

    if (!rc) {
        mutex_lock(&sus_mount_config_lock);
        if (!sus_mount_exiting) {
            susfs_sus_mount_supercall_impl(arg);
            mutex_unlock(&sus_mount_config_lock);
            susfs_control_put();
            return;
        }
        mutex_unlock(&sus_mount_config_lock);
        rc = -ENODEV;
        susfs_control_put();
    }
    if (copy_to_user(&((struct st_susfs_hide_sus_mnts_for_non_su_procs __user *)*arg)->err,
                     &rc, sizeof(rc)))
        pr_warn("sus_mount unavailable reply failed\n");
}
