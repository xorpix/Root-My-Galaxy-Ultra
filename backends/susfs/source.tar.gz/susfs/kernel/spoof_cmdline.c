// SPDX-License-Identifier: GPL-2.0
/*
 * spoof_cmdline.c - spoof /proc/bootconfig (SUSFS SPOOF_CMDLINE_OR_BOOTCONFIG).  boot_config_proc_show()
 * (fs/proc/bootconfig.c) does `if (saved_boot_config) seq_puts(m, saved_boot_config);`, so rewriting the static
 * pointer spoofs the whole file. ksud relocates this unexported pointer at load time.
 * Writers are serialized; replaced strings are reclaimed only after a Tasks RCU
 * grace period covers the native, non-sleeping seq_puts() reader window.
 */
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/cred.h>
#include <linux/mutex.h>
#include <linux/rcupdate.h>
#include "susfs_abi.h"
#include "susfs_log.h"
#include "susfs.h"	/* susfs_abi_path_ok */

/* unexported static var; ksud insmod relocates it via kallsyms */
extern char *saved_boot_config;

/* The supercall's field is 8192 wide, but this insmod parameter cannot be: module_param_string()'s value goes through a
 * sysfs attribute and a sysfs write is capped at one page, so the parameter tops out at 4095 bytes where the supercall
 * accepts 8191. */
static char param_bootconfig[4096];
module_param_string(bootconfig, param_bootconfig, sizeof(param_bootconfig), 0644);

static char *orig_boot_config;
static char *fake_boot_config;
static bool original_captured;
static bool spoof_active;
static bool bootconfig_exiting;
static DEFINE_MUTEX(bootconfig_lock);
static unsigned long bootconfig_values, bootconfig_sets, bootconfig_resets;
static unsigned long bootconfig_conflicts;
static int bootconfig_last_error;

/* Allocate bookkeeping with the text, before publishing it. The live value is
 * kept separate from values retired by successful replacement/restoration. */
struct bootconfig_value {
	struct list_head list;
	char text[];
};
static struct bootconfig_value *live_bootconfig;
static LIST_HEAD(retired_bootconfigs);

static void bootconfig_drain_retired(void)
{
	struct bootconfig_value *value, *next;
	LIST_HEAD(doomed);

	mutex_lock(&bootconfig_lock);
	list_splice_init(&retired_bootconfigs, &doomed);
	mutex_unlock(&bootconfig_lock);

	if (list_empty(&doomed))
		return;

	/* boot_config_proc_show() loads the pointer and passes it to seq_puts().
	 * That window only runs strlen()/memcpy() into an existing seq buffer:
	 * no allocation, voluntary scheduling or userspace access. Tasks RCU
	 * covers a preempted native reader; ordinary RCU alone does not.
	 * Module init already requires CONFIG_TASKS_RCU. Never replace this wait
	 * with a timed delay. No writer lock is held while waiting. */
	synchronize_rcu_tasks();
	list_for_each_entry_safe(value, next, &doomed, list) {
		list_del(&value->list);
		kfree(value);
	}
}

/* Allocate first, publish second.  Returns 0 or a negative errno. */
static int spoof_set(const char *fake)
{
	struct bootconfig_value *value;
	char *expected;
	size_t len = strlen(fake) + 1;
	int rc = 0;

	value = kmalloc(sizeof(*value) + len, GFP_KERNEL);
	if (!value)
		return -ENOMEM;
	memcpy(value->text, fake, len);
	mutex_lock(&bootconfig_lock);
	if (bootconfig_exiting) {
		rc = -ENODEV;
		goto out;
	}
	expected = original_captured ? (spoof_active ? fake_boot_config : orig_boot_config)
				     : READ_ONCE(saved_boot_config);
	/* A different writer owns a foreign pointer. Do not overwrite it or lose the
	 * original value that was captured before our first successful publication. */
	if (cmpxchg(&saved_boot_config, expected, value->text) != expected) {
		bootconfig_conflicts++;
		rc = -EBUSY;
	} else {
		if (!original_captured) {
			orig_boot_config = expected;
			original_captured = true;
		}
		if (live_bootconfig)
			list_add_tail(&live_bootconfig->list, &retired_bootconfigs);
		live_bootconfig = value;
		fake_boot_config = value->text;
		spoof_active = true;
		bootconfig_values++;
		bootconfig_sets++;
	}
out:
	bootconfig_last_error = rc;
	mutex_unlock(&bootconfig_lock);
	if (rc)
		kfree(value);
	else
		bootconfig_drain_retired();
	return rc;
}

static int spoof_reset(void)
{
	int rc = 0;

	mutex_lock(&bootconfig_lock);
	if (spoof_active &&
	    cmpxchg(&saved_boot_config, fake_boot_config, orig_boot_config) != fake_boot_config) {
		bootconfig_conflicts++;
		rc = -EBUSY;
	} else {
		if (live_bootconfig) {
			list_add_tail(&live_bootconfig->list, &retired_bootconfigs);
			live_bootconfig = NULL;
		}
		spoof_active = false;
		fake_boot_config = NULL;
		bootconfig_resets++;
	}
	bootconfig_last_error = rc;
	mutex_unlock(&bootconfig_lock);
	if (!rc)
		bootconfig_drain_retired();
	return rc;
}

static int bootconfig_reset_set(const char *val, const struct kernel_param *kp)
{
	bool reset;
	int rc;

	if (current_uid().val != 0)
		return -EPERM;
	rc = kstrtobool(val, &reset);
	if (rc || !reset)
		return -EINVAL;
	return spoof_reset();
}

static int bootconfig_stat_get(char *buffer, const struct kernel_param *kp)
{
	int len;

	mutex_lock(&bootconfig_lock);
	len = scnprintf(buffer, PAGE_SIZE,
		"checkpoint=18 restore=1 active=%d captured=%d values=%lu sets=%lu resets=%lu conflicts=%lu last_error=%d\n",
		(int)spoof_active, (int)original_captured, bootconfig_values,
		bootconfig_sets, bootconfig_resets, bootconfig_conflicts, bootconfig_last_error);
	mutex_unlock(&bootconfig_lock);
	return len;
}

/* Live restoration without overloading the upstream string-setting ABI. */
static const struct kernel_param_ops bootconfig_reset_ops = { .set = bootconfig_reset_set };
static const struct kernel_param_ops bootconfig_stat_ops = { .get = bootconfig_stat_get };
module_param_cb(bootconfig_reset, &bootconfig_reset_ops, NULL, 0200);
module_param_cb(bootconfig_stat, &bootconfig_stat_ops, NULL, 0444);

int susfs_spoof_cmdline_init(void)
{
	int rc;

	if (!param_bootconfig[0]) {
		SUSFS_LOGI("spoof_cmdline: no fake bootconfig, not armed\n");
		return 0;
	}
	rc = spoof_set(param_bootconfig);
	if (rc) {
		pr_err("spoof_cmdline: set failed %d, not armed\n", rc);
		return rc;
	}
	SUSFS_LOGI("spoof_cmdline armed: %s\n", param_bootconfig);
	return 0;
}

void susfs_spoof_cmdline_exit(void)
{
	mutex_lock(&bootconfig_lock);
	bootconfig_exiting = true;
	mutex_unlock(&bootconfig_lock);
	if (spoof_reset())
		/* A foreign owner may still hold our live pointer. Preserve it rather
		 * than overwrite foreign state or free memory with unknown readers. */
		pr_warn("spoof_cmdline: foreign bootconfig pointer; retaining the owned live value\n");
	bootconfig_drain_retired();
}

/* supercall: CMD_SUSFS_SET_CMDLINE_OR_BOOTCONFIG */
void susfs_spoof_cmdline_supercall(void __user **arg)
{
	struct st_susfs_spoof_cmdline_or_bootconfig *info;
	int err;

	info = kzalloc(sizeof(*info), GFP_KERNEL);
	if (!info) {
		/* The kprobe has already claimed the syscall and answered 0, so returning silently leaves the
		 * caller's pre-seeded 126 (ERR_CMD_NOT_SUPPORTED) in place: the C tool then reports "please
		 * enable SUSFS in kernel" for a command this kernel implements, and ksud's err==126 check turns
		 * it into a silent success.  Upstream writes -ENOMEM here (fs/susfs.c:707-713); task_work
		 * context, so the writeback is safe. */
		err = -ENOMEM;
		if (copy_to_user(&((struct st_susfs_spoof_cmdline_or_bootconfig __user *)*arg)->err,
				 &err, sizeof(err)))
			pr_warn("cmdline supercall copy_to_user failed\n");
		pr_warn_ratelimited("spoof_cmdline: kzalloc failed, reported -ENOMEM\n");
		return;
	}

	if (copy_from_user(info, (void __user *)*arg, sizeof(*info))) {
		info->err = -EFAULT;
		goto out;
	}

	/* Empty string is rejected upstream (-EINVAL); report the real result instead of always claiming success. */
	if (!info->fake_cmdline_or_bootconfig[0]) {
		info->err = -EINVAL;
		goto out;
	}
	/* spoof_set() kstrdup()s this, i.e. strlen()s it: an unterminated fixed-size ABI field would be read past the end. */
	if (!susfs_abi_path_ok(info->fake_cmdline_or_bootconfig,
			       sizeof(info->fake_cmdline_or_bootconfig))) {
		info->err = -ENAMETOOLONG;
		goto out;
	}

	info->err = spoof_set(info->fake_cmdline_or_bootconfig);
	if (!info->err)
		SUSFS_LOGI("spoof_cmdline: set fake bootconfig (supercall)\n");
out:
	/* upstream writes back only ->err for input-type commands */
	if (copy_to_user(&((struct st_susfs_spoof_cmdline_or_bootconfig __user *)*arg)->err,
			 &info->err, sizeof(info->err)))
		pr_warn("cmdline supercall copy_to_user failed\n");
	kfree(info);
}
