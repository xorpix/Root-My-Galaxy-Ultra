/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __SUSFS_H
#define __SUSFS_H

#include <linux/string.h>
#include <linux/err.h>	/* IS_ERR */
#include <linux/mm.h>	/* PAGE_SIZE */

/* A kernel pointer taken out of a kprobe register, checked before dereference: single_open()'s fake inode is (void *)1
 * and a kretprobe hands that sentinel over as "the argument" - the sus_map vma probe panicked on exactly that (fault
 * address 0xa1) until this test existed.  Every kernel object lives above the first page, so "< PAGE_SIZE" covers a
 * sentinel and a garbage register too, and IS_ERR() covers error pointers; user pointers must NOT go through it. */
static inline bool susfs_ptr_plausible(const void *p)
{
	return (unsigned long)p >= PAGE_SIZE && !IS_ERR(p);
}

/* Bind a fixed-size ABI pathname field to a C string safely: char[N] pathname fields a caller need not NUL-terminate, and
 * strlen()/strcmp()/kern_path() on one walks off the end of the struct, which lives on OUR kernel stack.  Every consumer of
 * an ABI pathname goes through this first. */
static inline bool susfs_abi_path_ok(const char *field, size_t size)
{
	return strnlen(field, size) < size;
}

/* Add a path to sus_path's hidden set from kernel code (no supercall needed); returns 0 or negative errno. */
int sus_path_add_hidden(const char *path);

/* Same, for one of this module's own control nodes: flagged so the gate hides it from EVERY non-root caller, not merely
 * from app processes KernelSU would umount modules for - otherwise a probe running as system (1000) or shell (2000) reads the node name out of /proc. */
int sus_path_add_self_hidden(const char *path);

/* Undo sus_path_add_self_hidden(): drops the rule for @path and restores whatever it changed (the relaxed mode, the inode
 * reference); returns the number of rules removed, so 0 means "was not registered".  Process context only (iput). */
int sus_path_del_path(const char *path);

/* ---- sus_path's dirent filter, driven by the sys_exit tracepoint in susfs_kstat.c ----
 *
 * There is exactly ONE sys_exit tracepoint in this module and it lives in susfs_kstat.c (it is what
 * spoofs stat).  The listing (getdents) rewrite is called from that handler through these two
 * functions rather than through a second probe of its own: the tracepoint is paid for on every
 * syscall already, so a whitelisted number costs one compare, while the two getdents kretprobes
 * this replaces cost a trap per listing (measured 906 ns) and can silently drop a return once
 * maxactive is reached.  sus_path.c still owns the whole rewrite (bounce buffer, per-ABI record
 * layout, (ino, name) match, gate); susfs_kstat.c owns only "which number, which user pointer".
 *
 *   sus_path_dirent_filter(@syscall_nr, @buf, @ret)
 *       @buf  is the ALREADY-converted user pointer (the caller must apply compat_ptr() for a
 *             32-bit task: a compat pointer is a zero-extended u32 and must not be passed raw)
 *       @ret  is the syscall's return value
 *       returns what the syscall should return now - @ret itself when nothing was filtered or the
 *       number is not one this layer knows, so the caller can always assign the result back.
 *       Non-sleeping (tracepoint context); takes its own spinlock around the shared scratch buffer.
 */
long sus_path_dirent_filter(long syscall_nr, unsigned long buf, long ret);

/* One line of dirent counters for /proc/susfs_kstat's counter block (which ABI reached the filter,
 * and why a listing that should have been filtered was not).  Returns the bytes written. */
int sus_path_dirent_stat_line(char *buf, size_t size);

/* Whether any rule is live right now.  The create-family entries run for every
 * mkdirat/symlinkat/mknodat/linkat on the system, so they test this before they resolve a
 * path: an empty table costs one load instead of a lookup, and deleting the last rule takes
 * that cost away again. */
bool sus_path_rules_present(void);

struct inode;
/* Whether sus_path hides @inode from the CURRENT caller, for layers outside sus_path that
 * match its read-path answer (create_gate): the same gate the LSM layer and the dirent
 * rewrite run, including this caller's resolver exemption. */
bool sus_path_inode_hidden_public(struct inode *inode);

/* The module's own name: the /sys/module directory and the modinfo name are both the module file name, and the self-hide
 * rules and the /proc/modules filter have to agree with it. */
#define SUSFS_LKM_MODULE_NAME "susfs_guard_lkm"
#define SUSFS_LKM_SYSFS_DIR   "/sys/module/" SUSFS_LKM_MODULE_NAME

/* hide_modules (susfs_hide_syms.c): filters module NAMES out of /proc/modules (plus /sys/module and /proc/kallsyms for
 * non-root callers).  Node and same-named parameter are root-only; the node answers ENOENT through sus_path's hidden set. */
#define SUSFS_HIDE_MODULES_NODE "/proc/susfs_hide_modules"
bool susfs_hide_modules_active(void);

/* The sus_mount control node: decides WHICH mounts count as ours (the on/off switch stays the hide_sus_mnts_for_non_su_procs supercall); root-only, ENOENT for everyone else through sus_path. */
#define SUSFS_HIDE_MOUNTS_NODE "/proc/susfs_hide_mounts"
bool susfs_hide_modules_node_ready(void);

/* sus_path's own control node: `cat` is the rule listing (the hide_list parameter view), writing takes add/del/clear.  An
 * operator who cannot see the rule table cannot tell "registered" from "hiding"; root-only, everyone else gets ENOENT. */
#define SUSFS_PATH_NODE "/proc/susfs_path"

/* Whether the /proc/susfs_* control nodes are created at all.  Defaults to TRUE; they are created only when the LSM layer
 * that hides them is installed, so nobody ends up with an unprotected control node, and expose_proc=0 removes them. */
extern bool susfs_expose_proc;

/* feature init/exit (each feature is its own translation unit) */
int susfs_uname_init(void);
void susfs_uname_exit(void);

int susfs_kstat_init(void);
void susfs_kstat_exit(void);

int susfs_sus_map_init(void);
void susfs_sus_map_exit(void);

int sus_path_init(void);
void sus_path_exit(void);

/* create_gate (susfs_create_gate.c): answers the create family the way an absent
 * name would, via the fp-hook layer.  NOT required: armed entries answer EACCES
 * for hidden names, unarmed ones keep the kernel's own EEXIST. */
int susfs_create_gate_init(void);
void susfs_create_gate_exit(void);

int susfs_sus_mount_init(void);
void susfs_sus_mount_exit(void);

int susfs_spoof_cmdline_init(void);
void susfs_spoof_cmdline_exit(void);

int susfs_open_redirect_init(void);
void susfs_open_redirect_exit(void);

int susfs_enable_log_init(void);
void susfs_enable_log_exit(void);
bool susfs_log_enabled(void);

int susfs_avc_spoof_init(void);
void susfs_avc_spoof_exit(void);

int susfs_supercall_init(void);
void susfs_supercall_exit(void);
bool susfs_supercall_kprobe_active(void);

/* The features a layer can arm, one row per layer table entry.  The reboot kprobe reads the
 * bitmap with test_bit(); the arm happens once, in process context, before the module can
 * serve a command. */
enum susfs_feature {
	SUSFS_FEAT_SUS_PATH = 0,
	SUSFS_FEAT_SUS_MOUNT,
	SUSFS_FEAT_SUS_KSTAT,
	SUSFS_FEAT_SPOOF_UNAME,
	SUSFS_FEAT_ENABLE_LOG,
	SUSFS_FEAT_HIDE_SYMS,
	SUSFS_FEAT_SPOOF_CMDLINE,
	SUSFS_FEAT_OPEN_REDIRECT,
	SUSFS_FEAT_SUS_MAP,
	SUSFS_FEAT_AVC_SPOOF,	/* commands only: no upstream CONFIG_* line for it */
	SUSFS_FEAT_PRIORITY_FILTER,
	SUSFS_FEAT_COUNT,
};

void susfs_supercall_arm_feature(enum susfs_feature feature);
bool susfs_supercall_feature_armed(enum susfs_feature feature);

/* feature supercall handlers (upstream signature: void xxx(void __user **arg)) */
void susfs_uname_supercall(void __user **arg);
void susfs_enable_log_supercall(void __user **arg);
void susfs_avc_spoof_supercall(void __user **arg);
void susfs_spoof_cmdline_supercall(void __user **arg);
void susfs_sus_map_supercall(void __user **arg);
void sus_path_supercall(unsigned int cmd, void __user **arg);
void susfs_kstat_supercall(unsigned int cmd, void __user **arg);
void susfs_open_redirect_supercall(void __user **arg);
void susfs_sus_mount_supercall(void __user **arg);
void susfs_priority_filter_supercall(void __user **arg);
int susfs_priority_filter_init(void);
void susfs_priority_filter_exit(void);

int susfs_hide_syms_init(void);
void susfs_hide_syms_exit(void);

/* Actual install state: enabled_features must not advertise a feature whose registration failed - hide_syms used to fail
 * silently and still be reported as active, the kind of inconsistency a detector looks for. */
bool susfs_hide_syms_active(void);
bool sus_path_lsm_active(void);

/* Whether a 0777 /proc/susfs_* control node may be created.  Two independent conditions, neither optional: susfs_expose_proc
 * (the operator opted in) and sus_path_lsm_active() (with 0777 DAC passes every caller, so only the LSM layer can still
 * answer ENOENT for an app).  This gates node CREATION ONLY, never hook registration: an earlier revision returned early from
 * the feature inits on !susfs_expose_proc, which silently disabled sus_kstat's tracepoint and kretprobe. */
static inline bool susfs_control_node_allowed(void)
{
	return susfs_expose_proc && sus_path_lsm_active();
}

/* open_redirect, reverse direction, for callers that only have an inode NUMBER: fdinfo prints "ino:\t<i>" with no device, so
 * this is a lookup by ino alone and returns false when the number is ambiguous (two rules, same redirected ino) or the caller is
 * not one the reverse disguise applies to.  On success *out_ino is the target inode to show, *out_mnt_id the target mount id. */
bool susfs_open_redirect_spoof_ids(unsigned long ino, unsigned long *out_ino, unsigned long *out_mnt_id);

/* The pathname width every OPEN_REDIRECT ABI field is bound to: the char[256] supercall/proc fields and the rule table's
 * pathname fields share it (a local redefine in one translation unit would let one side truncate what the other side
 * accepts). */
#define SUSFS_OR_PATH_MAX 256

struct path;

/* open_redirect, forward direction, name layer: the open syscall-entry wrappers (susfs_or_entry.c) call this with the
 * path they are about to open.  True when a live rule whose uid_scheme matches the caller redirects that inode, and
 * *buf then holds the redirect target to open instead (NUL-terminated within buflen).  False leaves the original
 * syscall unchanged, which is always a correct fallback. */
bool susfs_open_redirect_match_path(const struct path *path, char *buf, size_t buflen);

/* Published rule count (slots not being rewritten or deleted).  The wrappers' fast path, the "(empty)"
 * /proc output and or_add()'s capacity handling all want the number, not a scan. */
extern unsigned int susfs_open_redirect_rules;
static inline bool susfs_open_redirect_active(void)
{
	return susfs_open_redirect_rules != 0;
}

/* Name-layer state: whether the open syscall entries are currently owned by the wrappers (susfs_or_entry.c).
 * or_add() refuses rules while this is false, so a listed rule is always one a caller can actually reach. */
bool susfs_or_entry_armed(void);

#endif
