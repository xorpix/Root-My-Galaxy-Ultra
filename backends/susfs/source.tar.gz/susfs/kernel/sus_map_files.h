/* SPDX-License-Identifier: GPL-2.0 */
/* Included by sus_map.c so rule matching and the app gate remain one source.
 * Android 16 / 6.12 native procfs semantics are retained, including ptrace and
 * capability checks, padding-aware ranges and ownership passed to nd_jump_link.
 * No path_put(), mmap lock or allocation executes in a probe callback. */

static typeof(((struct file_operations *)0)->iterate_shared) map_files_original_iterate;
static typeof(((struct inode_operations *)0)->readlink) map_files_original_readlink;
static typeof(((struct inode_operations *)0)->get_link) map_files_original_get_link;
static typeof(((struct inode_operations *)0)->lookup) map_files_original_lookup;
static typeof(((struct dentry_operations *)0)->d_revalidate) map_files_original_revalidate;
/* Private helper prototype verified against the pinned fs/proc/base.c. */
static struct dentry *(*map_files_instantiate)(struct dentry *, struct task_struct *, const void *);
static typeof(&nd_jump_link) map_files_jump_link;
/* ptrace_may_access is private in Android common; call its resolved, fully typed
 * target rather than adding an unavailable module import or bypassing access. */
static typeof(&ptrace_may_access) map_files_may_access;
#ifdef VMA_PAD_START
/* Android keeps this helper private too; its native implementation respects
 * the boot-time page-size migration gate as well as the VMA padding bits. */
static typeof(&vma_pad_pages) map_files_pad_pages;
#endif
static bool map_files_installed;
static int map_files_probe_slot = -1;
static int map_files_probe_error;
static const struct inode_operations *map_files_native_iops;
static struct kprobe map_files_probes[5];
static bool map_files_probe_armed[5];
static atomic_t n_map_files_diverted = ATOMIC_INIT(0);
static atomic_t n_map_files_bypassed = ATOMIC_INIT(0);
static atomic_t map_files_callbacks = ATOMIC_INIT(0);
static DECLARE_WAIT_QUEUE_HEAD(map_files_waitq);
static atomic_t n_map_files_iterate = ATOMIC_INIT(0);
static atomic_t n_map_files_entries_hidden = ATOMIC_INIT(0);
static atomic_t n_map_files_readlink = ATOMIC_INIT(0);
static atomic_t n_map_files_follow = ATOMIC_INIT(0);
static atomic_t n_map_files_paths = ATOMIC_INIT(0);
static atomic_t n_map_files_puts = ATOMIC_INIT(0);
static atomic_t n_map_files_jumps = ATOMIC_INIT(0);
static atomic_t n_map_files_lookup = ATOMIC_INIT(0);
static atomic_t n_map_files_lookup_hides = ATOMIC_INIT(0);
static atomic_t n_map_files_revalidate = ATOMIC_INIT(0);
static atomic_t n_map_files_revalidate_hides = ATOMIC_INIT(0);
static atomic_t n_map_files_revalidate_rcu = ATOMIC_INIT(0);

static void sus_map_files_enter(void)
{
    atomic_inc(&map_files_callbacks);
    smp_mb__after_atomic();
}

static void sus_map_files_leave(void)
{
    smp_mb__before_atomic();
    if (atomic_dec_and_test(&map_files_callbacks))
        wake_up_all(&map_files_waitq);
}

/* Only process-context calls into the original function publish a guard.
 * The probe only scans this short list under an IRQ-safe lock; it allocates
 * nothing, takes no mmap lock and never releases a path. Stack ownership
 * makes the guard task-specific across sleep/migration and removes it on all
 * native returns. Guard exactly one probe, so other map_files operations in
 * the same task are still filtered. */
struct sus_map_files_guard {
    struct list_head link;
    struct task_struct *task;
    const struct kprobe *probe;
};
static LIST_HEAD(map_files_guards);
static DEFINE_SPINLOCK(map_files_guard_lock);

static bool sus_map_files_bypass(const struct kprobe *probe)
{
    struct sus_map_files_guard *guard;
    unsigned long flags;
    bool found = false;

    spin_lock_irqsave(&map_files_guard_lock, flags);
    list_for_each_entry(guard, &map_files_guards, link) {
        if (guard->task == current && guard->probe == probe) {
            found = true;
            break;
        }
    }
    spin_unlock_irqrestore(&map_files_guard_lock, flags);
    return found;
}

static void sus_map_files_guard_begin(struct sus_map_files_guard *guard, int slot)
{
    unsigned long flags;
    guard->task = current;
    guard->probe = &map_files_probes[slot];
    spin_lock_irqsave(&map_files_guard_lock, flags);
    list_add(&guard->link, &map_files_guards);
    spin_unlock_irqrestore(&map_files_guard_lock, flags);
}

static void sus_map_files_guard_end(struct sus_map_files_guard *guard)
{
    unsigned long flags;
    spin_lock_irqsave(&map_files_guard_lock, flags);
    list_del(&guard->link);
    spin_unlock_irqrestore(&map_files_guard_lock, flags);
}

static int sus_map_files_native_iterate(struct file *file, struct dir_context *ctx)
{
    struct sus_map_files_guard guard;
    int rc;
    sus_map_files_guard_begin(&guard, 0);
    rc = map_files_original_iterate(file, ctx);
    sus_map_files_guard_end(&guard);
    return rc;
}

static int sus_map_files_native_readlink(struct dentry *dentry, char __user *buffer, int len)
{
    struct sus_map_files_guard guard;
    int rc;
    sus_map_files_guard_begin(&guard, 1);
    rc = map_files_original_readlink(dentry, buffer, len);
    sus_map_files_guard_end(&guard);
    return rc;
}

static const char *sus_map_files_native_get_link(struct dentry *dentry, struct inode *inode,
                                                struct delayed_call *done)
{
    struct sus_map_files_guard guard;
    const char *rc;
    sus_map_files_guard_begin(&guard, 2);
    rc = map_files_original_get_link(dentry, inode, done);
    sus_map_files_guard_end(&guard);
    return rc;
}

static struct dentry *sus_map_files_native_lookup(struct inode *dir, struct dentry *dentry,
                                                 unsigned int flags)
{
    struct sus_map_files_guard guard;
    struct dentry *result;
    sus_map_files_guard_begin(&guard, 3);
    result = map_files_original_lookup(dir, dentry, flags);
    sus_map_files_guard_end(&guard);
    return result;
}

static int sus_map_files_native_revalidate(struct dentry *dentry, unsigned int flags)
{
    struct sus_map_files_guard guard;
    int rc;
    sus_map_files_guard_begin(&guard, 4);
    rc = map_files_original_revalidate(dentry, flags);
    sus_map_files_guard_end(&guard);
    return rc;
}

/* Names supplied by dir_emit are length-delimited, not NUL-terminated. */
static bool sus_map_files_range(const char *name, int len,
                                unsigned long *start, unsigned long *end)
{
    unsigned long values[2] = {0, 0};
    int part = 0, digits = 0, i;

    if (!name || len < 3 || len > 4 * (int)sizeof(long) + 1)
        return false;
    for (i = 0; i < len; i++) {
        unsigned int digit;
        char c = name[i];
        if (c == '-' && !part && digits) {
            part = 1;
            digits = 0;
            continue;
        }
        if (c >= '0' && c <= '9')
            digit = c - '0';
        else if (c >= 'a' && c <= 'f')
            digit = c - 'a' + 10;
        else if (c >= 'A' && c <= 'F')
            digit = c - 'A' + 10;
        else
            return false;
        if (++digits > 2 * (int)sizeof(long) ||
            (digits > 1 && values[part] == 0))
            return false;
        values[part] = (values[part] << 4) | digit;
    }
    if (!part || !digits || values[0] >= values[1])
        return false;
    *start = values[0];
    *end = values[1];
    return true;
}

static unsigned long sus_map_files_vma_end(struct vm_area_struct *vma)
{
#ifdef VMA_PAD_START
    return vma->vm_end - (map_files_pad_pages(vma) << PAGE_SHIFT);
#else
    return vma->vm_end;
#endif
}

/* Caller holds mmap_lock. Never use the procfs symlink inode as file identity. */
static struct vm_area_struct *sus_map_files_vma(struct mm_struct *mm,
                                                unsigned long start,
                                                unsigned long end)
{
    struct vm_area_struct *vma = find_vma(mm, start);
    if (!vma || vma->vm_start != start || sus_map_files_vma_end(vma) != end)
        return NULL;
    return vma;
}

static bool sus_map_files_hidden_vma(struct vm_area_struct *vma)
{
    struct inode *inode;
    if (!vma || !vma->vm_file)
        return false;
    inode = file_inode(vma->vm_file);
    return inode && sus_map_lookup(inode->i_ino, inode->i_sb->s_dev);
}

static struct mm_struct *sus_map_files_mm(struct inode *inode)
{
    struct task_struct *task = get_proc_task(inode);
    struct mm_struct *mm;
    if (!task)
        return NULL;
    mm = get_task_mm(task);
    put_task_struct(task);
    return mm;
}

static bool sus_map_files_access(struct inode *inode)
{
    struct task_struct *task = get_proc_task(inode);
    bool allowed;
    if (!task)
        return false;
    allowed = map_files_may_access(task, PTRACE_MODE_READ_FSCREDS);
    put_task_struct(task);
    return allowed;
}

/* A cold exact-name lookup has no proc symlink inode yet. Use the parent PID
 * inode, native ptrace gate and native exact range, and make the hide decision
 * under the same mmap lock as instantiation. Calling native lookup after an
 * unlocked precheck would allow a remap to substitute a hidden file. */
static struct dentry *sus_map_files_lookup(struct inode *dir, struct dentry *dentry,
                                          unsigned int flags)
{
    struct task_struct *task;
    struct mm_struct *mm;
    struct vm_area_struct *vma;
    struct dentry *result;
    unsigned long start, end;

    atomic_inc(&n_map_files_lookup);
    if (!sus_map_gate_ok() || !READ_ONCE(nmap)) {
        result = sus_map_files_native_lookup(dir, dentry, flags);
        goto out;
    }
    result = ERR_PTR(-ENOENT);
    task = get_proc_task(dir);
    if (!task)
        goto out;
    result = ERR_PTR(-EACCES);
    if (!map_files_may_access(task, PTRACE_MODE_READ_FSCREDS))
        goto put_task;
    result = ERR_PTR(-ENOENT);
    if (!sus_map_files_range(dentry->d_name.name, dentry->d_name.len, &start, &end))
        goto put_task;
    mm = get_task_mm(task);
    if (!mm)
        goto put_task;
    result = ERR_PTR(-EINTR);
    if (mmap_read_lock_killable(mm))
        goto put_mm;
    result = ERR_PTR(-ENOENT);
    vma = find_exact_vma(mm, start, end);
    if (sus_map_files_hidden_vma(vma)) {
        atomic_inc(&n_map_files_lookup_hides);
    } else if (vma && vma->vm_file) {
        result = map_files_instantiate(dentry, task,
                                      (void *)(unsigned long)vma->vm_file->f_mode);
    }
    mmap_read_unlock(mm);
put_mm:
    mmput(mm);
put_task:
    put_task_struct(task);
out:
    sus_map_files_leave();
    return result;
}

/* Cached lstat/O_PATH resolves through d_revalidate, never get_link. Retain
 * native mm_access/owner/SELinux refresh and all native failure results, then
 * check the live backing file. RCU lookup must return -ECHILD without taking
 * references or locks. Hidden entries return a negative errno, not zero:
 * zero tells VFS to invalidate and retry the lookup instead of rejecting it.
 * Never hold our mmap lock across native revalidation (recursive read locks
 * can deadlock behind a queued writer). */
static int sus_map_files_revalidate(struct dentry *dentry, unsigned int flags)
{
    struct mm_struct *mm;
    unsigned long start, end;
    int rc;

    atomic_inc(&n_map_files_revalidate);
    if (flags & LOOKUP_RCU) {
        atomic_inc(&n_map_files_revalidate_rcu);
        rc = -ECHILD;
        goto out;
    }
    rc = sus_map_files_native_revalidate(dentry, flags);
    if (rc != 1 || !sus_map_gate_ok() || !READ_ONCE(nmap))
        goto out;
    if (!sus_map_files_range(dentry->d_name.name, dentry->d_name.len, &start, &end))
        goto out;
    mm = sus_map_files_mm(d_inode(dentry));
    if (!mm) {
        rc = -ENOENT;
        goto out;
    }
    rc = mmap_read_lock_killable(mm);
    if (!rc) {
        if (sus_map_files_hidden_vma(find_exact_vma(mm, start, end))) {
            atomic_inc(&n_map_files_revalidate_hides);
            rc = -ENOENT;
        } else {
            rc = 1;
        }
        mmap_read_unlock(mm);
    }
    mmput(mm);
out:
    sus_map_files_leave();
    return rc;
}

/* Match and acquire under the SAME mmap lock. A remap cannot change the file
 * between our decision and path_get. Hidden calls acquire no path references. */
static int sus_map_files_path(struct dentry *dentry, struct path *path)
{
    struct mm_struct *mm;
    struct vm_area_struct *vma;
    unsigned long start, end;
    int rc = -ENOENT;

    atomic_inc(&n_getlink_calls);
    if (!sus_map_files_range(dentry->d_name.name, dentry->d_name.len, &start, &end))
        return -EINVAL;
    mm = sus_map_files_mm(d_inode(dentry));
    if (!mm)
        return rc;
    rc = mmap_read_lock_killable(mm);
    if (rc)
        goto out;
    rc = -ENOENT;
    /* Native link lookup requires vm_end; Android readdir may emit a shorter
     * VMA_PAD_START range. Do not turn a native nonresolving padded link into
     * a new readable link. Directory matching uses the padded range below. */
    vma = find_exact_vma(mm, start, end);
    if (sus_map_files_hidden_vma(vma)) {
        atomic_inc(&n_map_files_hides);
    } else if (vma && vma->vm_file) {
        *path = *file_user_path(vma->vm_file);
        path_get(path);
        atomic_inc(&n_map_files_paths);
        atomic_inc(&n_getlink_nomatch);
        rc = 0;
    } else {
        atomic_inc(&n_getlink_skip);
    }
    mmap_read_unlock(mm);
out:
    mmput(mm);
    return rc;
}

static int sus_map_files_readlink(struct dentry *dentry, char __user *buffer, int buflen)
{
    struct path path;
    char *tmp, *pathname;
    int rc;

    atomic_inc(&n_map_files_readlink);
    if (!sus_map_gate_ok() || !READ_ONCE(nmap)) {
        rc = sus_map_files_native_readlink(dentry, buffer, buflen);
        goto out;
    }
    rc = -EACCES;
    if (!sus_map_files_access(d_inode(dentry)))
        goto out;
    rc = sus_map_files_path(dentry, &path);
    if (rc)
        goto out;
    tmp = kmalloc(PATH_MAX, GFP_KERNEL);
    rc = -ENOMEM;
    if (tmp) {
        pathname = d_path(&path, tmp, PATH_MAX);
        rc = PTR_ERR(pathname);
        if (!IS_ERR(pathname)) {
            rc = min_t(int, tmp + PATH_MAX - 1 - pathname, buflen);
            if (copy_to_user(buffer, pathname, rc))
                rc = -EFAULT;
        }
        kfree(tmp);
    }
    path_put(&path);
    atomic_inc(&n_map_files_puts);
out:
    sus_map_files_leave();
    return rc;
}

static const char *sus_map_files_get_link(struct dentry *dentry, struct inode *inode,
                                         struct delayed_call *done)
{
    struct path path;
    const char *result;
    int rc;

    atomic_inc(&n_map_files_follow);
    if (!sus_map_gate_ok() || !READ_ONCE(nmap) || !dentry) {
        result = sus_map_files_native_get_link(dentry, inode, done);
        goto out;
    }
    rc = -EPERM;
    if (!checkpoint_restore_ns_capable(&init_user_ns))
        goto error;
    rc = -EACCES;
    if (!sus_map_files_access(inode))
        goto error;
    rc = sus_map_files_path(dentry, &path);
    if (rc)
        goto error;
    /* nd_jump_link consumes the path on both success and failure. */
    rc = map_files_jump_link(&path);
    atomic_inc(&n_map_files_jumps);
error:
    result = ERR_PTR(rc);
out:
    sus_map_files_leave();
    return result;
}

struct sus_map_files_context {
    struct dir_context ctx;
    struct dir_context *caller;
    struct mm_struct *mm;
    int error;
};

static bool sus_map_files_emit(struct dir_context *ctx, const char *name, int len,
                               loff_t offset, u64 ino, unsigned int type)
{
    struct sus_map_files_context *bridge = container_of(ctx, struct sus_map_files_context, ctx);
    unsigned long start, end;
    bool hidden = false, accepted;
    int rc;

    if (bridge->mm && sus_map_files_range(name, len, &start, &end)) {
        rc = mmap_read_lock_killable(bridge->mm);
        if (rc) {
            bridge->error = rc;
            return false;
        }
        hidden = sus_map_files_hidden_vma(sus_map_files_vma(bridge->mm, start, end));
        mmap_read_unlock(bridge->mm);
    }
    if (hidden) {
        atomic_inc(&n_map_files_entries_hidden);
        /* Native readdir advances the same cookie for this consumed entry. */
        return true;
    }
    /* Never run an actor which can fault user memory while holding mmap_lock. */
    bridge->caller->pos = ctx->pos;
    accepted = bridge->caller->actor(bridge->caller, name, len, offset, ino, type);
    ctx->pos = bridge->caller->pos;
    return accepted;
}

static int sus_map_files_iterate(struct file *file, struct dir_context *ctx)
{
    struct sus_map_files_context bridge = {
        .ctx = {.actor = sus_map_files_emit, .pos = ctx->pos},
        .caller = ctx,
    };
    int rc;

    atomic_inc(&n_map_files_iterate);
    if (!sus_map_gate_ok() || !READ_ONCE(nmap)) {
        rc = sus_map_files_native_iterate(file, ctx);
        goto out;
    }
    bridge.mm = sus_map_files_mm(file_inode(file));
    rc = sus_map_files_native_iterate(file, &bridge.ctx);
    ctx->pos = bridge.ctx.pos;
    if (!rc && bridge.error)
        rc = bridge.error;
    if (bridge.mm)
        mmput(bridge.mm);
out:
    sus_map_files_leave();
    return rc;
}

static_assert(__same_type(typeof(&sus_map_files_iterate), typeof(map_files_original_iterate)));
static_assert(__same_type(typeof(&sus_map_files_readlink), typeof(map_files_original_readlink)));
static_assert(__same_type(typeof(&sus_map_files_get_link), typeof(map_files_original_get_link)));
static_assert(__same_type(typeof(&sus_map_files_lookup), typeof(map_files_original_lookup)));
static_assert(__same_type(typeof(&sus_map_files_revalidate), typeof(map_files_original_revalidate)));
static_assert(__same_type(typeof(&sus_map_files_emit), typeof(((struct dir_context *)0)->actor)));

/* Divert at the original function ENTRY. ARM64 returns from the breakpoint
 * before the typed replacement executes, so sleeping native procfs operations
 * run in the caller's normal context. Count the diversion here, before the
 * first replacement instruction, to cover a preempted entry during teardown. */
static int sus_map_files_pre(struct kprobe *probe, struct pt_regs *regs)
{
    void *replacement;

    if (!READ_ONCE(nmap) || !sus_map_gate_ok())
        return 0;
    if (sus_map_files_bypass(probe)) {
        atomic_inc(&n_map_files_bypassed);
        return 0;
    }
    if (probe == &map_files_probes[0]) {
        replacement = sus_map_files_iterate;
    } else if (probe == &map_files_probes[1]) {
        struct dentry *dentry = (struct dentry *)regs->regs[0];
        /* proc_pid_readlink is shared by fd/cwd/exe links. Only the
         * validated map_files inode-operations table belongs to this layer. */
        if (!dentry || !d_inode(dentry) ||
            READ_ONCE(d_inode(dentry)->i_op) != map_files_native_iops)
            return 0;
        replacement = sus_map_files_readlink;
    } else if (probe == &map_files_probes[2]) {
        if (!regs->regs[0]) /* native RCU lookup returns -ECHILD */
            return 0;
        replacement = sus_map_files_get_link;
    } else if (probe == &map_files_probes[3]) {
        replacement = sus_map_files_lookup;
    } else if (probe == &map_files_probes[4]) {
        replacement = sus_map_files_revalidate;
    } else {
        return 0;
    }
    sus_map_files_enter();
    atomic_inc(&n_map_files_diverted);
    instruction_pointer_set(regs, (unsigned long)replacement);
    return 1;
}

static struct kprobe map_files_probes[5] = {
    {.symbol_name = "proc_map_files_readdir", .pre_handler = sus_map_files_pre},
    {.symbol_name = "proc_pid_readlink", .pre_handler = sus_map_files_pre},
    {.symbol_name = "proc_map_files_get_link", .pre_handler = sus_map_files_pre},
    {.symbol_name = "proc_map_files_lookup", .pre_handler = sus_map_files_pre},
    {.symbol_name = "map_files_d_revalidate", .pre_handler = sus_map_files_pre},
};

static_assert(__same_type(typeof(&sus_map_files_pre),
                         typeof(((struct kprobe *)0)->pre_handler)));

static void sus_map_files_remove(void)
{
    int i;
    WRITE_ONCE(map_files_installed, false);
    for (i = ARRAY_SIZE(map_files_probes) - 1; i >= 0; i--) {
        if (!map_files_probe_armed[i])
            continue;
        unregister_kprobe(&map_files_probes[i]);
        map_files_probe_armed[i] = false;
    }
    /* Unregister drains probe handlers, not diverted sleeping frames. Count
     * those frames from the pre-handler through their final return, and drain
     * the last decrement/return tail before module text may disappear. */
    synchronize_rcu_tasks();
    wait_event(map_files_waitq, atomic_read(&map_files_callbacks) == 0);
    synchronize_rcu_tasks();
}

static int sus_map_files_install(void)
{
    const struct file_operations *fops;
    const struct inode_operations *iops;
    const struct inode_operations *dir_iops;
    const struct dentry_operations *dops;
    unsigned long faddr[2], iaddr[2], diraddr[2], daddr[2];
    void *targets[5];
    int i, rc;

    if (map_files_installed)
        return 0;
    if (ksu_find_symbol_all("proc_map_files_operations", faddr, 2) != 1 ||
        ksu_find_symbol_all("proc_map_files_link_inode_operations", iaddr, 2) != 1 ||
        ksu_find_symbol_all("proc_map_files_inode_operations", diraddr, 2) != 1 ||
        ksu_find_symbol_all("tid_map_files_dentry_operations", daddr, 2) != 1)
        return -ENOENT;
    fops = (const struct file_operations *)faddr[0];
    iops = (const struct inode_operations *)iaddr[0];
    dir_iops = (const struct inode_operations *)diraddr[0];
    dops = (const struct dentry_operations *)daddr[0];
    map_files_original_iterate = READ_ONCE(fops->iterate_shared);
    map_files_original_readlink = READ_ONCE(iops->readlink);
    map_files_original_get_link = READ_ONCE(iops->get_link);
    map_files_original_lookup = READ_ONCE(dir_iops->lookup);
    map_files_original_revalidate = READ_ONCE(dops->d_revalidate);
    map_files_instantiate = (typeof(map_files_instantiate))ksu_resolve_symbol_for_functable_hook("proc_map_files_instantiate");
    map_files_jump_link = (typeof(map_files_jump_link))find_kernel_symbol_exact("nd_jump_link");
    map_files_may_access = (typeof(map_files_may_access))ksu_resolve_symbol_for_functable_hook("ptrace_may_access");
#ifdef VMA_PAD_START
    map_files_pad_pages = (typeof(map_files_pad_pages))ksu_resolve_symbol_for_functable_hook("vma_pad_pages");
    if (!map_files_pad_pages)
        return -EINVAL;
#endif
    if (!map_files_original_iterate || !map_files_original_readlink ||
        !map_files_original_get_link || !map_files_jump_link || !map_files_may_access ||
        !map_files_original_lookup || !map_files_original_revalidate || !map_files_instantiate ||
        (void *)map_files_original_iterate != ksu_resolve_symbol_for_functable_hook("proc_map_files_readdir") ||
        (void *)map_files_original_readlink != ksu_resolve_symbol_for_functable_hook("proc_pid_readlink") ||
        (void *)map_files_original_get_link != ksu_resolve_symbol_for_functable_hook("proc_map_files_get_link") ||
        (void *)map_files_original_lookup != ksu_resolve_symbol_for_functable_hook("proc_map_files_lookup") ||
        (void *)map_files_original_revalidate != ksu_resolve_symbol_for_functable_hook("map_files_d_revalidate"))
        return -EINVAL;
    map_files_native_iops = iops;
    targets[0] = (void *)map_files_original_iterate;
    targets[1] = (void *)map_files_original_readlink;
    targets[2] = (void *)map_files_original_get_link;
    targets[3] = (void *)map_files_original_lookup;
    targets[4] = (void *)map_files_original_revalidate;
    for (i = 0; i < ARRAY_SIZE(map_files_probes); i++) {
        /* No callback-table write is attempted. Fresh flags prevent a retained
         * KPROBE_FLAG_DISABLED from making reinstallation silently inactive. */
        map_files_probes[i].addr = NULL;
        map_files_probes[i].flags = 0;
        WRITE_ONCE(map_files_probe_slot, i);
        rc = register_kprobe(&map_files_probes[i]);
        if (!rc) {
            map_files_probe_armed[i] = true;
            /* Refuse adjusted/non-entry addresses: the wrapper expects the
             * original argument registers and an untouched stack/LR. */
            if ((void *)map_files_probes[i].addr != targets[i])
                rc = -EINVAL;
        }
        WRITE_ONCE(map_files_probe_error, rc);
        if (rc) {
            pr_err("sus_map: map_files probe %d failed %d; no rule published\n", i, rc);
            sus_map_files_remove();
            return rc;
        }
    }
    if (READ_ONCE(fops->iterate_shared) != map_files_original_iterate ||
        READ_ONCE(iops->readlink) != map_files_original_readlink ||
        READ_ONCE(iops->get_link) != map_files_original_get_link ||
        READ_ONCE(dir_iops->lookup) != map_files_original_lookup ||
        READ_ONCE(dops->d_revalidate) != map_files_original_revalidate) {
        WRITE_ONCE(map_files_probe_error, -EAGAIN);
        sus_map_files_remove();
        return -EAGAIN;
    }
    WRITE_ONCE(map_files_installed, true);
    return 0;
}
