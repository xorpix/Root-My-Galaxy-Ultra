// SPDX-License-Identifier: GPL-2.0
/*
 * susfs_uname.c - spoof uname release/version (SUSFS SPOOF_UNAME).  Upstream patches the body of
 * SYSCALL_DEFINE1(newuname) between the memcpy(utsname) and copy_to_user; the LKM equivalent hooks
 * __arm64_sys_newuname with a kretprobe and rewrites the release/version fields of the user buffer just before
 * the syscall returns - the target pages were just faulted in by the original copy_to_user, so the handler's
 * copy_to_user cannot fault, and "default" copies the device's CURRENT utsname()->release/version at runtime.
 * Upstream semantics: OFF by default, enabled by CMD_SUSFS_SET_UNAME alone, kretprobe registered lazily.
 */
#include <linux/module.h>
#include <linux/kprobes.h>
#include <linux/mutex.h>
#include <linux/spinlock.h>
#include <linux/uaccess.h>
#include <linux/utsname.h>
#include <linux/string.h>
#include <linux/version.h>
#include "susfs_abi.h"
#include "susfs_log.h"
#include "susfs.h"	/* susfs_abi_path_ok */

#define SUSFS_UNAME_LEN (__NEW_UTS_LEN + 1)

static char fake_release[SUSFS_UNAME_LEN];
static char fake_version[SUSFS_UNAME_LEN];
static bool uname_spoof_enabled;
static DEFINE_SPINLOCK(uname_state_lock);

/* optional insmod-time override; supercall is the primary interface */
module_param_string(release, fake_release, sizeof(fake_release), 0444);
module_param_string(version, fake_version, sizeof(fake_version), 0444);
module_param(uname_spoof_enabled, bool, 0444);
MODULE_PARM_DESC(release, "fake uname release (insmod override)");
MODULE_PARM_DESC(version, "fake uname version (insmod override)");
MODULE_PARM_DESC(uname_spoof_enabled, "enable uname spoofing (insmod override)");

struct uname_args {
    struct new_utsname __user *name;
};

static int kr_newuname_entry(struct kretprobe_instance *ri, struct pt_regs *regs)
{
    struct uname_args *a = (struct uname_args *)ri->data;
    struct pt_regs *user = (struct pt_regs *)regs->regs[0];

    /* this GKI kernel does NOT auto-adjust syscall-wrapper probe regs:
     * regs->regs[0] is the struct pt_regs* argument, not the user arg */
    if (!user)
        return 1;   /* no return handler: ri->data would be left stale */

    a->name = (struct new_utsname __user *)user->regs[0];
    return 0;
}

static int kr_newuname_ret(struct kretprobe_instance *ri, struct pt_regs *regs)
{
    struct uname_args *a = (struct uname_args *)ri->data;
    char release[SUSFS_UNAME_LEN], version[SUSFS_UNAME_LEN];
    unsigned long flags;
    bool enabled;

    if (regs_return_value(regs) != 0 || !a->name)
        return 0;
    spin_lock_irqsave(&uname_state_lock, flags);
    enabled = uname_spoof_enabled;
    memcpy(release, fake_release, sizeof(release));
    memcpy(version, fake_version, sizeof(version));
    spin_unlock_irqrestore(&uname_state_lock, flags);
    if (!enabled)
        return 0;
    /* Return probes cannot sleep. Make fault suppression explicit for the
     * user copies, outside the state lock, including either early failure. */
    pagefault_disable();
    if (copy_to_user((char __user *)a->name + offsetof(struct new_utsname, release),
                     release, SUSFS_UNAME_LEN))
        goto out;
    if (copy_to_user((char __user *)a->name + offsetof(struct new_utsname, version),
                     version, SUSFS_UNAME_LEN))
        goto out;
out:
    pagefault_enable();
    return 0;
}

static struct kretprobe krp = {
    .kp.symbol_name = "__arm64_sys_newuname",
    .entry_handler = kr_newuname_entry,
    .handler = kr_newuname_ret,
    .data_size = sizeof(struct uname_args),
    .maxactive = 32,
};

static bool uname_registered;
static DEFINE_MUTEX(uname_ctl_lock);
static bool uname_exiting;

/* Caller serializes registration, publication and exit with uname_ctl_lock. */
static int uname_register_locked(void)
{
    int rc;

    if (uname_exiting)
        return -ENODEV;
    if (uname_registered)
        return 0;
    krp.kp.addr = NULL;
    krp.kp.flags = 0;
    rc = register_kretprobe(&krp);
    if (!rc)
        uname_registered = true;
    return rc;
}

static void uname_unregister(void)
{
    unsigned long flags;

    mutex_lock(&uname_ctl_lock);
    uname_exiting = true;
    spin_lock_irqsave(&uname_state_lock, flags);
    uname_spoof_enabled = false;
    spin_unlock_irqrestore(&uname_state_lock, flags);
    if (uname_registered) {
        unregister_kretprobe(&krp);
        uname_registered = false;
    }
    mutex_unlock(&uname_ctl_lock);
}

/* Parameter strings and shorter replacement values leave bytes after their
 * terminator untouched. Clear that tail before copying out the whole field.
 * Keep the existing string APIs so this port needs no strscpy_pad import. */
static void uname_pad(char *value, size_t size)
{
    size_t len = strnlen(value, size);

    if (len < size)
        memset(value + len, 0, size - len);
}

int susfs_uname_init(void)
{
    bool requested = uname_spoof_enabled && fake_release[0] && fake_version[0];
    unsigned long flags;
    int rc = 0;

    uname_spoof_enabled = false;
    uname_pad(fake_release, sizeof(fake_release));
    uname_pad(fake_version, sizeof(fake_version));
    mutex_lock(&uname_ctl_lock);
    if (requested)
        rc = uname_register_locked();
    spin_lock_irqsave(&uname_state_lock, flags);
    uname_spoof_enabled = requested && !rc;
    spin_unlock_irqrestore(&uname_state_lock, flags);
    mutex_unlock(&uname_ctl_lock);
    return rc;
}

void susfs_uname_exit(void)
{
    uname_unregister();
}

/* supercall: CMD_SUSFS_SET_UNAME */
void susfs_uname_supercall(void __user **arg)
{
    struct st_susfs_uname info = {0};
    char release[SUSFS_UNAME_LEN] = {0}, version[SUSFS_UNAME_LEN] = {0};
    unsigned long flags;
    int rc;

    if (copy_from_user(&info, (void __user *)*arg, sizeof(info))) {
        info.err = -EFAULT;
        goto out;
    }
    if (*info.release == '\0' || *info.version == '\0') {
        /* -EINVAL: the buffer came across fine, the VALUE is what is wrong. */
        info.err = -EINVAL;
        goto out;
    }
    /* char[65] ABI fields the caller need not terminate; strcmp() and strscpy() below would run past the end. */
    if (!susfs_abi_path_ok(info.release, sizeof(info.release)) ||
        !susfs_abi_path_ok(info.version, sizeof(info.version))) {
        info.err = -ENAMETOOLONG;
        goto out;
    }

    /* Build a fully initialized pair before publishing anything. */
    strscpy(release, !strcmp(info.release, "default") ? utsname()->release : info.release,
             sizeof(release));
    strscpy(version, !strcmp(info.version, "default") ? utsname()->version : info.version,
             sizeof(version));
    uname_pad(release, sizeof(release));
    uname_pad(version, sizeof(version));
    mutex_lock(&uname_ctl_lock);
    rc = uname_register_locked();
    if (!rc) {
        spin_lock_irqsave(&uname_state_lock, flags);
        memcpy(fake_release, release, sizeof(fake_release));
        memcpy(fake_version, version, sizeof(fake_version));
        uname_spoof_enabled = true;
        spin_unlock_irqrestore(&uname_state_lock, flags);
    }
    mutex_unlock(&uname_ctl_lock);
    info.err = rc;
out:
    /* upstream writes back only ->err for input-type commands */
    if (copy_to_user(&((struct st_susfs_uname __user *)*arg)->err,
                     &info.err, sizeof(info.err)))
        pr_warn("uname supercall copy_to_user failed\n");
}
