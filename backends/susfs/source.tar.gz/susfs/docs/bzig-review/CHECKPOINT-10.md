# RMGU BZIG checkpoint 10: mount identity and repeat activation

Target: SM-S948B, S948BXXS4BZIG, kernel
`6.12.69-android16-6-pb4d3caf-abogkiS948BXXS4BZIG-4k`.
This follows checkpoint 9's successful metadata, redirect and path hardware
tests. The new module still needs phone validation.

## Two defects found through the mount runner

The first active mount run hid the selected bind from all three app tables, but
fdinfo returned `12688`, absent from the app's mountinfo. The next run confirmed
that `12688` is the bind's `/data` parent and the ordinary source file's mount;
all baseline observers shared namespace `mnt:[4026536673]`. That run then failed
the enable command with reply `-22` and `show_probes=0/3`.

1. `sus_mount_ident_match()` accepted an exact (or truncated) source-name match
   without requiring the recorded device/root inode. A bind and its parent both
   use `/dev/block/dm-81`, so one recorded bind incorrectly hid the parent and
   unrelated mounts backed by that device. The identity fallback now requires
   both device and mount-root inode. Source-prefix configuration still selects
   mounts through the existing prefix matcher; source names are diagnostic only
   in the identity record.
2. Linux resolves a named probe into its address and retains that address after
   successful unregister. Re-registering both `symbol_name` and `addr` fails
   with `-EINVAL`. The mount registration path now clears the address before
   registering each named table, statx, superblock, clone and new-mount probe.
   Explicitly addressed fdinfo probes retain their separate lifecycle.

Thirteen production-C host regressions pass normally and with ASan/UBSan.
Eleven fail against the checkpoint-9 source, including the shared-device parent
case and second enable. The repeat-enable regression runs sixteen activation
and teardown cycles and verifies all expected probes each time.

## Phone validation

Use the separate `RMGU · SusFS Test 10` app. Reboot before loading it to clear
the checkpoint-9 module and its retained records. Regain root normally, grant
this app root, and activate SusFS. Mount hiding should start disabled.

Run the unchanged revision-3 `rmgu-susfs-mount-test.sh` from ordinary Termux:

```sh
cd ~
su -c 'cat /sdcard/Download/rmgu-susfs-mount-test.sh' | sh
```

Repeat the same command on the same boot. Both runs must pass all three tables,
root exclusion, ordinary file access, fdinfo/statx mount-ID agreement and row
membership, restoration, and cleanup. The second run verifies repeat enable.
Keep the complete output if either fails. Host tests and cross-compilation do
not establish that these hardware assertions pass.

The metadata/redirect and path runners remain regression checks after the mount
test. SUS_MAP and broader device/namespace coverage remain separate work.
