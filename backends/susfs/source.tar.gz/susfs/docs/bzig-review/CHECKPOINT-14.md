# Checkpoint 14: maps seq callback

One CP13 phone run completed restoration and cleanup without a reported panic.
It failed the target's active maps row assertion: maps=1, expected zero. The
same target disappeared from smaps, its 4096 KiB RSS was excluded from rollup
within tolerance (4036 KiB decrease), map-files readlink returned ENOENT,
pagemap returned no bytes/metadata, proc-memory returned EIO, and
process_vm_readv returned EFAULT. Root and the control retained normal access.
After removing the rule all measured target interfaces recovered, rules=0,
and cleanup completed. This is a partial phone result, not a SUS_MAP PASS or
long-run stability certification. The GUP/pin counters show actual activity.

The maps probe targeted show_map_vma, a void formatter. The Android 16 / 6.12
source's proc_pid_maps_op.show is show_map(m, vma), which calls that formatter
and handles compatibility padding. LTO may inline the formatter into this
callback while retaining a standalone symbol for other users. Registration
of its probe does not prove maps reaches it. CP13 has no listing hit counters,
so inlining remains a source-supported explanation, not a measured phone
compiler decision.

CP14 requires a probe on show_map itself, using the same VMA argument and app
gate, and skips that entire row by returning zero before emission. show_smap
and the CP13 negative remote-page return remain intact. Read-only map_stat
now reports maps_calls/maps_hides and smaps_calls/smaps_hides; call counters
include root invocations, while hide counters require the ordinary-app rule.
The actual maps callback must register before a new rule can be published.

The host harness models the real show_map seq dispatch with show_map_vma
inlined. Production probe declarations decide whether interception occurs.
The old CP13 source fails this case; the corrected source passes all 26 cases
normally and with ASan/UBSan, including root/control exclusion and restoration.
Host tests cannot establish Samsung symbol availability or actual reachability.

Phone runner revision 3 retains the strict maps assertion and flushed markers,
and checks for CP14's listing counters before adding any rule. It uses a
distinct cp14 filename. Install Test 14, fully reboot, regain root, grant and
activate SusFS from Test 14, then run the revised runner once from ordinary
Termux. If it reaches PASS, run again on the same boot. Retain both outputs.
Broader namespace, compat, cross-VMA and map-files lifetime work remain open.
