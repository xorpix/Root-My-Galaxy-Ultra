# BZIG source and build checkpoint 6

Target under review: Samsung SM-S948B / m3q, S948BXXS4BZIG,
`6.12.69-android16-6-pb4d3caf-abogkiS948BXXS4BZIG-4k`.

SUSFS base: `inforcqb/susfs4ksu-lkm` dev3,
`c2a5575e0a230db992ad94e2924bc38333797336`.
App observed: `xorpix/Root-My-Galaxy-Ultra`,
`5287e5bb112ef33143ba23457c05255e5498cf27` (UAPI 5 update).

This is a source/build checkpoint for the separate SUSFS project. It supplies
no app activation, boot script, or approved phone module. App sources, the
working backend bundles and both exploits are unchanged.

## Changes

- Carry checkpoint 5's deferred-request ownership and dispatcher ordering onto
  dev3. Initialization still requires Tasks RCU before any hook is installed.
- Give `ksu_symbol_name_of()` the same local `__nocfi` wrapper annotation as the
  existing runtime-resolved symbol callers. Upstream dev3 explicitly records
  this omission on its 6.12/6.18 path. This narrows a known instrumentation gap;
  it is not evidence that Samsung actually raised a CFI fault here. The kernel's
  global CFI setting and LSM callback type metadata remain enabled.
- Check callback types against the prepared kernel's actual LSM member
  declarations in both initializer macros. Remove the early `void *` casts at
  the 13 call sites so a wrong signature cannot silently pass this check.
- Replace LSM cleanup's runtime lookup and 50 ms fallback with direct
  `synchronize_rcu()` and `synchronize_rcu_tasks()` calls. The dispatcher already
  requires the latter API, so failing to resolve it must not degrade to a delay.
- Correct the comment describing kstat/path teardown order. The shared sys-exit
  tracepoint is removed before the path layer frees its buffer; no ordering
  code was changed for this clarification.
- Add reproducible host build, callback rejection and artifact inspection tools.
  Preserve upstream's CRLF source and declare its whitespace policy explicitly.

## Completed checks

| Check | Result |
| --- | --- |
| ARM64 build | Upstream dev3 and patched source compile against Android 16 / 6.12 DDK, kernel baseline 6.12.76-4k |
| Deferred-request lifecycle | 13 host cases pass normally and with ASan/UBSan; 200 admission/removal races per run |
| Callback signature guard | 10 real-header compiler cases pass: correct callbacks compile; wrong return, argument, constness and erased types are rejected |
| Emitted wrapper code | The reviewed local indirect-call CFI check is removed only at the annotated wrapper; the lookup call remains |
| Incoming LSM callback metadata | All 13 local kCFI type words match the unmodified dev3 build |
| BZIG BTF/DWARF comparison | 21 previously selected type sizes and shared named top-level field locations match; all 13 hook declarations and compiled offsets match |
| New lifetime types | `callback_head`, `pt_regs`, and both recorded BTF definitions of `module` match the candidate's sizes and named top-level offsets |
| ReSukiSU status protocol | Nine constants and three status structure size/error offsets agree with source at `8770c7e324a22895703c4916b8a16520e0b81c79` |

The candidate has one additional named `task_struct.__kabi_reserved1` member;
equal sizes and shared member offsets do not establish identical type graphs.
The two phone `module` BTF definitions were both checked rather than choosing
one arbitrarily. `module.state` is at byte zero in each and in the candidate.

The DDK image is `ghcr.io/ylarod/ddk-min:android16-6.12-20260828`; the checkpoint
records the image manifest and verified layer hashes. It uses Clang r536225.
This host lacks `pahole`, so module BTF generation was explicitly omitted with
`CONFIG_DEBUG_INFO_BTF_MODULES=`. DWARF and CFI remain enabled. This build is not
a byte-for-byte reproduction of the upstream release binary.

`__versions` is still empty. The module's imports include the lifetime APIs, but
recorded BTF names and declarations do not establish runtime resolvability,
export policy or symbol-version compatibility on Samsung.

## Remaining blockers

1. **Sleeping LSM callbacks.** Tasks RCU is not a join operation for callbacks
   which voluntarily sleep inside the original SELinux handler. The LSM layer
   still needs a lifetime protocol covering the full callback body and its
   return window. The deferred-request fix does not cover these separate calls.
2. **Failed restoration.** LSM unregister functions return `void`; some error
   paths leave the hook tracked, while outer teardown can continue freeing
   feature state. Module exit cannot simply return an error to veto removal.
   Restoration must be verified within an ownership/removal design that cannot
   release live code or data when restoration is incomplete.
3. **Exact Samsung compatibility.** The build baseline is 6.12.76, while BZIG
   reports 6.12.69 with vendor changes. The supplied configuration enables RKP,
   KDP, DEFEX and enforced CFI. Selected layouts do not validate protected-memory
   writes, all runtime calls, module policy or every private interface.
4. **Runtime integration.** Matching three daemon status structures does not prove
   all feature commands, coexistence with the active driver, health reporting,
   or recovery. The app must not advertise an active SUSFS feature from these
   host results.

The next implementation milestone is the remaining LSM ownership/restoration
contract, followed by matching build evidence and controlled hardware tests.
Assessment remains `ReviewRequired`. No phone module was loaded or unloaded;
no APK was built. No claim of Knox preservation or boot safety is made.

## Reproduce on a Linux build host

With the pinned DDK already prepared (paths may differ):

```sh
python3 tools/build_review.py \
  --kdir /opt/ddk/kdir/android16-6.12 \
  --clang-bin /opt/ddk/clang/clang-r536225/bin \
  --rust-bin /opt/ddk/rust/rust-1.82.0/bin \
  --evidence-dir ../build-evidence --omit-module-btf
python3 tests/build/check_hook_types.py \
  --kdir /opt/ddk/kdir/android16-6.12 \
  --clang-bin /opt/ddk/clang/clang-r536225/bin
python3 tests/lifecycle/run.py
python3 tests/lifecycle/run.py --sanitizers
```

Omit `--omit-module-btf` on a host with the required `pahole`. For artifact
comparison, build clean dev3 separately using the same flags, then run
`tools/review_artifact.py --baseline <original.ko> --candidate <patched.ko>
--objdump <llvm-objdump> --json <report.json>`. It requires pyelftools 0.32.
These commands run on the build host; none is a phone installation step.

## Primary references

- [Pinned dev3 source](https://github.com/inforcqb/susfs4ksu-lkm/tree/c2a5575e0a230db992ad94e2924bc38333797336)
- [Dev3 release and known CFI issue](https://github.com/inforcqb/susfs4ksu-lkm/releases/tag/v2.3.0-r18-dev3)
- [ReSukiSU status definitions](https://github.com/ReSukiSU/ReSukiSU/tree/8770c7e324a22895703c4916b8a16520e0b81c79/userspace/ksud/src/android/susfs/api)
- [Tasks RCU requirements](https://docs.kernel.org/RCU/Design/Requirements/Requirements.html#tasks-rcu)

The generic DDK/API references are not a substitute for matching Samsung source.
