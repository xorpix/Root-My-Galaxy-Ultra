# CP15 reconstruction and CP14 module qualification

The interrupted build workspace was reset before CP15 was saved. The CP15
source changes, new kernel binary, APK and build logs were unavailable. This
recovery branch starts from the durable, phone-validated CP14 source commit
`9fe622dec9d4208071d7509558e49ca3ead73dfd`; it adds a module/symbol qualification
runner and its host checks. CP15 kernel changes have now been reconstructed,
with production-body host tests and a guarded phone runner. See
`CP15-IMPLEMENTATION.md` for the current source state and build commands.
No reconstructed CP15 kernel binary or APK has been built or phone-tested.

The recovered CP14 ZIP has SHA-256
`4e2ad801711490716531ab0aad0652ab8f5fd91fa0f99570cb97353fa1fd69f1`.
The latest hardware record was recovered independently, including both CP14
map passes and the subsequent feature, path and mount passes. Module/symbol
filtering remains unqualified by those earlier diagnostic counters.

## Module runner revision 1 phone result

On 8 October 2026 the user ran revision 1 from ordinary Termux UID `10362`,
context `u:r:untrusted_app_27:s0:c106,c257,c512,c768`. With the name list
briefly cleared, the first app `/proc/modules` read failed with EACCES
(`errno=13`). The root comparison and active assertions were never reached.
Cleanup verified restoration of `kernelsu susfs_guard_lkm` in the original
order. This is a blocked baseline, not a filtering qualification or evidence
of a module-hiding regression. The cause cannot be attributed to SELinux or
DAC from errno alone.

The earlier feature shell runner scans `/proc/modules` and `/proc/kallsyms`
using `su -c`. Its diagnostic counters did not establish ordinary app access.

## Revision 2 phone portability failure

At 06:45 Europe/Oslo on 8 October 2026, the user reported that revision 2
stopped during optional app permission diagnostics with
`module 'os' has no attribute 'getxattr'`. This Termux Python build omits the
API. The failure occurred before the root preflight and before any module-list
write. No filtering result was obtained by this run.

Revision 3 treats label retrieval as optional, records unavailable APIs, and
prevents ordinary diagnostic exceptions from discarding completed visibility
reads. Required observations, baseline assertions and cleanup remain strict.
The new full-flow host fixture executes the actual app observer and generated
root Python with an OS API lacking getxattr. It reproduces revision 2's exact
failure and completes revision 3's baseline/active/restoration cycle. Additional
coverage confirms diagnostic failures remain nonfatal while core table errors
still fail. These are host simulations; the subsequent phone result is recorded
below separately.

## Revision 3 phone result: scoped partial pass

On 8 October 2026 the user supplied a completed revision-3 run from ordinary
Termux UID `10362`, PID `24526`, context
`u:r:untrusted_app_27:s0:c106,c257,c512,c768`. Root baseline/active PIDs were
`24829` / `24939`, with context `u:r:ksu:s0`. The run used and restored the
exact names `kernelsu susfs_guard_lkm`. Attribution follows the ongoing CP14
test sequence; no independent live module hash or boot identifier was supplied.

| Observation | Cleared-name baseline | Original names active |
| --- | ---: | ---: |
| Root kernelsu module rows | 1 | 0 |
| Root kernelsu module-tagged kallsyms rows | 2010 | 0 |
| Root susfs_guard_lkm module rows | 1 | 0 |
| Root susfs_guard_lkm module-tagged kallsyms rows | 1840 | 0 |
| App susfs_guard_lkm stat | Accessible directory | ENOENT (2) |
| Root susfs_guard_lkm stat and enumeration | Accessible and listed | Accessible and listed |

App `/proc/modules`, `/proc/kallsyms` and `/sys/module` enumeration returned
EACCES (13) in preflight, baseline and active phases. Their counts are `null`,
not hidden zeroes, and these scopes remain unqualified. Root could read all
three interfaces. Root saw proc modes 0444 and sysfs mode 0755, and SELinux
enforcement was 1; these observations do not determine the exact access-denial
cause. Python's missing getxattr was reported without aborting the test.

App stat is an independent positive-baseline observation: the guard directory
was accessible with the names cleared and returned ENOENT with the original
names restored. The runner conservatively couples app sysfs stat qualification
to readable directory enumeration, so its final summary does not separately
assert this stat-only effect. No app directory-entry hiding is established.
`/sys/module/kernelsu` was already absent to root and is unmeasured.

Unrelated `6lowpan` retained its root module row and root/app stat access;
root could enumerate its directory. Core symbol `init_task` retained one row.
The diagnostics reported `rules=1 (failed=6)`, 6 removed module lines and 11550
removed kallsyms lines. The historical failed counter does not establish a
hook failure in this run, nor justify treating every possible error as absent.

Cleanup verified exact list restoration. The runner ended with `PARTIAL PASS`
for root tables, root sysfs management, controls and restoration. No freeze,
panic, reboot or Python exception was reported. This is one scoped run, not
repeat-cycle, long-run or full-release qualification. The runner is unchanged;
another portability revision or identical phone rerun is not needed to accept
this result. CP15 reconstruction is the next implementation stage.

## Runner behavior

The completed phone run used the ordinary Termux command:

```sh
su -c 'cat /sdcard/Download/rmgu-susfs-module-test-cp14.py' | python -u
```

Revision 3 first checks app and root access without changing rules and prints
permission diagnostics for denied app interfaces. It then briefly clears only
the module-name list to obtain real baseline
rows, then restores the exact list before active checks and on exit. It does
not clear the independent symbol-prefix filter or alter map, mount, boot or
AVC settings. It checks existing configured names rather than adding names.

| Interface | Active app result | Active root result |
| --- | --- | --- |
| `/proc/modules` | Configured names omitted if baseline is readable; otherwise blocked | Configured names omitted |
| `/proc/kallsyms` | Configured module tags omitted if baseline is readable; otherwise blocked | Configured module tags omitted |
| Existing `/sys/module/<name>` | Stat returns ENOENT and directory entry omitted where baseline permits both reads | Directory remains accessible and listed |
| Unrelated module/sysfs/core symbol | Preserved for each readable interface | Visible |

Root must have a loaded baseline target, positive target module-symbol rows,
an existing target sysfs directory, and unrelated controls. Every readable app
interface keeps its strict baseline and active assertions. Only EACCES/EPERM
permit an app scope to be recorded as blocked. Such data is printed as `null`,
never as zero hidden rows. A denied or newly readable interface after a
readable/blocked baseline respectively is an access-change failure. Malformed
tables and other I/O errors fail instead of being skipped.

Successful accessible checks with a blocked app scope produce `PARTIAL PASS`,
listing the measured scopes and leaving blocked scopes unqualified. Sysfs
paths absent even to root are reported as unmeasured. Permission denial never
satisfies an ENOENT assertion for a baseline-readable target. Neither policy
nor file modes are changed. The historical `failed` counter remains diagnostic.

Thirty-three host tests pass for parsers, exact module matching, nonvacuous
assertions, leaked-table and missing-control negative cases, permission
blocks and access changes, and restoration after failed/partial writes and
interrupts. The main-flow fixtures verify that a failed root preflight writes
nothing, app denial produces only a scoped partial pass, and a baseline
permission change restores the original list. Standalone and generated
root-reader Python syntax passes. These host checks precede the separately
recorded phone partial pass. The CP14 kernel and APK have not been rebuilt.

## CP15 reconstruction status

The prior turn reported a CP15 map-files implementation that replaces the
leaking return probe with typed native iterate/readlink/get_link ops, checks
hidden ranges before native path references are acquired, preserves directory
cookies, and restores dispatch slots before draining sleeping callbacks. It
also reported serialized module-list management, separate missing/error sysfs
diagnostics, and an explicit rescan. These changes are now reconstructed in
this branch, with host verification. Real prepared-header compilation,
compiler-output review, APK packaging and phone qualification remain pending.

The retained CP14 source confirms the map-files gap: `kernel/sus_map.c`
contains no range-directory filtering and changes a successful
`map_files_get_link` return to ENOENT after obtaining its output path, without
releasing that path in the return handler. Enumeration and native path-reference
ownership are corrected together in `kernel/sus_map_files.h`. Callback types
are derived from the real kernel operation fields, but actual header/KCFI
compilation remains blocked by the reset build environment. Host stubs do not
replace that check or certify vendor kernel layouts.

Previously reported, now unavailable commit identities:

- SusFS: `13ea2bda92fd281a05182d934a0fc32b9eb5d65b`.
- App: `b068b839ad60fcec5d83f07cd047197ed83643ec`.

Those identities are recovery notes; this branch is not either commit.
Prior host-build success does not certify a reconstructed source tree.

The matching DDK/compiler and Android SDK/cache were also reset. The current
runtime has a host GCC and Java 17, but no prepared Android kernel tree, Android
Clang, Rust toolchain, SDK or Gradle cache. Direct Android source downloads time
out, and the inspected DDK workflow exposes no downloadable build artifact.

The CP14 build evidence pins Android Clang r536225 (19.0.1), prepared Android
16 / 6.12 headers, kernel release header `6.12.76-4k`, autoconf SHA-256
`1fbc9de7fd352a6a44f0a67296bad10464b956bf59144382f404ac17d7e2fde2`,
and Module.symvers SHA-256
`7d6930b74c649e4e2ceda3ef24e74774458844c34a41d29e042ccf916b509f96`.
These prepared headers are not a claim that Samsung's exact kernel layout or
export policy matches. Live loading and behavior remain separate phone checks.

The durable app integration bundle ends at CP14
`c22d5a868436bd369c4d744cffe6bbf548acfa52` and requires base
`5c7e483fcc60169a691e37a6dea602d132e5895c` from the app source history.
The new recovery package includes this unchanged bundle for resuming work.
