# Checkpoint 16: rejected callback-write rollback and bounded root commands

CP15's phone runner completed app/root baselines, including map_files listdir
and 128-byte getdents64 resumption, then stopped after its ENABLE marker while
the phone remained responsive. That marker precedes three root operations:
the rule write, rule verification and native-installation diagnostics. The
provided output alone does not identify which operation blocked. A read-only
collector captures matching writer/readers and their kernel stack without
reading the SusFS controls, which share a module parameter mutex.

Source review found a reproducible rollback defect. CP15 marks a slot as
possibly installed before writing it, correctly accounting for a partial
write. If protected memory rejects the write without changing the slot, its
rollback nevertheless retries the same forbidden write indefinitely. New
production-body cases model permanent rejection on both the first and second
slots. Both detect the defect with unmodified CP15 source.

CP16 reads each attempted slot before restoration. An observed original
callback requires no further write. A genuinely changed or unreadable slot
retains the existing restoration retry and callback-drain policy; live module
callback text is never freed on an unconfirmed restoration. Previously
installed slots are restored when a later slot is rejected. Failed publication
reports the patch slot/error and does not add the target rule. Native filtering
and access checks remain the same.

The Python runner's subprocess.run uses a context manager that waits for its
direct su child after timeout. Killing a child stuck in an uninterruptible
kernel operation or running under changed credentials may not reap it, leaving
that wait unbounded. A Linux negative control shows that a normally killable
direct child DOES return at timeout even if a grandchild retains stdout; an
inherited pipe is not claimed as the cause. CP16 captures stdout/stderr in
regular temporary files and bounds the direct child's wait and kill/reap attempt.
A timeout is treated
as an unknown management outcome. It avoids further rule queries/writes and
retains the fixture until a full reboot. A real subprocess test leaves a
grandchild alive with inherited stdout and verifies that the new timeout
returns promptly. Another case models a denied kill while a real child remains
alive and verifies the bounded reap wait. A separate test checks that cleanup makes no extra
root calls and preserves the fixture.

Runner revision 5 checks the new rollback marker before creating a fixture or
changing rules and distinguishes WRITE ADD, write return and rule verification.
It requires CP16 rather than allowing the stalled CP15 module to be reused.

The confirmed host defect and the phone stall are distinct evidence. The phone
stack is pending, so neither protected-memory rejection nor this rollback loop
is claimed as the proven cause of that particular stall. CP16 hardware loading
and hiding remain untested until the user supplies the next phone result.
