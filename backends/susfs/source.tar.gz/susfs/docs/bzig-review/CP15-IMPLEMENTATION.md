# CP15 reconstructed source, 8 October 2026

The source implements map_files directory filtering, reference-safe native
link callbacks, and serialized module-name management. CP14 remains the last
phone-tested APK. The pinned Android build environment has now been restored,
the CP15 module compiles, and real-header and emitted KCFI checks pass. APK
packaging is recorded separately; no CP15 phone result is claimed.

## Map_files callbacks

CP14's return probe changed a successful map_files_get_link result into ENOENT
after native code had acquired the output path. Its caller therefore skipped
the native path_put. CP15 replaces that probe with typed iterate_shared,
readlink and get_link slots in the native procfs operation tables. The real
fs/proc/internal.h supplies proc_inode access; no proc_inode mirror is used.

Hidden readlink and magic-link lookups check the exact VMA and inode/device
rule under mmap_lock before path_get. Visible readlink paths are released on
success, allocation failure, d_path failure and user-copy failure. Magic-link
paths transfer ownership to native nd_jump_link, which consumes them on success
and error. Native capability and ptrace access checks remain in force. The
private ptrace_may_access helper is resolved through a fully typed pointer;
its absence rejects installation instead of skipping permission checks.

Directory filtering bridges the native iterator. Consumed hidden entries keep
native cookies; visible entries retain inode, type and offset. The bridge
releases mmap_lock before invoking the caller's actor, which may fault user
memory. Android's VMA_PAD_START directory names are matched separately from
the native link lookup's strict vm_end requirement. The private Android
vma_pad_pages helper is resolved through its header-derived type, preserving
the native page-size migration gate. Missing helpers reject installation.

Installation checks unique operation tables and their original callback
targets. Partial writes are restored. Teardown restores dispatch slots first,
waits for sleeping callback frames, then uses a second Tasks RCU grace period
to cover the return tail. Failed restoration is retried before callback text
can be freed. Map rules are not published if this native layer is unavailable.

Directory identity matching follows the live VMA after native enumeration has
collected a name. Concurrent exec/unmap/remap of another process can race with
that native snapshot and remains an unqualified stress scope. Direct lookup
or stat of a known range name is not newly filtered by this patch. The phone
runner measures directory listings and link reads of stable self mappings.

## Module-name controller

Proc and parameter writes now share one configuration mutex across snapshot,
commit and sleeping sysfs reconciliation. Probe name lookups retain the short
spinlock. Diagnostic reads, initialization and teardown use the same mutex.
The rescan command preserves the exact list while retrying path registration
after a late module load. The cumulative failed counter is retained; absent
counts ENOENT registration results and errors counts other failures. Sysfs path
buffers now fit every accepted MODULE_NAME_LEN name without truncation.

CP14's module phone result remains a scoped partial pass: root table filtering
and management passed, while ordinary app tables and sysfs enumeration were
blocked by EACCES. These source changes do not qualify those blocked scopes.

## Verification

| Check | Result | Scope |
| --- | ---: | --- |
| Native map_files production-body cases | 25 passed | Instrumented kernel stubs |
| Deliberate map_files reference leak, double-release, entry leak and wrong type | 4 detected | Host negative controls |
| Native map_files with ASan/UBSan | 25 passed | Host memory/undefined-behavior checks |
| Module controller cases / missing serialization negative control | 7 / 1 passed | Actual production controller with stubs |
| Existing map rule/GUP/pin/listing cases | 27 passed | Host production bodies |
| CP15 runner observer/assertions | 7 passed | Linux observer plus assertion fixtures |
| Existing module runner | 33 passed | Host scenarios |
| Mount / feature / lifecycle / LSM lifetime | 15 / 13 / 13 / 5 passed | Existing host regressions |
| Real-header LSM / map_files positive and negative types | 10 / 12 passed | Pinned Android DDK |
| CP15 emitted artifact checks | 8 passed | ARM64 KCFI fixture, import and lifetime review |
| App JVM tests / SusFS status tests | 819 / 9 passed | Restored CP14 app base |

LeakSanitizer's proc task scan is blocked by this executor; it was disabled.
Each native callback case separately checks balanced path, mm, task and heap
ownership. The executor also denies self process_vm_readv; its real errno is
retained in evidence and positive phone-baseline assertion fixtures are labeled
as modeled. Directory observations use actual Linux listdir and 128-byte
getdents64 calls. Host success alone does not qualify Android or device behavior;
the real-header and KCFI results above are separate compiler-output evidence.

The phone runner is revision 4. It rejects CP14 before creating a fixture or
adding a rule, verifies native installation after rule publication, and checks
target omission and control/root retention through both directory readers.
The same mapping survives baseline, active and restored phases. Existing
rules are never cleared. It is ready for a built CP15, not for the CP14 APK.

## Build continuation

The workspace reset removed the toolchain. The original image route was
recovered as ghcr.io/ylarod/ddk-min:android16-6.12-20260828. Its manifest and
three original Clang, Rust and kernel layer SHA-256 digests were checked before
extracting /opt/ddk. The restored autoconf.h and Module.symvers hashes match
CP14 exactly. Android Clang r536225 / 19.0.1, Rust 1.82.0, real private proc
headers, SDK 37.0, NDK r28c and CMake 3.22.1 are available. No source was
published externally.

The pinned build entry point checks the CP14 autoconf and Module.symvers hashes
and Android Clang version before running real-header callback positive and
negative type checks and compiling the whole module:

```sh
python3 tools/rebuild_cp15.py \
  --kdir /opt/ddk/kdir/android16-6.12 \
  --clang-bin /opt/ddk/clang/clang-r536225/bin \
  --evidence-dir /build/cp15-evidence
```

Pass --rust-bin /opt/ddk/rust/rust-1.82.0/bin when Rust is outside PATH.
The whole module compiled after resolving the private padding helper and
using an int precision for MODULE_NAME_LEN formatting. All four incoming
map_files KCFI words match address-taken fixtures built from real headers;
each new callback retains outgoing KCFI checks. Existing path callback words
are unchanged, all 17 added imports occur in the pinned DDK export list, and
private helpers are resolved instead of imported.

Both the retained CP14 module and CP15 have empty version/CRC sections despite
the DDK's MODVERSIONS configuration. This is recorded explicitly, not treated
as an import-CRC pass. Exact Samsung symbol CRCs, live callback hashes,
protected-memory writes and CP15 device behavior remain unqualified. The
APK uses the recovered CP14 integration with a separate CP15 identity and
must be tested after a fresh full reboot.

## Primary source reference

Native semantics were checked against aosp-mirror/kernel_common's
android16-6.12 fs/proc/base.c (blob 26abf573e6150968471135a2e998422fc849e5d2),
include/linux/mm.h (blob ab0cabb957014412ef4c0b04e70e212f875d4ac3),
fs/namei.c and kernel/ptrace.c. The branch can change; these references are
Android common behavior, not Samsung vendor layout certification.

- https://github.com/aosp-mirror/kernel_common/blob/android16-6.12/fs/proc/base.c
- https://github.com/aosp-mirror/kernel_common/blob/android16-6.12/fs/namei.c
- https://github.com/aosp-mirror/kernel_common/blob/android16-6.12/kernel/ptrace.c
