# RMGU BZIG checkpoint 12: reversible SUS_MAP rules and phone runner

Target: SM-S948B, S948BXXS4BZIG, kernel
`6.12.69-android16-6-pb4d3caf-abogkiS948BXXS4BZIG-4k`.
Checkpoint 12 requires phone validation.

Checkpoint 11 passed two consecutive revision-3 mount runs. Identity hits rose
from 8 to 16 and fdinfo/statx rewrites each rose from 1 to 2, confirming
callbacks after reactivation. The unchanged feature and path runners then
passed metadata spoofing, app-open redirect, descriptor path/inode disguise,
ordinary-app path/stat/read/directory hiding, root exclusion and restoration.

SUS_MAP's existing rules were append-only. Changing the stored `map_ino`
parameter after initialization does not remove a published rule. Checkpoint 12
adds root-only `/sys/module/susfs_guard_lkm/parameters/map_rules` management:

- Read: active count and inode/device pairs.
- `add <absolute-path>`: resolve the file and publish a deduplicated rule.
- `del <absolute-path>`: remove exactly that inode/device rule, reusing its slot.
- `clear`: remove all rules. The phone runner never uses this command.

Readers and writers share a short IRQ-safe rule-table lock. A configuration
mutex serializes controls and probe registration. The required maps hook is
armed before new rule publication; failure leaves no new rule. Missing optional
probes can be retried. Named probe registrations reset retained addresses and
disabled flags, including the map-files kretprobe. Removal leaves the probes
registered with no match for the removed inode, restoring its views without
rebooting. The upstream `0x60020` add ABI remains unchanged. Mount identity and
mount probe fixes remain unchanged; the root exploit and loader/status helpers
are unchanged.

Sixteen production-C regressions cover rule controls, isolation, deduplication,
capacity reuse, callback restoration and root exclusion, invalid inputs,
failed/partial registration, sixteen lifecycle cycles and concurrent readers.
They pass normally and with ASan/UBSan. Page-walk and map-files callback effects
still require phone observation. The Python reader's baseline maps/smaps,
rollup, pagemap, map-files and proc-memory checks run successfully on the host.
The host refuses process_vm_readv with EPERM; its baseline remains mandatory
on the phone and this host run does not validate the filtering implementation.

## Phone test

Install the separate **SusFS Test 12** APK and fully reboot to clear the loaded
checkpoint-11 module. Regain root normally, grant Test 12 root and activate
SusFS. Copy `rmgu-susfs-map-test.py` to Downloads. Run from ordinary Termux:

```sh
cd ~
su -c 'cat /sdcard/Download/rmgu-susfs-map-test.py' | python
```

The runner requires an empty map-rule baseline and never clears existing rules.
It maps an app-created 4 MiB target plus a 64 KiB control, faults every page,
checks the app and a root reader, adds exactly the target rule, collects every
active result, then removes the rule and verifies restoration. It checks maps,
smaps, smaps_rollup RSS, pagemap metadata, map_files readlink, proc-memory and
process_vm_readv reads, while the owner's direct access and control mapping
remain usable. Rollup RSS uses a 512 KiB noise allowance. It prints complete
phase measurements and diagnostics on failure, and retains the fixture if
rule removal cannot be verified. It also handles interrupt/termination signals.
The owner app process keeps the same mappings across all phases.

Run it twice on one boot to exercise rule removal and slot reuse. Keep complete
outputs on any failure. A blocked baseline is reported before adding a rule;
it does not establish filtering. Passing is specific to the tested mapping
surfaces, not full upstream parity: this LKM's map-files entry remains listed
while readlink is hidden. Broader namespace/clone coverage and other firmware
remain separate work.
