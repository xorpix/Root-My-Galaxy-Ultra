# RMGU BZIG checkpoint 11: active probes after re-enable

Target: SM-S948B, S948BXXS4BZIG, kernel
`6.12.69-android16-6-pb4d3caf-abogkiS948BXXS4BZIG-4k`.
Checkpoint 11 requires phone validation.

Checkpoint 10's first revision-3 mount run passed all three filtered tables,
root exclusion, file reads, fdinfo/statx replacement ID `1596`, restoration and
cleanup. The second run registered all probes and returned enable reply zero,
but the fixture still appeared in app mountinfo and hook hit counters did not
increase. Both runs used namespace `mnt:[4026536364]`.

## Cause and correction

`__unregister_kprobe_top()` calls `__disable_kprobe()`, which retains
`KPROBE_FLAG_DISABLED` in the probe. `register_kprobe()` deliberately preserves
that bit and returns success with the probe disabled. Checkpoint 10 reset the
resolved address only, so it fixed the earlier `-EINVAL` while leaving the
probe inactive on the next registration.

All mount probe registration paths now reset flags as well as the name-based
address input. The explicitly addressed fdinfo probes also reset flags before
registration. No identity, mount-ID mapping, syscall ABI, root exploit, or
loader/status-helper behavior is changed by this checkpoint.

## Regression evidence

The previous host harness modeled retained addresses but omitted the retained
disabled flag and checked registration counts. It therefore missed this
successful-but-inactive re-enable. The expanded harness follows the inspected
Android 16 / 6.12 kernel flag behavior and extracts the actual production table
pre-handler. Fifteen cases pass normally and with ASan/UBSan; six fail against
checkpoint 10. The new callback case verifies table skipping, root exclusion
and parent visibility across three cycles; the existing repeat-enable case
checks sixteen cycles and now requires every registered probe to be active.
The addressed fdinfo path is checked separately.

## Phone validation

1. Install the separate `RMGU · SusFS Test 11` app.
2. Fully reboot to clear the checkpoint-10 module. Regain root normally, grant
   Test 11 root and activate SusFS. Mount hiding starts disabled.
3. Run the unchanged revision-3 `rmgu-susfs-mount-test.sh` twice on the same boot:

```sh
cd ~
su -c 'cat /sdcard/Download/rmgu-susfs-mount-test.sh' | sh
```

Both runs must pass table filtering, root exclusion, file reads, fdinfo/statx ID
membership and agreement, restoration, and cleanup. Keep complete output on a
failure. Metadata/redirect and path runners remain regression checks after the
mount test. SUS_MAP and broader namespace/device coverage remain separate work.
