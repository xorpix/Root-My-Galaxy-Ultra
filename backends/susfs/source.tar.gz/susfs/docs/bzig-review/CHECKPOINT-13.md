# Checkpoint 13: remote-page failure contract

The CP12 mapping runner caused two reported freezes and reboots. The supplied
`rmgu-susfs-crash.txt` contains a preserved `/proc/last_kmsg` panic from Python
UID 10362, PID 6349, on the exact BZIG kernel. The hidden target's map/smaps,
page-walk and map-files hooks ran before the failure:

```text
Unable to handle kernel paging request at virtual address ffffffd000000000
pc : __memcpy+0x24/0x250
lr : __access_remote_vm+0x174/0x330
Call trace: __memcpy -> access_remote_vm -> mem_rw -> mem_read -> __arm64_sys_pread64
Kernel panic - not syncing: Oops: Fatal exception
```

`sus_map_vm_access_pre()` returned zero from `get_user_pages_remote()` without
populating its page output. Linux 6.12's `get_user_page_vma_remote()` rejects
only `got < 0`; a zero result therefore reaches the copy with an uninitialized
page pointer. CP13 returns `-EFAULT` for a blocked, nonempty remote request.
It leaves the caller's page outputs and mmap lock state unchanged, passes
zero-page requests through, and verifies both VMA bounds before applying a
rule. No callback type or loader behavior changes.

The crash also records `__get_user_pages_remote` registration failing with
`-ENOENT`. CP13 replaces that absent private symbol with the public
`pin_user_pages_remote` wrapper used by process-vm reads. Both public remote
wrappers require the caller-held mmap read lock. An internal helper that
acquires the lock cannot safely be used for this VMA lookup. The `pin_calls`
counter exposes actual reachability; LTO can still inline a wrapper. Phone
coverage of process-vm filtering remains pending.

The host harness now compiles the production remote callback and declarations
alongside the existing rule/maps code. Its 25 cases pass normally and with
ASan/UBSan. Reusing CP12 source produces seven expected assertion failures,
including the poisoned-page consumer and the gap/zero-page cases. This safely
reproduces the return-contract bug without loading a module. The CP12 private
inner callback is used only as a source-level negative control for the shared
handler, not as evidence of live symbol availability.

Phone runner revision 2 prints and flushes each phase/reader operation before
the syscall, forwards root-reader progress live, and refuses an old module
without `pin_calls` before adding any rule. Baseline, control/root exclusion,
active behavior, restoration and cleanup assertions remain strict.

Install Test 13, fully reboot, regain root and activate SusFS from Test 13.
Run the revised mapping runner from ordinary Termux once; if it passes, run
it again on the same boot. Retain complete outputs. A soft restart does not
replace an already loaded module. This checkpoint is host-validated only until
those phone results arrive. The existing map-files range-listing difference
and path-reference lifetime follow-up remain separate work.
