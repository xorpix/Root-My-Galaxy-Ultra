# RMGU SusFS integration recovery, 2026-10-17

The new Samsung path-entry implementation adapts upstream pre-emission directory
filtering, O_PATH denial before fd installation, and consistent readlink ENOENT.
It uses existing kprobe diversion and process-context callbacks, not syscall-table
or inode-operation-table writes. Mount prefixes increase from 8 to 64, with
coherent snapshots, bounded formatting and heap staging buffers.

Upstream reviewed through inforcqb/susfs4ksu-lkm commit
5be002255e638358d24343ecb9a7259e92941fec. Baseline private source is
fae2c03cbb4427d0ae6340dc4eb1cf70ea827780 and its module is byte-identical to
published RMGU 1.2.11. Already present fdinfo, map_files, compat-stat and
inode teardown fixes were retained. The full upstream architecture was not
merged wholesale; per-thread KernelSU unmount gates remain separate work.

The source was initially committed as 562f682b1aa234c67438f9ca6fd994e617c3ee7b.
The module compiled successfully with the pinned Android16/6.12 DDK,
Clang r536225 and CFI. The four real-kernel-header check groups and 18 host
runners passed, including the new path-entry and prefix tests.

A stalled GitHub blob operation and session interruption reset the workspace.
The stripped candidate module was recovered byte-for-byte from retained data:
SHA256 f5d6c2aac361205263220f4033cd5f8df3894926aab487a2e09d223a3b84ceae.
The private baseline was recovered from the saved mount-test1 bundle, then the
recorded production edits and tests were replayed. The recovery commit is a
new commit identity; the original 562f682 commit object was not retained.
Host checks were rerun on the recovered source. Recompilation against the DDK
has not been repeated after the reset; no phone test is claimed.

The matched backend artifact from GitHub run 39026444326 passed all 928 Android
unit tests and its APK build. It contains Next 33391/UAPI 6, BakaSU 35230/UAPI 5,
and unchanged KernelSU 32692/UAPI 6. The artifact's APK does NOT contain this
new SusFS module and uses a disposable verification key. It is not included as
an installable candidate in the checkpoint. The backend patch is included so
its paired drivers, daemons and provenance can be restored without rebuilding.

Automatic approval review rejected uploading the new compiled kernel module
to the public xorpix/Root-My-Galaxy-Ultra repository. The connected user and
repository owner were both verified as xorpix, with admin permission, and the
existing public module was verified. Review nevertheless requires explicit
end-user authorization for the new compiled payload and public destination.
No workaround or indirect upload was performed. The remote draft PR #18
remains at c20019f4da2b2502dc525aa0fc36c29574cba184.

Next: obtain explicit upload authorization, restore/provision the pinned DDK,
rebuild and compare the recovered production source, commit the final module
profile and paired backend assets to the feature branch, then run the prepared
signed test workflow. Confirm hardware behavior before a stable release.
