# Stable directory fix cleanup

The user confirmed Test4 passes the 200-listing control-path test and that
ordinary apps/modules, root before unlock and soft restarts work on the phone.
For the stable candidate, remove temporary path-entry hit counters, bounded
control-name/inode/UID sampling, per-actor credential tracing and entry_diag
output. Keep the tested syscall wrappers, native emitters, caller UID capture,
identity/ownership rules, recursion guard and callback-lifetime drain intact.
The established module controls and status interfaces remain functional.

All 18 host runners pass after cleanup, with ASan/UBSan where supported.
Pinned Android16/6.12 DDK compilation with CFI and all five real-header checker
groups pass. The counter-independent tests retain directory bytes, reference,
locking, error and teardown assertions. The compiled module has no entry_diag
or temporary sample/counter symbols. Phone evidence for the functional fix is
retained separately in the release checkpoint.
