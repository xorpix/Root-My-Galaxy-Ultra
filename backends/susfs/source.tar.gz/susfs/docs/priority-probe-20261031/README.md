# Samsung priority entry-probe fallback

Phone observation: SM-S948B, firmware S948BXXU5BZJA, kernel
6.12.69-android16-6-pa4ef354-abogkiS948BXXU5BZJA-4k. Test3 reported
`init_errno=-14 stage=2 op=0`, both installation masks zero, compat table present,
and `native_insn=compat_insn=d503233f`. This localizes the optional layer failure
to the first table hook's no-fault write, before automatic selection is enabled.
Repeated rebooting cannot change this write failure. Core SusFS remains active.

The existing syscall-table path remains first choice. Only -EFAULT, after the
FP helper has restored every published entry and drained callbacks, admits the
entry-probe route. No protected-write workaround or kernel protection setting is
added. All four kernel targets must be proven named core entry starts. Native
and compat table entries must share each target (the four int-only priority
APIs do so in the previously reviewed BZJA image). Separate compat targets,
foreign hooks, missing/unreadable tables or entries, CONFIG_ARM64_BTI_KERNEL,
and explicit BTI c/jc landing instructions disable this optional feature.

The exact inspected addresses are registered. A post handler keeps probes
unoptimized: Linux jump-optimized kprobes ignore pre-handler PC redirection.
Each pre handler leaves the frame unchanged when passing through, or sets the
return value and returns to the incoming LR before the original entry's PAC.
The shared decision function preserves root/system/trusted/self/namespace,
PID/process-group and default-UID exclusions and I/O-priority error ordering.
It allocates nothing, takes no mutex and does no VFS/package work in a probe.
KernelSU predicates are the existing non-sleeping policy lookups.

Ready is published only after four successful registrations and a second table
identity check. Partial failures unregister every armed probe. Exit disables
filtering first, unregisters probes, then drains counters and Tasks RCU return
tails before releasing policy/helper pointers. Probe addresses and disabled
flags are reset for reuse. Existing table restoration/draining is unchanged.

Status adds `route` (0=off, 1=table, 2=entry probes), `probe_mask` and
`table_errno`. `init_errno=0 stage=0 route=2 probe_mask=f table_errno=-14` is the
expected successful fallback; configuration/automatic flags are independent.
Stage 4 identifies a refused or failed fallback. No function addresses are
printed through status. All status fields retain the existing root-only mode.

Recorded host evidence: all 29 suites / 56 normal and ASan/UBSan runner
executions passed. Actual production C is exercised with CONFIG_COMPAT on/off,
all four table/registration failures, missing/divergent/foreign targets,
unreadable entries, both BTI landing pads, BTI kernel configuration, rearming,
unchanged syscall frames, root policy changes, error ordering, concurrent rule
updates and teardown while a callback's return tail is active. Deliberately
unsafe variants are rejected. Kernel headers, incoming callback KCFI and module
imports must still be verified by the pinned-DDK build.

This route is limited to the four priority syscalls; no global syscall
tracepoint, timer or scan is introduced. Probe breakpoint handling adds work on
these calls. Hardware behavior and interaction with other runtime kernel hooks
remain unverified until test4 is run on the phone. In particular, future code
that redirects table entries after initialization can change coverage.

HMA OSS uses Android framework package filtering in system_server rather than
these kernel priority entry points, so this change adds no direct hook overlap.
Keep RMGU out of HMA's filtered-caller scope so its PackageManager inventory can
see inactive root managers. Hiding RMGU from other apps is compatible with that
scope. No HMA templates/settings or inactive-manager names are changed here;
phone coexistence still requires validation.

References: https://docs.kernel.org/trace/kprobes.html and the source-pinned
HMA review in the app repository, docs/susfs-hma-compatibility-20261031.md.
