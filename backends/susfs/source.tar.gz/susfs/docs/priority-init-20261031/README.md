# Persistent priority initialization result

The first phone test of automatic app selection used BZJA
`6.12.69-android16-6-pa4ef354-abogkiS948BXXU5BZJA-4k`. The read-only status was
`ready=0 configured=0 generation=0 automatic=0 own_appid=0 root_lookup=1`.
The operator confirmed multiple full reboots, `fail_layer=0`, and the presence of
`ioprio_check_cap`, `sys_call_table` and `compat_sys_call_table`. No relevant
printk output was returned. The failure is in priority initialization, before
automatic list activation; the exact failing step remains unknown.

This diagnostic revision preserves the initialization errno, stage and operation
after rollback in the existing root-only `priority_filter` status. Stage 1 means
validation-helper lookup, 2 hook installation, 3 missing compat coverage, and 0
successful initialization. Operation 0/1/2/3 means getpriority/setpriority/
ioprio_get/ioprio_set; -1 means no operation. Native/compat masks capture the
attempt before cleanup; they do not claim that failed hooks remain installed.
The two entry-instruction words and compat-table presence help distinguish
landing validation, symbol resolution and table admission. No kernel addresses
are exposed. The client buffer is extended to 512 bytes.

All hook admission, rollback, lifetime, caller gates, I/O-priority validation and
automatic selection semantics are unchanged. This revision diagnoses the phone
failure; it does not claim to repair it. The app no longer presents a generic
reboot instruction for every unavailable result, and logs the bounded native
status when readiness/policy checks fail.

Focused production-C priority and control-client runners pass in normal and
ASan/UBSan configurations. Initialization tests assert retained helper/install/
compat errors after cleanup and reset on a subsequent successful initialization.
The ARM64 module/client build and real-header/BZJA static checks also pass.
These checks do not execute kernel hooks or establish phone compatibility.
