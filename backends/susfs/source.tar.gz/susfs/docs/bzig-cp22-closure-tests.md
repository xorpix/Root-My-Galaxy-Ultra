# CP22 closure tests: suspended after phone freeze/reboot

**Do not run the native control test, consolidated regression or observation
suite. Leave SusFS off after reboot.** On 9 October 2026 the revision-4 native
runner was followed by a full freeze and reboot at the first absent LOOP
control/readback. No crash stack is available yet; this is a known target
failure, not a permission-blocked PASS.

The updated native and acceptance runners stop before any root operation.
The kernel/APK are unchanged; no repair is claimed. The module inventory remains
permission-blocked and another inventory run is not the next required step.

Use the read-only `rmgu-susfs-cp22-crash-collect.py` from ordinary Termux:

```sh
python -u /sdcard/Download/RMGU-SUSFS-CP22-closure-tests/rmgu-susfs-cp22-crash-collect.py
```

For the separately downloaded file, omit `RMGU-SUSFS-CP22-closure-tests/`.
If Download access is denied, use `termux-setup-storage` and its normal Android
storage grant. Upload the ZIP printed by the collector. It uses no root by
default and changes no feature controls, test rules, original logs or fixtures.
Do not activate SusFS merely to obtain logs. See
`RMGU-SUSFS-CP22-crash-next-steps.md` for optional existing-root reads and the
ADB bug-report alternative.

## Frozen status

| Block | Status |
| --- | --- |
| A1 | Closed: scoped CP22 redirect maps/smaps phone PASS |
| A2 | Permission-blocked inventory; module/symbol effects unqualified |
| A3 | Observability investigation closed; inaccessible/unobserved effects retain their limits |
| A4 | Known target freeze/reboot at first absent LOOP control/readback; repair pending crash evidence |
| A5 | Suspended until the target crash is repaired and the final candidate is agreed |

Earlier passes retain their original scope. No additional acceptance area or
new kernel checkpoint is introduced by this response. Native controls and the
fixed eleven-fixture regression remain in the archive as suspended source,
not instructions to run against the failing CP22 module.

Target: SM-S948B / S948BXXS4BZIG, kernel
`6.12.69-android16-6-pb4d3caf-abogkiS948BXXS4BZIG-4k`.
The package preserves full source/history, earlier phone receipts and host
verification. Host collector/suspension checks are not kernel or phone passes.
Never unload or replace a live kernel module. Preserve the old fixture journal
and helper logs; cleanup after the crash has not been confirmed.
