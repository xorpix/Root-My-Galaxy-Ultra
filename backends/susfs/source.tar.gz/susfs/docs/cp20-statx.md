# Checkpoint 20: statx device matching and field widths

The CP19 native phone runner completed both owned-rule cycles and exact cleanup,
but all four native statx forms exposed the real target inode/size. Held/fresh
fstat and path/AT_EMPTY_PATH newfstatat spoofed correctly, while root and the
unrelated control stayed real. The statx counters showed 16 lookup misses and
zero rewrites or uaccess faults. This is a statx failure, not a full kstat pass.

The rule table stores new_encode_dev() values. CP19 read stx_dev_major as if it
were that encoded device and omitted stx_dev_minor. For the reported 254:81
device, the lookup therefore used 254 instead of 65105. CP20 reads the two u32
fields and converts them with new_encode_dev(MKDEV(major, minor)) before lookup.
Spoofed device writes decode the stored value and fill both full u32 fields;
the 20-bit minor no longer truncates to u16. Statx timestamp seconds use signed
64-bit writes, and their offsets derive from struct statx_timestamp. Compile-time
assertions check all changed widths and offsets against the pinned DDK headers.

The returned mask, rule selection, app/root gate, unlocked user accesses and
table snapshot behavior are retained. No callback route, map/mount implementation
or control ABI is changed. A read-only diagnostic identifies the statx correction:
`statx: checkpoint=20 device_pair=1 dev_bits=32 time_bits=64`.

The production statx rewriter fails the reported device test when extracted
from CP19 and passes all eleven CP20 cases under ASan/UBSan. Coverage includes
device and inode separation, large minor numbers, timestamp widths, masks,
byte preservation, app/root/control gates, empty/no-flag rules, user-copy faults,
snapshot lifetime and the common compat statx layout. These host tests do not
qualify compat process behavior on the phone. The existing syscall/fdinfo
production harness passes thirteen sanitizer cases. The phone runner passes
23 host cases, including rejection of CP19 before any fixture/control writes.

The revision 2 phone runner keeps the CP19 syscall assertions and two-cycle
owned-rule workflow. Its added preflight requires the new statx diagnostic.
The map metadata diagnostic remains checkpoint 19 because that implementation
is unchanged. The runner qualifies native inode/size only: other spoof fields,
compat processes, maps identity, redirect statfs, concurrent races, unloading,
long-run stability and earlier permission/audit gaps remain separate scopes.

Install `RMGU-1.1.8-susfs-cp20.apk`, fully reboot, open **RMGU · SusFS Test 20**,
grant root and activate the module. Then run from ordinary Termux:

```sh
su -c 'cat /sdcard/Download/rmgu-susfs-kstat-native-test-cp20.py' | python -u
```

The source checkpoint includes the pinned-build evidence, complete SusFS source
and git bundle, app integration bundle and rebuild scripts. Host compilation,
KCFI review and APK tests remain distinct from CP20 phone validation.


## Runner revision 3: actual proc output ordering

The revision 2 phone run on 9 October 2026 returns `FAIL: Invalid kstat rule list`
from the initial read-only preflight. It never reaches fixture creation, an owned
rule write or native statx assertions. Source-grounded reproduction identifies
a runner bug: production kstat_proc_show emits rules, then the new `statx:`
diagnostic, then `maps:` and syscall counters. Revision 2 included every line
before `maps:` in its rule list. The initial host fixture had placed the new
marker after the counters, so it did not catch this format mismatch.

Revision 3 separates the exact CP20 diagnostic immediately before `maps:` from
the rule region. It still rejects malformed rows, mixed empty/rule output,
unknown rule-region lines, absent/misplaced/duplicate markers and missing native
counters. Native syscall assertions, owned-only writes, two activation cycles,
bounded root commands and exact original-list checks are retained.

All 33 runner tests pass. The new regression compiles the actual production
kstat_proc_show and its rule/counter types/table with host output/locking stubs.
Its empty, foreign, owned and combined table outputs all reproduce the revision
2 failure and parse correctly with revision 3. Both empty and nonempty production
outputs pass read-only preflight. Existing tests retain actual host syscalls,
leak/error checks, unknown-command handling and cleanup conflict checks; a new
two-cycle workflow preserves a nonempty original rule list. This does not
qualify the live Samsung statx effect, which still needs a completed phone run.

The APK, module and app integration are unchanged. Keep the CP20 module already
loaded for this run. Save `rmgu-susfs-kstat-native-test-cp20-r3.py` in Download
and run from ordinary Termux:

```sh
su -c 'cat /sdcard/Download/rmgu-susfs-kstat-native-test-cp20-r3.py' | python -u
```
