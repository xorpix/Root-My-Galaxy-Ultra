# Samsung supercall dispatcher — 29 October 2026

Base: Samsung source `cc2b27a3f66f11cd9b6bf511a60b8e47c128eae4`.
Adapted from upstream's table delivery and fallback changes through
[`2517cae`](https://github.com/inforcqb/susfs4ksu-for-lkm/commit/2517cae8695eac0a294d555718cf280d1d43c8c0),
including `792ac97`, `f912c9c` and `a8c5d7e`. This is a focused dispatcher port;
the maps and symbol-listing BTI conversions are separate changes.

## Delivery and ownership

1. Try the reboot entry through the existing Samsung syscall-table helper.
   Its saved-original publication, verified write/rollback, native ownership
   checks and complete callback drain remain unchanged. A failed install must
   restore any possible publication before it can return to the fallback.
2. Only then consider the existing kprobe delivery. Refuse it when the selected
   build enables `CONFIG_ARM64_BTI_KERNEL`, the exact reboot body cannot be
   resolved/read, or that entry begins with explicit `BTI c`/`BTI jc`. Probe the
   same address that was inspected; there is no second name-based resolution.
   This is a conservative entry check, not general certification of another KMI.
3. Both routes call one admission/queue function. Wrong magic, non-root callers,
   unsupported/inactive commands, initialization, removal, allocation failure
   and enqueue failure retain the existing forwarding behavior and reference
   accounting. Payload ABI and the deferred handlers are unchanged.
4. The table wrapper counts its entire frame, including a potentially sleeping
   normal reboot call. Queued commands additionally own a module reference
   through dispatch and work-object cleanup. Initialization cannot publish work.
5. Teardown restores/drains the table wrapper or unregisters the probe, then
   waits for the task-work callback's final return tail on either route. There
   is no timed teardown fallback. The existing rule that live kernel references
   prevent module text from being freed remains in force.

The root-readable parameter
`/sys/module/susfs_guard_lkm/parameters/supercall_route` reports `syscall-table`,
`kprobe` or `none`. It is read-only, including in the runtime parameter API.
An unconditional warning after successful initialization identifies kprobe
delivery and its kernel-debugging/instruction-inspection trace. Table delivery
avoids this particular reboot-entry breakpoint; other module probes remain.

## Validation

- The lifecycle harness now runs 40 cases/configurations in normal and
  ASan/UBSan builds. Both routes cover queued/sleeping commands, initialization,
  removal admission, payload/allocation/enqueue failures and the callback tail.
  Additional cases exercise route selection, full original-register/result
  forwarding, a sleeping original syscall, the wrapper return tail, failed
  publication before fallback, BTI refusal, missing/unreadable entries,
  registration failure and 20 alternating route lifecycles. The admission race
  runs 200 iterations per route and build mode.
- Four negative controls remove initialization admission, wrapper counting,
  task-work tail synchronization or the explicit BTI guard. Each must fail its
  behavioral test. The real table helper's restoration, late-entry and
  wake/return-tail cases remain in `tests/fp_hooks`.
- All 26 host suites are validated in their 50 supported runner configurations.
  One pre-existing 8192-rule path-listing ASan case exceeded the Python runner's
  20-second deadline. Its C harness already allowed 120 seconds; the outer
  deadline now matches that budget only for this sanitizer stress case. The
  failed attempts and the final targeted rerun are retained in the records.
- The Android16/6.12 DDK build retains CFI, Tasks RCU, MODVERSIONS and 4 KiB pages.
  All 14 syscall wrappers match the real kernel-header syscall type and carry
  call landing instructions. Kernel imports, existing callback CFI types and
  module version-table shape match the previous Samsung module.

These are host models, compile checks and static artifact checks. They do not
test Samsung protected-memory writes or live kernel dispatch. No phone load,
unload, reboot or app test has been performed for this adaptation.

## Reproduce

```sh
python3 tools/run_host_suite.py --output build/dispatcher-host
python3 tests/lifecycle/run.py --sanitizers --json build/dispatcher-lifecycle.json
python3 tools/build_review.py --kdir /opt/ddk/kdir/android16-6.12 \
  --clang-bin /opt/ddk/clang/clang-r536225/bin \
  --evidence-dir build/dispatcher-module --omit-module-btf --jobs 2
python3 tools/check_audit_artifact.py --candidate kernel/susfs_guard_lkm.ko \
  --baseline /path/to/previous/susfs_guard_lkm.ko \
  --kdir /opt/ddk/kdir/android16-6.12 \
  --clang-bin /opt/ddk/clang/clang-r536225/bin --output build/dispatcher-artifact
```

Provision the pinned DDK using the app repository's `tools/provision_ddk.py`.
The artifact checker needs `pyelftools`. Preserve an unstripped artifact for
investigation; use the pinned `llvm-strip -d` for distribution.

For phone validation, install the test APK, fully reboot, restore root and
activate SusFS. Read `supercall_route`, verify the app's status and the manager's
normal version/feature/rule commands, then check the configured modules after
the normal soft restart. A soft restart alone retains the previously loaded
SusFS module and cannot replace it with this build.
