# Samsung SusFS audit repairs — 27 October 2026

This change repairs the five findings from the audit of source `870bf952aab096789a0f4153bc5ea5bf6fcfba1e`, adds both suggested lookup optimizations, and corrects the AArch32 create-syscall bindings discovered during the repair.

| Finding | Repair |
| --- | --- |
| F1: failed restore / rollback | Track native and compat publication independently, verify each restore by reading the table, and retain module text until both entries are restored. A foreign hook does not prevent restoration of the other table. |
| F2: sleeping callbacks | Count each of the 13 syscall wrappers across helper work and the original call. Restore entries, wait for late entrants with Tasks RCU, drain active callbacks, then wait for the final return tail. No timed fallback. |
| F3: inconsistent directory policy | Capture the original caller's complete KernelSU umount decision before filesystem credential overrides. Preserve owner and control-node exceptions. |
| F4: mixed uname state | Serialize writers and registration; snapshot both padded fields under a short spinlock, then copy to userspace after unlocking. Insmod parameters are read-only at runtime; the supercall remains the runtime update interface. Failed registration and exit cannot publish enabled state. |
| F5: recycled mount identity | Read each inode/device pair under the same IRQ-safe lock as retirement and reuse. |
| P1: repeated linear path scans | Add 256 inode-hash buckets under the existing rule lock, maintain them on add, pending resolution, delete, clear, superblock retirement and exit. Pending rules are not indexed. Preserve pointer, device and control-node filesystem-type matching. |
| P2: empty mapping rules | Return before locking, policy and diagnostic counter work when the release-published mapping count is zero. |

The compat create entries are **mkdirat 323, mknodat 324, linkat 330 and symlinkat 331**, checked against the prepared ARM64 kernel's generated compat header. Each uses its own compat wrapper and saved original, rather than the native entry or native syscall numbering.

A permanent restoration failure or a foreign hook that still chains to SusFS intentionally blocks teardown. Finishing an unload and freeing live callback text is unsafe. A full reboot is the recovery path in that condition; there is no forced timeout.

## Validation

- All **26 host suites / 50 runner executions** passed. Twenty-four suites support both normal and ASan/UBSan builds; two run their supported default mode. LeakSanitizer cannot inspect process state on this host, so it is disabled; ASan and UBSan remain enabled. Allocation/refcount assertions still run.
- New failure injection covers failed native/compat writes, writes that fail after publication, successful return without a store, failed rollback, restore retry and foreign ownership. Controlled lifetime tests cover sleeping work, delayed entry, multiple callbacks and wake/return tails. All 13 real wrappers are checked on success, original-call, missing-original and denial paths.
- Controlled `uname` interleaving, concurrent writers, registration failure and exit tests pass, with runtime negative controls. Mount retirement/reuse is excluded while the reader holds its snapshot lock. Index lifecycle and policy cases pass through 8192 rules.
- Android16/6.12 DDK cross-build with clang-r536225, CFI, Tasks RCU and 4 KiB pages passed. This uses the same 6.12.76-4k build headers and Samsung loader compatibility mechanism as the prior shipped module; it is not a new Samsung kernel image.
- All 13 syscall wrappers match a real-kernel-header syscall CFI fixture and have valid ARM64 call landing instructions. All **136 kernel imports**, module metadata and version-table layout match the previous module. Existing callback CFI types are unchanged; the internal `susfs_fp_drain` helper intentionally gains its hook argument.
- Thirteen real-header identity/LSM callback type cases and three path-entry layout cases passed, including negative controls.

The host index benchmark used 20,000 negative queries per size, best of three trials. At 8192 rules the largest bucket held 34 records; the observed negative lookup was about 43 ns on this host. These are host complexity checks, not phone frame-time measurements or a claim that SusFS caused UI microfreezes.

No phone load/unload, reboot or app stress test has been performed for this revision. **Fully reboot after installing an APK containing the new module**: a soft reboot can retain the old loaded module.

## Reproduce

Use the app repository's pinned `tools/provision_ddk.py` to prepare `/opt/ddk`, then in this source tree:

```sh
python3 tools/run_host_suite.py --output build/host-suite
python3 tools/build_review.py --kdir /opt/ddk/kdir/android16-6.12 \
  --clang-bin /opt/ddk/clang/clang-r536225/bin --evidence-dir build/module \
  --omit-module-btf --jobs 2
python3 tools/check_audit_artifact.py --candidate kernel/susfs_guard_lkm.ko \
  --baseline /path/to/previous/susfs_guard_lkm.ko \
  --kdir /opt/ddk/kdir/android16-6.12 \
  --clang-bin /opt/ddk/clang/clang-r536225/bin --output build/artifact
```

The artifact checker needs `pyelftools`. Strip a distribution copy with the pinned toolchain's `llvm-strip -d`; retain the unstripped module for investigation. APK integration, profile hashes and signing are checked separately in the app repository.
