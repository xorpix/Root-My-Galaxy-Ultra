# CP19 regression results and mapping lifetime follow-up

Ivan's 9 October 2026 outputs complete the queued feature, path and mount
regressions on the reported CP19 setup. Metadata inode/size spoofing,
app-open redirect with original descriptor identity, ordinary path/directory
hiding, shared-namespace bind mount listings, root exclusion, fdinfo/statx
consistency, restoration and cleanup pass in their tested scopes.

Module/symbol counters remain diagnostic in the feature script. The original
bind mount ID 34844 becomes 2000000000; restoration returns visibility and
matching fdinfo/statx IDs, not the original numeric ID. Parent 14179 remains
visible. The missing ancestor 13984 is already absent in both baseline views.

## Focused follow-up using the existing CP19 APK

`tests/phone/rmgu-susfs-map-lifetime-test.py` is a self-contained ordinary
Termux runner for the pinned SM-S948B BZIG kernel. It refuses existing map
rules and older metadata implementations before creating its fixture.
It changes only the newly created target inode/device rule; it does not write
bootconfig, uname, AVC, log, mount, module-name or SELinux controls.

One app child holds a file-backed alias and a separate stable control. The
worker reserves its own anonymous range before using MAP_FIXED within that
range only. Two default cycles replace the target alias with a vacant
PROT_NONE reservation, an unrelated control alias, and the target again. The
same address is reused with one-page and two-page ranges. Direct bytes and
backing inode/device checks reject corrupted mappings and stale file identity.
No pointer into the vacant reservation is dereferenced.

The same child then execs Python once while its hidden mapping is still live;
its new mappings are probed after readiness. PID, procfs PID, start time and
all UIDs are checked throughout. `/proc/self` provides the worker's identity
even when the host's procfs and syscall PID namespaces differ. Available
SELinux context/mount namespace values are compared; permission-denied optional
diagnostics are recorded rather than treated as identity changes.

Each serialized phase compares the child's own view, its app parent's
cross-process view and a root reader in the controller's mount namespace.
It reads maps/smaps, map_files normal/small-buffer listings, cached exact-name
metadata/readlink, pagemap, proc-memory and process_vm_readv. Only operations
accessible in the native baseline qualify a hiding/restoration assertion.
Permission-blocked reads remain explicitly unqualified; no policy or modes
are changed to enable them. Root controls preserve available access.

Rule removal is verified before a final post-exec observation. The owned child
is stopped and reaped before deleting its private fixture. User-space IPC,
directory loops and root-command waits are bounded. A root-command timeout or interruption
leaves its outcome unknown, prevents further rule commands and retains the
fixture/evidence. A kernel task in D state can outlive user-space time limits;
cleanup does not claim it was stopped. Only this Popen-owned child can receive
cleanup signals.

This tests serialized remapping/exec with stable observations. It does not
qualify concurrent exec/read races, previously opened proc descriptors,
unloading, long-run stability or other firmware/variants. No kernel or APK
implementation changed for this follow-up, and no private GitHub push occurred.

## Host verification

35 focused tests pass: eight actual Linux worker cases exercise native
reservation/address reuse, different lengths, vacancy, exec/PID continuity,
startup and ownership; assertion cases detect metadata, memory, root/control
and restoration failures; workflow cases verify rule cleanup after a leak,
returned ADD failure, unknown root-write outcome, interrupted/unreapable root
commands and unreaped worker.
The retained 22 map-runner checks also pass. Actual Linux observations preserve
host permission denials and are labeled hardware_validated=false. Modeled
hidden expectations test the runner and do not qualify Samsung kernel behavior.

Logs: `tests/phone/evidence/cp19-lifetime-host-tests.txt`,
`cp19-retained-map-runner-tests.txt` and `cp19-lifetime-host-observer.json`.
The revision 1 phone run now reports PARTIAL PASS for its available serialized
self/parent/root scopes, two remaps/address reuse cycles and one owned exec.
Native followed-link app reads remain blocked with baseline EPERM; races, held
proc descriptors, unloading and long-run stability remain unqualified.
Normalized phone evidence: `tests/phone/evidence/cp19-map-lifetime-phone-20261009.json`.
Keep the current CP19 boot for further qualification; the original command is
the delivered standalone copy from ordinary Termux:

```sh
su -c 'cat /sdcard/Download/rmgu-susfs-map-lifetime-test-cp19.py' | python -u
```
