# Automatic protection of root-related apps

Extends the reviewed PR #158 priority filter (Samsung parent `fc114e5`) with the
scope requested by the maintainer: RMGU, installed root managers, and apps granted
root. The existing four native/compat operations and caller exclusions remain.

## Live kernel policy

A single immutable RCU rules object holds the explicit manager bitmap, automatic
mode and RMGU app ID. Readers first check the bitmap, then RMGU's app ID or the
backend's live `ksu_is_uid_granted_root(target_uid)` predicate. The latter includes
the registered manager. Grants, revocations and manager registration changes take
effect without polling, package lookup, allocation or credential changes. It uses
the exact target UID for per-user root grants; own/explicit app IDs apply across
Android users, as in the earlier filter. Sharing an app ID cannot be separated.
Trusted KernelSU profiles, root/system and self queries keep their normal behavior.

All four exact bundled backend pins expose the same `bool(uid_t)` root predicate
and behavior (recorded in `records/backend-policy.json`). Targets are app IDs
10000..19999, so the predicate's context-sensitive UID-zero special case is never
reached. SusFS accesses no private allowlist structures. The existing allowlist's
non-sleeping read path supplies grant decisions inside the RCU read section.

Both KSU policy pointers are resolved while preemption is disabled, with the
owning module retained before either is published. The root pointer must belong
to the same owner as the umount predicate. An ownerless pointer requires an exact
vmlinux symbol match. Unknown ownership, a going module or missing root predicate
leaves automatic selection unavailable. The reference is released only after all
SusFS feature exits, hook drains and a final Tasks-RCU grace period. This also
repairs the old umount pointer lifetime. While SusFS is active, its backend must
remain loaded. A full reboot is the supported way to switch these modules.

## Configuration and Android integration

The existing standard `0x60030` ABI is unchanged: a transactional package-list
replacement. It now replaces only explicit extras, preserving automatic mode.
`clear` clears those extras; it does not turn automatic mode off.

The root-only private command `0x6f001` accepts `{ unsigned int enabled;
unsigned int own_appid; int err; }` (12 bytes, error offset 8). Enable requires
1 and an app ID in 10000..19999; disable requires both fields zero. It preserves
the explicit bitmap and refuses configuration if the optional hook layer failed.
The freestanding client exposes `auto <app_id>` and `auto-off`. Existing manual
usage still works with automatic mode off. No upstream feature bit was invented.

RMGU passes read-only (0400) `priority_auto_root=1 priority_appid=<own app ID>`
parameters at load, enabling the live policy before successful activation. Missing
policy support disables only this optional automatic feature. A read-only status
reports ready, configured, generation, automatic, own_appid and root_lookup. The
app verifies mode/ownership and can enable it on an already loaded new module.
An older live module needs a full reboot after the APK update.

Only after unlock, a coalesced Android JobService inventories installed known or
structurally recognized managers, including renamed managers found by the existing
APK/daemon scanner and the user's manager choice. It resolves fresh names each
time; no numeric UID list is persisted. Boot/unlock, app resume, supported removal
broadcasts and dynamic package-change receivers request a refresh. Android does
not deliver every install broadcast to a stopped background process: a newly
installed inactive manager can wait until the next app open/activation/unlock.
The active registered manager and granted-root apps are protected immediately by
the kernel regardless of whether RMGU's process is running. There is no timer or
recurring grant scan, and package inventory does not delay early root.

The background worker uses bounded direct `su`, a cross-process configuration
lock and a current-boot device-protected JSON record. It publishes a whole fresh
manager list. A confirmed native failure can clear stale extras and retry once;
a timeout is indeterminate and triggers no competing fallback command. Status
shows automatic protection or an update/full-reboot hint, without a confirmation
screen. Core SusFS status is independent of this optional feature.

## Validation

29 host suites / 56 normal and sanitizer configurations pass. Production-C tests
cover live grants/revocations, per-user decisions, own ID, manual coexistence,
invalid/unsupported commands, read-only boot parameters, initialization failure,
concurrent bitmap/automatic writers/readers and RCU retirement. Dependency tests
cover built-in/module ownership, missing/foreign/going providers and grace/ref
lifetime; five deliberately unsafe mutants must fail. Lifecycle tests cover root
admission and refusal of both priority commands when the optional layer fails.

The Android16/6.12 ARM64 DDK module and freestanding client build successfully.
All 22 syscall wrappers match real-header CFI types and valid landing instructions;
baseline imports, callback types and version table shape remain intact. Only
`_ctype`, `strim`, `strsep` and `preempt_schedule` are added to the stable module's
imports. All 140 imported names and the dynamically resolved module-owner helper
exist in the recovered BZJA kernel. Its actual I/O-priority validation still
matches the callable helper. Metadata changes only by the two parameter types.
Records pin the exact source hashes and distributed bytes. These are static/host
checks, not complete ABI proof or phone validation. Hardware validation is pending.

See the app repository's `docs/susfs-priority-filter-20261030.md` for test APK and
rollback instructions. Full source, tests and previous evidence are retained.
