# Samsung priority UID filter

Current extension: [automatic root-app selection](../auto-root-apps-20261031/README.md).

Adaptation of [upstream PR #158](https://github.com/inforcqb/susfs4ksu-for-lkm/pull/158),
reviewed at `d55749105beaac03776d95241f4400a68292f831`, onto Samsung source
`961fb6a0585c4ad503f9a9e1fe107058d3595c92`.

## Behavior and improvements

The standard `0x60030` command accepts a comma-separated package list. A successful
command replaces the entire list; an empty list clears it. Selected app IDs answer
`ESRCH` to priority-by-UID operations from untrusted/umounted app callers. Root,
system/shell identities in every Android user, trusted KernelSU profiles, and the
selected app itself retain the kernel's normal behavior. Ordinary PID/process-group
operations also retain their original handlers.

Compared with the proposal:

- All four native and four AArch32 wrappers have separate original pointers and
  span the complete callback lifetime, including sleeping originals and return tails.
  The existing verified restoration and Tasks-RCU drain remain unchanged.
- Installation is all-or-none, including compat coverage on a compat kernel. A
  failed optional layer rolls back and refuses the command; core SusFS stays usable.
- The set path uses the existing root caller's credentials. It never edits a private
  SELinux blob, assumes a fixed root domain, or manipulates Samsung credential refs.
  A denied lookup returns an error and preserves the previous list.
- Names, directory ownership, namespace and input termination are validated before
  publication. Immutable bitmaps are replaced under a mutex and retired after RCU;
  readers do not allocate, look up paths or modify credentials.
- The caller boundary excludes system IDs in every Android user but includes SDK
  sandboxes (20000-29999) and app-zygote isolated children (90000-98999), as well as
  ordinary apps and isolated processes. AOSP defines these ranges in
  [Process.java](https://github.com/aosp-mirror/platform_frameworks_base/blob/main/core/java/android/os/Process.java).
  Limiting callers to 10000-19999/99000-99999 would leave a query route around
  filtering. The existing KernelSU umount/trusted-profile gate still applies.
- `ioprio_set` uses the running kernel's actual `ioprio_check_cap` before returning
  `ESRCH`. Otherwise an invalid priority would expose a different error for hidden
  and genuinely absent UIDs. The BZJA binary inlines this check in its syscall;
  the 19-instruction validation prefix matches the callable helper after register
  and branch-label normalization.
- Root can read readiness/count/generation from the read-only `priority_filter`
  module parameter. There is no new invented `CONFIG_*` feature line.

The standalone module defaults to no configured targets unless automatic boot
parameters are supplied. The app now enables automatic root-app protection and
refreshes installed-manager extras after unlock; see the extension above. The
four priority entries remain installed while the optional layer is initialized.

## ABI and control client

The payload has `char app_strings[65535]`, one alignment byte, then `int err` at
offset 65536; total size is 65540. Old commands and layouts are unchanged.

`rmgu-priority-ctl` is a freestanding ARM64 PIE, with no libc, interpreter or
dynamic relocations. The APK packages the same executable as
`librmgususfs_priority.so`; the test artifact also provides the standalone name.

```
rmgu-priority-ctl status
rmgu-priority-ctl set com.example.one,com.example.two
rmgu-priority-ctl query 10123
rmgu-priority-ctl probe 19998 10123
rmgu-priority-ctl clear
```

Run these as root. `probe` requires the target app to be running and observable as
root before it can give a meaningful result. It creates its own mount namespace,
makes its mounts private, clears supplementary groups and retained privileges,
then drops to the requested ordinary caller UID. This keeps KernelSU's setuid
unmount action inside that private namespace. It only reads priorities and sends
an intentionally invalid `ioprio_set`, never a valid scheduling change. It also
checks self visibility and correct invalid-input errors. The output is JSON;
0 means verified, 1 means the expected filtering/result was not observed, and 2
means invalid arguments or an inconclusive/blocked probe.

`query` is a read-only observation under the caller's existing UID and SELinux
context, suitable for comparison from a real app shell and from root. It makes
no filtering verdict without a known running-target baseline. The automated
probe tests UID/namespace behavior; it is not a complete app/SELinux sandbox test.
`configured` counts unique app IDs, including shared-UID deduplication.

## Limits and phone validation

This is UID filtering on four syscalls, not complete package/process hiding.
Packages sharing an app UID are inseparable. App IDs apply across Android users;
configuration resolves `/data/data/<package>` in user zero. Packages existing
only in another Android user need a separate future resolver. Set the list after
first unlock, when credential-encrypted app-data directories can be resolved.

The module retains numbers, not package observers or inode/mount references.
Reapply the list after installing, uninstalling or reinstalling selected apps:
UID changes can leave a stale rule, and UID reuse can otherwise filter a different
package. Failed updates preserve the last successful list; clear is explicit.
Rules are boot-local and must be reapplied after a full reboot.

No phone test is claimed here. Install the signed test APK, **fully reboot**, root
and activate SusFS, then check `ready=1` before configuring a harmless running app.
Use an ordinary caller app ID distinct from the target. A synthetic caller such
as 19998 should be checked against the phone's actual assigned IDs first; the
probe changes only its own process IDs. Test each backend/firmware actually used.
Do not attempt to replace a live module with `rmmod`.

## Reproduction and evidence

```
python3 tools/run_host_suite.py --output build/priority-host
python3 tools/build_review.py --kdir /opt/ddk/kdir/android16-6.12 \
  --clang-bin /opt/ddk/clang/clang-r536225/bin \
  --rust-bin /opt/ddk/rust/rust-1.82.0/bin \
  --evidence-dir build/priority-module --omit-module-btf --jobs 2
python3 tools/build_priority_client.py \
  --clang-bin /opt/ddk/clang/clang-r536225/bin --output build/rmgu-priority-ctl
python3 tools/check_priority_artifact.py --candidate kernel/susfs_guard_lkm.ko \
  --baseline /path/to/961fb6-module.ko --kdir /opt/ddk/kdir/android16-6.12 \
  --clang-bin /opt/ddk/clang/clang-r536225/bin --output build/priority-artifact
```

Host models exercise production C, including fault injection and negative controls.
They are not execution of an ARM64 kernel. `check_priority_bzja.py` additionally
checks recovered symbols/CFI and the actual I/O validation prefix of the pinned
BZJA image. Empty import-version tables still prevent a complete CRC/ABI claim.
Records in this directory identify the compiler/build and all validation results.
