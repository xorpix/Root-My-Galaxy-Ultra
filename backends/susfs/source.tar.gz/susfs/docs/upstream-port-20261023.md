# Samsung SusFS: upstream sync 2026-10-23

Base: this fork's `port` head before the round
`7f2218e57220fda19d87ba3ccf7e96855e0ba6e8` ("susfs_kprobe: clear
KPROBE_FLAG_DISABLED on struct reuse"), which corresponds to upstream PR #114
and upstream tag `r20` territory.

Upstream reference: `inforcqb/susfs4ksu-lkm`, the closed range
`cc40d2d159534abf973d4148cd834cc4c4ec3028..d9c851d73d2a4b6dc75e38e10ccb0a2c34ffacce`
— 42 upstream commits: merged PRs #116, #118, #119, #120, #121, #122, #123,
#124, #125, #126, #127 (and their in-branch syncs; issue #115 drove #118 plus
the #121-merge revert `78b3f77` and PR #123 that merged the revert). Same
policy as the previous rounds: curated ports onto the phone-tested Samsung
implementation, judged range-net file by file, never blob-to-blob.

## Integrated

Adapted ports, site by site against the Samsung code:

- **create_gate + fp_hook (issue #115)** - upstream `5a2f345` (PR #118:
  `34d1d2b`, `7ae22b6`, `d73c734`, `191ef33`, `cffb6d0`; the fp-hook layer
  files). New `kernel/susfs_fp_hook.{c,h}` (syscall interception by
  replacing `sys_call_table`/`compat_sys_call_table` entries - data-only
  writes through the existing `ksu_patch_text()`, checking the wrapper's
  first instruction for a BTI/PAC landing pad, dual-table original
  publication order) and `kernel/susfs_create_gate.c` (the create family -
  `mkdirat`/`mknodat`/`symlinkat`/`linkat`, each native + AArch32 - answers
  `-EACCES` for a name its caller cannot see, matching the work an absent
  name would run, and `-ENOENT` for linkat's hidden OLD end). Both new files
  are byte-identical to upstream. `ksu_umount_gate`-class kernel changes: in
  the fork's build, the syscall-table machinery is installed only through
  the create-gate layer - the fork's `susfs_kstat` rides the sys-exit
  tracepoint, so `susfs_fp_init()` is the only direct fp_hook consumer's
  first layer here. The resolver pair and `__nocfi` idioms were already on
  this tree; nothing new to port for them.

- **Layer table: fatal column, feature column, arming** - upstream `fa45618`
  ("fp_hook a fatal layer"), `d8caaaf` ("lsm_hook a fatal layer"),
  `b215942` (fail_layer renumbering), `64da500` + PR #122 ("arm each feature
  only when its layer init succeeded"). Our table is now 15 rows
  (`fp_hook`, `ksu_umount_gate`, `lsm_hook`, `sus_path`, `create_gate`,
  `uname`, `kstat`, `sus_map`, `sus_mount`, `cmdline`, `open_redirect`,
  `enable_log`, `avc_spoof`, `hide_syms`, `supercall`) carrying
  `fatal` + `feature` columns: `fp_hook`/`lsm_hook`/`sus_path` and the
  feature layers refuse the load on failure (the fork's strict posture,
  unchanged), the two degrade-capable layers (`ksu_umount_gate`,
  `create_gate`) log "that feature stays off" and let the load complete,
  exactly upstream's split. `ksu_lsm_hook_ready()` resolves the table the
  hook insertion walks (`static_calls_table` on 6.12, `security_hook_heads`
  below) and the layer refuses `-ENOENT` on a miss. Each successful init
  arms its feature for the supercall before the next layer starts. Fork
  diagnostics: `fail_layer` is now 1-based over the NEW order -
  `1 fp_hook, 2 ksu_umount_gate, 3 lsm_hook, 4 sus_path, 5 create_gate,
  6 uname, 7 kstat, 8 sus_map, 9 sus_mount, 10 cmdline, 11 open_redirect,
  12 enable_log, 13 avc_spoof, 14 hide_syms, 15 supercall` - the one
  external reference (the `ksu_umount_gate.c` comment) moved 1 to 2.

- **Supercall feature registry** - upstream `64da500` (PR #122). `enabled_features`
  switched from `bool (*active)(void)` rows to `enum susfs_feature` rows armed
  through a `DECLARE_BITMAP(...)` of bits, armed in process context by
  `susfs_main.c`, read with `test_bit()` in the reboot(2) pre-handler and by
  the SHOW list. A command is handled only while its
  feature is armed: an un-armed layer's commands fall through like unknown
  ones, so SHOW_ENABLED_FEATURES and the accepted command set cannot
  disagree. The fork's `CMD_SUSFS_SHOW_VARIANT` stays in the always-handled
  set. `sus_path_lsm_active`/`susfs_hide_syms_active` survive: they remain
  the control-node/`(!reclaim)`-screen predicates.

- **sus_path: rules presence + the public hidden gate + placeholder
  rework** - upstream `34d1d2b` + the reapply line `1227b41`/`edce422`
  (PR #124), and the create-gate groundwork in `d73c734`. Added
  `sus_path_rules_present()` (feature-free early-out for the syscall-table
  resolvers) and `sus_path_inode_hidden_public()` (the non-hook callers'
  reuse of `sus_path_inode_hidden()`, resolver exemption included), both
  declared in `susfs.h`. `struct sus_dirent_layout` gained `align`
  (8 native / 4 compat) and `type_at_tail` (compat keeps its type byte in
  the record's last one). The all-hidden placeholder now writes the
  SHRUNKEN record - `d_reclen = min_reclen` (header, one name byte, plus
  the compat tail byte, aligned), clears the native `d_type` byte,
  scrubs `[name_off, count)` BEFORE overwriting anything (so a fault
  leaves the first record's own header intact and the "return count"
  fallback still claims nothing was filtered), keeps `d_off` (the
  telldir/seekdir cookie) and re-derives the "what readdir actually does"
  comment (no d_ino-based skip is relied on). Fork kstat/dirent layering is
  unchanged - the rewriter stays post-hoc on the sys_exit tracepoint.

- **ksu_umount_gate: isolated uids** - upstream `ba9b084` + `149c168`
  (PR #126, issue #34 follow-ups). Both inline gates gained the
  `susfs_uid_is_isolated()` short-circuit BEFORE asking KernelSU: isolated
  appids (99000..99999 per `PER_USER_RANGE`) have no KernelSU profile, so
  an ask returns the global default while the KSU patch marks them
  unconditionally (`kernel_umount.c:97` `|| is_isolated_process`, and the
  SUSFS setuid patch the same way) - the gates now say what the device
  actually does. `umounted_app()` answers true for them before the ask;
  `umounted()` answers true BEFORE the `gate_off` fallback's uid test too
  (the patch marks them even where no uid half exists), while everything
  else on the no-uid-half path still answers false (an unpatched kernel's
  own behaviour). `susfs_ksu_umount_uid_applies()` now spells its isolated
  range through the helper. Header/subset comment sources stay
  `kernel_umount.c:97`, `kernel/policy/allowlist.h:8-13` and the setuid
  hook patch.

- **hide_syms: warn/err split for the non-kallsyms caller** - upstream
  `d105533`. The `hide_syms_s_show_pre()` layout-guard message split:
  a rejected caller is a REAL mirror drift (`pr_err`, the identity path
  resolved) only when the probe walked by table identity; on the by-name
  path (the m_show hotfix's kallsyms mirror) a shared `s_show` body or an
  unrelated `s_show` is equally possible, so that case demotes to
  `pr_warn` - "this alone proves neither that hiding is off nor that it
  is on". Counting (`hide_layout_bad`) and the skip behaviour unchanged.

- **sus_mount: count the id-map overflow loudly** - the `b281f71` spirit.
  Our map is a hash table with dynamic per-entry allocation
  (`SUS_MOUNT_IDMAP_MAX` 8192, `n_idmap`/`n_idmap_peak` counted), so the
  flow a full 64-slot upstream array forced does not exist here; what we
  took is the "say it once" property the table's own counting now has:
  the first refused learning warns, as `n_ident_full` already did.

## Not ported (and why)

- **`sus_dirent` compat check order** - upstream `7ae22b6` (+ the
  `1227b41`-era reapply; #121's merge was reverted by `78b3f77` and the
  content re-landed through PR #124). `sd_filldir()` exists only in
  upstream's dir-context actor; the fork has no `sus_dirent.c` at all -
  its getdents rewriter is post-hoc on the user buffer and never
  fabricates the EINVAL/EOVERFLOW errno pair, whose order is the kernel's
  own `compat_filldir()` decision. Nothing in the fork re-derives that
  order, so there is no equivalent site to fix.

- **sus_mount id-map sizing/walk** - upstream `6a71f94` (64 to 256),
  `f3f98b5` (passes sized from the walk), `d9c851d` (1024 + sorted search
  + magic-mount-store coverage). The fork's id map is a hash table with
  8192 dynamic entries, counted peaks, defensive stale-drop and
  `cleanup_mnt` retirement - none of which has a fixed-array pass
  structure to re-size or re-sort, and its marking is a single namespace
  walk (the eight-ID batch and its pass constant were deliberately
  removed here). Upstream's "720 is the current marking bound" fits well
  under 8192. The overflow warn (above) is the one pull-quote taken.

- **`ksu_allow_gate`** - upstream `6c8f466`/`7abf960`/`a5433d6`/`d1dd56a`
  (PR #116, and re-landed by PR #124 after the #121 revert round). The fork
  does not carry `ksu_allow_gate.{c,h}` - the feature is deliberately not in
  this line, so its warning-ordering fixes have no site.

- **`susfs_kstat` comment renumbering** - upstream `fa45618`'s comment fix.
  The fork's `susfs_kstat.c` has no `fail_layer` reference (its layer rides
  the tracepoint, not the fp-hook wrapper table), nothing to renumber.

- **susfs_opath / dirent layer rows** - upstream `fa45618`-adjacent rows
  for the opath/dirent fp layers. Not in this line: the fork's dirent
  rides the kstat sys-exit tracepoint and O_PATH refusals are the
  `sus_path` LAYER's own hook.

- **CI/build/release plumbing** - upstream `4cce89b`, `d689786`, `ac115b6`,
  `f2816f4` (capability warning checks, codeql variants, artifact pinning).
  This project builds through its own DDK pipeline (`tools/build_review.py`)
  and publishes through the user-dispatched `release.yml` only; upstream's
  CI migration does not apply.

## Verification

- Host deck: all 20 runners, plain + sanitizers (40/40 green, `DECK_FAIL=0`,
  clang r536225 in the DDK container). The runners that pin changed
  behaviour were updated with the port: `tests/r18_fixes/dirent_test.c` to
  the shrunken-placeholder contract (`min_reclen`, d_reclen rewritten,
  native d_type cleared, scrub-before-header fault property, `d_off`
  preserved; computes `min_reclen` from `name_off` + the ABI alone so the
  previous source still compiles as the negative control),
  `tests/lifecycle/lifecycle_test.c` for the 15-row table (12 alive bits,
  `susfs_fp_init` is a non-marking stub - the layer installs nothing
  itself - `ksu_lsm_hook_ready()` true, the feature-arming stubs, and
  `test_partial_failures` splitting `fatal` rows (`-EIO`, nothing
  reachable, version request keeps 126) from the non-fatal rows
  (`ksu_umount_gate`/`create_gate`: load completes, the reboot probe is
  live, then a normal removal)).
- `tests/mshow_filter/host_kernel.h` gained the `pr_warn` shim the warn/err
  split needs. `tests/path_listing/path_listing_test.c` now raises its own
  watchdog to 120 s under sanitizers only: the maximum-table case was
  barely under the 15 s budget before this round, and the ASAN build needs
  the real-time difference (verified against the pre-round tree, which
  shows the same 5/5 kills - not a port regression).
- KO build: `python3 tools/build_review.py --kdir
  /opt/ddk/kdir/android16-6.12 --clang-bin
  /opt/ddk/clang/clang-r536225/bin --evidence-dir /src/build/evidence
  --omit-module-btf`, then `llvm-strip -d`. Produced
  `kernel/susfs_guard_lkm.ko` (522448 bytes,
  `1b3e1ce6cfb89a3bf24905108fe3b14da8c63a594a06a16f05221896174b947b`).
- Import surface vs `old/` and `old17/` (.ko binaries, `llvm-nm
  --undefined-only`): exactly two additions, both genuine and
  create-gate-only - `inode_permission` (the parent check an absent name
  runs) and `nop_mnt_idmap` (its 6.3+ idmap argument). No removals.
  `getname_flags`/`filename_lookup`/`putname` stay runtime-resolved by
  name (function pointers, as upstream), `sys_call_table`/
  `compat_sys_call_table`/`synchronize_rcu_tasks` likewise - so the
  fingerprint carries no new kernel-export reads except the two above.

## Follow-up, same day: upstream 7565d75 (+9b27112)

Two further open_redirect commits on top of that closed range are ported in
this round as well. They rework the feature's forward direction across two
files and change the rule table's bookkeeping, so they get their own section
instead of an "Integrated" bullet.

### The rework

- **`7565d75` ("redirect at the name layer, hold nothing")** - upstream stops
  holding anything per rule: a rule kept the target's `struct path`, pinning
  a dentry and a mount for the module's lifetime, which is both a per-rule
  memory cost and a lease that can hold a umount open. The redirect decision
  moves to the open syscall entry, where the name is still in registers and
  nothing has to be kept. Adapted onto the Samsung code with the fork's own
  entry mechanism instead of upstream's hook sites: the fork's target
  kernels LTO-inline the whole open path into the syscall entries, so no
  kprobe site is left there, while this same round's `5a2f345` port
  (create_gate + fp_hook) provides a working syscall-entry mechanism. New
  `kernel/susfs_or_entry.{c,h}` replaces the open syscall entries with
  wrappers built on `susfs_fp_hook` (create_gate pattern), owned by
  open_redirect's init/exit, and each wrapper asks
  `susfs_open_redirect_match_path()` (susfs.h) with the path it is about to
  open. Production changes:
  - `susfs_open_redirect.c` is rewritten around holding nothing: a rule
    keeps `(target_ino, target_dev, target_igen)`, the add-time spoofed
    kstatfs snapshot and the two pathnames, never a dentry, mount or inode
    reference. Both `kern_path()` results are `path_put()` before
    `or_add()` returns, so a rule can no longer hold a umount open.
    `i_generation` accompanies both inode numbers (the same reasoning as
    NFS's export key). `or_register()` refuses with `-ENODEV` while the
    wrappers are not armed (`susfs_or_entry_armed()`, checked before the
    idempotent flag short-circuit) or while `or_exiting` closes the
    facility: a rule the table lists is always one a caller can reach.
  - The reverse faces are re-pointed for the unpinned layout: `d_path` and
    `vfs_statfs` become caller-visible kretprobe pairs (entry stage
    captures argument pointers and rule data under rcu, return stage
    writes the answer), maxactive 16, dev-style like every other
    per-syscall face in this module. The maps face keeps the fork's
    find-only rcu window in `or_maps_ret()` (the module-static array
    outlives every pointer a late reader holds; the comment argues why the
    longer window buys nothing), and the fdinfo face is carried verbatim.
    The `/proc` output is byte-identical to the pre-rework fork (rule and
    hooks lines verified char for char); the hooks line's first field is
    the new forward layer's own `susfs_or_entry_armed()` instead of the
    old registration flag.
  - `SUSFS_OR_PATH_MAX 256` moves to susfs.h, retiring the local
    `OR_PATH_MAX`: the supercall/proc `char[256]` ABI fields, the rule
    storage and the wrapper buffers share one width definition.

- **`9b27112` ("hand a rule's slot back instead of spending one per add")** -
  upstream: rewriting an existing rule on a full table used to fail, because
  the rewrite took a fresh slot while the old rule's slot was emptied inside
  the same add; a steadily rewritten (not grown) table drifted to its cap
  and then refused. The rewrite must hand the old slot back and take it
  again. Ported as `or_reclaim_slot()` (set `dead`, `smp_wmb`, one
  `synchronize_rcu()`, release) plus `or_release_slot()` (clear, keep
  `dead` true, push onto the `or_free` stack; LIFO, so a rewrite retakes
  its own slot). `or_add()` reworks to `!e && !or_free_n && nor >=
  SUS_OR_MAX` as the only capacity refusal, and `or_clear_all()` pays ONE
  grace period per clear (`find_next_bit()` over a handback bitmask)
  instead of one per rule. The reverse kretprobes deliberately stay
  registered across add/del/clear bursts: unregister/re-register was
  observed to leave the hook silently gone after a burst, an empty rule
  table already makes every lookup miss, and the `/proc` hooks line still
  reports their registration.

### Verification for the follow-up

- Host deck: all 22 runners, plain + sanitizers (44/44 green,
  `DECK_FAIL=0`). Runner updates that pin the rework:
  `tests/redirect_statfs` runs the new entry/return pair
  (`or_statfs_entry`/`or_statfs_ret`) instead of the single pre-handler,
  and gains a `kernel-error` case (a kernel statfs error must leave the
  caller's answer standing); the face now also gates on `i_generation` in
  both directions. `tests/redirect_maps` carries the igen fields and the
  rcu stubs its fragment needs. `tests/r18_fixes`' redirect group is
  rewritten: publication checks inode numbers plus generation, that
  nothing stays pinned, the zeroed-snapshot direction, and requires
  `susfs_open_redirect_rules` to move with `nor`; `replacement-capacity`
  and `replacement-success` pin 9b27112 exactly (a rewrite on a full table
  succeeds, reuses the same slot, `nor` stays at the high-water mark, one
  grace per rewrite); the probe-redirect group is no longer a kprobe
  install count but a state test of
  `or_register()`/`or_unregister()`/`susfs_open_redirect_exit()`, with
  `susfs_or_entry_armed()` as the knob in `failed-retry`. The r18 fixture
  extractor is hardened so a comment that happens to mention `NAME()` can
  never start a function fragment (the fragment's first line must be a
  signature line), and the redirect/probe-redirect groups record a
  graceful skip in negative mode: their fragments are version-locked to
  the rework and cannot compile against the pre-rework source.
  `feature_hooks` needed no edit: its fdinfo fragment is carried verbatim
  and stays green.
- KO build: same invocation as the round above (`tools/build_review.py
  --kdir /opt/ddk/kdir/android16-6.12 --clang-bin
  /opt/ddk/clang/clang-r536225/bin --evidence-dir /src/build/evidence
  --omit-module-btf`, then `llvm-strip -d`). Produced
  `kernel/susfs_guard_lkm.ko` (545160 bytes,
  `f19289735dcf9a9136ff82d49dffd9dfd695cd7d4f74c32e560b34648914adfb`,
  +22712 over the previous round, the wrapper layer).
- Import surface vs `old/` and `old17/` (`llvm-nm --undefined-only`; the
  diff is identical against both refs): the two create-gate additions
  already documented above plus one removal -
  `dcache_clean_inval_poc`, retired by the by-name flush resolver (the
  `11e692c` port above: the helper is found by name at load now, so it no
  longer sits in the module's import list). Nothing from this rework: the
  wrappers and the re-pointed kretprobes touch only memory and registers
  already in their prototypes, and the tables they write
  (`sys_call_table`, `compat_sys_call_table`) stay name-resolved, so the
  open_redirect changes leave the import fingerprint alone.
- Unvalidated on device, as every round here. The wrappers now carry the
  redirect decision, so the next device session needs, in addition to the
  usual load and layer checks: the layer armed state on the hooks line,
  one add/del/clear burst with the counters moving, open(2) of a rule's
  target from a matching uid scheme landing on the redirect target, and
  the five documented reverse faces still listening after the burst.

## Follow-up to the follow-up: the external review (same day)

- Review follow-ups to this round: the forward wrapper had zero
  host coverage - the deck compiles susfs_open_redirect.c and sus_path.c,
  never susfs_or_entry.c - so the decision code that makes the pass/redirect/
  error split was pinned device-side only. New `tests/redirect_entry` runner
  (fragment extraction from `susfs_or_entry.c`, compiled with `-D__aarch64__`
  and `-DLOOKUP_CACHED`, modelled open primitives, 29 cases + 3 source
  guards): PASS vs redirect vs error per entry kind, the `(1 << 32)` flag
  bypass, every openat2 edge the kernel answers with an error (short
  `usize`, unknown resolve bit, `BENEATH|IN_ROOT`, `CACHED` with create,
  unknown flag, bad mode, `O_PATH` with an extra flag, larger-structure
  tail), `O_LARGEFILE` present on native openat/openat2 and absent on the
  compat open/openat pair and `O_PATH` while compat openat2 (served by the
  native implementation on this tree) carries it, `O_CLOEXEC` stripped from
  the open and applied to the descriptor, descriptor taken before the open
  and `fd_install` after the fsnotify notification, and the two documented
  missing-symbol directions (no `fsnotify_open`: the fd is still handed
  out; no `check_zeroed_user`: a larger `open_how` is handed back). The
  `O_LARGEFILE` model value (`00100000`) is the unconditional definition in
  this tree's `include/uapi/asm-generic/fcntl.h` (no arm64 override). The
  real open path stays device-only evidence, as before.
- Two kernel-side tightenings from the same review: `or_maps_ret()` now
  holds `rcu_read_lock()` across the find AND the later entry reads (the
  dev:ino pair and the pathnames) instead of dereferencing after the
  unlock - the array is module-static so this was never a use-after-free,
  but it let a concurrent rewrite or delete race behind the read and
  briefly lose one maps-line disguise; `or_maps_replace()` only edits the
  already-emitted seq buffer in place (no allocation, no sleep), so the
  whole edit is safe in the rcu section, matching the d_path/vfs_statfs
  faces. And `or_add()` now raises `dead` and `smp_wmb()` BEFORE
  publishing a never-used tail slot (`WRITE_ONCE(nor, nor + 1)`, readers
  already `READ_ONCE(nor)`), so a reader that observes the new count also
  observes the slot skipped while it is filled - the BSS-zero slot could
  otherwise look live inside the reader count.
- Deck: 23 runners, plain and sanitizers, 46/46 (`DECK_FAIL=0`). KO
  rebuilt the same way as the round above: 545232 bytes (the two
  kernel-side tightenings reflow a few instructions),
  `45ec8bb004d5161ca856380f29999d2c6d103f4c444d5773cde59448d3276d72`.
  Import surface unchanged against both the cp-era refs (`old/`, `old17/`:
  same create-gate additions + `dcache_clean_inval_poc` retirement) and
  the module that shipped in RMGU 1.2.24
  (`f19289735dcf9a9136ff82d49dffd9dfd695cd7d4f74c32e560b34648914adfb`,
  545160 bytes): this round adds and removes no symbol.
- Still inherent, NOT addressed (a design trade-off, not a bug): with one
  or more rules live, every open pays an extra getname + filename_lookup
  before falling through to the real syscall. The active() fast path keeps
  the no-rules case zero-cost; with rules present this is the entry-point
  interception cost the LTO-inlined open path forces here, which upstream
  avoids only by patching post-resolution (`do_sys_openat2`).
