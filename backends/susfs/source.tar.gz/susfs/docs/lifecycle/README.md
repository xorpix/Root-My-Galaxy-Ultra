# Deferred request lifetime — BZIG source review

Base: `inforcqb/susfs4ksu-lkm` commit
`c2a5575e0a230db992ad94e2924bc38333797336` (reviewed dev3 snapshot).
The dispatcher changes originated in checkpoint 5 against dev2; checkpoint 6
rebases them without changing their ownership contract.

This patch addresses the dispatcher's lifetime during normal module removal and
failed initialization. It is a source review candidate, not a BZIG-compatible
module release. It does not establish safe removal of the module's other hooks.

## Changes and ownership contract

1. Requests received while the module is still `MODULE_STATE_COMING` are left
   unhandled. Failed initialization can free module memory without honoring
   references acquired during initialization; publishing task work then would
   therefore be unsafe. The caller can query again after initialization succeeds.
2. A recognized request acquires `try_module_get(THIS_MODULE)` before allocating
   or publishing its work. Allocation and enqueue failures release that reference.
   Once queued, the work owns it until dispatch and work-object cleanup finish.
3. The callback's final operation is `module_put()`. Nothing in the callback may
   access module state or voluntarily schedule after releasing ownership.
   Sleeping inside a handler is covered by the reference, not by an RCU delay.
4. Normal kernel module deletion refuses while a request owns a reference. A
   request delayed by a stopped task or a blocked handler can therefore keep the
   module busy. This patch does not cancel that request, add a timeout, or force
   removal. Forced module removal is outside this contract.
5. The dispatcher is initialized last and removed first. Its exit unregisters
   the kprobe and then calls the native `synchronize_rcu_tasks()` API. References
   cover dispatch; this grace period covers a task preempted after its final
   release but before it has returned to the kernel's task-work runner.
6. Initialization requires `CONFIG_TASKS_RCU=y` before installing any hooks.
   Without it, the generic header can alias the API to ordinary RCU, which does
   not supply the required return-tail contract. There is no fixed-delay fallback
   in the newly added dispatcher cleanup.

This changes the diagnostic `fail_layer` indices: `hide_syms` is now 11 and
`supercall` 12. Other indices are unchanged. Protocol fields and command handlers
are unchanged.

## Verification and its limits

`tests/lifecycle/run.py` compiles the actual edited `susfs_main.c` and
`susfs_supercall.c`, together with their actual ABI declarations. A host model
replaces kernel APIs, feature implementations, and private kernel types.

Thirteen cases cover queued and sleeping requests, allocation/enqueue failure,
initialization and removal rejection, payload-copy and status-allocation errors,
multiple pending requests, registration rollback, each diagnostic layer failure,
the final return window, missing Tasks RCU, and 200 request/removal races.

All thirteen pass with optimization and with AddressSanitizer plus
UndefinedBehaviorSanitizer. The allocation and reference balances are asserted.
The original unpatched dev2 source failed twelve contract tests; its registration rollback case
passes. These are host contract failures, not reproduced kernel crashes.

The host model deliberately controls the grace-period wait and probe lifetime.
It does not verify Linux's implementation of either primitive, exhaust all
interleavings, test weak-memory behavior, emulate Samsung protections, or prove
an arm64/CFI ABI match. Checkpoint 6 additionally cross-compiles the module against
the pinned Android 16 / 6.12 DDK; see `docs/bzig-review/README.md` for the scope
and remaining differences from Samsung BZIG. No phone test was performed.
LeakSanitizer cannot inspect process task lists in the execution
environment; the successful sanitizer run uses ASan/UBSan without LeakSanitizer.

## Remaining BZIG integration work

- Compile against suitable, pinned kernel build inputs and inspect the resulting
  imports, including `try_module_get`, `module_put`, and
  `synchronize_rcu_tasks`. Resolve exact BZIG symbol-version and private-ABI
  evidence rather than assuming a generic 6.12 build matches Samsung.
- Review the other hook removal and partial-initialization paths independently.
  Their restoration checks and existing fallback behavior are not repaired by
  this dispatcher patch.
- Validate protected-memory and runtime CFI behavior on matching hardware under
  an explicit recovery plan before adding app activation. The existing selected
  BTF matches and `CONFIG_TASKS_RCU=y` observation do not prove these properties.
- Keep app support assessment at `ReviewRequired` until these questions are
  resolved. This patch supplies no evidence of Knox preservation or boot safety.

## API references used

These are generic Linux 6.12 references, not matching Samsung source:

- [Module acquisition, release, and removal](https://github.com/torvalds/linux/blob/v6.12/kernel/module/main.c)
- [Module state and reference declarations](https://github.com/torvalds/linux/blob/v6.12/include/linux/module.h)
- [Task-work queue and runner](https://github.com/torvalds/linux/blob/v6.12/kernel/task_work.c)
- [Kprobe unregistration](https://github.com/torvalds/linux/blob/v6.12/kernel/kprobes.c)
- [RCU declarations and configuration fallbacks](https://github.com/torvalds/linux/blob/v6.12/include/linux/rcupdate.h)
- [Tasks RCU requirements](https://docs.kernel.org/RCU/Design/Requirements/Requirements.html#tasks-rcu)
