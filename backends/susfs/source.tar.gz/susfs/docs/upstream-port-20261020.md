# Samsung SusFS: upstream sync 2026-10-20

Base: the phone-tested RMGU module revision
`70e1372131107d8903a83201162d5a1fe88ecdee` in the recovered tree, which the
shipped 1.2.16 module binaries were built from
`a8e803f9dea7b61faaf3451669df42d12f017467` ("Remove temporary directory
tracing for stable release").
Upstream reference: `inforcqb/susfs4ksu-lkm`, `main` at
`ba5c6d00977719f43cc827d362374a192c0e5c1a` (Merge PR #109); the merge base
with this line is exactly `c2a5575e0a230db992ad94e2924bc38333797336`: our side
+61 RMGU commits, upstream +227 (199 non-merge), tags `v2.3.0-r18` through
`r18.3` reached. This is the project's curated port onto the Samsung
implementation, not a wholesale rebase and not a replacement of the phone-tested
Samsung integration.

## Integrated

Tier-1 — clean cherry-picks, upstream messages preserved (upstream =
local copy):

- `e7bce5b` = `e972fe2` Makefile: move the srctree check into the all: recipe
- `76926ff` = `9509659` lsm_hook: stop clearing the node's own forward pointer on unlink
- `44c7672` = `463ee2b` susfs_kstat: assert the argv requirement inside the parser
- `82fe0e4` = `883df73` tools/verify-gki: stop reading EACCES as a pass, and judge the del check on rc
- `3be524e` = `05f1f5e` tools/susfs_mmap: emit_maps_line() needs the buffer capacity
- `6aa6868` = `d4a0814` susfs_hide_syms: read the hide_modules list under the lock that publishes it
- `236866f` = `7578c0c` susfs_supercall: mark the LKM first, stop advertising the port-only entry
- `3d56aa1` = `1914a4c` lsm_hook: find the < 6.12 hook list by identity, not by a build-time offset
- `ef64b3d` = `ebee04b` lsm_hook: find the 6.12 slot by identity, not by a build-time offset
- `3ab9f54` = `6940e13` lsm_hook: switch the static call through __static_call_update (>= 6.12)
- `5bde9c2` = `3deffc8` lsm_hook: accept a SELinux hook whose name contains the hook name (issue #1)
- `772b188` = `b2fd07b` kprobes: a probe struct has to be cleared before it can arm again
- `4bfae70` = `9079b90` tools/susfs_compat_stat: count the residue the record walk cannot see

Already verified present (no-op): `191339d`, `5ff3d67`, the statx halves, the
pending-credential ownership, and the ihold'd inode teardown at fs teardown
(our `e357462`, upstream `75c1006`).

Manual ports, adapted site by site against the Samsung code:

- **`ksu_umount_gate` (issue #34)** — upstream `77d962d`/`4aca086`/`8473996`/
  `fb88f44`/`5f5d21e`. New `kernel/ksu_umount_gate.{c,h}`; the resolver gained
  the module-aware `ksu_kallsyms_lookup_name()` (the raw tail ends in
  `module_kallsyms_lookup_name()`, so a name owned by the loaded kernelsu.ko
  is found — `find_kernel_symbol_exact()` deliberately refuses module owners
  and was the wrong tool). Resolved ONCE at load, by name; nothing imported,
  so no loader change. `susfs_ksu_umount_gate_off` defaults to the pre-#34
  answer (`uid >= 10000`), so absent KernelSU or an unresolvable name is a
  silent degradation. Six decision points converted: `sus_map`'s read gate,
  `susfs_kstat`'s read gate, `sus_path`'s uid-only and LSM gates,
  `sus_path_entry.h`'s per-entry uid tests (`susfs_ksu_umount_uid_applies`,
  the boundary set KernelSU itself asks about), `open_redirect`'s
  reverse-disguise gate and its `uid_scheme` 3/4 pair (scheme 4 answers
  `susfs_is_current_proc_umounted()` deliberately without the app-uid half).
  `OR_APP_UID_MIN` is gone. The gate layer is first and non-fatal in the
  layer table. Behaviour after this: a su-granted app, the manager and a
  profile with "umount modules" off are no longer hidden from — that is the
  point of #34; hiding from every app-uid process was the proxy's bug.

- **hide_syms probe identity** — upstream `f02bdfb`/`3ca6bdf`.
  `hide_syms_resolve_show()` reads `kallsyms_op`/`modules_op` `.show` through
  `copy_from_kernel_nofault`, validates the table value AS-IS with the new
  resolver helpers `ksu_symbol_is_start()`/`ksu_addr_is_named()` (address->name
  through the bootstrapped `kallsyms_lookup()` plus the reverse membership
  test, covering code-folded/vendor-aliased addresses the way `lsm_hook`
  already does), and only when the value is NOT the named function's body
  treats it as an entry stub: optional `bti c` skipped, unconditional `b`
  followed (`bl` deliberately not), destination re-validated. The decision
  comes from the instructions, never from a CONFIG. On validation failure the
  probe arms BY NAME as before, and the handlers' `m->op` identity check is
  off on that path; with a validated table the probe can no longer skip lines
  of an unrelated /proc file. Both handlers read `m` through
  `regs_get_kernel_argument()`. A modules `m_show` failure no longer refuses
  the layer (nor unregisters `s_show`) — warn + degrade. `exit()` clears the
  probe structs via `susfs_kp_forget_addr()` and NULLs the table targets.
  NOT ported from the same commits: the insmod-parameter deferral and the
  hide_modules config-lock simplification (this tree's transaction
  implementation is deliberately beyond upstream there — the app passes
  `hide_modules=kernelsu,susfs_guard_lkm` at every insmod and the phone-passed
  model is kept), and the control node still answers our uid gate
  (`ksu_allow_gate` is not ported, see below).

- **kprobes header** — `susfs_kprobe.h` carried a nested `/* ... */` inside
  its mirror comment, which terminated the comment early and made the header
  unparseable the first time a kernel build included it; upstream fixed the
  same line in its copy (`(only on failure)`), we did the same.

## Skipped, with reasons

- Wholesale rebase/merge of upstream's 227 commits — rejected; patch-id
  comparison is invalid across divergent trees and the project model is
  curated porting with per-commit re-verification.
- **New-file replacement architectures** (`sus_dirent.c`, `susfs_opath.c`,
  `susfs_or_entry.c` `91ded01`+, `susfs_fp_hook.c`): our Samsung dirent/
  path/redirect implementations are the phone-tested equivalents; the
  opath/fp_hook designs target backend hooks this device does not use.
- **`imports_guard`** (`25431ad` series, `573e2b7`/`8f6776e`): the failure
  mode it defends (a loader that keeps going after a lookup miss and leaves
  `SHN_ABS/0` in the image) cannot occur with this project's loader — it
  rewrites only names it actually found in `/proc/kallsyms`, refuses
  zero-address kallsyms output outright, and leaves every miss as
  `SHN_UNDEF` for the kernel's `simplify_symbols()` to reject with a clear
  "Unknown symbol". Belt-and-braces only; revisit if the embedded loader ever
  changes its unresolved-symbol policy.
- **`patch_memory` cache-flush helper by name** (`b149871`): it removes a
  build-time header probe so ONE module can load across kernels carrying
  either dcache spelling. We build exactly one kdir (android16-6.12); a
  kernel carrying the other spelling would refuse the load explicitly
  ("Unknown symbol"), not mispatch — and the in-scope kernels carry the
  modern name (in-service validated). The build-time probe stays.
- **`open_redirect` name-layer rework** (`b824d9f` + follow-ups): a
  re-architecture of a feature whose fallback behaviour here is phone-tested;
  deferred until a device need is shown.
- **`ksu_allow_gate`** (`1de4a91`+`9b99d7c`+`c0a7d42`+`cb6e2aa`): control
  nodes follow KernelSU's su gate and carry its file label. The app owns
  control-node visibility in this project and protects nodes with its own
  gate; the sweep across all three backend pins adds sensitivity without a
  demonstrated device need. Revisit if the app hands node access decisions
  to the kernel.
- **`sus_map` show_map inline probe** (`da50133`+`c6f6806`): our sus_map
  hooks the actual `.show` boundary already (a superset of the upstream
  inline-formatter handling); what remains upstream-side is counters.
- **`4aca086`'s import-based phase**: superseded by the resolve-at-load
  design, which is what was ported.
- Flashable-module packaging (`4bc30b8`), `kmi.sh`, CI/Gitee/README commits:
  packaging and infrastructure, not module source.

## Validation

- All 18 host runners pass sequentially under the pinned clang (Android
  Clang 19.0.1, r536225) inside the DDK image, and again with `--sanitizers`;
  the fragment runners carry a host replica of the new gate helper so their
  assertions are unchanged, and `lifecycle` now stubs the umount-gate layer.
  Two runners needed `-Wno-c23-extensions` for message-less `static_assert()`
  — the pinned clang rejects it at C11 under `-Werror`, which broke both
  runners on the SHIPPED source as well.
- The dirent bound now promotes `reclen` to `size_t` before the
  `DIRENT_BUF_SIZE` compare: `d_reclen` is u16, so the previous comparison was
  a compile-time tautology the pinned clang rejects. Semantics unchanged
  (`d_reclen` cannot reach 65536 by type).
- Module compiles in
  `ghcr.io/ylarod/ddk-min:android16-6.12-20260828` (clang r536225,
  UTS_RELEASE `6.12.76-4k`, autoconf/Module.symvers hashes identical to the
  original module build record), config identical
  (CONFIG_CFI_CLANG=/CFI_ICALL_NORMALIZE_INTEGERS/TASKS_RCU/MODVERSIONS/
  ARM64_4K_PAGES). Review artifact 3,044,208 B; `llvm-strip -d` gives the
  shippable 498,032 B module.
- Import surface UNCHANGED: 135 strong undefined symbols, none added, none
  removed versus the shipped 1.2.16 module; `ksu_uid_should_umount` is
  deliberately NOT an import (resolved by name at load) and no weak imports
  exist. Loader and status helpers are untouched this round.
- Loader/status ABI and all assets except the module are unchanged between
  1.2.16 and 1.2.17.

Host/build results do not constitute phone acceptance. The rebuilt module
ships marked experimental until one successful on-device activation has
re-hosted it (SM-S948B, BZIG): the gate changes hide-after-activation
behaviour (su-granted apps see promoted files; ordinary apps still do not),
and the hide_syms probes change arming paths (table identity with by-name
fallback). `adb` verification helpers remain tools/verify-gki.sh.

## Hotfix: m_show back to by-name (same day, after on-device testing)

One on-device pass found its share list: with the table-identity arming the
module stayed visible in `/proc/modules` to ROOT readers on S948B/BZIG
6.12.69 — and the app-side self-check could not catch it, because SELinux
denies untrusted_app reads of `/proc/modules` entirely, so the app view reads
empty regardless. The identity machinery was ported for `m_show` too; the
1.2.16-shipped behaviour hid the line from every reader by prompt the app
passes `hide_modules=kernelsu,susfs_guard_lkm` and the sysfs rules are what
the phone qualification exercised, so the regression was invisible in
host tests.

- `m_show` is armed BY NAME unconditionally again; `modules_op_target` stays
  NULL, which turns the handler's `m->op` identity check permanently off
  (it short-circuits on NULL) — exactly the 1.2.16 path.
- `s_show` keeps the table-identity path, which the same device pass found
  working (kallsyms hiding intact).
- The deck gained `tests/mshow_filter`: the live fragment is compiled twice —
  as shipped, and with the m_show body replaced by the frozen 1.2.16-shipped
  handler — and driven over the same invocation matrix, expecting identical
  observables everywhere but the one documented divergence (an impossible
  `m == NULL` call), plus a negative control re-arming the gate to prove the
  harness detects suppression. 19 runners now, all green in both the plain
  and sanitizer passes.
- New module: 497,672 B stripped, sha256
  `0c2129f8befcf5c1a8ac94f37218d08f957395f367f9a0bda0c2fcc0f18a2ec0`; import
  surface identical to both the 1.2.16 and 1.2.17 modules (135 strong
  undefined symbols, none added/removed).

## Maintenance: 2026-10-21 upstream sync (bootconfig, padding, variant)

Source bundle from the collaborator on the same fork line, reviewed and
integrated hunk-for-hunk (same git blob hashes for all three kernel files):

- `spoof_cmdline.c` (upstream `f5f9c05e`): bootconfig reclamation instead of
  retaining every published buffer forever. The live value is separate from
  retired ones; successful replacement/restoration retires only the
  unpublished value, `synchronize_rcu_tasks()` covers the native,
  non-sleeping `boot_config_proc_show()` reader window (no timed delay), and
  the freed bodies come after the grace period. Exit blocks new sets
  (`-ENODEV`), and a failed restoration at unload deliberately retains the
  possibly-borrowed live value rather than freeing memory with unknown
  readers. `synchronize_rcu_tasks` was already an import; the surface does
  not change.
- `susfs_uname.c` (upstream `9d36644f`): `uname_pad()` zeroes the tail of
  `fake_release`/`fake_version` after module-param parsing and after
  supercall writes, using the existing string APIs — no `strscpy_pad`
  import.
- `susfs_abi.h` (upstream `8b65f13f`): `SUSFS_VARIANT_STR` becomes
  `GKI-LKM`, inside the unchanged 16-byte supercall ABI field.

Reviewed without a source change, per the same bundle: mount-ID batch
scanning, identity devname lookup, `imports_guard`, `ksu_allow_gate`
relabel, source-SID audit rewrite, two x64-project links. The `m_show`
hotfix, mount implementation and AVC production code are untouched.

Their harness update is part of the change and ships with it: the
`identity_controls` runner gains reclaim-bound, reader-replace,
reader-reset, foreign-unload, exit, three uname-padding and variant cases,
plus two new negative controls (omit-reader-grace, omit-uname-padding) and
allocation accounting on kmalloc/kfree. LSan process inspection stays an
opt-in `--leak-check` flag; the foreign-unload case intentionally retains
one allocation and disables leak detection for that case only.

Validated here with the pinned DDK toolchain, which the collaboration
bundle could not do: 19 runners cover the matrix, green in the plain and
the sanitizer passes (38/38 module runs). New module: 498,272 B stripped,
sha256
`b1bf151ccf81daecc98ff97eab5a34248f33b4088019fb3532b45615628b6f4b`; import
surface identical to the 1.2.16, 1.2.17 and 1.2.18 modules (135 strong
undefined symbols, none added or removed). Still unvalidated on device —
it stays experimental until one BZIG activation passes.

## Upstream review through PR #114: probe reuse clears the disabled bit

The collaborator's follow-up review (2026-10-21) covers every upstream
commit through `cc40d2d` / PR #114: 26 commits, of which all but one were
already applied or were deliberate skips here — the one gap is
`7d74b9b` (`susfs_kprobe: clear KPROBE_FLAG_DISABLED too when a probe
struct is reused`).

`register_kprobe()` preserves `KPROBE_FLAG_DISABLED`, and unregistering
leaves it set. Both shared reuse helpers (`susfs_kp_forget_addr`,
`susfs_krp_forget_addr`) now clear the disabled bit together with the
address, preserving unrelated bits (`GONE`, `OPTIMIZED`) and the symbol
name. Without this, a struct reused after a disable/unregister cycle — an
enable/disable control surface or a retry after a failed registration —
could register again successfully yet stay disarmed: a feature silently
off with a clean-looking return. The change is a pure header edit; no
import is added or removed.

New runner `tests/kprobe_reuse` compiles the actual production header
against a host model of the native registration rule: eight positive
cases (repeated kprobe/kretprobe cycles, failed lookup then retry,
unrelated-flag preservation, idempotence) and six negative controls that
remove the fix and must fail. The deck is 20 runners; both plain and
sanitizer passes are green (40/40 module runs). New module: 498,272 B
stripped, sha256
`aa29c33d829414f15f3793c6e31c68490411bce0d0c9eff9872a74b2ef7fb6d6`;
import surface unchanged (135 strong undefined symbols). Still
unvalidated on device.
