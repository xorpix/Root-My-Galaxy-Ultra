# Mount consistency test candidate — 2026-10-14

Base: released RMGU 1.2.5 private SusFS source
`70e1372131107d8903a83201162d5a1fe88ecdee`. This is a new candidate built from
that source, not an older checkpoint payload. The historical `rebuild_cp15.py`
filename identifies the retained pinned-toolchain wrapper; it builds this
working tree, verifies the original DDK hashes, and does not select CP15 sources.

## Changes

- Require all three mount-table hooks. A failed registration logs the precise
  symbol and errno, rolls back installed hooks and returns failure to userspace.
  Registration remains sequential; this does not claim an atomic transition.
- Recognize configured backing paths on the actual `/data` filesystem, including
  bind roots and overlay upper/top-lower paths. The existing module-root and exact
  KSU-overlay rules remain. Reuse this classifier for table hiding, mount-ID
  mappings, namespace scans and existing EROFS statfs routing.
- Absolute prefix rules match complete path components. `/data/adb` and
  `/data/adb/` include that directory and descendants, not `/data/adb_backup`.
  Non-path source prefixes retain their existing semantics.
- Report backing-helper availability in `mount_stat`.

## Design and scope

The motivating comparison was JingMatrix/KernelSU commit
`70c21174ca43d890d47d5d74948a33d2df971672`, especially complete three-table hook
coverage and backing-path recognition. This implementation retains the RMGU
probe architecture. It does not patch proc operation tables, leave callbacks in
open file handles, scan rendered mount text, or add broad keyword rules.

Backing paths are borrowed only while the caller holds the overlay mount/root;
there are no persistent filesystem references, path lookups, allocations or
sleeping operations in the added classifier. The lower walk is bounded to four
layers. The 256-byte path buffer leaves overlong paths unmatched. It does not
inspect every lower layer, external loop-device contents, or KernelSU's private
unmount list. Missing optional overlay helpers are reported, not guessed.

Reader scope remains the existing non-su SELinux-domain policy. At the released
pins, all three backends implement `ksu_uid_should_umount(uid_t)`, but this is
an internal function rather than an exported module interface. Calling a cached
address from this separately loadable module would also require backend-owner
lifetime handling. Per-app policy integration is deferred until a supported
interface can cover profile updates, both isolated UID ranges, and backend
unloading consistently across mount tables, fdinfo/statx and statfs. No user
profile is changed by this candidate.

## Validation

- 43 production-C host cases, normally and with ASan/UBSan.
- The seven relevant new cases fail against the unchanged 1.2.5 source.
- Prepared Android 16 / 6.12 DDK signature checks, including the new resolved
  `ovl_path_upper` prototype, and ARM64 compilation with the retained toolchain.
- Package evidence records exact source, module and toolchain hashes.

Host checks do not execute a Samsung kernel. Device validation remains pending.

## Phone comparison

Use the signed test APK over 1.2.5, perform a full reboot, then activate root and
SusFS normally. A soft reboot cannot replace the already loaded kernel module.
Keep the selected backend, module versions, detector versions and module
settings the same as the baseline.

Collect `cat /sys/module/susfs_guard_lkm/parameters/mount_stat` as root. Successful
mount hiding requires `hide=1` and `show_probes=3/3`; the new `backing` line shows
which helpers resolved. Compare exported detector reports and ordinary app
behaviour, then repeat after a soft reboot. Peer-process views and isolated
processes need actual device checks; host fixtures do not simulate Android's
process policy or prove detector results.
