# CP21 redirect statfs phone PASS and redirect mapping follow-up

On 9 October 2026 the user supplied a completed revision-2 redirect statfs
phone PASS. It resolves revision 1's missing Python xattr API blocker. All
three owned destination labels are copied and read back through libc as the
48-byte app SELinux label. The source and destination filesystems differ:
source type `0xf2f52010`, fsid `[65105, 0]`, flags `1062`; destination type
`0x01021994`, fsid `[1283055985, 2787221286]`, flags `4130`.

In two proc scheme-3 cycles, the app reads redirected content and sees the
source filesystem for the destination and redirected descriptors. Root sees
actual backing filesystems. The descriptor opened before ADD retains the
original content. After DEL, a descriptor opened while redirected still reads
the destination, but reports its native destination filesystem again. Fresh
source opens, unrelated controls and error results are preserved. The runner
reports exact original-list restoration, closed descriptors, fixture cleanup
and a returned prompt. Final reverse counters are dpath=12, statfs=10,
maps=0/0/0 and fdinfo=0/0. No mappings were created in that test.

The normalized evidence is
`tests/phone/evidence/cp21-redirect-statfs-phone-pass-20261009.json`.
It records user-supplied output, not an independently observed phone session.
Printed stable fields/content support the result; the compact log omits raw
ABI/spare buffers, explicit proc-fd values, identity receipts and final table
rows. Their successful checks are reported by the runner. Runtime binary
hashes were not independently read. Free-space/file counts are recorded but
not compared exactly. This qualifies the tested native statfs scope; it does
not qualify complete SusFS behavior.

## Next phone runner

Use the already installed and loaded CP21 build. Save the standalone file as
`rmgu-susfs-redirect-maps-test-cp21.py` in Download, then run from ordinary Termux:

```sh
su -c 'cat /sdcard/Download/rmgu-susfs-redirect-maps-test-cp21.py' | python -u
```

The runner reuses revision 2's bounded root calls, exact rule parser, verified
descriptor label copying and owned fixture cleanup. It creates fresh exclusive
app files and two owned files under `/dev`, each sixteen native pages long.
Root verifies ownership before resizing only the new destination files. App
and root baselines, complete label receipts and distinct backing devices are
required before adding the owned scheme-3 rule.

There are six baseline mappings: two source aliases, two destination aliases
and one control from each filesystem. After ADD, two more aliases are mapped
through a fresh source open, whose actual backing must be the destination.
Mapped content is checked at creation; each observation also checks descriptor
content and root's real backing-file identity through the app's proc-fd path.

For all known ranges, the runner compares exact inode/device/path/header bytes
in maps and smaps with full and 127-byte reads. During ADD, destination-backed
app rows must describe the source; source mappings created before ADD remain
native. Root and unrelated controls remain native. After each DEL, active
mappings remain open and must describe their actual destination backing again.
Both full cycles restore the original rule list and release owned mappings,
descriptors and fixture names. No kernel or app sources were changed or rebuilt.

Known failures remove only a confirmed owned rule and retain source evidence.
Unknown root-command outcomes stop further root/control calls. A changed
foreign list or missing ownership receipt refuses destructive cleanup.

## Host validation and limits

```sh
python3 tests/phone/build_redirect_maps_runner.py
python3 tests/phone/test_redirect_maps_runner.py
```

Eighteen checks pass. The workflow uses real host files, mappings and proc
headers with explicit phone credential, namespace, label and control stubs.
Its header effects execute the unchanged C `or_maps_entry`/`or_maps_ret`
callback, UID gate, reverse lookup and buffer replacement. Separate callback
cases run with AddressSanitizer and UndefinedBehaviorSanitizer; LeakSanitizer
is disabled. Capacity guards, root/control gates, missing route delivery,
malformed/duplicate/missing headers, bounded reads, baseline blocking,
publication failure, unknown root outcomes and cleanup refusal are checked.
Both maps-only and smaps-only effect leaks are detected and restored.

These checks do not prove Samsung probe registration, inlined formatter
reachability, live SELinux access or kernel reference lifetime. The new mapping
effects still need phone qualification. Its scope is native AArch64 proc scheme
3 with owned stable mappings. Compat, supercalls, other UID schemes, map_files
reverse identity, concurrent mapping/exec races, retired path-reference release,
unloading and long-run stability remain unqualified.

The preserved module was built from
`0196175b4dbf9ac934aba8d38f1276d4cdcbed3a`; the unchanged app source is
`4cc102e539699ffbba232e2e87f08873fdfe513b`. The archive contains the source
history and baseline module for recovery. It supplies no live module replacement.
