# CP19 native metadata syscall qualification

`rmgu-susfs-kstat-native-test-cp19.py` uses the existing CP19 APK/current boot.
The previous feature runs qualified their stat tools, with newfstatat rewrites,
but fstat/statx rewrite counters remained zero. This runner directly issues
AArch64 newfstatat=79, fstat=80 and statx=291. It checks a descriptor held
before activation and newly opened descriptors, path and AT_EMPTY_PATH forms,
statx basic/inode/size request masks and returned mask preservation. Two
owned inode/size updates must affect app results while leaving root, an
unrelated control, unselected fields and native EBADF/ENOENT behavior intact.

Only the new target rule is added/deleted; there is no global clear. Existing
kstat rows are preserved and compared exactly after removal. Root commands
have bounded waits. Unknown command outcomes or failed restoration retain
the original list and observations and stop further control commands.
Native buffers have guards outside their real ABI payload. No invalid pointer
or policy/mode change is used to gain access. Missing required native baselines
stop before adding a rule. The ABI decoder is checked against the retained
AArch64/256-byte statx offset contracts and real Linux native calls on the
host. Modeled spoof expectations test assertions/control flow, not the phone.

21 focused host cases pass. No kernel/app implementation or APK was changed;
no private GitHub push occurred. Phone native fstat/statx qualification is
pending. This runner qualifies inode/size only; compat processes, other spoof
fields, maps identity rewriting and redirect statfs remain separate scopes.

```sh
su -c 'cat /sdcard/Download/rmgu-susfs-kstat-native-test-cp19.py' | python -u
```
