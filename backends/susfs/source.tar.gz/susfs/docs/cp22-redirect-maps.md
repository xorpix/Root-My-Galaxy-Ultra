# CP22: redirect maps identity on direct listing callbacks

The CP21 phone challenge identifies a real, narrowly scoped identity leak:
all four destination-backed aliases show the original source pathname alongside
native destination device/inode in app maps. App smaps rewrites all three.
Root/control views and held mapping restoration after DEL retain their tested
behavior. The supplied run stops after the first cycle and retains evidence;
no second-cycle or explicit cleanup PASS is claimed.

Kstat received direct show_map/show_smap probes at CP21, but redirect identity
still used show_map_vma. This is a second use of the same formatter reachability
gap and should have been audited together. CP22 moves redirect identity to the
actual maps/smaps listing callbacks and avoids a nested formatter probe.

Each entry captures the buffer and start count. The return handler validates a
successful show, unchanged buffer, exact backing inode/device and the new
header boundary. It edits only that record, preserves metrics and unrelated
rows, matches the exact registered pathname or its deleted suffix, and forces
a seq retry when growth needs more room. Both probes register as a pair;
partial registration rolls back, and later activation resets retained probe
addresses/flags. Read-only redirect_map_stat reports both route counters and
registration state without changing the existing proc control/diagnostic format.

Validation uses actual production C with explicit host kernel/dispatch stubs.
The CP21 helper-only source fails the inlined-maps challenge; CP22 passes all
12 route/lifecycle cases normally and with ASan/UBSan. The phone runner's 18
checks pass, including full/small aliases, rule restoration and actual callback
formatting. Six retained kstat route regressions pass. Eight retained statfs
and 13 feature callback sanitizer cases pass. Pinned real-header checks and
ARM64 artifact checks bind the compiled callback types and objects to the new
module. These are host/build results; phone effects remain pending.

The standalone CP22 runner requires the new checkpoint route marker before
fixture or feature writes. It keeps pre-ADD source/destination aliases, creates
fresh redirected aliases, checks full/small maps/smaps in app/root, checks
restoration with active mappings held, and performs two owned activation cycles.
It preserves the previously verified descriptor label copying.

The device finish line is docs/bzig-acceptance-checklist.md. Future qualification
closes those five blocks; a new test is not an automatic reason for a new build.
