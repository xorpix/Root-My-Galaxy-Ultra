# Readlink LSM consistency, 2026-10-27

Port of upstream `b69dee412aac54cdf99832412de3b4758118a1eb` onto Samsung source
`b5c994d8ba9638afb1f0b3e71a5e450d535a8077`.

The Samsung `do_readlinkat` entry wrapper already checks the resolved inode
before the plain-file EINVAL gate and `security_inode_readlink`. Keep that
phone-tested route. This port adds upstream's `inode_readlink` LSM check for
callers reaching the security hook directly: a registered target hidden from
that caller gets ENOENT before SELinux can return EACCES.

The new callback uses the existing Samsung inode identity, owner, KernelSU
umount and control-node gates. It enters and leaves the callback lifetime
tracker on every path, including a sleeping original SELinux call on 6.12.
Unhidden objects retain the original SELinux return value; older kernels
continue through the existing LSM chain. Hook registration participates in
the path layer's mandatory rollback and normal unload arrays.

The proc/sysfs listing gains `readlink: lsm_enoent=N`. It counts only denials
from this LSM hook; the earlier syscall-wrapper denials do not increment it.
There is no upstream inode-operation readlink copy in the Samsung fork, so
the upstream i_op hit/arm-failure fields are not introduced.

Regression coverage compiles the production gate, callback and lifetime
macros for both list and static-call dispatch, with hidden/visible paths,
SELinux errors, ownership and umount exemptions, root/control-node policy,
procfs identity aliases, pending rules and sleeping pass-through calls.
Runtime negative controls reproduce the errno leak and a missing lifetime
exit. The syscall-entry test also checks that hidden plain files and symlinks
return ENOENT without reaching a modeled SELinux denial.

The DDK workflow and real-header signature tests include `inode_readlink`.
Automated checks do not establish phone validation for this revision.

## Validation

- Android16/6.12 DDK build passed with clang-r536225 and CFI enabled;
  module BTF generation omitted as in the existing build.
- All 24 native host runners passed in plain and ASan/UBSan modes (48 runs).
  The new LSM runner exercises 42 cases and three runtime negative controls
  per mode. Existing native tests that require Clang were run with the DDK
  compiler. LeakSanitizer cannot inspect /proc task lists in this environment;
  its process-enumeration check was disabled while ASan/UBSan remained enabled.
- All 13 real-header identity/type cases passed, including correct readlink
  type acceptance and wrong return/const-pointer rejection.
- Stripped module size: 546,152 bytes (previously 545,232).
- Stripped module SHA-256:
  `3374a5b721f2abdce2f5b993cd424e6c25e30f02c57215a0ce9c455c560a1fa8`.
- All 136 undefined kernel imports are identical to the currently bundled
  module; no imports added or removed.
- No kernel module was loaded or exercised on a phone during this validation.
