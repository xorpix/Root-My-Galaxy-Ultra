# Samsung modules callback hardening

Base native source: `3a65e96f3694f19abd7feb1f905e4794f48d5aee`.
Motivation: upstream `inforcqb/susfs4ksu-for-lkm` PR #200.

The previous Samsung module always registered `m_show` by name. A duplicate
name could select another callback, whose second argument was then read as a
module list entry. Upstream removes the unvalidated fallback; this adaptation
also preserves the entry-registration behavior which passed the Samsung phone
tests. It does not restore the live `m->op == modules_op` gate that regressed
root module hiding on S948B/BZIG.

The loader resolves and validates `modules_op.show` using the existing
core-symbol/body and CFI-stub checks. The by-name probe remains inert while the
kernel registers it. Its actual resolved address must equal the verified
callback entry, or follow just its BTI landing instruction; an adjustment past
PAC or any other instruction is refused. A failed check unregisters the probe
and leaves module-row filtering inactive with a warning. No unverified
name-only filtering is enabled. Teardown closes callback admission before
unregistering the probe.

After admission, the module name is copied into a fixed-size local buffer
through `copy_from_kernel_nofault`. Pointer underflow/overflow, unreadable data
and names without a terminator are rejected before the name matcher runs.

The full host deck passes 66 runner executions across 34 suites. New production
extraction tests cover registration races, duplicate names, failure cleanup,
CFI/BTI entry handling and the Samsung regression; three deliberately broken
implementations are rejected. These results are not device validation.

The existing symbol resolver, mount implementation, syscall wrappers, loader,
root backends and SusFS ABI/version remain unchanged. A candidate APK must be
phone-tested before this source is treated as a qualified replacement for the
currently shipped module.
