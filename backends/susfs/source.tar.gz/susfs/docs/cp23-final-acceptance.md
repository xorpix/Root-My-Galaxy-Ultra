# CP23 final BZIG acceptance run


## Revision 2: complete-snapshot preflight limit

The reported revision-1 run stopped before fixtures with `Path list is
truncated`. The user confirms that Brene deliberately spoofs app uname; root
still checks the native kernel separately. Both CP23 path getters are bounded
to PAGE_SIZE in the kernel. Their omitted rows cannot be recovered by larger
Python reads or by switching from proc to sysfs. The rules remain intact.

Revision 2 records this as BLOCKED and saves available raw fragments, sizes,
hashes, interface errno, root kernel/boot, CP23 diagnostics and app uname to
`~/rmgu-cp23-preflight-*.json` (0600). It sends no fixture controls, starts no
observation and leaves A5 unqualified. An unknown warning remains a failure.
The report records visible rows only; it never invents a total rule count.
This is a runner diagnostic correction, not a repair of the kernel listing
limit. Do not clear existing rules, disable Brene or rerun solely to reproduce
the known blocker. A complete kernel listing interface is required to complete
the original A5 check with the current rule set.

Optional read-only collection, after replacing the extracted archive files:

```sh
su -c 'cat /sdcard/Download/RMGU-SUSFS-CP23-final-tests/rmgu-susfs-acceptance-test-cp23.py' | python -u - --preflight
```

This command starts no fixture even when a complete snapshot is available.
The original regression/observation commands below remain applicable only
when their baseline requirements are met. Kernel/APK and frozen fixtures are
unchanged. Twenty-five CP23 host checks and sixty retained checks pass.


The reproduced LOOP panic is closed within the tested phone scope. The user
reported a PASS from the focused CP23 runner and a completed PARTIAL PASS from
native-control revision 4. Its remaining optional non-su UID-0 reader was denied
in baseline; it did not expose another feature failure. Both runs confirmed
owned cleanup and exact original rule restoration. No additional LOOP or native
control run is required for this repair.

This package resumes the existing A5 closure block. It does not change the
kernel, APK, feature set or the frozen eleven-fixture regression list. The
older CP22 native and acceptance entry points remain suspended. The new final
runner refuses a missing CP23 credential marker, a different native kernel,
pending resolver work, active caller credentials or a disabled app-only gate
before starting fixtures.

The runner embeds the complete fixed fixture manifest. The root reader compares
the extracted manifest and every script's exact size/hash against that embedded
copy. The retained fixture files have the same bytes as the CP22 closure archive.
Its own root dispatcher permits only state reads, source reads, module inventory
and the existing owned module-name assertion. It does not dispatch native LOOP
or the broad native-control workflow.

The A2 assessment first records app/root errno values for /proc/modules,
/proc/kallsyms and /sys/module. A permission-denied baseline is retained as
UNQUALIFIED, before controls. If the entire baseline is available, the existing
selected-module/control assertions run. An unexpected blocker or failed effect
stops the suite; a denied baseline is not counted as module hiding evidence.

The eleven retained fixtures run serially. Their full logs and inputs remain in
the app's private home. Every successful test is followed by a complete root
snapshot comparison: rules, settings, native kernel, boot identity and CP23
credential state must match the initial snapshot. Diagnostic counters are
excluded from settings equality. The existing mount fixture's raw numeric mount
ID is not restored; its previously documented limit remains. New failures,
unexpected partial scopes, timeouts or changed state stop subsequent fixtures.
The parent does not launch additional cleanup controls after an unknown child
outcome; the retained fixture owns its normal cleanup.

A successful regression creates a receipt and starts one observation window.
The user must use the phone normally for at least 30 minutes, then explicitly
report clean, issue or unobserved. The finisher checks the original boot,
unchanged settings and the saved complete regression receipt. Time alone does
not qualify a result. No race stress, live unload or long-run claim is added.

## Phone commands

Keep the currently loaded CP23 activation. If it has been cleared by a reboot,
activate the existing RMGU · SusFS Test 23 APK. Do not load an older checkpoint
or unload/replace a live module.

Extract RMGU-SUSFS-CP23-final-tests.zip in Download so the script is at the exact
path below. From ordinary Termux, run:

```sh
su -c 'cat /sdcard/Download/RMGU-SUSFS-CP23-final-tests/rmgu-susfs-acceptance-test-cp23.py' | python -u
```

After the regression passes, it starts the observation window. Use the phone
normally for 30 minutes. If no new issue occurred, run:

```sh
su -c 'cat /sdcard/Download/RMGU-SUSFS-CP23-final-tests/rmgu-susfs-acceptance-test-cp23.py' | python -u - --finish-observation "$HOME/rmgu-susfs-cp23-final/observation.json" --outcome clean
```

For a new issue, replace the final arguments with
`--outcome issue --notes "what happened"`. For an unobserved window, use
`--outcome unobserved`. A short clean window remains blocked and can be finished
later; a saved completed result is never overwritten.

Do not repeat the suite merely because A2 remains permission-blocked. Logs and
receipts are kept at `~/rmgu-susfs-cp23-final/`. The runner refuses to overwrite
an earlier closing run. On failure, retain that directory and the printed
terminal output; no new acceptance area is added automatically.

## Verification and limits

Twenty-five CP23 host checks cover candidate guards, exact fixture hashes, module
baseline classification, actual child exit handling, stop-on-failure and
explicit observation outcomes. All sixty retained closure checks pass. Syntax
checks pass for all eleven fixtures and the generated standalone runner.
These are runner checks, not new Samsung execution results.

The loaded candidate remains CP23: SusFS source
730855fc8036a8a8dd56695c53243559f076ee72, app source
fffe1753a44ebe3a2922e2d529354f6ee5d15fdc, module SHA-256
18af3af8a37f2d9c4c1f384ba77b60b0dc49a595007f9a666aab7aa5f6ea789a.
The closure source bundle adds only runner, receipt and documentation changes;
the kernel sources are identical to CP23. The APK is supplied in the original
checkpoint 23 archive and does not need replacement for this run.

When the final regression and declared observation pass, A5 closes within this
frozen native BZIG scope. Module baseline blocks, mapping follow/open permission
blocks, the optional non-su UID-0 baseline, unavailable app bootconfig/emitted AVC
effects, compat, other kernels, arbitrary races, live unloading and long-run
stability retain their explicit limits. This is not a claim that every SusFS
effect or every device has been fully validated.
