# CP21 redirect statfs runner revision 2

The 9 October 2026 phone output from revision 1 stops during owned `/dev`
fixture setup with `AttributeError: module 'os' has no attribute 'getxattr'`.
It reports zero original redirect rules, no feature controls attempted, a root
cleanup call and a returned prompt. No statfs baseline or active effect test is
reached. The reported BLOCKED result identifies a runner portability bug;
redirect statfs remains unqualified. The prior CP21 maps identity PASS and CP20
native metadata passes retain their established scopes.

Revision 2 calls typed libc `fgetxattr` and `fsetxattr` through ctypes. It copies
the source app labels through open descriptors into the exclusive owned
directory and two files, preserving opaque bytes and reading each label back.
It checks the source labels again, uses a bounded guarded read buffer, closes
setup descriptors and returns known partial ownership receipts for cleanup.
The workflow requires complete successful label receipts before it checks app
access, distinct backing filesystems and baselines or adds a rule.

The existing qualification remains two scheme-3 cycles of native statfs/fstatfs,
fresh/held and proc-fd views, content provenance, root/control/error preservation,
exact original rule restoration and owned cleanup. Only the confirmed owned row
may be deleted; unknown root outcomes stop all further root/control calls.
There are no kernel or app source changes, rebuilds, mount operations, SELinux
policy edits, feature-flag changes, global rule clears or module unloads.

The new native-xattr suite passes 12 checks. It reproduces r1's missing API error
with filesystem mutations stubbed, then runs actual libc xattrs and actual r2
fixture functions while the Python xattr APIs are removed. It uses owned host
`user.*` attributes as explicit stand-ins, without changing host SELinux labels
or root-level `/dev` objects. It covers exact opaque bytes, descriptor closure,
read limits/errors, guard/readback rejection, pre-creation source checks,
partial denial cleanup and preservation of an existing destination.
The retained 22 runner checks pass, including incomplete label receipt blocking.
All 13 Android NDK AArch64 ABI static assertions and both descriptor-xattr
function-prototype checks compile successfully. These host results do not
qualify live Android SELinux label copying or kernel statfs effects.

Use the already installed and loaded CP21 build. Save the corrected standalone
runner with its revisioned filename to Download, then run from ordinary Termux:

```sh
su -c 'cat /sdcard/Download/rmgu-susfs-redirect-statfs-test-cp21-r2.py' | python -u
```

The retained app evidence from r1 is
`/data/data/com.termux/files/home/rmgu-susfs-redirect-statfs.ie2q3do2`.
The printed cleanup has no reported helper error; source control flow supports
successful owned device-directory cleanup, but no receipt or independent
filesystem inspection was supplied. Leave that evidence available; r2 creates
a fresh exclusive fixture and does not need to alter the retained one.

The unchanged local CP21 module SHA-256 is
`93d18d6c66d605d7ad63d52eaf80fd990f1caf8d2cb2698d2e0d16d06ddf0bc4`;
APK SHA-256 is
`842c3e5224d6d3cadc0a36e7becf91cd68fa25b6a95121050e5439743f0b84f2`.
Runtime phone binary hashes were not independently read. Phone qualification
of r2, compat/supercalls/other UID schemes, redirect maps identity, concurrency,
retired-rule reference release, unloading and long-run stability remain open.
