# CP22 freeze/reboot: next step

Stop the native control test and the regression/observation suite. Leave SusFS
off after the reported reboot. The updated native and acceptance entry points
stop before any root operation. This is a test suspension, not a kernel repair.

The terminal photo reaches the first control call registering the still-absent
owned `loop` path (`0x55553`). The ordinary PATH add/hide/root-read/remove and
restoration checks have completed. The optional non-su reader's earlier EACCES
was reported and handled; execution continued after it. The final control call
contains both a syscall and a configuration snapshot, so the exact instruction
where the device froze is not established.

## Collect existing evidence

Save `rmgu-susfs-cp22-crash-collect.py` in Download. From ordinary Termux:

```sh
python -u /sdcard/Download/rmgu-susfs-cp22-crash-collect.py
```

If Termux cannot read Download, run `termux-setup-storage` and grant its normal
Android storage permission, then use the same command. This does not change
SELinux, kernel settings or test fixtures.

The collector copies surviving `$HOME/rmgu-cp22-root-*` helper logs and native
`fixture.json` journals; it also reads accessible boot identity/reason, pstore,
last_kmsg and current-boot dmesg. It prints `EVIDENCE ZIP:`. The ZIP is copied to
Download when that directory is writable; otherwise it stays in the printed
Termux home directory. Upload that ZIP. The manifest records source paths,
access failures, truncation, hashes and helper timeouts. Raw bytes are retained.
Per-file reads are capped at 2 MiB, each environment reader at 20 seconds, and
the retained evidence at 32 MiB. Original logs, fixtures and records stay intact.

It uses no `su` by default. Only if `su` is already working independently of
reactivating SusFS, the same command may be run with `--root` to read protected
crash records. Do not run the root exploit or activate/load CP22 solely for this
collection. The optional read process accepts no feature commands or user
filenames; completed output survives a timeout.

If protected crash records are unavailable, a computer with already-authorized
ADB can collect an Android bug report without loading SusFS:

```sh
adb bugreport rmgu-cp22-crash-bugreport.zip
```

A bug report can include unrelated device logs; the focused collector is the
first choice. Do not reproduce the freeze to obtain a new report. Do not clear
pstore, delete old fixtures, replay old-boot cleanup or unload the live module.

## What the source establishes

At kernel pin `647ae2d01f609930d02df62de74f1f080821d8df`, the absent LOOP handler
publishes a pending rule, takes a caller credential reference, immediately runs
a resolver with credential override and VFS lookup, then schedules retries and
writes its reply. The root helper subsequently reads configuration snapshots.
The screenshot matches this phase but is insufficient to select a credential,
lookup, locking, workqueue or readback repair. No speculative kernel patch or
new APK is supplied as a fix.

A4 is now a known target crash blocker. A5 is paused. Earlier scoped stat,
redirect and mapping passes remain evidence with their stated limits. The five
acceptance blocks remain fixed; this defect belongs to A4.

The next repair must use the retained crash stack/reboot reason and exact target
ABI. Host tests confirm the collector's byte preservation, symlink handling,
timeout output retention and the two suspended entry points; they do not
validate Android execution or fix the reported kernel crash.

Primary documentation:
- [Linux ramoops: persistent records and reading pstore](https://docs.kernel.org/admin-guide/ramoops.html)
- [Android bug reports](https://source.android.com/docs/core/tests/debug/read-bug-reports)
