# CP20 native metadata pass and remaining-field follow-up

The 9 October 2026 revision 3 phone run passes both owned inode/size cycles.
Baseline target inode/size are 879406/19; control values are 797465/20. Active
app values become 100879407/4115 and 100879408/8211 through all eight tested
methods. Root and the unrelated control remain native. Both removals restore
every method, the final table is empty and cleanup returns the shell prompt.
Statx reports rw=8; fstat and newfstatat each report rw=4. These are cumulative
diagnostics; actual returned values establish the tested effects.

This qualifies native AArch64 inode/size on the reported BZIG setup, including
held/fresh descriptors, path and empty-path calls, statx request masks, two
activations, root/control and error preservation, exact restoration and cleanup.
The normalized phone record preserves these observations without claiming an
independently observed session or independently read APK/module hashes.

The new runner keeps CP20 loaded and adds no kernel or app changes. Its three
owned-rule profiles cover all twelve proc-static override components: inode,
encoded device, nlink, size, atime/mtime/ctime seconds and nanoseconds, blocks and
block size. Two full profiles include large device minors, 64-bit inode/size/
block values, unsigned 32-bit nlink and signed timestamp seconds beyond 32 bits.
A selected-field profile leaves inode, size, block size and unselected timestamp
components native. It compares advertised native fields and unchanged payload
bytes, including padding, masks, attributes and unrelated metadata.

Each profile is tested through held/fresh fstat, path/empty-path newfstatat and
eight statx forms, including held descriptors and inode/size/nlink/time/block/
zero request masks. Full basic-stat support is required in preflight. Request
masks are interpreted with the returned field mask, preserving the production
contract. Actual syscall results decide the outcome; counters remain diagnostic.

Only an owned fixture path is added and deleted. Published values and flags are
verified exactly; every unrelated rule must retain its exact row and order.
Rules are removed between profiles. Root commands remain bounded, and an unknown
command outcome stops further controls and retains recovery observations. No
actual large file is allocated and no real file timestamps/device are changed.

All 22 new host checks and 33 retained runner checks pass. The new tests exercise
actual host native syscalls, independent UAPI-buffer workflow/error models and
the production parse_override/static-add/proc-show functions compiled with host
kernel API stubs. All three command profiles round-trip through production code
with exact values and flags 0xfff, 0xfff and 0x666. Host checks do not qualify the
new fields on Samsung; a completed phone run is still required.

Save `rmgu-susfs-kstat-fields-test-cp20.py` in Download and run from ordinary
Termux with the existing CP20 module active:

```sh
su -c 'cat /sdcard/Download/rmgu-susfs-kstat-fields-test-cp20.py' | python -u
```

Compat processes, supercall payloads, maps identity rewriting, redirect statfs,
concurrency, previously opened proc descriptors, unloading, long-run stability,
other firmware/variants and emitted AVC context remain separate qualifications.
