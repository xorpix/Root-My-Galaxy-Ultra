# Checkpoint 19: direct map_files metadata

Target: SM-S948B, S948BXXS4BZIG, kernel
`6.12.69-android16-6-pb4d3caf-abogkiS948BXXS4BZIG-4k`.

## Trigger and resulting behavior

The CP18 revision 7 phone test warmed an owned mapping's proc symlink before
enabling its inode/device rule. Directory enumeration and readlink hid the
mapping, but `lstat` and `open(O_PATH | O_NOFOLLOW)` still succeeded with the
same proc symlink identity. The run completed restoration and cleanup.

CP19 also checks `map_files_d_revalidate` and `proc_map_files_lookup`. Cached
hidden entries return `-ENOENT`; RCU revalidation returns `-ECHILD` without
sleeping or taking references. Exact-name lookup checks the backing inode/device
under the same mmap read lock used for native symlink instantiation. A hidden
mapping is rejected before instantiation. Native permission checks, owner and
SELinux refresh, root access, and unrelated file identity remain in place.

All five map_files entry probes use the retained CP17 entry diversion route.
The native callback tables remain unchanged. Installation validates their typed
entry addresses, rolls back partially installed probes on failure, and publishes
no rule unless every required hook is ready. Teardown drains diverted callbacks
before module text can be released.

The new `map_metadata` diagnostic identifies checkpoint 19 and separates cold
lookup, cached revalidation and RCU retry counters. The phone runner refuses
older loaded modules before making fixture/rule changes. Its revision 8 covers
warmed entries and fresh alias range names whose first procfs access is lstat,
followed by O_PATH and existing followed-link operations. Different alias lengths
prevent range-name reuse between phases. Aliases close before directory churn.

## Validation

- The actual production map_files header passes 46 host cases with ASan/UBSan;
  12 deliberate defects are detected. New cases exercise cached/cold hiding,
  device separation, visible instantiation, permission/interruption errors,
  RCU behavior, rule removal, partial installation and sleeping teardown.
- 27 retained map/rule/memory host cases pass with ASan/UBSan.
- 21 real DDK map_files callback type checks pass, including six positive and
  negative metadata callback cases. LSM and identity type checks also pass.
- The revision 8 phone observer and assertion/cleanup/timeout suite passes
  22 host tests. Its Linux observer results are recorded separately from modeled
  phone expectations where the host restricts process_vm_readv.
- The module builds with the pinned prepared Android 16 6.12 DDK and Android
  Clang r536225/19.0.1. ARM64 KCFI review compares incoming callback types to
  real-header fixtures, retained CP18 types and the pinned DDK vmlinux.
- The app's 819 JVM tests pass, including nine SusFS tests. Final APK packaging
  checks record the signing result, isolated CP19 identity, shortcuts and exact
  module/helper/profile hashes in the accompanying evidence.

The candidate requires phone validation. Host stubs and the DDK vmlinux are not
the live Samsung kernel. The retained empty module version table does not
qualify Samsung CRCs. App followed-link operations that already fail in the
baseline remain unqualified; limited unrelated alias churn does not qualify
arbitrary hidden-target remap/exec races or long-run stability. AVC emitted
target-context rewriting and earlier unqualified scopes remain open.

## Run

Install `RMGU-1.1.8-susfs-cp19.apk`, fully reboot, open **RMGU · SusFS Test 19**,
grant root and activate its module. Then, from ordinary Termux:

```sh
su -c 'cat /sdcard/Download/rmgu-susfs-map-test-cp19.py' | python -u
```

Keep the existing feature/path/mount scripts available for subsequent regression
checks. This checkpoint does not request another unchanged AVC audit trial.
