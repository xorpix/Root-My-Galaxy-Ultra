# Samsung path listing: Test4

Test3 phone evidence supplied on 2026-10-17: 200 non-root `/proc`
listings left `app_iterate=58 proc_iterate=0 actor=302 hidden=0` unchanged;
`susfs_path` remained listed. O_PATH and readlink each returned ENOENT and
incremented their own denial counter. This identifies missing directory
coverage; it does not establish the cause of the bypass inside the vendor
kernel. Earlier credential and cross-procfs identity corrections remain.

Test4 also diverts `__arm64_sys_getdents64` (native 61 and AArch32 217) and
`__arm64_compat_sys_getdents` (AArch32 141). Each body calls the filtered
iterator explicitly, so an inlined iterate_dir at the original syscall site
cannot bypass it. Kernel filldir64/compat_filldir still handle record
validation, user access, capacity, signals and compat overflow. The syscall
bodies preserve the native final-cookie, partial-return and error sequence.

The file reference uses fget/fput. It avoids relying on the private fdget_pos
return ABI, which changed during the 6.12 series. The acquired reference makes
the native position-lock condition equivalent to FMODE_ATOMIC_POS. Its mutex
is held through iteration and the final cookie write and is released before
fput. No new module imports are needed. The existing diversion counter spans
the entire syscall body and is drained during removal.

The bounded report is revision 4. `syscall_armed=2` reports both new entry
probes; `sys64` and `sys32` report actual replacement calls, not just probe
registration. A 64-bit Termux test is expected to advance sys64 and
proc_iterate; it does not qualify the on-device 32-bit path.

Host checks reproduce an unfiltered listing when the iterate entry is
bypassed, then verify the production syscall replacements remove hidden
entries before the emitter. They cover buffer tails, hidden-only EOF,
short-buffer continuation, final-cookie faults, permissions, invalid/O_PATH
descriptors, signals, compat overflow, argument truncation, position locks,
reference balance, every probe-install rollback, and a diverted syscall
held across removal. ASan/UBSan pass. Production actor/record layouts and
syscall wrapper types are checked against the pinned real fs/readdir.c;
wrong count-width and wrong compat-cookie controls are rejected.

Phone acceptance remains pending. Install the separately signed Test4 APK,
open it, fully reboot, activate root/SusFS, then run the non-root Python
before/after test. Require revision 4, syscall_armed=2, Listed=False, and
ENOENT for both O_PATH and readlink. Preserve existing rules. Also check
ordinary apps/modules, root before unlock and soft restarts before stable
release. Test4 does not refresh the already matched backend artifact.
