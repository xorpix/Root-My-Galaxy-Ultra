# RMGU SusFS BZIG acceptance checklist — CP23 closing stage, 9 October 2026

The reproduced native LOOP panic is closed within the tested phone scope.
The user's CP23 focused runner passed after the registering helper exited;
the background resolver completed and released its caller credential copy.
The previously panicking native-control revision 4 also completed with exact
cleanup. Its optional non-su UID-0 reader remains baseline-blocked by EACCES.
The repair needs no additional LOOP/native-control test round.

Target: SM-S948B, S948BXXS4BZIG, native AArch64 on
`6.12.69-android16-6-pb4d3caf-abogkiS948BXXS4BZIG-4k`.

The finish line remains the frozen A1–A5 list. There is one closing run left:
the already declared eleven-fixture final-candidate regression followed by one
30-minute ordinary-use observation. A2 permission-denied baseline effects stay
explicitly unqualified. Passing the closing run adds no mandatory coverage area.
A concrete defect in this agreed device scope can still require a repair.

## Evidence already accepted within its stated scope

| Area | Current evidence | Limits retained |
| --- | --- | --- |
| Path hiding | App stat/read/listing hiding, root access, removal and cleanup passed | Owned fixture and tested paths |
| Mount hiding | Three mount tables, root exclusion, fdinfo/statx ID consistency, restoration and cleanup passed | Owned bind fixture, tested namespace; original raw numeric ID was not restored |
| Native kstat | All 12 override components, wide values, signed times, masks, held/fresh descriptors, root/control/error preservation passed at CP20 | Proc static-rule interface on native AArch64 |
| Kstat maps identity | Maps/smaps aliases, full/small reads, wide/selected identities, native stat consistency, root/control/header preservation passed at CP21 | Stable owned mappings |
| Mapping hiding | Maps/smaps, rollup, pagemap, known-range metadata, directory walks, proc memory and process_vm_readv passed at CP19 within available scopes | Baseline-blocked app follow/open reads remain unqualified |
| Mapping lifetime | Serialized target remaps, unrelated same-address control reuse, owned exec and restoration passed at CP19 | No concurrent mapping/exec race or previously opened proc descriptor qualification |
| Uname and log controls | Native defaults, two updates, invalid-input rejection, both log interfaces and exact restoration passed at CP17 | Tested device/interfaces |
| Open redirect | App content, root exclusion, descriptor pathname/inode disguise and restoration passed | Tested owned source rule and UID scheme |
| Redirect statfs | Distinct filesystems, stable native statfs/fstatfs fields, held/fresh and proc-fd views, root/control/error checks and two cycles passed at CP21 | Scheme 3; volatile free-space/file counts not compared exactly |
| Bootconfig and AVC controls | Root bootconfig changes/native restoration and control roundtrips passed at CP18 | App bootconfig reads denied in baseline; emitted AVC context effect not observed |

## Frozen closure blocks

| ID | Current status | Finish condition |
| --- | --- | --- |
| A1 | CLOSED — CP22 redirect maps phone PASS | Both routes, aliases, full/small reads, root/controls and exact rule cleanup passed |
| A2 | UNQUALIFIED — app/root module inventory baseline denied in the reported CP22 run | The closing runner records the exact interface errno breakdown. A denied baseline leaves effects unqualified before controls; if the full baseline is available, existing owned module/control assertions run |
| A3 | CLOSED — observability investigation with retained limits | Root/control passes stand; app bootconfig baseline was denied and no tagged AVC events were emitted; no repeated absent-audit challenge |
| A4 | CLOSED within available native scopes on CP23 | Focused LOOP PASS and native-control revision-4 PARTIAL PASS; optional non-su UID-0 EACCES baseline remains unqualified; cleanup and original-state restoration reported |
| A5 | BLOCKED — CP23 original path-rule list is truncated before fixtures | A complete original-rule snapshot is required before the fixed eleven fixtures and one declared 30-minute observation. CP23 currently exposes only one page of path rules; the reported truncation leaves A5 unqualified |

## Final-run package

Use `RMGU-SUSFS-CP23-final-tests.zip` with the existing CP23 activation. The new
runner checks the CP23 native credential-copy marker and native BZIG kernel,
requires no pending work/live caller credentials and verifies every retained
script against an embedded fixed manifest. Full logs and receipts stay in the
Termux home. It stops on a failure, unexpected partial scope, timeout or changed
configuration. The previous CP22 native/acceptance entry points remain suspended.
No kernel/APK replacement is made for this stage.

After the eleven-fixture regression passes, the runner starts the observation
window and prints the finish command. Elapsed time alone is not a pass. A reboot,
changed rules/settings, reported issue or unobserved window cannot qualify A5.
A2 permission denial is neither a successful hiding assertion nor a new kernel
failure; it is retained in the final report.

The latest phone evidence is recorded in
`cp23-loop-native-phone-pass-20261009.json`, transcribed from the user's pasted
output. The device receipt itself was not uploaded. The new closing runner has
25 passing host checks and the 60 retained closure checks also pass. These are
runner checks; the CP23 final regression/observation have not yet run on the phone.

## Release scope

When A5 passes, this frozen native BZIG functional acceptance closes with its
explicit unqualified effects. We will not describe inaccessible/unobserved
module, app bootconfig or emitted AVC effects as fully tested. Other models and
firmwares, AArch32 compat, arbitrary concurrent races, previously opened proc
mapping descriptors, live unloading and long-run stability remain separate
qualification work; they do not silently extend this checklist.

Features remain implemented. This list controls verification and claims, not
feature removal or gating. Preserve original settings/rules and remove only
owned fixtures. Do not unload/replace the live module. Reboot before switching
activation checkpoints. No private GitHub push is required.

## Reported CP23 panic-closure evidence

Boot `c96a7cc9-ce81-4335-bddc-d17ecbf4b47b`, Termux reader UID 10362.
The focused native LOOP replied syscall=0/errno=0/reply=0 with preserved guards.
After helper PID 24794 exited, one background tick/walk resolved the target;
`pending` and live credential copies returned from 1 to 0. Ordinary app stat/read
returned ENOENT; root access remained. Owned DEL/cleanup restored the original
self-protect rows. Native-control revision 4 completed PATH/LOOP/MAP, native
queries/errors, static/dynamic kstat and redirect schemes 0–4 in available scopes,
then verified cleanup. Its optional non-su UID-0 baseline EACCES remains explicit.
These results close the reproduced regression without a new kernel checkpoint.

## Final preflight blocked with the current configuration — 9 October 2026

The user ran CP23 final acceptance revision 1. It stopped at the first root
state read with `Path list is truncated`; no fixture or feature-control write
was reached. The app uname was `6.12.69-android16-7-g35704527-ab55361754`;
the user confirms Brene deliberately spoofs uname and reports it works so far.
That app value is informational. The separate native root kernel guard precedes
the failing path parser. This is not a new uname mismatch or a reproduced panic.

Source review confirms both `/proc/susfs_path` and the `hide_list` sysfs getter
use `sus_path_format_list(..., PAGE_SIZE)` and print a truncation warning when
their page fills. The rules remain intact; their omitted tail is not available
through another complete CP23 listing interface. Whether Brene added particular
hidden rows is not established by the supplied output. Clearing foreign rules,
ignoring truncation or claiming exact full restoration from a prefix would
violate this checklist. Keep the current settings and rules.

Final-run revision 2 reports this condition as BLOCKED and retains a private
read-only JSON report with both available listing fragments, root native kernel,
boot, CP23 credential diagnostics and app uname. It launches no fixtures or
observation window in this state. `--preflight` collects state only. Do not rerun
to reproduce the known blocker. A5 stays unqualified until a complete original
path inventory is available; no completed acceptance or module/APK repair is
claimed. All 25 CP23 runner checks and 60 retained checks pass on the host.
The frozen eleven fixture files, kernel and APK are unchanged.
