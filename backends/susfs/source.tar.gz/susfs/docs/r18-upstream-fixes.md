# Samsung SusFS 2.3.0: selected R18 fixes

Base: the phone-tested Samsung mount fix, `66c69ba56183ac4d467cabaef44ed198632cc4ac`.
Upstream reference: `inforcqb/susfs4ksu-lkm`, tag `v2.3.0-r18`, resolved on
2026-10-12 to `4636014b5f9e043007733490d6fd4c05129454e3`.
This is a selective port onto the Samsung implementation, not a replacement of
the Samsung kernel integration with the upstream tree.

## Changes

- Clear dropped directory records beyond the returned length for native and
  AArch32 listings. Clear hidden-name tails in the all-hidden placeholder, keep
  that placeholder nonzero in length so the next chunk remains reachable, and
  scrub the tail after a rewrite that stops with a complete prefix. Count each
  failed rewrite/scrub event once.
- Adapt the upstream scrub to the actual Android 16 `sys_exit` tracepoint:
  keep page faults disabled through every user-buffer mutation. The pinned
  `include/linux/tracepoint.h` disables preemption around callbacks, so the
  upstream suggestion to enable faults for the final scrub cannot be used here.
  A failed no-fault scrub is reported; full raw-byte hiding is not claimed for
  a buffer that becomes inaccessible during rewriting.
- Initialize redirect entries before increasing the reader-visible count.
  Preserve immutable retired path references and the existing reader barriers.
  Refuse a replacement at capacity before retiring the working rule.
- Close re-registration during final unload under the same locks as arming:
  redirect uses `or_lock`, AVC uses its existing configuration lock, and kstat
  maps/smaps uses a separate lifecycle mutex. Uname arming is serialized and
  retryable after registration failure. Reset probe addresses and disabled
  flags before retrying forward/reverse redirect registration.
- Port subtraction-based ELF section bounds checks into the Samsung loader,
  retaining its complete-vermagic replacement and kptr restoration behavior.

Relevant upstream changes include `60349c7`, `191339d`, `ea35c35`, `f531327`,
`be6bd75`, `f69aca5`, `b2b7f59` and `3cd45a9`.
The Samsung map management already serializes arming, removal and teardown and
closes admission with `map_ready`; the native statx device matcher and full-width
device rewriting already implement the intended statx fixes. Pending-path rules
already own separate credential references. Those implementations are retained.
Development O_PATH changes and a general upstream rebase are outside this port.

## Validation

- All 14 retained native host runners pass; sanitizers are used by every runner
  that supports them. The module-controller runner retains its pthread and
  deliberate missing-lock negative control.
- 48 new production-C regression cases pass under ASan/UBSan, with instrumented
  kernel or syscall stubs. These cover both directory ABIs, buffer residue,
  placeholders, partial rewrites, scrub faults, redirect publication/capacity,
  probe admission during exit, retry/concurrency, and malformed ELF ranges.
- 25 corresponding old-source cases fail as expected, using the exact baseline
  source as the negative control. New AVC exit tests and their missing-admission
  negative control also pass in the retained identity-controls runner.
- The module compiles against the pinned Android16/6.12 DDK with Android Clang
  r536225/19.0.1, including all four real-kernel type-check groups.
- All 135 strong undefined symbols and the selected probe targets are present
  in the pinned System.map. The ABI header and mount recognition/statfs/cache
  source file are unchanged. The existing inode-teardown handler is retained
  within sus_path.c; only its directory rewrite and diagnostic line change.
- The freestanding AArch64 loader compiles with the same pinned compiler.

Host/build results do not constitute phone acceptance. Test the new candidate
after a full reboot before publishing a stable release. The existing mount-gap
and SELinux timing heuristic limitations are not claimed solved by these fixes.
