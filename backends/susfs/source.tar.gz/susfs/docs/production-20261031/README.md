# Production cleanup for RMGU 1.3.1

The maintainer accepted the priority-test4 device testing and reported no HMA
failures on 31 October 2026. The priority hooks, verified Samsung fallback,
callback lifetime handling, caller exclusions and automatic policy are retained.

The shipping control client now exposes configuration and status only. Temporary
UID-transition probes and raw priority queries are removed. Verbose initialization
fields and the module fail_layer parameter are removed from the kernel module.
The rollback tests now inject failures into the host model without a shipping
fault-injection switch. The normal root-only automatic-protection status remains.

All 29 host suites / 56 normal and sanitizer configurations passed. The rebuilt
Android16/6.12 module preserves the 22 syscall wrappers, five probe callback types,
140 imports, symbol-version layout and baseline callback types against real
kernel headers. The freestanding ARM64 client has no interpreter or relocator.
The production cleanup itself has build/host/ABI validation; the accepted phone
results were obtained with test4 before these diagnostic-only removals.

See records/ for the build, ABI and host regression evidence. Earlier test guides
in this archive are historical; their removed probe commands do not apply to the
production client.
