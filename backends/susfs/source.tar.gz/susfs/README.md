# Samsung production release

See [RMGU 1.3.1 cleanup and validation](docs/production-20261031/README.md). Earlier test instructions below are historical.

# Samsung automatic root-app selection

See [automatic selection and policy lifetime review](docs/auto-root-apps-20261031/README.md).

# Samsung priority UID filter adaptation

See [priority-filter review, validation and control guide](docs/priority-filter-20261030/README.md).

# Samsung dispatcher adaptation

See [29 October dispatcher adaptation and validation](docs/dispatcher-20261029/README.md) for the current Samsung changes. It retains the [27 October audit repairs](docs/audit-20261027/README.md).

# Samsung audit repairs

See [27 October audit fixes and validation](docs/audit-20261027/README.md) for the current Samsung changes and build instructions.

# RMGU SUSFS — checkpoint 6

This checkpoint advances the separate SUSFS module source to dev3 and adds
verified ARM64 builds. It does not modify Root My Galaxy Ultra.

**Do not apply this patch inside `C:\azhl\source`.** There is no APK to build,
phone command to run, or approved device module in this package. Your existing
UAPI 5 backend update is the app baseline observed during this work.

## Completed

- Rebased checkpoint 5's deferred-request lifetime fix onto SUSFS dev3.
- Corrected the documented local CFI-wrapper omission in symbol-name lookup.
- Added compiler checks for exact LSM callback types, before pointer casts.
- Removed the cleanup path's 50 ms synchronization fallback.
- Cross-compiled original and patched ARM64 sources with the pinned Android 16 /
  6.12 DDK, retaining CFI and DWARF. Module BTF generation was omitted because
  this host lacks `pahole`.
- Passed 13 lifecycle cases normally and under ASan/UBSan, 10 compiler cases,
  artifact checks and selected comparisons with your BZIG BTF.
- Checked the three SUSFS status queries against ReSukiSU's UAPI 5 source.
- Verified the cumulative patch applies cleanly and recreates all 16 changed
  files byte for byte. No upstream commit or issue was published.

## Source patch

Use a **new, clean checkout of the SUSFS repository** on Linux/WSL:

```sh
git clone --branch v2.3.0-r18-dev3 https://github.com/inforcqb/susfs4ksu-lkm.git susfs-bzig-review
cd susfs-bzig-review
git checkout --detach c2a5575e0a230db992ad94e2924bc38333797336
git apply --check /path/to/apply-to-susfs-c2a5575.patch
git apply /path/to/apply-to-susfs-c2a5575.patch
```

This patch includes the earlier lifecycle changes. Do not stack checkpoint 5's
dev2 patch on top of it. `changed-sources/` contains the resulting files for
review or manual application. `REVIEW.md` explains build reproduction and scope.
`inspection-tools/` contains the offline BTF/DWARF readers from earlier
checkpoints; they inspect local files and never load kernel code.

## What still blocks device integration

The LSM hooks still need a complete lifetime/restoration design: a callback may
sleep inside SELinux, and failed restoration must not permit live code or data
to be freed. Samsung RKP/KDP behavior and exact runtime compatibility are also
unverified. These are separate from the deferred-request fix.

The generic build is 6.12.76-4k; the supplied BZIG kernel is 6.12.69 with Samsung
changes. The built module still has no symbol-version CRC records. Matching
selected structures cannot establish complete compatibility.

Assessment stays **ReviewRequired**. The next implementation step is LSM
callback ownership and verified restoration, before any phone activation.
No module was loaded/unloaded on hardware, and no Knox or boot-safety guarantee
is made. There is no new device report for you to collect at this checkpoint.

`evidence/` records results and source/build provenance. `SHA256SUMS` covers
the package. App sources, exploit implementations and backend binaries were
not changed by this checkpoint.
