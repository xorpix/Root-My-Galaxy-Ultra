#!/usr/bin/env python3
"""Read kernel-module DWARF on the host. Does not execute or load the module.

Requires pyelftools 0.32 and libzstd. Compatibility shims decode ELF Zstandard
debug sections and ignore R_AARCH64_NONE relocations (defined as no-ops).
"""
import ctypes as C
import ctypes.util
import hashlib
import json
from pathlib import Path
import struct
import sys

from elftools.elf.elffile import ELFFile
from elftools.elf.sections import Section
from elftools.elf.relocation import RelocationHandler


def install_reader_compatibility():
    original_data = Section.data
    original_reloc = RelocationHandler._do_apply_relocation
    z = C.CDLL(ctypes.util.find_library('zstd'))
    z.ZSTD_decompress.argtypes = [C.c_void_p, C.c_size_t, C.c_void_p, C.c_size_t]
    z.ZSTD_decompress.restype = C.c_size_t
    z.ZSTD_isError.argtypes = [C.c_size_t]
    z.ZSTD_isError.restype = C.c_uint

    def data(section):
        if section.compressed and section._compression_type == 2:
            if section.elffile.elfclass != 64 or not section.elffile.little_endian:
                raise ValueError('This Zstd shim expects ELF64 little endian')
            section.stream.seek(section['sh_offset'])
            _, _, size, _ = struct.unpack('<IIQQ', section.stream.read(24))
            if size > 256 * 1024 * 1024:
                raise ValueError('Debug section exceeds inspection limit')
            compressed = section.stream.read(section['sh_size'] - 24)
            target = C.create_string_buffer(size)
            actual = z.ZSTD_decompress(target, size, compressed, len(compressed))
            if z.ZSTD_isError(actual) or actual != size:
                raise ValueError('Zstd decoding failed')
            return target.raw
        return original_data(section)

    def relocate(handler, stream, reloc, symtab):
        if handler.elffile.get_machine_arch() == 'AArch64' and reloc['r_info_type'] == 0:
            return
        return original_reloc(handler, stream, reloc, symtab)

    Section.data = data
    RelocationHandler._do_apply_relocation = relocate


def name(die):
    attr = die.attributes.get('DW_AT_name')
    return attr.value.decode(errors='replace') if attr else ''


def target(die):
    return die.get_DIE_from_attribute('DW_AT_type') if 'DW_AT_type' in die.attributes else None


def array_count(die):
    if die.tag != 'DW_TAG_array_type':
        return None
    counts = []
    for child in die.iter_children():
        if child.tag != 'DW_TAG_subrange_type':
            continue
        attrs = child.attributes
        if 'DW_AT_count' in attrs:
            counts.append(attrs['DW_AT_count'].value)
        elif 'DW_AT_upper_bound' in attrs:
            lower = attrs.get('DW_AT_lower_bound')
            counts.append(attrs['DW_AT_upper_bound'].value - (lower.value if lower else 0) + 1)
        else:
            counts.append(None)
    return counts[0] if len(counts) == 1 else counts


def describe(die, depth=0):
    if die is None:
        return 'void'
    if depth > 12:
        return '<depth limit>'
    tag = die.tag
    sub = lambda d: describe(d, depth + 1)
    if tag == 'DW_TAG_pointer_type':
        return sub(target(die)) + '*'
    if tag in ('DW_TAG_const_type', 'DW_TAG_volatile_type', 'DW_TAG_restrict_type'):
        return tag[7:-5] + ' ' + sub(target(die))
    if tag == 'DW_TAG_array_type':
        return f'{sub(target(die))}[{array_count(die)}]'
    if tag == 'DW_TAG_subroutine_type':
        args = [sub(target(c)) for c in die.iter_children() if c.tag == 'DW_TAG_formal_parameter']
        return sub(target(die)) + ' (' + ', '.join(args) + ')'
    if tag in ('DW_TAG_structure_type', 'DW_TAG_union_type'):
        return ('struct ' if tag == 'DW_TAG_structure_type' else 'union ') + (name(die) or '<anonymous>')
    return name(die) or tag


def record(die):
    result = {'name': name(die), 'kind_name': 'STRUCT' if die.tag == 'DW_TAG_structure_type' else 'UNION',
              'size_bytes': die.attributes['DW_AT_byte_size'].value, 'members': []}
    for child in die.iter_children():
        if child.tag != 'DW_TAG_member':
            continue
        pos = child.attributes.get('DW_AT_data_member_location')
        offset = pos.value if pos else 0
        if not isinstance(offset, int):
            raise ValueError(f'Nonconstant member location: {name(die)}.{name(child)}')
        mt = target(child)
        bit_offset = child.attributes.get('DW_AT_data_bit_offset')
        bit_size = child.attributes.get('DW_AT_bit_size')
        member = {'name': name(child), 'type': describe(mt),
                  'offset_bits': bit_offset.value if bit_offset else offset * 8,
                  'bitfield_size': bit_size.value if bit_size else 0}
        if mt.tag == 'DW_TAG_array_type':
            member['array_length'] = array_count(mt)
        result['members'].append(member)
    return result


if __name__ == '__main__':
    install_reader_compatibility()
    path = Path(sys.argv[1])
    names = sys.argv[2:]
    types = {n: [] for n in names}
    with path.open('rb') as stream:
        elf = ELFFile(stream)
        dwarf = elf.get_dwarf_info()
        for cu in dwarf.iter_CUs():
            for die in cu.iter_DIEs():
                n = name(die)
                if n in types and die.tag in ('DW_TAG_structure_type', 'DW_TAG_union_type') and 'DW_AT_byte_size' in die.attributes:
                    rec = record(die)
                    if rec not in types[n]:
                        types[n].append(rec)
        modinfo = elf.get_section_by_name('.modinfo').data().split(b'\0')
        version = next((s.decode() for s in modinfo if s.startswith(b'vermagic=')), None)
    print(json.dumps({'file': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                      'vermagic': version, 'types': types}, indent=2))
