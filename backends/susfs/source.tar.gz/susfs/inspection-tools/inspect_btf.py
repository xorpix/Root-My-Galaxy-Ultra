#!/usr/bin/env python3
"""Offline BTF inspection through the installed libbpf. Never loads BPF or kernel code."""
import ctypes as C
import ctypes.util
import hashlib
import json
from pathlib import Path
import struct
import sys

KINDS = ['VOID', 'INT', 'PTR', 'ARRAY', 'STRUCT', 'UNION', 'ENUM', 'FWD',
         'TYPEDEF', 'VOLATILE', 'CONST', 'RESTRICT', 'FUNC', 'FUNC_PROTO',
         'VAR', 'DATASEC', 'FLOAT', 'DECL_TAG', 'TYPE_TAG', 'ENUM64']


class Btf:
    def __init__(self, path):
        self.lib = C.CDLL(ctypes.util.find_library('bpf'), use_errno=True)
        signatures = {
            'btf__parse_raw': ([C.c_char_p], C.c_void_p),
            'libbpf_get_error': ([C.c_void_p], C.c_long),
            'btf__type_cnt': ([C.c_void_p], C.c_uint32),
            'btf__type_by_id': ([C.c_void_p, C.c_uint32], C.c_void_p),
            'btf__name_by_offset': ([C.c_void_p, C.c_uint32], C.c_char_p),
            'btf__resolve_size': ([C.c_void_p, C.c_uint32], C.c_longlong),
            'btf__set_pointer_size': ([C.c_void_p, C.c_size_t], C.c_int),
            'btf__free': ([C.c_void_p], None),
        }
        for name, (args, result) in signatures.items():
            fn = getattr(self.lib, name)
            fn.argtypes, fn.restype = args, result
        self.handle = self.lib.btf__parse_raw(str(path).encode())
        error = self.lib.libbpf_get_error(self.handle)
        if not self.handle or error:
            raise ValueError(f'libbpf could not parse input: {error}')
        if self.lib.btf__set_pointer_size(self.handle, 8):
            raise ValueError('Could not select ARM64 pointer size')
        self.count = self.lib.btf__type_cnt(self.handle)
        self.by_name = {}
        for type_id in range(1, self.count):
            t = self.type(type_id)
            if t['name']:
                self.by_name.setdefault(t['name'], []).append(type_id)

    def close(self):
        self.lib.btf__free(self.handle)

    def name(self, offset):
        value = self.lib.btf__name_by_offset(self.handle, offset)
        if value is None:
            raise ValueError(f'Invalid name offset {offset}')
        return value.decode('utf-8', errors='replace')

    def type(self, type_id):
        if type_id == 0:
            return {'id': 0, 'name': 'void', 'kind': 0, 'vlen': 0, 'size_type': 0, 'flag': 0}
        pointer = self.lib.btf__type_by_id(self.handle, type_id)
        if not pointer:
            raise ValueError(f'Invalid type id {type_id}')
        name, info, size_type = struct.unpack('<III', C.string_at(pointer, 12))
        return {'id': type_id, 'name': self.name(name), 'kind': (info >> 24) & 31,
                'vlen': info & 65535, 'flag': info >> 31, 'size_type': size_type,
                '_pointer': pointer}

    def describe(self, type_id, depth=0):
        t = self.type(type_id)
        kind = t['kind']
        if depth > 12:
            return f'type#{type_id}'
        sub = lambda value: self.describe(value, depth + 1)
        if kind == 2:
            return sub(t['size_type']) + '*'
        if kind == 3:
            element, _, count = struct.unpack('<III', C.string_at(t['_pointer'] + 12, 12))
            return f'{sub(element)}[{count}]'
        if kind in (9, 10, 11, 18):
            return KINDS[kind].lower() + ' ' + sub(t['size_type'])
        if kind == 13:
            params = [struct.unpack('<II', C.string_at(t['_pointer'] + 12 + i * 8, 8))[1]
                      for i in range(t['vlen'])]
            return sub(t['size_type']) + ' (' + ', '.join(sub(p) for p in params) + ')'
        if kind in (12, 14):
            return sub(t['size_type'])
        if kind in (4, 5, 7):
            return KINDS[kind].lower() + ' ' + (t['name'] or f'<anonymous#{type_id}>')
        return t['name'] or KINDS[kind].lower()

    def record(self, type_id):
        t = self.type(type_id)
        result = {key: value for key, value in t.items() if key != '_pointer'}
        result['kind_name'] = KINDS[t['kind']]
        size = self.lib.btf__resolve_size(self.handle, type_id)
        if size >= 0:
            result['size_bytes'] = size
        result['description'] = self.describe(type_id)
        if t['kind'] in (4, 5):
            members = []
            for i in range(t['vlen']):
                name, member_type, offset = struct.unpack('<III', C.string_at(t['_pointer'] + 12 + i * 12, 12))
                bit_offset = offset & 0xffffff if t['flag'] else offset
                member = {'name': self.name(name), 'type_id': member_type,
                          'type': self.describe(member_type), 'offset_bits': bit_offset,
                          'bitfield_size': offset >> 24 if t['flag'] else 0}
                mt = self.type(member_type)
                if mt['kind'] == 3:
                    _, _, count = struct.unpack('<III', C.string_at(mt['_pointer'] + 12, 12))
                    member['array_length'] = count
                members.append(member)
            result['members'] = members
        return result


if __name__ == '__main__':
    path = Path(sys.argv[1])
    names = sys.argv[2:]
    btf = Btf(path)
    try:
        result = {'file': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                  'type_count_including_void': btf.count,
                  'types': {name: [btf.record(i) for i in btf.by_name.get(name, [])] for name in names}}
        print(json.dumps(result, indent=2))
    finally:
        btf.close()
