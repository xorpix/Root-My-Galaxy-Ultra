#!/usr/bin/env python3
"""Compare saved host-side type descriptions and module initializer constants."""
import json
from pathlib import Path
import struct
import sys

from elftools.elf.elffile import ELFFile

HOOKS = {
    'inode_getattr': 'getattr', 'inode_permission': 'perm',
    'inode_unlink': 'unlink', 'inode_rmdir': 'rmdir',
    'inode_rename': 'rename', 'inode_link': 'link', 'sb_statfs': 'statfs',
    'inode_setattr': 'setattr', 'inode_getxattr': 'getxattr',
    'inode_listxattr': 'listxattr', 'inode_setxattr': 'setxattr',
    'inode_removexattr': 'removexattr', 'path_notify': 'notify',
}


def members(t):
    return {m['name']: m for m in t['members'] if m['name']}


def main(root):
    phone = json.loads((root / 'samsung-types.json').read_text())['types']
    candidate = json.loads((root / 'candidate-types.json').read_text())['types']
    hook_layout = json.loads((root / 'candidate-hook-layout.json').read_text())['types']['ksu_lsm_hook'][0]
    hook_fields = members(hook_layout)
    comparisons = []
    for name, records in phone.items():
        a = [t for t in records if t['kind_name'] in ('STRUCT', 'UNION')]
        b = candidate.get(name, [])
        if not a or not b:
            continue
        if len(b) != 1:
            raise ValueError(f'Ambiguous candidate type {name}')
        am, bm = members(a[0]), members(b[0])
        mismatches = []
        for member in sorted(set(am) & set(bm)):
            for field in ('offset_bits', 'bitfield_size'):
                if am[member][field] != bm[member][field]:
                    mismatches.append({'member': member, 'field': field,
                                       'phone': am[member][field], 'candidate': bm[member][field]})
        comparisons.append({
            'name': name, 'phone_bytes': a[0]['size_bytes'], 'candidate_bytes': b[0]['size_bytes'],
            'shared_named_members': len(set(am) & set(bm)),
            'member_location_mismatches': mismatches,
            'phone_only_members': sorted(set(am) - set(bm)),
            'candidate_only_members': sorted(set(bm) - set(am)),
        })

    table = members(phone['lsm_static_calls_table'][0])
    ph = members(phone['security_list_options'][0])
    ch = members(candidate['security_list_options'][0])
    phone_hook_word = members(phone['security_hook_list'][0])['hook']['offset_bits'] // 8
    hooks = []
    with (root / 'candidate-android16-6.12.ko').open('rb') as stream:
        elf = ELFFile(stream)
        symtab = elf.get_section_by_name('.symtab')
        for member, suffix in HOOKS.items():
            name = f'sus_path_{suffix}_hook'
            entries = symtab.get_symbol_by_name(name)
            if not entries or len(entries) != 1:
                raise ValueError(f'Missing or ambiguous initializer: {name}')
            symbol = entries[0]
            section = elf.get_section(symbol['st_shndx'])
            offset = symbol['st_value'] - section['sh_addr']
            constants = {}
            for field in ('head_offset', 'hook_offset'):
                location = offset + hook_fields[field]['offset_bits'] // 8
                # These fields must be absolute integer initializers, not relocated pointers.
                for reloc_section in elf.iter_sections():
                    if reloc_section['sh_type'] not in ('SHT_REL', 'SHT_RELA') or reloc_section['sh_info'] != symbol['st_shndx']:
                        continue
                    if any(location <= r['r_offset'] < location + 8 and r['r_info_type'] != 0 for r in reloc_section.iter_relocations()):
                        raise ValueError(f'Relocation intersects constant: {name}.{field}')
                constants[field] = struct.unpack_from('<Q', section.data(), location)[0]
            phone_offset = table[member]['offset_bits'] // 8
            hooks.append({
                'name': member, 'initializer': name,
                'phone_table_offset_bytes': phone_offset,
                'candidate_table_offset_bytes': constants['head_offset'],
                'table_offset_match': phone_offset == constants['head_offset'],
                'phone_hook_word_offset_bytes': phone_hook_word,
                'candidate_hook_word_offset_bytes': constants['hook_offset'],
                'hook_word_offset_match': phone_hook_word == constants['hook_offset'],
                'phone_signature': ph[member]['type'],
                'candidate_signature': ch[member]['type'],
                'signature_spelling_match': ph[member]['type'] == ch[member]['type'],
            })
    result = {
        'scope': 'Selected type sizes and named top-level member locations; 13 initializer constants and type descriptions. Not a whole-kernel ABI or CFI-hash certification.',
        'structures': comparisons,
        'hooks': hooks,
        'phone_slots_per_hook': sorted({m['array_length'] for m in table.values()}),
    }
    (root / 'comparison.json').write_text(json.dumps(result, indent=2) + '\n')
    print(f'Compared {len(comparisons)} selected structure/union types and {len(hooks)} hooks.')
    print('Size mismatches:', sum(t['phone_bytes'] != t['candidate_bytes'] for t in comparisons))
    print('Shared named member-location mismatches:', sum(len(t['member_location_mismatches']) for t in comparisons))
    print('Nonidentical member sets:', [(t['name'], t['phone_only_members'], t['candidate_only_members']) for t in comparisons if t['phone_only_members'] or t['candidate_only_members']])
    for hook in hooks:
        print(hook['name'], 'table=', hook['phone_table_offset_bytes'], hook['candidate_table_offset_bytes'],
              'signature=', hook['signature_spelling_match'], 'hook word=', hook['hook_word_offset_match'])


if __name__ == '__main__':
    main(Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent)
