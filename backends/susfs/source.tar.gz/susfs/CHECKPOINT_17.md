# Checkpoint 17: native map_files without callback-table writes

The CP15 phone collector captured repeated slot-0 restoration warnings and
root parameter readers blocked in param_attr_show. CP16 now completes cleanup
and returns to the prompt, but its target-rule write returns EFAULT. All CP16
warmup and app/root baselines passed; the hidden phase did not execute. The
specific patch slot/error and the reason Samsung rejected the write remain
unqualified until the requested map_stat/kernel log is supplied.

This revision removes every map_files callback-table write. It registers
function-entry kprobes on proc_map_files_readdir, proc_pid_readlink and
proc_map_files_get_link. The original immutable tables are validated before
and after registration. A registration failure, an adjusted/non-entry address,
or an unexpected callback table prevents the target rule from being published.

The pre-handler redirects the instruction pointer to the correctly typed
replacement, then returns. ARM64 kprobes resets its handler context before
execution resumes at that replacement. Native procfs locking, allocations,
path references, access checks and directory actors therefore execute in the
original process context. The pre-handler only checks the app gate and a
spinlock-protected guard list, accounts for the diverted call and selects PC.

A stack-owned guard identifies the current task and exact original probe
while the replacement calls native code. It avoids recursive diversion
without blocking other tasks or other map_files operations. The shared
proc_pid_readlink hook diverts only inodes with the validated map_files i_ops;
fd, cwd and exe links retain their original path. NULL-dentry RCU get_link and
root/empty-rule calls stay native.

Callback lifetime is counted in the pre-handler, before the first replacement
instruction. Unregistering all probes prevents new diversions. Tasks grace
periods and the active-call drain retain module text through sleeping calls
and their final return. No forbidden callback restoration retry is necessary.
Reinstallation resets the retained probe disabled flag.

The unchanged filtering bodies retain ptrace/capability checks, matching under
mmap_lock, path ownership and padding-aware enumeration. A hidden entry is
consumed with its original directory cookie; a visible actor runs without
mmap_lock held. Known-range direct stat and concurrent remap/exec enumeration
remain outside the current phone test's qualification.

Fresh local verification: 30 actual production-C cases normally and with
ASan/UBSan, eight defect controls per run, 27 map-hook cases, 12 observer/root
timeout tests, 10 real-header LSM type cases and 15 map_files/probe type cases.
The ARM64 module is compiled with the pinned Android 16/6.12 DDK and Clang
r536225. Artifact review compares all five incoming callback KCFI words with
header-typed fixtures and retains outgoing checks in the four callbacks.
Host fixtures cannot establish live Samsung probe reachability or callback
ABI. Module import CRC qualification remains unavailable, as in retained CP14.

Runner revision 6 requires route=kprobe and divert_checked=1 before creating
fixtures. It retains bounded root commands and cleanup and prints map_stat
after a writer exits with an error. It never reads controls after an unknown
management timeout. Test 17 uses a separate app identity; install it, fully
reboot, grant root and enable SusFS through Test 17 before running the CP17
runner from ordinary Termux. Live CP17 validation is pending.

Corresponding source, binaries, evidence and toolchain pins accompany the
checkpoint. No private source changes are published to an external repository.
