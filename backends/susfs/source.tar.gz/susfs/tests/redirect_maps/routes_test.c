#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#define OR_APP_UID_MIN 10000
#define READ_ONCE(x) (x)
#define smp_rmb() ((void)0)
#define MAJOR(x) ((uint32_t)(x)>>20)
#define MINOR(x) ((uint32_t)(x)&0xfffffu)
#define PAGE_SIZE 4096
#define ATOMIC_INIT(x) (x)
#define module_param_cb(a,b,c,d)
typedef int atomic_t;
static void atomic_inc(atomic_t *x){++*x;}
static int atomic_read(const atomic_t *x){return *x;}
struct host_uid{unsigned val;};static struct host_uid reader={10362};
static struct host_uid current_uid(void){return reader;}
struct seq_file{char *buf;size_t count,size;};
struct super_block{uint32_t s_dev;};struct inode{unsigned long i_ino;struct super_block *i_sb;unsigned int i_generation;};
struct file{struct inode *inode;};struct vm_area_struct{struct file *vm_file;};
struct kretprobe_instance{void *data;};struct pt_regs{unsigned long regs[31];};
struct kprobe{const char *symbol_name;void *addr;unsigned flags;};
struct kretprobe{struct kprobe kp;int(*entry_handler)(struct kretprobe_instance*,struct pt_regs*);int(*handler)(struct kretprobe_instance*,struct pt_regs*);size_t data_size;int maxactive,nmissed;bool registered;};
struct kernel_param{int dummy;};struct kernel_param_ops{int(*get)(char*,const struct kernel_param*);};
struct sus_or_entry{unsigned long target_ino,redirected_ino;uint32_t target_dev,redirected_dev;unsigned int target_igen,redirected_igen;char target_pathname[256],redirected_pathname[256];bool dead;};
static struct sus_or_entry or_entries[64];static int nor;
static struct inode *file_inode(struct file *f){return f->inode;}
static bool susfs_ptr_plausible(const void*p){return (uintptr_t)p>4096;}
static void rcu_read_lock(void){}static void rcu_read_unlock(void){}
static int scnprintf(char*p,size_t n,const char*fmt,...){va_list a;va_start(a,fmt);int r=vsnprintf(p,n,fmt,a);va_end(a);return r<0?0:(r<(int)n?r:(int)n-1);}
static int calls,fail_at;
static int register_kretprobe(struct kretprobe*p){++calls;if(calls==fail_at)return -5;assert(!p->kp.addr);p->kp.addr=(void*)0x7000;p->registered=true;return 0;}
static void unregister_kretprobe(struct kretprobe*p){assert(p->registered);p->registered=false;p->kp.flags|=1;}

/* Host model of the load-time umount gate (issue #34): nothing resolves on the host, so the gate
 * answers the pre-#34 way - app uids and nothing else.  The extracted production fragment's gate
 * calls this replica instead of ksu_umount_gate.h's inline, keeping every other expectation here
 * byte-identical to what it tested before the KSU integration landed in the kernel sources. */
static inline bool susfs_is_current_proc_umounted_app(void)
{
    return current_uid().val >= 10000;
}
#include "production.h"
static void init_rule(void){nor=1;or_entries[0]=(struct sus_or_entry){.target_ino=524630,.target_dev=(254u<<20)|81u,.redirected_ino=2339,.redirected_dev=19,.redirected_igen=7};strcpy(or_entries[0].target_pathname,"/data/owned/source");strcpy(or_entries[0].redirected_pathname,"/dev/owned/dest");}
static void show(struct seq_file*m,struct vm_area_struct*v,int route,const char*row,int error,bool changed){
 struct kretprobe*p=NULL;
#if NEW_ROUTES
 assert(!or_maps_arm());p=route?&kr_or_smaps:&kr_or_maps;
#else
 /* show_map formats inline; show_smap calls the observed helper. */
 or_maps_registered=true;
 if(route && or_maps_registered)p=&kr_or_maps;
#endif
 struct or_maps_args data;struct kretprobe_instance ri={&data};struct pt_regs regs={{(unsigned long)m,(unsigned long)v}};int skip=1;
 if(p && !(p->kp.flags&1))skip=p->entry_handler(&ri,&regs);
 static char replacement[4096];if(changed){memcpy(replacement,m->buf,m->count);m->buf=replacement;}
 size_t n=strlen(row);assert(m->count+n<m->size);memcpy(m->buf+m->count,row,n);m->count+=n;
 regs.regs[0]=(unsigned long)error;if(!skip)p->handler(&ri,&regs);
}
int main(int argc,char**argv){assert(argc==2);init_rule();const char*c=argv[1];
#if NEW_ROUTES
 if(!strcmp(c,"arm-cycles")){for(int i=0;i<4;i++){assert(!or_maps_arm());assert(kr_or_maps.registered&&kr_or_smaps.registered);assert(!(kr_or_maps.kp.flags|kr_or_smaps.kp.flags));or_maps_disarm();assert(!kr_or_maps.registered&&!kr_or_smaps.registered);}puts("four registration cycles");return 0;}
 if(!strcmp(c,"arm-first-failure")||!strcmp(c,"arm-second-retry")){fail_at=!strcmp(c,"arm-first-failure")?1:2;assert(or_maps_arm()==-5);assert(!or_maps_registered&&!kr_or_maps.registered&&!kr_or_smaps.registered);fail_at=0;assert(!or_maps_arm());assert(!(kr_or_maps.kp.flags|kr_or_smaps.kp.flags));or_maps_disarm();return 0;}
#endif
 char store[4096],row[512];memset(store,0x71,sizeof(store));struct seq_file m={store,0,sizeof(store)-16};struct super_block sb={19};struct inode inode={2339,&sb,7};struct file file={&inode};struct vm_area_struct v={&file};
 const char*path=or_entries[0].redirected_pathname;bool prefix=!strcmp(c,"row-scope"),already=!strcmp(c,"inlined-maps")||!strcmp(c,"outofline-smaps"),changed=!strcmp(c,"buffer-change");
 if(already)path=or_entries[0].target_pathname;
 if(prefix){const char*prior="9000-a000 rw-p 00000000 00:13 2339     /dev/owned/dest\n";m.count=strlen(prior);memcpy(store,prior,m.count);}
 size_t before=m.count;char saved[512];memcpy(saved,store,before);
 snprintf(row,sizeof(row),"1000-2000 rw-p 00000000 00:13 2339     %s%s\nRss: 4 kB\n",path,!strcmp(c,"path-prefix")?"-other":!strcmp(c,"deleted")?" (deleted)":"");
 bool capacity=!strcmp(c,"capacity-growth"),root=!strcmp(c,"root-control");if(capacity){or_entries[0].target_ino=1099512621261ul;m.size=before+strlen(row)+1;}if(root)reader.val=0;
 show(&m,&v,strcmp(c,"inlined-maps")!=0,row,!strcmp(c,"failed-show")?-1:0,changed);
 if(m.count<m.size)m.buf[m.count]=0;
 if(root||changed||!strcmp(c,"failed-show")){assert(m.count==before+strlen(row));assert(!memcmp(m.buf+before,row,strlen(row)));}
 else if(capacity){assert(m.count==m.size);}
 else{assert(!memcmp(m.buf,saved,before));assert(strstr(m.buf+before,"fe:51 524630"));if(!strcmp(c,"path-prefix"))assert(strstr(m.buf+before,"/dev/owned/dest-other"));else assert(strstr(m.buf+before,"/data/owned/source"));assert(!memcmp(m.buf+m.count-10,"Rss: 4 kB\n",10));}
 for(size_t i=sizeof(store)-16;i<sizeof(store);i++)assert((unsigned char)store[i]==0x71);
 puts("header and guard checks");return 0;
}
