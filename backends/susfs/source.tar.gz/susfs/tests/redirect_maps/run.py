#!/usr/bin/env python3
"""Production listing callbacks/registration with explicit host kernel stubs."""
import argparse,json,os,re,subprocess,tempfile
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--source-dir',type=Path,default=Path(__file__).resolve().parents[2]);p.add_argument('--sanitizers',action='store_true');p.add_argument('--only-case');p.add_argument('--expected-failure',action='store_true');p.add_argument('--json',type=Path);a=p.parse_args()
s=(a.source_dir/'kernel/susfs_open_redirect.c').read_text()
def function(name):
 m=re.search(r'^static [^\n]*\b'+name+r'\([^;{]*\)\n\{\n.*?^\}\n',s,re.M|re.S)
 if not m:raise RuntimeError('Production function missing: '+name)
 return m[0]
start=s.index('static atomic_t or_rev_maps_hits');end=s.index('/* ---- reverse face 4:',start)
block=s[start:end];modern='kr_or_smaps' in block
production=function('or_reverse_visible')+function('or_find_by_redirected_inode')+block
cases=['inlined-maps','outofline-smaps','row-scope','path-prefix','deleted','capacity-growth','failed-show','buffer-change','root-control','arm-cycles','arm-first-failure','arm-second-retry']
if a.only_case:assert a.only_case in cases;cases=[a.only_case]
results=[]
with tempfile.TemporaryDirectory(prefix='rmgu-redirect-routes-') as tmp:
 tmp=Path(tmp);(tmp/'production.h').write_text(production);exe=tmp/'routes'
 flags=['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-no-pie'] if a.sanitizers else ['-O2']
 subprocess.run([os.environ.get('CC','cc'),'-std=gnu11','-Wall','-Wextra','-Werror','-Wno-unused-function','-Wno-unused-parameter',*flags,'-DNEW_ROUTES='+str(int(modern)),'-I'+str(tmp),str(Path(__file__).with_name('routes_test.c')),'-o',str(exe)],check=True)
 env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
 for case in cases:
  r=subprocess.run([str(exe),case],capture_output=True,text=True,timeout=20,env=env)
  results.append({'case':case,'exit_code':r.returncode,'stdout':r.stdout.strip(),'stderr':r.stderr.strip()});print(('PASS ' if r.returncode==0 else 'FAIL ')+case)
receipt={'kind':'actual production C; kernel APIs and formatter dispatch are explicit host stubs','checkpoint':22,'modern_listing_objects':modern,'sanitizers':a.sanitizers,'lsan':False,'hardware_validated':False,'expected_failure':a.expected_failure,'results':results}
if a.json:a.json.parent.mkdir(parents=True,exist_ok=True);a.json.write_text(json.dumps(receipt,indent=2)+'\n')
failed=any(r['exit_code'] for r in results)
raise SystemExit(not failed if a.expected_failure else failed)
