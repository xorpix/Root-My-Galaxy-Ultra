// SPDX-License-Identifier: GPL-2.0
#define SUSFS_INSMOD_HOSTTEST
#include PRODUCTION
#include <assert.h>
#include <setjmp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static char image[1024],output[4096];
static size_t used;
static int exited,init_calls;
static jmp_buf fatal;
sysarg sys6(sysarg n,sysarg a,sysarg b,sysarg c,sysarg d,sysarg e,sysarg f) {
    (void)d; (void)e; (void)f;
    if(n==SYS_openat) return !strcmp((const char*)b,"fixture.ko")?10:-2;
    if(n==SYS_lseek) return sizeof(image);
    if(n==SYS_mmap) return (sysarg)image;
    if(n==SYS_close) return 0;
    if(n==SYS_write) { assert(used+(size_t)c<sizeof(output)); memcpy(output+used,(const void*)b,(size_t)c); used+=(size_t)c; output[used]=0; return c; }
    if(n==SYS_init_module) { init_calls++; return -38; }
    if(n==SYS_exit) { exited=(int)a; longjmp(fatal,1); }
    return -38;
}
int main(int argc,char **argv) {
    assert(argc==2); const char *test=argv[1]; static const char *expect;
    struct elf64_ehdr *eh=(void*)image;
    eh->e_ident[0]=0x7f; eh->e_ident[1]='E'; eh->e_ident[2]='L'; eh->e_ident[3]='F';
    eh->e_ident[EI_CLASS]=ELFCLASS64; eh->e_ident[EI_DATA]=ELFDATA2LSB;
    eh->e_machine=EM_AARCH64; eh->e_shoff=64; eh->e_shentsize=64; eh->e_shnum=5; eh->e_shstrndx=1;
    struct elf64_shdr *s=(void*)(image+64);
    static const char names[]="\0.shstrtab\0.symtab\0.strtab\0.modinfo\0";
    memcpy(image+400,names,sizeof(names));
    s[1]=(struct elf64_shdr){.sh_name=1,.sh_type=SHT_STRTAB,.sh_offset=400,.sh_size=sizeof(names)};
    s[2]=(struct elf64_shdr){.sh_name=11,.sh_type=SHT_SYMTAB,.sh_offset=512,.sh_size=48,.sh_link=3};
    s[3]=(struct elf64_shdr){.sh_name=19,.sh_type=SHT_STRTAB,.sh_offset=600,.sh_size=16};
    s[4]=(struct elf64_shdr){.sh_name=27,.sh_type=SHT_PROGBITS,.sh_offset=700,.sh_size=16};
    assert(!strcmp(image+400+s[2].sh_name,".symtab"));
    assert(!strcmp(image+400+s[3].sh_name,".strtab"));
    assert(!strcmp(image+400+s[4].sh_name,".modinfo"));
    struct elf64_sym *syms=(void*)(image+512);
    syms[1]=(struct elf64_sym){.st_name=1,.st_info=0x10,.st_shndx=0};
    memcpy(image+600,"\0unresolved\0",12);
    memcpy(image+700,"license=GPL\0",12);
    if(!strcmp(test,"table-wrap")) { eh->e_shoff=~(u64)0-63; eh->e_shnum=2; expect="section table outside"; }
    else if(!strcmp(test,"table-past-end")) { eh->e_shoff=2048; expect="section table outside"; }
    else if(!strcmp(test,"table-truncated")) { eh->e_shoff=900; expect="section table outside"; }
    else if(!strcmp(test,"shstr-wrap")) { s[1].sh_offset=~(u64)0-7; s[1].sh_size=16; expect="no section-name"; }
    else if(!strcmp(test,"symtab-wrap")) { s[2].sh_offset=~(u64)0-23; expect="symbol table outside"; }
    else if(!strcmp(test,"strtab-wrap")) { s[3].sh_offset=~(u64)0-7; expect="symbol table outside"; }
    else if(!strcmp(test,"modinfo-wrap")) { s[4].sh_offset=~(u64)0-7; expect=".modinfo outside"; }
    else if(!strcmp(test,"size-wrap")) { s[3].sh_size=~(u64)0-500; expect="symbol table outside"; }
    else if(!strcmp(test,"modinfo-name-tail")) {
        s[1].sh_offset=sizeof(image)-1;s[1].sh_size=1;image[sizeof(image)-1]='.';
        s[2].sh_name=0;s[4].sh_name=0;expect="kallsyms";
    }
    else if(!strcmp(test,"modinfo-name-prefix")) {
        s[1].sh_size=s[4].sh_name+sizeof(".modinfo")-1;
        s[4].sh_offset=~(u64)0-7;expect="kallsyms";
    }
    else if(!strcmp(test,"valid-ranges")) expect="kallsyms";
    else abort();
    char *args[]={"loader","fixture.ko",NULL};
    if(!setjmp(fatal)) { insmod_main(2,args); abort(); }
    assert(exited && !init_calls && strstr(output,expect));
    puts("PASS"); return 0;
}
