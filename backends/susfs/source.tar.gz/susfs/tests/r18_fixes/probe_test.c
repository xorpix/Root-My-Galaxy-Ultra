// SPDX-License-Identifier: GPL-2.0
#include <assert.h>
#include <errno.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define DEFINE_MUTEX(x) pthread_mutex_t x=PTHREAD_MUTEX_INITIALIZER
#define mutex_lock(x) assert(!pthread_mutex_lock(x))
#define mutex_unlock(x) assert(!pthread_mutex_unlock(x))
#define SUSFS_LOGI(...) ((void)0)
struct kprobe { void *addr; unsigned flags; bool live; };
struct kretprobe { struct kprobe kp; };
static int registrations, disarms, fail_registration;
static int register_kprobe(struct kprobe *p) {
    assert(!p->live && !p->addr && !p->flags); p->addr=(void*)0x1234; registrations++;
    if(fail_registration) { fail_registration--; return -EINVAL; }
    p->live=true; return 0;
}
static int register_kretprobe(struct kretprobe *p) { return register_kprobe(&p->kp); }
static void unregister_kprobe(struct kprobe *p) { assert(p->live && p->addr); p->live=false; p->flags=1; disarms++; }
static void unregister_kretprobe(struct kretprobe *p) { unregister_kprobe(&p->kp); }
#if GROUP == 1
static struct kretprobe krp_kstat_maps,krp_kstat_smaps;
static DEFINE_MUTEX(kstat_lock);
#elif GROUP == 2
static struct kretprobe krp;
static bool uname_spoof_enabled;
static DEFINE_MUTEX(uname_state_lock);
#define spin_lock_irqsave(p,f) do { (f)=0; mutex_lock(p); } while(0)
#define spin_unlock_irqrestore(p,f) do { (void)(f); mutex_unlock(p); } while(0)
#else
/* The open_redirect registration is a state change, not a kprobe install: the forward direction
 * lives in susfs_or_entry.c's wrappers, so the knob is susfs_or_entry_armed() and the reverse
 * kretprobes stay out of these cases (they are driven by their own harnesses). */
static struct kretprobe kr_or_dpath, kr_or_vfs_statfs;
static DEFINE_MUTEX(or_lock);
struct sus_or_entry { bool dead; };
static struct sus_or_entry or_entries[64];
static int nor;
static unsigned int susfs_open_redirect_rules, or_free_n;
static void *or_proc_entry;
static bool or_entry_armed_ok = true;
static bool susfs_or_entry_armed(void) { return or_entry_armed_ok; }
static void susfs_or_entry_exit(void) { }
static void or_fdinfo_disarm(void) { }
static void or_maps_disarm(void) { }
static void proc_remove(void *p) { }
#define READ_ONCE(x) (x)
#define WRITE_ONCE(x,v) ((x)=(v))
#define smp_rmb() ((void)0)
#define smp_wmb() ((void)0)
#endif
#include PRODUCTION
static int arm(void) {
#if GROUP == 1
    mutex_lock(&kstat_lock); int rc=kstat_maps_arm(); mutex_unlock(&kstat_lock); return rc;
#elif GROUP == 2
    mutex_lock(&uname_ctl_lock); int rc=uname_register_locked(); mutex_unlock(&uname_ctl_lock); return rc;
#else
    mutex_lock(&or_lock); int rc=or_register(); mutex_unlock(&or_lock); return rc;
#endif
}
static void stop(void) {
#if GROUP == 1
    kstat_maps_disarm();
#elif GROUP == 2
    uname_unregister();
#else
    susfs_open_redirect_exit();
#endif
}
static bool live(void) {
#if GROUP == 1
    return krp_kstat_maps.kp.live || krp_kstat_smaps.kp.live;
#elif GROUP == 2
    return krp.kp.live;
#else
    return or_registered || or_dpath_registered || or_statfs_registered;
#endif
}
static void *arm_thread(void *p) { assert(!arm()); return NULL; }
static pthread_barrier_t gate;
static void *late_writer(void *p) { pthread_barrier_wait(&gate); assert(arm()==-ENODEV); return NULL; }
int main(int argc,char **argv) {
    assert(argc==2); const char *c=argv[1];
    if(!strcmp(c,"exit-live") || !strcmp(c,"exit-unarmed")) {
        if(!strcmp(c,"exit-live")) assert(!arm());
        stop(); int before=registrations;
        assert(arm()==-ENODEV && registrations==before && !live());
    } else if(!strcmp(c,"failed-retry")) {
#if GROUP == 3
        /* The name layer is the registration state: making its knob lie makes the add refuse. */
        or_entry_armed_ok=false; assert(arm()==-ENODEV && !live());
        or_entry_armed_ok=true; assert(!arm() && live()); stop(); assert(!live());
#else
        fail_registration=1; assert(arm()==-EINVAL && !live());
        assert(!arm() && live()); stop(); assert(!live());
#endif
    } else if(!strcmp(c,"concurrent-arm")) {
        pthread_t t[4]; for(int i=0;i<4;i++) assert(!pthread_create(&t[i],NULL,arm_thread,NULL));
        for(int i=0;i<4;i++) assert(!pthread_join(t[i],NULL));
        assert(registrations==(GROUP==1?2:(GROUP==2?1:0))); stop(); assert(!live() && registrations==disarms);
    } else if(!strcmp(c,"late-writer")) {
        assert(!arm()); assert(!pthread_barrier_init(&gate,NULL,2)); pthread_t t;
        assert(!pthread_create(&t,NULL,late_writer,NULL)); stop(); pthread_barrier_wait(&gate);
        assert(!pthread_join(t,NULL)); assert(!live() && registrations==disarms);
    } else abort();
    puts("PASS"); return 0;
}
