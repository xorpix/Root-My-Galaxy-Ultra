// SPDX-License-Identifier: GPL-2.0
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#define __user
#define READ_ONCE(x) (x)
#define DIRENT_BUF_SIZE 65536
#define pr_warn_ratelimited(...) ((void)0)
#define ALIGN(n, a) ((((size_t)(n)) + (a) - 1) & ~((size_t)(a) - 1))
typedef uint64_t u64;
typedef int64_t s64;
typedef uint32_t u32;
typedef struct { int value; } atomic_t;
static void atomic_inc(atomic_t *a) { a->value++; }
static atomic_t n_dirent_rewrite_fail, n_dirent_all_hidden;
static int sus_path_count = 1, sus_path_buf_lock, fault_disabled;
static char hide_name[128], scratch[DIRENT_BUF_SIZE];
static char *dirent_tmp = scratch;
static unsigned char buffer[2048];
static const unsigned char *fail_from;
static int clear_failure, clear_calls;
static void spin_lock(int *l) { assert(!*l); *l = 1; }
static void spin_unlock(int *l) { assert(*l); *l = 0; }
static void pagefault_disable(void) { fault_disabled++; }
static void pagefault_enable(void) { assert(fault_disabled == 1); fault_disabled--; }
static int copy_from_user(void *to, const void *from, size_t n) {
    assert(fault_disabled);
    if (fail_from && (const unsigned char *)from >= fail_from) return 1;
    memcpy(to, from, n); return 0;
}
static int copy_to_user(void *to, const void *from, size_t n) {
    assert(fault_disabled); memcpy(to, from, n); return 0;
}
static long strnlen_user(const void *from, size_t n) {
    assert(fault_disabled); const char *p = memchr(from, 0, n);
    return p ? p - (const char *)from + 1 : (long)n + 1;
}
static unsigned long clear_user(void *to, unsigned long n) {
    assert(fault_disabled && !sus_path_buf_lock); clear_calls++;
    if (clear_failure) { if (n) memset(to, 0, 1); return n; }
    memset(to, 0, n); return 0;
}
static bool sus_path_is_hidden(u64 ino, const char *name) {
    (void)ino; return !strncmp(name, "susfs_", 6);
}
#include PRODUCTION

static size_t entry(size_t at, const struct sus_dirent_layout *l, const char *name, u64 ino) {
    size_t n = (l->name_off + strlen(name) + 1 + 7) & ~(size_t)7;
    unsigned short reclen = (unsigned short)n;
    memset(buffer + at, 0xa5, n);
    memcpy(buffer + at, &ino, l->ino_size);
    memcpy(buffer + at + l->reclen_off, &reclen, 2);
    strcpy((char *)buffer + at + l->name_off, name);
    return n;
}
static bool contains(const char *name, size_t n) {
    size_t len = strlen(name);
    for (size_t i = 0; i + len <= n; i++) if (!memcmp(buffer + i, name, len)) return true;
    return false;
}
static void zero_tail(size_t at, size_t n) {
    for (size_t i = at; i < n; i++) assert(!buffer[i]);
}
int main(int argc, char **argv) {
    assert(argc == 2); bool compat = !strncmp(argv[1], "compat-", 7);
    const char *c = strchr(argv[1], '-') + 1;
    const struct sus_dirent_layout *l = compat ? &sus_dirent_compat : &sus_dirent_l64;
    /* The smallest record this ABI can express - the same formula the production
     * placeholder uses: header, one byte of name, and the compat type byte at tail.
     * Spelled from name_off and the ABI alone (not the layout's own align field, so the
     * previous source - which predates that field - still compiles this test). */
    size_t min_reclen = ALIGN(l->name_off + (compat ? 2 : 1), compat ? 4 : 8);
    memset(buffer, 0x5a, sizeof(buffer));
    size_t first = entry(0, l, "ordinary-one", 100);
    size_t hidden = entry(first, l, "susfs_kstat", 200);
    size_t second = entry(first + hidden, l, "ordinary-two", 300);
    size_t last = entry(first + hidden + second, l, "susfs_hidden_last", 400);
    size_t count = first + hidden + second + last, expected = first + second;
    if (!strcmp(c, "all-hidden") || !strcmp(c, "all-hidden-next-chunk") || !strcmp(c, "placeholder-scrub-fault")) {
        first = entry(0, l, "susfs_kstat", 200);
        count = first + entry(first, l, "susfs_hidden_last", 400);
        /* The placeholder is the SHRUNKEN record: the hidden entry's own length was its
         * name's length rounded up, and it said d_type for a hidden file - the record
         * this leaves says one entry and nothing about it. */
        expected = min_reclen;
    } else if (!strcmp(c, "partial-fault") || !strcmp(c, "partial-and-scrub-fault")) {
        fail_from = buffer + first + hidden + second; expected = first + second;
    } else if (!strcmp(c, "first-fault")) {
        fail_from = buffer; expected = count;
    } else if (!strcmp(c, "malformed-first")) {
        unsigned short bad = 1; memcpy(buffer + l->reclen_off, &bad, 2); expected = count;
    } else if (!strcmp(c, "no-rules")) {
        sus_path_count = 0; expected = count;
    }
    if (strstr(c, "scrub-fault")) clear_failure = 1;
    if (!strcmp(c, "placeholder-scrub-fault")) expected = count;
    unsigned char before[sizeof(buffer)]; memcpy(before, buffer, sizeof(buffer));
    long ret = sus_path_filter((unsigned long)buffer, (long)count, l);
    assert(ret == (long)expected && !sus_path_buf_lock && !fault_disabled);
    assert(!memcmp(buffer + count, before + count, sizeof(buffer) - count));
    if (!strcmp(c, "first-fault") || !strcmp(c, "malformed-first") || !strcmp(c, "no-rules")) {
        assert(!memcmp(buffer, before, count));
        assert(n_dirent_rewrite_fail.value == (strcmp(c, "no-rules") != 0));
    } else if (strstr(c, "scrub-fault")) {
        if (!strcmp(c, "placeholder-scrub-fault")) {
            assert(ret == (long)count);
            /* The scrub runs BEFORE any header write: a faulted chain keeps its whole
             * header, so the placeholder is never written onto a chain that failed. */
            assert(!memcmp(buffer, before, (size_t)l->name_off));
        }
        assert(n_dirent_rewrite_fail.value == 1);
        assert(clear_calls > 0);
    } else {
        assert(!contains("susfs_kstat", count) && !contains("usfs_kstat", count));
        assert(!contains("susfs_hidden_last", count) && !contains("usfs_hidden_last", count));
        zero_tail((size_t)ret, count);
        if (!strncmp(c, "all-hidden", 10)) {
            u64 ino = 0; memcpy(&ino, buffer, l->ino_size);
            unsigned short rl; memcpy(&rl, buffer + l->reclen_off, sizeof(rl));
            assert(!ino && !buffer[l->name_off] && n_dirent_all_hidden.value == 1);
            /* d_reclen shrank to min_reclen, and the type byte the record carries is
             * cleared (native: the byte before the name; compat: the record's last one). */
            assert(rl == (unsigned short)min_reclen);
            zero_tail((size_t)l->name_off, min_reclen);
            if (!compat) assert(!buffer[l->name_off - 1]);
            assert(!memcmp(buffer + l->ino_size, before + l->ino_size,
                           (size_t)l->reclen_off - l->ino_size));  /* d_off survives */
            if (!strcmp(c, "all-hidden-next-chunk")) {
                count = entry(0, l, "next-visible", 500);
                assert(sus_path_filter((unsigned long)buffer, count, l) == (long)count);
                assert(contains("next-visible", count));
            }
        } else assert(contains("ordinary-one", ret) && contains("ordinary-two", ret));
        assert(n_dirent_rewrite_fail.value == (!strcmp(c, "partial-fault")));
    }
    puts("PASS"); return 0;
}
