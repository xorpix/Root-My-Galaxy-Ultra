// SPDX-License-Identifier: GPL-2.0
/* R18 redirect rules, host side: publication by inode numbers plus i_generation, a zeroed statfs
 * snapshot when no snapshot call exists, and the 9b27112 slot handback (a rewrite of an existing
 * rule must succeed on a full table by taking its own slot back instead of failing on capacity). */
#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#define SUS_OR_MAX 64
#define SUSFS_OR_PATH_MAX 256
#define UID_NON_APP_PROC 0
#define UID_ROOT_PROC_EXCEPT_SU_PROC 1
#define UID_NON_SU_PROC 2
#define UID_UMOUNTED_APP_PROC 3
#define UID_UMOUNTED_PROC 4
#define FUSE_SUPER_MAGIC 0x65735546
#define LOOKUP_FOLLOW 1
#define READ_ONCE(x) (x)
#define WRITE_ONCE(x,v) ((x)=(v))
#define smp_rmb() ((void)0)
#define smp_wmb() ((void)0)
#define __nocfi
#define noinline
#define pr_warn(...) ((void)0)
#define WARN_ON_ONCE(x) do { if (x) abort(); } while (0)
struct super_block { dev_t s_dev; unsigned long s_magic; };
struct inode { unsigned long i_ino; struct super_block *i_sb; unsigned int i_generation; };
struct dentry { struct inode *inode; struct super_block *d_sb; int refs; };
struct mount { int mnt_id; };
struct path { struct dentry *dentry; struct mount *mnt; };
struct kstatfs { long f_blocks; };
struct item { char name[256]; struct inode inode; struct dentry dentry; struct mount mount; };
static struct super_block sb = { .s_dev = 19, .s_magic = 0x1234 };
static struct item items[160];
static int nitems, check_publication, sync_rcu_calls;
static struct inode *publishing_inode;
static unsigned int or_su_sid = 1;
static char or_su_ctx[] = "u:r:su:s0";
static void publication_hook(void);
static struct mount *real_mount(struct mount *m) { if(check_publication) publication_hook(); return m; }
static struct inode *d_backing_inode(struct dentry *d) { return d->inode; }
static int kern_path(const char *name, int flags, struct path *p) {
    (void)flags; int i;
    for(i=0;i<nitems;i++) if(!strcmp(items[i].name,name)) break;
    if(i==nitems) { assert(nitems<160); nitems++; strcpy(items[i].name,name);
        items[i].inode=(struct inode){1000+(unsigned long)i,&sb,(unsigned)i+7};
        items[i].dentry=(struct dentry){&items[i].inode,&sb,0}; items[i].mount.mnt_id=100+i; }
    items[i].dentry.refs++; p->dentry=&items[i].dentry; p->mnt=&items[i].mount;
    if(check_publication && !publishing_inode) publishing_inode=&items[i].inode;
    return 0;
}
static void path_put(struct path *p) { assert(p->dentry && p->dentry->refs>0); p->dentry->refs--; }
static bool susfs_abi_path_ok(const char *s,size_t n) { return s[0] && strnlen(s,n)<n; }
static void or_resolve_su_sid(void) { }
static int or_register(void) { return 0; }
static void or_register_reverse(void) { }
static void synchronize_rcu(void) { sync_rcu_calls++; }
static void strscpy(char *to,const char *from,size_t n) { assert(strlen(from)<n); strcpy(to,from); }
#include PRODUCTION
static void publication_hook(void) {
    struct sus_or_entry *e=or_find_by_inode(publishing_inode->i_ino,sb.s_dev,publishing_inode->i_generation);
    assert(!e); /* Neither forward nor reverse readers may see an unfinished slot. */
    assert(!or_find_by_redirected_inode(items[nitems-1].inode.i_ino,sb.s_dev,items[nitems-1].inode.i_generation));
}
static void release_entries(void) {
    /* Rules hold no references any more: an add must leave nothing pinned for the module's life. */
    for(int i=0;i<nitems;i++) assert(!items[i].dentry.refs);
}
int main(int argc,char **argv) {
    assert(argc==2); const char *c=argv[1];
    if(!strcmp(c,"publication")) {
        check_publication=1; assert(!or_add("/target","/redirected",0)); check_publication=0;
        struct sus_or_entry *e=or_find_by_inode(items[0].inode.i_ino,sb.s_dev,items[0].inode.i_generation);
        assert(e && !e->dead && nor==1 && susfs_open_redirect_rules==1);
        assert(e->target_mnt_id==100);
        /* no vfs_statfs on the host: the snapshot stays zeroed, which is the refuse-safe direction */
        assert(e->spoofed_kstatfs.f_blocks==0);
    } else if(!strcmp(c,"replacement-capacity")) {
        for(int i=0;i<64;i++) { char t[40],r[40]; snprintf(t,sizeof(t),"/t%d",i); snprintf(r,sizeof(r),"/r%d",i); assert(!or_add(t,r,0)); }
        assert(or_add("/t99-new","/r99",0)==-ENOSPC);
        assert(nor==64 && susfs_open_redirect_rules==64);
        /* a rewrite of an already-listed rule hands its own slot back and takes it again */
        assert(!or_add("/t0","/replacement",0));
        assert(!strcmp(or_find_by_path("/t0")->redirected_pathname,"/replacement"));
        assert(nor==64 && susfs_open_redirect_rules==64 && sync_rcu_calls>=1);
    } else if(!strcmp(c,"replacement-success")) {
        assert(!or_add("/target","/one",0)); struct sus_or_entry *old=or_find_by_path("/target");
        assert(!or_add("/target","/two",0)); struct sus_or_entry *new=or_find_by_path("/target");
        assert(old==new && !new->dead && nor==1 && susfs_open_redirect_rules==1);
        assert(!strcmp(new->redirected_pathname,"/two"));
        assert(sync_rcu_calls==1);  /* one grace for the rewrite's handback, not a second slot */
    } else if(!strcmp(c,"reserved-target")) {
        assert(!or_add("/target","/reserved",0));
        assert(or_add("/reserved","/other",0)==-EINVAL && nor==1 && susfs_open_redirect_rules==1);
    } else abort();
    release_entries(); puts("PASS"); return 0;
}
