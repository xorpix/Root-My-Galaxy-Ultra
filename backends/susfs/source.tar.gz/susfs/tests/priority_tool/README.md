# Production priority control client tests

The real control client runs against a modeled syscall boundary. Tests cover
configuration ABI size, unsupported-command sentinels, result propagation,
root-only status, overflow rejection, short writes and rejection of retired
query/probe commands. Any unexpected identity or scheduling syscall fails.
Run `python3 tests/priority_tool/run.py`, optionally with `--sanitizers`.
