# Priority client host checks

The production freestanding client runs against a syscall model, never real host
UID-changing calls. Tests enforce namespace isolation/private mounts before ID
changes, complete group/UID dropping, read-only probes, invalid-only scheduling
validation, unsupported-command sentinels, correct JSON/exit states, and every
failure before dropping IDs. Negative controls must detect removing mount privacy,
sending a valid scheduling update, accepting an unanswered ABI command, or
rejecting SDK sandbox callers through an ordinary-app-only UID gate. Successful
probes include ordinary, SDK sandbox and app-zygote caller IDs.
