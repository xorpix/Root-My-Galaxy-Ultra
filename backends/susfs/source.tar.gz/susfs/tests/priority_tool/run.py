#!/usr/bin/env python3
"""Compile the production control client with a syscall model; never changes host IDs."""
import argparse,json,os,re,subprocess,tempfile
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--sanitizers',action='store_true');a=p.parse_args()
here=Path(__file__).resolve().parent;root=here.parents[1]
text=(root/'tools/rmgu_priority_ctl.c').read_text()
abi=re.sub(r'^#include[^\n]*\n','',(root/'kernel/susfs_abi.h').read_text(),flags=re.M)
flags=['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-no-pie'] if a.sanitizers else ['-O2']
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
cases=['auto','auto-off','auto-invalid','auto-unhandled','auto-error','set','clear','status','unhandled','command-error','no-status','overflow','retired-query','retired-probe']
with tempfile.TemporaryDirectory(prefix='priority-tool-') as d:
 d=Path(d);(d/'abi.h').write_text(abi)
 def build(label,source):
  path=d/(label+'.h');path.write_text(source);exe=d/label
  subprocess.run(['cc','-std=gnu11','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-Wno-unused-variable',*flags,'-DABI="'+str(d/'abi.h')+'"','-DPRODUCTION="'+str(path)+'"',str(here/'tool_test.c'),'-o',str(exe)],check=True)
  return exe
 exe=build('production',text)
 for case in cases:
  r=subprocess.run([str(exe),case],capture_output=True,text=True,env=env,timeout=10)
  if r.returncode:raise RuntimeError(case+'\n'+r.stdout+'\n'+r.stderr)
  assert json.loads(r.stdout)['schema']==1
  print('PASS priority client '+case,flush=True)
 for label,before,after,case in [
  ('omit-unsupported-sentinel','payload.err=126','payload.err=0','unhandled')]:
  assert before in text
  exe=build(label,text.replace(before,after,1))
  r=subprocess.run([str(exe),case],capture_output=True,text=True,env=env,timeout=10)
  assert r.returncode,'Negative control not detected: '+label
  print('PASS negative/'+label,flush=True)
