#include <assert.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef uint32_t u32;
typedef uint64_t u64;
typedef int64_t s64;
#define __NEW_UTS_LEN 64
#include ABI
#define PRIORITY_TOOL_HOSTTEST
#include PRODUCTION
static char captured[8192];static unsigned long captured_len;
static const char *test_case;
static int ns_created,private_mount,keepcaps,nnp,groups,gids,ids;
static long identity,baseline_error,invalid_error=-22,probe_uid=19998;
static int hidden=1,unhandled,command_error;
static int failing(long n,long option) {
    if(!strncmp(test_case,"fail-",5)){
        const char *s=test_case+5;
        return (eq(s,"namespace")&&n==97)||(eq(s,"private")&&n==40)||
          (eq(s,"keepcaps")&&n==167&&option==8)||(eq(s,"nnp")&&n==167&&option==38)||
          (eq(s,"groups")&&n==159)||(eq(s,"gids")&&n==149)||(eq(s,"uids")&&n==147);
    }return 0;
}
sysarg priority_sys6(sysarg n,sysarg a,sysarg b,sysarg c,sysarg d,sysarg e,sysarg f) {
    (void)e;(void)f;
    if(n==64){assert(a==1&&captured_len+(usize)c<sizeof(captured));long amount=c>17?17:c;memcpy(captured+captured_len,(void *)b,amount);captured_len+=amount;return amount;}
    if(n==142){
        assert((usize)a==KSU_INSTALL_MAGIC1&&(usize)b==SUSFS_MAGIC);
        if(c==CMD_RMGU_SUSFS_AUTO_ROOT_APPS) {
            struct st_rmgu_susfs_auto_root_apps *p=(void *)d;
            assert(sizeof(*p)==sizeof(struct automatic_payload)&&p->err==126);
            assert(p->enabled==(eq(test_case,"auto-off")?0:1));
            assert(p->own_appid==(p->enabled?10123:0));
            if(!unhandled)p->err=command_error;
            return 0;
        }
        assert(c==CMD_SUSFS_SET_PRIORITY_UID_FILTER);
        struct st_susfs_priority_uid_filter *p=(void *)d;
        assert(sizeof(*p)==sizeof(payload)&&__builtin_offsetof(struct priority_payload,err)==__builtin_offsetof(struct st_susfs_priority_uid_filter,err));
        assert(p->err==126||eq(test_case,"unhandled"));
        if(eq(test_case,"set"))assert(!strcmp(p->app_strings,"com.hidden,com.second"));
        if(eq(test_case,"clear"))assert(!*p->app_strings);
        if(!unhandled)p->err=command_error;
        return 0;
    }
    if(n==174||n==175)return identity;
    if(n==56){assert(a==-100&&!strcmp((char *)b,"/sys/module/susfs_guard_lkm/parameters/priority_filter")&&c==0);return eq(test_case,"no-status")?-2:5;}
    if(n==63){assert(a==5);const char *s=eq(test_case,"automatic-ready")?"ready=1 configured=0 generation=2 automatic=1 own_appid=10123 root_lookup=1\n":eq(test_case,"not-ready")?"ready=0 configured=0 generation=0\n":"ready=1 configured=1 generation=2\n";assert((usize)c>strlen(s));memcpy((void *)b,s,strlen(s));return strlen(s);}
    if(n==57){assert(a==5);return 0;}
    if(n==141||n==31){
        assert(a==(n==141?2:3));
        if(eq(test_case,"query")){assert(identity==10002&&!ids&&!ns_created&&b==10001);return -3;}
        if(!identity){assert(b==10001);return baseline_error?baseline_error:(n==141?20:0);}
        assert(ids&&identity==probe_uid);
        if(b==probe_uid)return n==141?20:0;
        assert(b==10001);return hidden?-3:(n==141?20:0);
    }
    if(failing(n,a))return -1;
    if(n==97){assert(!identity&&a==0x20000);ns_created=1;return 0;}
    if(n==40){assert(ns_created&&!identity&&a==0&&!strcmp((char *)b,"/")&&c==0&&d==(0x4000|0x40000));private_mount=1;return 0;}
    if(n==167){assert(private_mount&&!identity);if(a==8){assert(!b);keepcaps=1;}else{assert(a==38&&b==1&&keepcaps);nnp=1;}return 0;}
    if(n==159){assert(private_mount&&nnp&&!a&&!b);groups=1;return 0;}
    if(n==149){assert(groups&&!identity&&a==probe_uid&&b==a&&c==a);gids=1;return 0;}
    if(n==147){assert(private_mount&&gids&&!identity&&a==probe_uid&&b==a&&c==a);ids=1;identity=a;return 0;}
    if(n==30){assert(ids&&identity==probe_uid&&a==3&&b==10001&&c==-1);return invalid_error;}
    assert(!"unexpected syscall");return -1;
}
int main(int argc,char **argv) {
    assert(argc==2);test_case=argv[1];char *args[]={"ctl","probe","19998","10001",NULL};int ac=4,expected=0;
    if(eq(test_case,"auto")||eq(test_case,"auto-unhandled")||eq(test_case,"auto-error")){args[1]="auto";args[2]="10123";ac=3;if(eq(test_case,"auto-unhandled")){unhandled=1;expected=1;}if(eq(test_case,"auto-error")){command_error=-95;expected=1;}}
    else if(eq(test_case,"auto-off")){args[1]="auto-off";ac=2;}
    else if(eq(test_case,"auto-invalid")){args[1]="auto";args[2]="9999";ac=3;expected=2;}
    else if(eq(test_case,"automatic-ready")){}
    else if(eq(test_case,"set")){args[1]="set";args[2]="com.hidden,com.second";ac=3;}
    else if(eq(test_case,"clear")){args[1]="clear";ac=2;}
    else if(eq(test_case,"status")){args[1]="status";ac=2;}
    else if(eq(test_case,"query")){args[1]="query";args[2]="10001";ac=3;identity=10002;}
    else if(eq(test_case,"probe-sdk")){args[2]="20002";probe_uid=20002;}
    else if(eq(test_case,"probe-app-zygote")){args[2]="90002";probe_uid=90002;}
    else if(eq(test_case,"unhandled")){args[1]="clear";ac=2;unhandled=1;expected=1;}
    else if(eq(test_case,"command-error")){args[1]="clear";ac=2;command_error=-13;expected=1;}
    else if(eq(test_case,"visible")){hidden=0;expected=1;}
    else if(eq(test_case,"wrong-validation")){invalid_error=-3;expected=1;}
    else if(eq(test_case,"missing-target")){baseline_error=-3;expected=2;}
    else if(eq(test_case,"not-root")){identity=10002;expected=2;}
    else if(eq(test_case,"no-status")||eq(test_case,"not-ready")){expected=2;}
    else if(eq(test_case,"overflow")){args[2]="2147483648";expected=2;}
    else if(eq(test_case,"self")){args[2]="10001";expected=2;}
    else if(!strncmp(test_case,"fail-",5)){expected=2;}
    else assert(eq(test_case,"probe"));
    int rc=priority_tool_main(ac,args);assert(rc==expected);captured[captured_len]=0;
    if(!strncmp(test_case,"fail-",5))assert(!identity&&!ids);
    if(eq(test_case,"probe")||eq(test_case,"probe-sdk")||eq(test_case,"probe-app-zygote"))assert(strstr(captured,"\"passed\":true"));
    fputs(captured,stdout);return 0;
}
