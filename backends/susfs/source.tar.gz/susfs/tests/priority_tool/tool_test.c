#include <assert.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
typedef uint32_t u32;
typedef uint64_t u64;
typedef int64_t s64;
#define __NEW_UTS_LEN 64
#include ABI
#define PRIORITY_TOOL_HOSTTEST
#include PRODUCTION
static char captured[8192];
static usize captured_len;
static const char *test_case;
static int unhandled,command_error;
sysarg priority_sys6(sysarg n,sysarg a,sysarg b,sysarg c,sysarg d,sysarg e,sysarg f) {
    (void)e;(void)f;
    if(n==64){assert(a==1&&captured_len+(usize)c<sizeof(captured));long amount=c>17?17:c;memcpy(captured+captured_len,(void *)b,amount);captured_len+=amount;return amount;}
    if(n==142){
        assert((usize)a==KSU_INSTALL_MAGIC1&&(usize)b==SUSFS_MAGIC);
        if(c==CMD_RMGU_SUSFS_AUTO_ROOT_APPS){
            struct st_rmgu_susfs_auto_root_apps *p=(void *)d;
            assert(sizeof(*p)==sizeof(struct automatic_payload)&&p->err==126);
            assert(p->enabled==(eq(test_case,"auto-off")?0:1));
            assert(p->own_appid==(p->enabled?10123:0));
            if(!unhandled)p->err=command_error;
            return 0;
        }
        assert(c==CMD_SUSFS_SET_PRIORITY_UID_FILTER);
        struct st_susfs_priority_uid_filter *p=(void *)d;
        assert(sizeof(*p)==sizeof(payload)&&__builtin_offsetof(struct priority_payload,err)==__builtin_offsetof(struct st_susfs_priority_uid_filter,err));
        assert(p->err==126||eq(test_case,"unhandled"));
        if(eq(test_case,"set"))assert(!strcmp(p->app_strings,"com.hidden,com.second"));
        if(eq(test_case,"clear"))assert(!*p->app_strings);
        if(!unhandled)p->err=command_error;
        return 0;
    }
    if(n==56){assert(a==-100&&!strcmp((char *)b,"/sys/module/susfs_guard_lkm/parameters/priority_filter")&&c==0);return eq(test_case,"no-status")?-2:5;}
    if(n==63){const char *s="ready=1 configured=0 generation=2 automatic=1 own_appid=10123 root_lookup=1\n";assert(a==5&&(usize)c>strlen(s));memcpy((void *)b,s,strlen(s));return strlen(s);}
    if(n==57){assert(a==5);return 0;}
    assert(!"Production client must not query or change identities/priorities");return -1;
}
int main(int argc,char **argv){
    assert(argc==2);test_case=argv[1];char *args[]={"ctl","auto","10123","10001",NULL};int ac=3,expected=0;
    if(eq(test_case,"auto-unhandled")){unhandled=1;expected=1;}
    else if(eq(test_case,"auto-error")){command_error=-95;expected=1;}
    else if(eq(test_case,"auto-invalid")){args[2]="9999";expected=2;}
    else if(eq(test_case,"overflow")){args[2]="2147483648";expected=2;}
    else if(eq(test_case,"set")){args[1]="set";args[2]="com.hidden,com.second";}
    else if(eq(test_case,"unhandled")||eq(test_case,"command-error")){args[1]="clear";ac=2;unhandled=eq(test_case,"unhandled");command_error=-13;expected=1;}
    else if(eq(test_case,"no-status")){args[1]="status";ac=2;expected=2;}
    else if(eq(test_case,"retired-query")||eq(test_case,"retired-probe")){args[1]=eq(test_case,"retired-query")?"query":"probe";ac=eq(test_case,"retired-query")?3:4;expected=2;}
    else if(!eq(test_case,"auto")){assert(eq(test_case,"auto-off")||eq(test_case,"clear")||eq(test_case,"status"));args[1]=(char *)test_case;ac=2;}
    assert(priority_tool_main(ac,args)==expected);captured[captured_len]=0;fputs(captured,stdout);return 0;
}
