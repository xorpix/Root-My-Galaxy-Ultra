/* SPDX-License-Identifier: GPL-2.0 */
/* Host shims for the hide_syms show-probe fragment (m_show filter equivalence).
 * The API surface is the union of what both extracted slices reference. */
#include <assert.h>
#include <errno.h>
#include <stdarg.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <limits.h>

#define MODULE_NAME_LEN 56
typedef struct { unsigned int val; } kuid_t;
static _Thread_local kuid_t host_uid, host_euid;
#define GLOBAL_ROOT_UID ((kuid_t){0})
static kuid_t current_uid(void) { return host_uid; }
static kuid_t current_euid(void) { return host_euid; }
static bool uid_eq(kuid_t a, kuid_t b) { return a.val == b.val; }
#define GFP_KERNEL 0
#define PAGE_SIZE 4096
#define READ_ONCE(v) __atomic_load_n(&(v),__ATOMIC_ACQUIRE)
#define smp_load_acquire(p) __atomic_load_n((p),__ATOMIC_ACQUIRE)
#define smp_store_release(p,v) __atomic_store_n((p),(v),__ATOMIC_RELEASE)
#define __nocfi
#define noinline
typedef uint32_t u32;
typedef int32_t s32;
typedef u32 kprobe_opcode_t;
#define KPROBE_FLAG_DISABLED 1
#define ARRAY_SIZE(a) (sizeof(a)/sizeof((a)[0]))
#define KERNEL_VERSION(a,b,c) (((a)<<16)+((b)<<8)+(c))
#define LINUX_VERSION_CODE KERNEL_VERSION(6,12,0)
#define KSYM_NAME_LEN 512
#define SUSFS_LOGI(...) ((void)0)
#define pr_err(...) ((void)0)
#define pr_warn(...) ((void)0)
typedef _Atomic int atomic_t;
#define ATOMIC_INIT(v) (v)
static void atomic_inc(atomic_t *p) { atomic_fetch_add(p,1); }
static int atomic_inc_return(atomic_t *p) { return atomic_fetch_add(p,1)+1; }
static int atomic_read(atomic_t *p) { return atomic_load(p); }
#define DEFINE_MUTEX(n) pthread_mutex_t n=PTHREAD_MUTEX_INITIALIZER
#define DEFINE_SPINLOCK(n) pthread_mutex_t n=PTHREAD_MUTEX_INITIALIZER
static int host_spin_depth;
static atomic_t host_allocations;
static void mutex_lock(pthread_mutex_t *p) { assert(p); pthread_mutex_lock(p); }
static void mutex_unlock(pthread_mutex_t *p) { pthread_mutex_unlock(p); }
static void spin_lock(pthread_mutex_t *p)
{ assert(!pthread_mutex_lock(p)); host_spin_depth++; }
static void spin_unlock(pthread_mutex_t *p)
{ assert(host_spin_depth>0); host_spin_depth--; assert(!pthread_mutex_unlock(p)); }
#define spin_lock_irqsave(p,f) do { (f)=0; spin_lock(p); } while(0)
#define spin_unlock_irqrestore(p,f) do { (void)(f); spin_unlock(p); } while(0)
static void *kvmalloc(size_t n,int flags)
{ (void)flags; void *p=malloc(n); if(p) atomic_inc(&host_allocations); return p; }
static void *kvmalloc_array(size_t n,size_t size,int flags) { return kvmalloc(n*size,flags); }
static void kvfree(void *p) { if(p) { atomic_fetch_sub(&host_allocations,1); free(p); } }
static int strscpy(char *out,const char *in,size_t size)
{ size_t n=strlen(in); if(n>=size) n=size-1; memcpy(out,in,n); out[n]=0; return (int)n; }
static int scnprintf(char *out,size_t size,const char *format,...)
{ if(!size) return 0; va_list ap; va_start(ap,format); int n=vsnprintf(out,size,format,ap); va_end(ap); return n<(int)size ? n : (int)size-1; }

/* register/seq-file/module world, arm64-shaped enough for the fragment */
struct pt_regs { unsigned long long regs[31]; unsigned long long sp; unsigned long long pc; };
static unsigned long regs_get_kernel_argument(struct pt_regs *r, int n) { return r->regs[n]; }
static void regs_set_return_value(struct pt_regs *r, unsigned long v) { r->regs[0] = v; }
struct seq_file { const void *op; void *private; };
struct seq_operations { void *start; void *stop; void *next; int (*show)(struct seq_file *, void *); };
struct kprobe { int (*pre_handler)(struct kprobe *, struct pt_regs *); kprobe_opcode_t *addr; const char *symbol_name; unsigned int flags, offset; u32 opcode; };
struct list_head { struct list_head *next; struct list_head *prev; };
struct module { char name[MODULE_NAME_LEN]; struct list_head list; };

static int sus_path_add_self_hidden(const char *path);
static int sus_path_del_path(const char *path);
static bool sus_path_lsm_active(void) { return true; }
static int susfs_control_get(void) { return 0; }
static void susfs_control_put(void) {}
static int host_nofault_calls;
#ifdef MSHOW_IDENTITY_TEST
static int copy_from_kernel_nofault(void *to,const void *from,size_t size);
#else
static int copy_from_kernel_nofault(void *to,const void *from,size_t size)
{ host_nofault_calls++;if (!from || (uintptr_t)from < PAGE_SIZE) return -EFAULT; memcpy(to,from,size);return 0; }
#endif
