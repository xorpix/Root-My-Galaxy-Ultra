#!/usr/bin/env python3
"""Preserve phone-qualified module-list filtering after callback validation.

Compare the live handler with the frozen 1.2.16 handler for readable module
arguments. The live fixture admits callbacks only after address validation;
registration, malformed arguments and failure cleanup are tested separately
by mshow_identity. A mismatching live seq_file.op must not suppress the
Samsung path. The negative control deliberately restores that old gate.
"""
import argparse, json, os, subprocess, tempfile
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-dir', type=Path, default=Path(__file__).resolve().parents[2])
parser.add_argument('--json', type=Path)
parser.add_argument('--sanitizers', action='store_true')
args = parser.parse_args()

here = Path(__file__).resolve().parent
source = (args.source_dir / 'kernel/susfs_hide_syms.c').read_text()

# live fragment: hide_modules state and name matcher, then both show handlers
b1 = source.index('#define HIDE_MODULES_MAX')
e1 = source.index('/* ---- the two frontends ---- */')
b2 = source.index('/* Local mirror of kernel/kallsyms.c struct kallsym_iter')
endmark = 'static bool m_show_registered;'
e2 = source.index(endmark) + len(endmark)
fragment = source[b1:e1].rstrip() + '\n\n' + source[b2:e2].rstrip() + '\n'

# the 1.2.16-shipped m_show handler, verbatim from the a8e803f9 baseline
frozen = (
    'static int hide_syms_m_show_pre(struct kprobe *kp, struct pt_regs *regs)\n'
    '{\n'
    '\tstruct module *mod;\n'
    '\tvoid *p = (void *)regs_get_kernel_argument(regs, 1);\n'
    '\n'
    '\tif (!p)\n'
    '\t\treturn 0;\n'
    '\n'
    '\t/* Same recovery the kernel\'s own m_show() does: the iterator hands over &module->list, so the module is one offset away. */\n'
    '\tmod = (struct module *)((char *)p - offsetof(struct module, list));\n'
    '\tif (!hide_module_name_match(mod->name))\n'
    '\t\treturn 0;\n'
    '\n'
    '\tatomic_inc(&n_modlines_skipped);\n'
    '\tregs_set_return_value(regs, 0);\t\t/* no output for this entry */\n'
    '\tregs->pc = regs->regs[30];\n'
    '\treturn 1;\n'
    '}\n'
)
a = fragment.index('static int hide_syms_m_show_pre(struct kprobe *kp, struct pt_regs *regs)')
b = fragment.index('static struct kprobe kp_m_show = {')
reference = fragment[:a] + frozen + fragment[b:]

negative = fragment.replace('|| !m || !p)',
                            '|| !m || (modules_op_target && m->op != modules_op_target) || !p)')
assert negative != fragment

# Registration must use the validating helper, preserving the tested name-based entry.
guard_ok = ('rc = hide_syms_modules_show_start();' in source
            and 'hide_syms_resolve_show(&resolved, "modules_op", "m_show"' in source
            and source.count('kp_m_show.symbol_name = "m_show";') == 1)

# case -> expectation tuple (ret, pc, rv0, skipped)
#   ret 1 with pc=1 rv0=1 skipped=1 means the /proc/modules line was filtered
EQ = [
    ('unreadable-private',     (0, 0, 0, 0)),
    ('enlisted-susfs',          (1, 1, 1, 1)),
    ('enlisted-kernelsu',       (1, 1, 1, 1)),
    ('not-enlisted-okmodule',   (0, 0, 0, 0)),
    ('null-p-shown',            (0, 0, 0, 0)),
    ('m-op-irrelevant',         (1, 1, 1, 1)),   # shipped arming: m->op must not matter
]
GATE = [
    ('op-match-still-hides',    (1, 1, 1, 1)),   # identity passes a genuine match
    ('op-mismatch-still-hides',  (1, 1, 1, 1)),   # must preserve Samsung hiding after address validation
]
expected = {
    # shipped arming, including the one impossible call where only the old
    # handler acted: documented divergence, asserted as exactly that
    # (the sentinel register stays 0 there, so rv0 records nothing)
    'current': dict(EQ) | {'m-null-impossible-call': (0, 0, 1, 0)} | dict(GATE),
    # 1.2.16: no m read, no gate - both gate cases hide
    'reference': dict(EQ) | {'m-null-impossible-call': (1, 1, 1, 1)} | {c: (1, 1, 1, 1) for c, _ in GATE},
}

cases = [c for c, _ in EQ] + ['m-null-impossible-call'] + [c for c, _ in GATE]

results, ok = [], True

def run_case(exe, case):
    run = subprocess.run([str(exe), case], capture_output=True, text=True, timeout=30,
                         env=dict(os.environ, ASAN_OPTIONS='detect_leaks=0:abort_on_error=1',
                                  UBSAN_OPTIONS='halt_on_error=1'))
    if run.returncode:
        return None
    line = next((l for l in run.stdout.splitlines() if l.startswith('OBS ')), None)
    if not line:
        return None
    kv = dict(x.split('=', 1) for x in line.split()[2:])
    return tuple(int(kv[k]) for k in ('ret', 'pc', 'rv0', 'skipped'))

with tempfile.TemporaryDirectory(prefix='susfs-mshow-filter-host-') as temporary:
    def compile_program(text, exe):
        production = Path(temporary) / (exe + '.h')
        production.write_text(text)
        flags = (['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-no-pie']
                 if args.sanitizers else ['-O2'])
        return subprocess.run([os.environ.get('CC', 'cc'), '-std=gnu11', '-Wall', '-Wextra', '-Werror'] + flags +
                              ['-Wno-unused-function', '-Wno-unused-variable', '-Wno-unused-parameter',
                               '-Wno-sign-compare', '-pthread',
                               '-I', str(here), '-DPRODUCTION="' + str(Path(temporary) / (exe + '.h')) + '"',
                               str(here / 'mshow_filter_test.c'), '-o', str(Path(temporary) / exe)],
                              capture_output=True, text=True)

    built = {}
    for build, text in (('current', fragment), ('reference', reference)):
        done = compile_program(text, build)
        if done.returncode:
            raise RuntimeError(build + ' fragment did not compile: ' + done.stderr)
        built[build] = str(Path(temporary) / build)

    print(('PASS ' if guard_ok else 'FAIL ') + 'm_show keeps by-name entry with modules callback validation')
    ok = ok and guard_ok

    for build in ('current', 'reference'):
        for case in cases:
            obs = run_case(built[build], case)
            got = tuple(obs[:4]) if obs else None
            passed = got == expected[build][case]
            print(('PASS ' if passed else 'FAIL ') + build + '/' + case)
            results.append({'build': build, 'case': case, 'passed': passed,
                            'expected': expected[build][case], 'observed': got})
            ok = ok and passed

    # Negative control: reinstating the live table-pointer gate must lose Samsung hiding.
    done = compile_program(negative, 'negative')
    if done.returncode:
        raise RuntimeError('negative control did not compile: ' + done.stderr)
    neg_obs = run_case(str(Path(temporary) / 'negative'), 'op-mismatch-still-hides')
    suppressed = neg_obs is None or neg_obs[0] != 1
    print(('PASS ' if suppressed else 'FAIL ') + 'missing-identity-detach negative control (gate can suppress hiding)')
    ok = ok and suppressed

summary = ('PASS m_show filter behaves like the phone-qualified 1.2.16 handler'
           if ok else 'FAIL m_show filter diverges from the 1.2.16 handler')
print(summary)
if args.json:
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps({'kind': '1.2.16-m_show equivalence over the live fragment',
                                     'hardware_validated': False,
                                     'guard': guard_ok,
                                     'sanitizers': args.sanitizers,
                                     'results': results,
                                     'negative_control': suppressed,
                                     'summary': summary}, indent=2) + '\n')
raise SystemExit(0 if ok else 1)
