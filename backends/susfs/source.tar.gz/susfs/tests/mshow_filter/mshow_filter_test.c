/* SPDX-License-Identifier: GPL-2.0 */
/* Compare valid module-list callbacks with the frozen phone-qualified handler.
 * Readiness represents a registration whose actual entry address was verified.
 * A different seq_file.op must not suppress that path on Samsung; only the
 * intentionally mutated negative control restores the old live pointer gate. */
#include "host_kernel.h"
#include PRODUCTION

static struct seq_operations ops_identity;  /* what "modules_op" resolves to   */
static struct seq_operations ops_other;     /* any other seq_operations table  */
static struct module probe_module;
static struct seq_file fixture_m;

static int sus_path_add_self_hidden(const char *path)
{
    /* not exercised by these cases; the production static must stay declared */
    assert(path); return 0;
}
static int sus_path_del_path(const char *path)
{
    assert(path); return 1;
}

/* one observed invocation of the m_show pre-handler */
static struct { int ret, pc_skipped, rval_zero, skipped_delta; } obs;

static void invoke(int gate_armed, const struct seq_operations *op,
                   int m_is_null, int p_is_null, const char *probe_name)
{
    struct pt_regs regs;
    int before;

    memset(&regs,0,sizeof(regs));
    memset(&fixture_m,0,sizeof(fixture_m));
    memset(&probe_module,0,sizeof(probe_module));
    strscpy(probe_module.name,probe_name,MODULE_NAME_LEN);
    fixture_m.op = (const void *)op;

    modules_op_target = gate_armed ? &ops_identity : NULL;
    smp_store_release(&modules_show_ready, true);

    before = atomic_read(&n_modlines_skipped);
    regs.regs[30] = 0xfeedf00dULL;             /* x30: "return here" marker     */
    regs.regs[0]  = m_is_null ? 0 : (unsigned long)&fixture_m;  /* rv0 is only meaningful when ret==1 */
    regs.regs[1]  = p_is_null ? 0 : (unsigned long)&probe_module.list;
    regs.pc       = 0xdeadbeefULL;
    obs.ret        = hide_syms_m_show_pre(&kp_m_show,&regs);
    obs.pc_skipped = regs.pc == regs.regs[30];
    obs.rval_zero  = regs.regs[0] == 0;
    obs.skipped_delta = atomic_read(&n_modlines_skipped) - before;
}

int main(int argc,char **argv)
{
    int gate_armed=0, m_is_null=0, p_is_null=0;
    const struct seq_operations *op=0;
    const char *probe="okmodule";

    assert(argc==2);
    const char *name=argv[1];
    assert(!hide_modules_command("kernelsu,susfs_guard_lkm",true));
    if(!strcmp(name,"unreadable-private")) {
        struct seq_file m={.private=(void *)1};
        struct pt_regs r={.regs={[0]=(unsigned long)&m,[30]=0x1234},.pc=0x4321};
        assert(!hide_syms_s_show_pre(&kp_s_show,&r));
        assert(r.pc==0x4321 && r.regs[0]==(unsigned long)&m);
        assert(host_nofault_calls==1 && atomic_read(&hide_layout_bad)==1);
        printf("OBS %s ret=0 pc=0 rv0=0 skipped=0\n",name);return 0;
    }
    if(!strcmp(name,"enlisted-susfs")) probe="susfs_guard_lkm";
    else if(!strcmp(name,"enlisted-kernelsu")) probe="kernelsu";
    else if(!strcmp(name,"not-enlisted-okmodule")) probe="okmodule";
    else if(!strcmp(name,"null-p-shown")) p_is_null=1;
    else if(!strcmp(name,"m-null-impossible-call")) { m_is_null=1; probe="susfs_guard_lkm"; }
    else if(!strcmp(name,"m-op-irrelevant")) { op=&ops_other; probe="susfs_guard_lkm"; }
    else if(!strcmp(name,"op-match-still-hides")) { gate_armed=1; op=&ops_identity; probe="susfs_guard_lkm"; }
    else if(!strcmp(name,"op-mismatch-still-hides")) { gate_armed=1; op=&ops_other; probe="susfs_guard_lkm"; }
    else assert(!"unknown case");

    invoke(gate_armed,op,m_is_null,p_is_null,probe);
    printf("OBS %s ret=%d pc=%d rv0=%d skipped=%d\n",
           name,obs.ret,obs.pc_skipped,obs.rval_zero,obs.skipped_delta);
    return 0;
}
