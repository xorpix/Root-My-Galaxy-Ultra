/* SPDX-License-Identifier: GPL-2.0 */
/* Drives the hide_syms show-probe fragment: the /proc/modules m_show filter.
 * One case per process; prints one OBS line per case for run.py to compare
 * against the frozen 1.2.16 reference build.
 *
 * Cases are stable across the two builds:
 *   - "eq" cases: modules_op_target stays NULL (the shipped arming) - the
 *     current and the 1.2.16-shipped handler must behave IDENTICALLY;
 *   - "gate" cases: modules_op_target armed like the 1.2.17 table-identity
 *     mode - they document what the identity check can do when it is active.
 * regs.regs[0] starts at a non-zero sentinel so the rv0 observable reports a
 * real regs_set_return_value() write, never the zero the fixture left there. */
#include "host_kernel.h"
#include PRODUCTION

static struct seq_operations ops_identity;  /* what "modules_op" resolves to   */
static struct seq_operations ops_other;     /* any other seq_operations table  */
static struct module probe_module;
static struct seq_file fixture_m;

static int sus_path_add_self_hidden(const char *path)
{
    /* not exercised by these cases; the production static must stay declared */
    assert(path); return 0;
}
static int sus_path_del_path(const char *path)
{
    assert(path); return 1;
}

/* one observed invocation of the m_show pre-handler */
static struct { int ret, pc_skipped, rval_zero, skipped_delta; } obs;

static void invoke(int gate_armed, const struct seq_operations *op,
                   int m_is_null, int p_is_null, const char *probe_name)
{
    struct pt_regs regs;
    int before;

    memset(&regs,0,sizeof(regs));
    memset(&fixture_m,0,sizeof(fixture_m));
    memset(&probe_module,0,sizeof(probe_module));
    strscpy(probe_module.name,probe_name,MODULE_NAME_LEN);
    fixture_m.op = (const void *)op;

    modules_op_target = gate_armed ? &ops_identity : NULL;

    before = atomic_read(&n_modlines_skipped);
    regs.regs[30] = 0xfeedf00dULL;             /* x30: "return here" marker     */
    regs.regs[0]  = m_is_null ? 0 : (unsigned long)&fixture_m;  /* rv0 is only meaningful when ret==1 */
    regs.regs[1]  = p_is_null ? 0 : (unsigned long)&probe_module.list;
    regs.pc       = 0xdeadbeefULL;
    obs.ret        = hide_syms_m_show_pre(&kp_m_show,&regs);
    obs.pc_skipped = regs.pc == regs.regs[30];
    obs.rval_zero  = regs.regs[0] == 0;
    obs.skipped_delta = atomic_read(&n_modlines_skipped) - before;
}

int main(int argc,char **argv)
{
    int gate_armed=0, m_is_null=0, p_is_null=0;
    const struct seq_operations *op=0;
    const char *probe="okmodule";

    assert(argc==2);
    const char *name=argv[1];
    assert(!hide_modules_command("kernelsu,susfs_guard_lkm",true));
    if(!strcmp(name,"enlisted-susfs")) probe="susfs_guard_lkm";
    else if(!strcmp(name,"enlisted-kernelsu")) probe="kernelsu";
    else if(!strcmp(name,"not-enlisted-okmodule")) probe="okmodule";
    else if(!strcmp(name,"null-p-shown")) p_is_null=1;
    else if(!strcmp(name,"m-null-impossible-call")) { m_is_null=1; probe="susfs_guard_lkm"; }
    else if(!strcmp(name,"m-op-irrelevant")) { op=&ops_other; probe="susfs_guard_lkm"; }
    else if(!strcmp(name,"op-match-still-hides")) { gate_armed=1; op=&ops_identity; probe="susfs_guard_lkm"; }
    else if(!strcmp(name,"op-mismatch-suppresses")) { gate_armed=1; op=&ops_other; probe="susfs_guard_lkm"; }
    else assert(!"unknown case");

    invoke(gate_armed,op,m_is_null,p_is_null,probe);
    printf("OBS %s ret=%d pc=%d rv0=%d skipped=%d\n",
           name,obs.ret,obs.pc_skipped,obs.rval_zero,obs.skipped_delta);
    return 0;
}
