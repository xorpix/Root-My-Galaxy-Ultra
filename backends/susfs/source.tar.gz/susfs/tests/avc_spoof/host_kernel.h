/* SPDX-License-Identifier: GPL-2.0 */
/* Host shims for the susfs_avc_spoof.c handler fragment (source+target SID swap).
 * The API surface is exactly what the extracted slice (globals + ABI enum +
 * avc_audit_post_pre) references; nothing from the register/proc/init tail. */
#include <assert.h>
#include <stdarg.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef uint16_t u16;
typedef uint32_t u32;

/* The kernel's compiler.h definition; the ABI static_assert and enums use it. */
#define __same_type(a, b) __builtin_types_compatible_p(typeof(a), typeof(b))

#define READ_ONCE(v) __atomic_load_n(&(v), __ATOMIC_ACQUIRE)
#define SUSFS_LOGI(...) ((void)0)
#define pr_info(...) ((void)0)
#define pr_warn(...) ((void)0)

typedef _Atomic int atomic_t;
#define ATOMIC_INIT(v) (v)
static void atomic_inc(atomic_t *p) { atomic_fetch_add(p, 1); }
static int atomic_read(atomic_t *p) { return atomic_load(p); }

/* DEFINE_MUTEX only has to produce a storage definition here: the slice declares
 * avc_config_lock but never locks it (the lock sites live past kp_avc). */
#define DEFINE_MUTEX(n) int n

/* arm64-shaped pt_regs: the handler indexes regs[avc_ssid_arg]/regs[avc_tsid_arg]. */
struct pt_regs { unsigned long long regs[31]; unsigned long long sp; unsigned long long pc; };
struct kprobe { int (*pre_handler)(struct kprobe *, struct pt_regs *); };

/* Forward decls the ABI typedefs reference by pointer. selinux_state is also
 * re-declared inside the slice, which is a harmless repeat of an incomplete type. */
struct common_audit_data;
struct selinux_state;

/* The symbol whose prototype decides avc_tsid_arg/avc_ssid_arg.  Declared with the
 * nostate signature by default (Android16/6.12: ssid=x0, tsid=x1) and with the older
 * state signature under AVC_ABI_STATE (ssid=x1, tsid=x2) so the derivation is exercised
 * against both ABIs. */
#ifdef AVC_ABI_STATE
int slow_avc_audit(struct selinux_state *, u32, u32, u16, u32, u32, u32,
		   int, struct common_audit_data *);
#else
int slow_avc_audit(u32, u32, u16, u32, u32, u32,
		   int, struct common_audit_data *);
#endif
