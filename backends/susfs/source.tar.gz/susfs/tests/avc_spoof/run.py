#!/usr/bin/env python3
"""Does the AVC audit handler hide the su domain on BOTH the source and target sid?

The su domain is the SOURCE of the denials it causes ("denied { ... }
scontext=u:r:ksu:s0 ...") and the TARGET of denials against it.  Rewriting the
target sid alone - the behaviour before this change - left every source-side line
intact (upstream a5e7ba5).

The live handler (globals + ABI enum + avc_audit_post_pre) is extracted from
kernel/susfs_avc_spoof.c and compiled against a modelled pt_regs for BOTH
slow_avc_audit ABIs:

  nostate  (>= 6.4, android16-6.12): slow_avc_audit(ssid, tsid, ...) -> ssid=x0, tsid=x1
  state    (older):                  slow_avc_audit(state, ssid, tsid, ...) -> ssid=x1, tsid=x2

The register indices are given to the test as an independent ground truth, so a wrong
avc_ssid_arg = avc_tsid_arg - 1 derivation moves the wrong register and fails here.

A source-text guard asserts the handler really rewrites both ends, and a negative
control strips the source branch (the pre-change morphology) and must leave a
source-side denial visible - proving the matrix can see the regression.
"""
import argparse, json, os, subprocess, tempfile
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-dir', type=Path, default=Path(__file__).resolve().parents[2])
parser.add_argument('--json', type=Path)
parser.add_argument('--sanitizers', action='store_true')
args = parser.parse_args()

here = Path(__file__).resolve().parent
source = (args.source_dir / 'kernel/susfs_avc_spoof.c').read_text()

# live fragment: the globals the handler reads, the ABI typedefs/enums, and the handler
b = source.index('static u32 avc_su_sid;')
e = source.index('static struct kprobe kp_avc = {')
fragment = source[b:e].rstrip() + '\n'

# source-text guard: both ends are written, and the source-sid register is derived
guard_ok = ('enum { avc_ssid_arg = avc_tsid_arg - 1 };' in source
            and 'regs->regs[avc_ssid_arg] = avc_priv_app_sid;' in source
            and 'regs->regs[avc_tsid_arg] = avc_priv_app_sid;' in source)

# negative control: delete the source-sid branch (the target-only, pre-a5e7ba5 handler)
neg_branch = ('\tif ((u32)regs->regs[avc_ssid_arg] == avc_su_sid) {\n'
              '\t\tregs->regs[avc_ssid_arg] = avc_priv_app_sid;\n'
              '\t\thit = true;\n'
              '\t}\n')
negative = fragment.replace(neg_branch, '')
assert negative != fragment, "negative-control transform matched nothing - fragment shape changed"

# case -> (ssid_changed, tsid_changed, other, hit); every case also requires ret=0, enter=1,
# valok=1, enum_ok=1 (checked as invariants below)
EXPECT = {
    'source-match':       (1, 0, 0, 1),   # scontext=ksu line: source rewritten, target left
    'target-match':       (0, 1, 0, 1),   # tcontext=ksu line: the original behaviour, still works
    'both-match':         (1, 1, 0, 1),
    'neither':            (0, 0, 0, 0),
    'disabled':           (0, 0, 0, 0),   # feature off: nothing moves even on a double match
    'su-unresolved-zero': (0, 0, 0, 0),   # su_sid=0 must not match a real sid 0
    'priv-unresolved':    (0, 0, 0, 0),   # priv_app_sid=0 must not be written over a real sid
}
ABIS = [('nostate', 0, 1, []), ('state', 1, 2, ['-DAVC_ABI_STATE'])]

results, ok = [], True


def obs(exe, case):
    r = subprocess.run([str(exe), case], capture_output=True, text=True, timeout=30)
    if r.returncode:
        return None
    line = next((l for l in r.stdout.splitlines() if l.startswith('OBS ')), None)
    if not line:
        return None
    return dict(x.split('=', 1) for x in line.split()[1:])


with tempfile.TemporaryDirectory(prefix='susfs-avc-spoof-host-') as tmp:
    def compile_program(text, name, extra):
        prod = Path(tmp) / (name + '.h')
        prod.write_text(text)
        flags = (['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-no-pie']
                 if args.sanitizers else ['-O2'])
        return subprocess.run(
            [os.environ.get('CC', 'cc'), '-std=gnu11', '-Wall', '-Wextra', '-Werror'] + flags +
            ['-Wno-unused-function', '-Wno-unused-variable', '-Wno-unused-parameter', '-Wno-sign-compare',
             '-I', str(here), '-DPRODUCTION="' + str(prod) + '"'] + extra +
            [str(here / 'avc_spoof_test.c'), '-o', str(Path(tmp) / name)],
            capture_output=True, text=True)

    print(('PASS ' if guard_ok else 'FAIL ') + 'source rewrites both sids and derives avc_ssid_arg')
    ok = ok and guard_ok

    for abi, ssid_reg, tsid_reg, extra in ABIS:
        defs = extra + ['-DEXP_SSID_REG=%d' % ssid_reg, '-DEXP_TSID_REG=%d' % tsid_reg]
        done = compile_program(fragment, 'avc_' + abi, defs)
        if done.returncode:
            raise RuntimeError('%s fragment did not compile: %s' % (abi, done.stderr))
        exe = Path(tmp) / ('avc_' + abi)
        for case, want in EXPECT.items():
            o = obs(exe, case)
            got = None
            inv = False
            if o:
                got = (int(o['ssid_changed']), int(o['tsid_changed']), int(o['other']), int(o['hit']))
                inv = (o['ret'] == '0' and o['enter'] == '1' and o['valok'] == '1' and o['enum_ok'] == '1')
            passed = (got == want) and inv
            print(('PASS ' if passed else 'FAIL ') + '%s/%s' % (abi, case))
            results.append({'abi': abi, 'case': case, 'passed': passed,
                            'expected': want, 'observed': got, 'invariants_ok': inv})
            ok = ok and passed

    # negative control (nostate): source branch removed -> a scontext=ksu denial stays visible
    defs = ['-DEXP_SSID_REG=0', '-DEXP_TSID_REG=1']
    done = compile_program(negative, 'avc_negative', defs)
    if done.returncode:
        raise RuntimeError('negative control did not compile: ' + done.stderr)
    o = obs(Path(tmp) / 'avc_negative', 'source-match')
    # regression morphology: the source sid is NOT rewritten and nothing is counted a hit
    leaked = o is not None and o['ssid_changed'] == '0' and o['hit'] == '0'
    print(('PASS ' if leaked else 'FAIL ') + 'target-only negative control leaves scontext=ksu visible')
    ok = ok and leaked

summary = ('PASS AVC handler spoofs the su domain on both source and target'
           if ok else 'FAIL AVC handler does not spoof both ends')
print(summary)
if args.json:
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps({'kind': 'AVC source+target sid spoof over the live handler',
                                     'hardware_validated': False,
                                     'guard': guard_ok,
                                     'sanitizers': args.sanitizers,
                                     'results': results,
                                     'negative_control': leaked,
                                     'summary': summary}, indent=2) + '\n')
raise SystemExit(0 if ok else 1)
