/* SPDX-License-Identifier: GPL-2.0 */
/* Drives the extracted avc_audit_post_pre() against a modelled pt_regs.
 *
 * The register that holds the source SID and the one that holds the target SID are
 * passed in by the runner per ABI build (EXP_SSID_REG/EXP_TSID_REG) as an INDEPENDENT
 * ground truth - not read from the production enum - so a wrong avc_ssid_arg derivation
 * moves the wrong register and is caught here, not merely confirmed consistent.
 *
 * Every register is seeded with a distinct sentinel; after the call the test checks
 * which of the two sid registers moved, that any move lands exactly on priv_app_sid,
 * and that NO other register was touched. */
#include "host_kernel.h"
#include PRODUCTION

#ifndef EXP_SSID_REG
#error "define EXP_SSID_REG (ground-truth source-sid register index for this ABI)"
#endif
#ifndef EXP_TSID_REG
#error "define EXP_TSID_REG (ground-truth target-sid register index for this ABI)"
#endif

#define SU   0xAAu   /* the su-domain sid the handler matches on */
#define PRIV 0xBBu   /* the priv_app sid it substitutes */
#define NREG 31

int main(int argc, char **argv)
{
	if (argc != 2) {
		fprintf(stderr, "usage: %s <case>\n", argv[0]);
		return 2;
	}
	const char *c = argv[1];

	/* Defaults: both contexts resolved, feature on. */
	avc_su_sid = SU;
	avc_priv_app_sid = PRIV;
	avc_spoof_enabled = true;

	unsigned long long in_ssid, in_tsid;

	if (!strcmp(c, "source-match"))            { in_ssid = SU;   in_tsid = 0x55; }
	else if (!strcmp(c, "target-match"))       { in_ssid = 0x55; in_tsid = SU;   }
	else if (!strcmp(c, "both-match"))         { in_ssid = SU;   in_tsid = SU;   }
	else if (!strcmp(c, "neither"))            { in_ssid = 0x55; in_tsid = 0x66; }
	else if (!strcmp(c, "disabled"))           { avc_spoof_enabled = false; in_ssid = SU; in_tsid = SU; }
	else if (!strcmp(c, "su-unresolved-zero")) { avc_su_sid = 0;  in_ssid = 0;  in_tsid = 0; }
	else if (!strcmp(c, "priv-unresolved"))    { avc_priv_app_sid = 0; in_ssid = SU; in_tsid = SU; }
	else { fprintf(stderr, "unknown case %s\n", c); return 2; }

	struct pt_regs regs;
	unsigned long long pre[NREG];
	for (int i = 0; i < NREG; i++)
		regs.regs[i] = 0x1000ULL + (unsigned)i;   /* distinct sentinels */
	regs.regs[EXP_SSID_REG] = in_ssid;
	regs.regs[EXP_TSID_REG] = in_tsid;
	for (int i = 0; i < NREG; i++)
		pre[i] = regs.regs[i];

	int enter0 = atomic_read(&avc_enter_count);
	int hit0 = atomic_read(&avc_hit_count);

	struct kprobe kp;
	memset(&kp, 0, sizeof kp);
	int ret = avc_audit_post_pre(&kp, &regs);

	int ssid_changed = regs.regs[EXP_SSID_REG] != pre[EXP_SSID_REG];
	int tsid_changed = regs.regs[EXP_TSID_REG] != pre[EXP_TSID_REG];
	int other = 0;
	for (int i = 0; i < NREG; i++) {
		if (i == EXP_SSID_REG || i == EXP_TSID_REG)
			continue;
		if (regs.regs[i] != pre[i])
			other = 1;
	}
	/* a rewritten sid must become exactly priv_app_sid, never anything else */
	int valok = (!ssid_changed || regs.regs[EXP_SSID_REG] == PRIV) &&
		    (!tsid_changed || regs.regs[EXP_TSID_REG] == PRIV);
	int hit = atomic_read(&avc_hit_count) - hit0;
	int enter = atomic_read(&avc_enter_count) - enter0;
	/* independent check that the production derivation agrees with ground truth */
	int enum_ok = (avc_ssid_arg == EXP_SSID_REG) && (avc_tsid_arg == EXP_TSID_REG);

	printf("OBS ret=%d ssid_changed=%d tsid_changed=%d other=%d hit=%d enter=%d valok=%d enum_ok=%d\n",
	       ret, ssid_changed, tsid_changed, other, hit, enter, valok, enum_ok);
	return 0;
}
