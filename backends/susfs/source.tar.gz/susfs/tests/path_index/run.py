#!/usr/bin/env python3
"""Check indexed production inode matching and host scaling through 8192 rules."""
import argparse,importlib.util,os,subprocess,tempfile
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--sanitizers',action='store_true');a=p.parse_args()
here=Path(__file__).resolve().parent;root=here.parents[1]
spec=importlib.util.spec_from_file_location('readlink',root/'tests/path_readlink_lsm/run.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
with tempfile.TemporaryDirectory(prefix='susfs-index-') as d:
 d=Path(d);f=d/'production.h';f.write_text(module.fragments(root));exe=d/'test'
 flags=['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-no-pie'] if a.sanitizers else ['-O2']
 subprocess.run(['cc','-std=gnu11','-Wall','-Wextra','-Werror','-Wno-unused-function','-Wno-unused-parameter','-pthread',*flags,'-DHOST_KERNEL=612','-DPRODUCTION="'+str(f)+'"',str(here/'index_test.c'),'-o',str(exe)],check=True)
 subprocess.run([str(exe)],check=True,timeout=30,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1'))
