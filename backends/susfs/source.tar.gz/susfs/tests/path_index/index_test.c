/* SPDX-License-Identifier: GPL-2.0 */
#include <stdlib.h>
#include <time.h>
#define main readlink_fixture_main
#include "../path_readlink_lsm/readlink_test.c"
#undef main
static double now(void) { struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec*1e9+t.tv_nsec; }
int main(void) {
    static const int counts[]={0,16,128,1024,8192};
    struct file_system_type fs={1};struct super_block sb={1,&fs},other={2,&fs};
    for(unsigned c=0;c<sizeof(counts)/sizeof(counts[0]);c++) {
        int count=counts[c];sus_path_count=count;
        struct sus_path_entry *rules=calloc(count?count:1,sizeof(*rules));
        struct inode *inodes=calloc(count?count:1,sizeof(*inodes));assert(rules&&inodes);
        for(int i=0;i<count;i++) {
            inodes[i]=(struct inode){&sb,(u64)i+1,{0}};
            rules[i]=(struct sus_path_entry){.inode=&inodes[i],.ino=i+1,.dev=1};
            sus_path_index_add(&rules[i]);
        }
        for(int i=0;i<count;i++) {
            struct inode clone=inodes[i];assert(sus_path_inode_hidden(&inodes[i]));
            assert(sus_path_inode_hidden(&clone));clone.i_sb=&other;assert(!sus_path_inode_hidden(&clone));
            rules[i].self_protect=true;assert(sus_path_inode_hidden(&clone));rules[i].self_protect=false;
            inodes[i].i_uid.val=uid;assert(!sus_path_inode_hidden(&inodes[i]));inodes[i].i_uid.val=0;
        }
        unsigned max=0,total=0;
        for(unsigned b=0;b<SUS_PATH_INDEX_SIZE;b++) {
            unsigned n=0;for(struct sus_path_entry *e=sus_path_index[b];e;e=e->index_next)n++;
            if(n>max)max=n;
            total+=n;
        }
        assert(total==(unsigned)count&&max<=40);
        struct inode miss={&sb,100000,{0}};double best=1e30;
        for(int trial=0;trial<3;trial++) {
            double start=now();for(int j=0;j<20000;j++)assert(!sus_path_inode_hidden(&miss));
            double ns=(now()-start)/20000;if(ns<best)best=ns;
        }
        printf("PASS rules=%d max_bucket=%u negative_lookup_ns=%.2f (host only)\n",count,max,best);
        for(int i=0;i<count;i++) {sus_path_index_del(&rules[i]);assert(!sus_path_inode_hidden(&inodes[i]));}
        for(unsigned b=0;b<SUS_PATH_INDEX_SIZE;b++)assert(!sus_path_index[b]);
        free(rules);free(inodes);
    }
    struct sus_path_entry pending={.ino=11,.dev=1};sus_path_index_add(&pending);
    assert(!sus_path_index[sus_path_index_bucket(11)]);
    struct inode zero={&sb,0,{0}};struct sus_path_entry rule={.inode=&zero};
    sus_path_count=1;sus_path_index_add(&rule);assert(sus_path_inode_hidden(&zero));sus_path_index_del(&rule);
    puts("PASS pending exclusion, inode-zero pointer matching and complete removal");return 0;
}
