#!/usr/bin/env python3
"""Check the production kallsyms iterator gate, including Android Rust symbols."""
import argparse
import importlib.util
import os
from pathlib import Path
import subprocess
import tempfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sanitizers', action='store_true')
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    spec = importlib.util.spec_from_file_location('extract', root / 'tests/path_creds/run.py')
    extract = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(extract)
    source = (root / 'kernel/susfs_hide_syms.c').read_text()
    function = extract.function(source, 'hide_syms_iter_plausible')
    harness = r'''
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
struct kallsym_iter_local {
    char type;
    char name[128];
    char module_name[56];
};
#include "production.h"
int main(void)
{
    struct kallsym_iter_local iter = {.name = "rust_symbol", .module_name = "ashmem_rust"};
    const char allowed[] = "3aAbBdDgGijNnRrSsTtUuVvWw";
    for (size_t i = 0; i < sizeof(allowed) - 1; i++) {
        iter.type = allowed[i];
        assert(hide_syms_iter_plausible(&iter));
    }
    for (unsigned int type = 0; type <= 255; type++) {
        iter.type = (char)type;
        bool expected = type != 0 && strchr(allowed, (char)type) != NULL;
        assert(hide_syms_iter_plausible(&iter) == expected);
    }
    iter.type = '3';
    memset(iter.name, 'x', sizeof(iter.name));
    assert(!hide_syms_iter_plausible(&iter));
    strcpy(iter.name, "rust_symbol");
    memset(iter.module_name, 'x', sizeof(iter.module_name));
    assert(!hide_syms_iter_plausible(&iter));
    puts("PASS Rust type, all 256 type bytes and unterminated iterator fields");
    return 0;
}
'''
    flags = (['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-no-pie']
             if args.sanitizers else ['-O2'])
    env = dict(os.environ, ASAN_OPTIONS='detect_leaks=0:abort_on_error=1',
               UBSAN_OPTIONS='halt_on_error=1')
    with tempfile.TemporaryDirectory(prefix='susfs-kallsyms-types-') as directory:
        work = Path(directory)
        header = work / 'production.h'
        header.write_text(function)
        test = work / 'test.c'
        test.write_text(harness)
        command = ['cc', '-std=gnu11', '-Wall', '-Wextra', '-Werror', *flags,
                   str(test), '-o', str(work / 'test')]
        subprocess.run(command, check=True)
        subprocess.run([str(work / 'test')], check=True, env=env)
        old = function.replace('"3aAbBdDgGijNnRrSsTtUuVvWw"', '"aAbBdDgGijNnRrSsTtUuVvWw"')
        if old == function:
            raise RuntimeError('Rust type regression control did not change the production gate')
        header.write_text(old)
        subprocess.run(command, check=True)
        result = subprocess.run([str(work / 'test')], env=env, capture_output=True)
        if result.returncode == 0:
            raise RuntimeError('The old alphabet escaped the Rust type regression')
        print('PASS rejected old-alphabet negative control')


if __name__ == '__main__':
    main()
