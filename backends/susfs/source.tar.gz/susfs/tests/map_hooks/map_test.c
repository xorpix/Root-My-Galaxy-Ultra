/* SPDX-License-Identifier: GPL-2.0 */
#include "host_kernel.h"

/* Host model of the load-time umount gate (issue #34): nothing resolves on the host, so the gate
 * answers the pre-#34 way - app uids and nothing else.  The extracted production fragment's gate
 * calls this replica instead of ksu_umount_gate.h's inline, keeping every other expectation here
 * byte-identical to what it tested before the KSU integration landed in the kernel sources. */
static inline bool susfs_is_current_proc_umounted_app(void)
{
    return current_uid().val >= 10000;
}
#include PRODUCTION

static int command(const char *s) { return sus_map_rules_set(s, NULL); }
static int fire(struct kprobe *kp, struct vm_area_struct *vma)
{
    struct pt_regs regs = {.regs = {[1]=(unsigned long)vma, [30]=0x1234}, .pc=0x4321};
    if (!kp->host_registered || (kp->flags & KPROBE_FLAG_DISABLED)) return 0;
    int rc = kp->pre_handler(kp, &regs);
    if (rc) assert(regs.pc == 0x1234 && regs.regs[0] == 0);
    return rc;
}
static void ready(void) { assert(!susfs_sus_map_init()); assert(map_ready); }
/* The real maps seq_operations dispatches show_map(m, vma). Model its
 * show_map_vma formatter as inlined, so probing only that helper cannot hide
 * a row. Callback selection comes from production probe symbol names. */
static int maps_seq_row(struct vm_area_struct *vma)
{
    for(size_t i=0;i<N_MAP_PROBES;i++) {
        if (!strcmp(map_probes[i]->symbol_name,"show_map") && fire(map_probes[i],vma))
            return 0;
    }
    return 1;
}

/* Model the real Linux 6.12 get_user_page_vma_remote() caller contract from
 * include/linux/mm.h: only `got < 0` bypasses consumption of its page output.
 * A poison output makes CP12's zero-without-a-page failure an assertion instead
 * of a host crash. The production pre-handler is compiled unchanged above. */
struct page { int marker; };
static struct page real_page = {42};
static struct pt_regs remote_regs(struct mm_struct *mm, unsigned long addr,
                                  unsigned long nr_pages, struct page **pages,
                                  int *locked)
{
    return (struct pt_regs){.regs = {[0]=(unsigned long)mm, [1]=addr,
        [2]=nr_pages, [4]=(unsigned long)pages, [5]=(unsigned long)locked,
        [30]=0x1234}, .pc=0x4321};
}
static bool remote_fire(struct kprobe *kp, struct pt_regs *r)
{
    struct pt_regs before = *r;
    if (!kp->host_registered || (kp->flags & KPROBE_FLAG_DISABLED)) return false;
    int handled = kp->pre_handler(kp, r);
    if (handled) {
        assert(r->pc == before.regs[30]);
        for (int i=1; i<31; i++) assert(r->regs[i] == before.regs[i]);
    } else assert(!memcmp(r, &before, sizeof(*r)));
    return handled;
}
static long single_page_consumer(struct kprobe *kp, struct mm_struct *mm,
                                 unsigned long addr)
{
    struct page *page = (void *)(uintptr_t)0xdead0000;
    struct pt_regs r = remote_regs(mm, addr, 1, &page, NULL);
    long got;
    if (remote_fire(kp, &r)) got = (long)r.regs[0];
    else { got=1; page=&real_page; } /* unfiltered primitive's success */
    if (got < 0) {
        assert(page == (void *)(uintptr_t)0xdead0000);
        return got;
    }
    /* The real caller does not check got == 0 before returning this page. */
    assert(got == 1 && page == &real_page);
    return 16; /* page data copied, as in __access_remote_vm */
}
static bool test_remote(const char *name)
{
    if (strncmp(name,"gup-",4) && strncmp(name,"pin-",4)) return false;
    struct file target={&host_ino[0]}, control={&host_ino[1]};
    struct vm_area_struct vmas[] = {
        {.vm_file=&control, .vm_start=0x1000, .vm_end=0x2000},
        {.vm_file=&target, .vm_start=0x3000, .vm_end=0x5000},
        {.vm_start=0x7000, .vm_end=0x8000},
    };
    struct mm_struct mm={.vmas=vmas,.count=ARRAY_SIZE(vmas),.read_locked=true};
    if (!strcmp(name,"pin-optional-retry")) fail_name=HOST_SECOND_REMOTE.symbol_name;
    if (!strcmp(name,"pin-optional-retry"))
        assert(command("add /file0")==-EINVAL && !nmap);
    else
        assert(!command("add /file0"));
    if (!strcmp(name,"gup-return-contract")) {
        assert(single_page_consumer(&kp_gup_remote,&mm,0x3000)==-EFAULT);
    } else if (!strcmp(name,"pin-return-contract")) {
        assert(single_page_consumer(&HOST_SECOND_REMOTE,&mm,0x3000)==-EFAULT);
    } else if (!strcmp(name,"gup-cross-vma") || !strcmp(name,"pin-cross-vma")) {
        struct pt_regs r=remote_regs(&mm,0x1000,4,NULL,NULL);
        struct kprobe *kp=name[0]=='p'?&HOST_SECOND_REMOTE:&kp_gup_remote;
        assert(remote_fire(kp,&r) && (long)r.regs[0]==-EFAULT);
    } else if (!strcmp(name,"gup-overflow")) {
        struct pt_regs r=remote_regs(&mm,0x1000,ULONG_MAX,NULL,NULL);
        assert(remote_fire(&kp_gup_remote,&r) && (long)r.regs[0]==-EFAULT);
    } else if (!strcmp(name,"gup-tagged")) {
        assert(single_page_consumer(&kp_gup_remote,&mm,0xab00000000003000UL)==-EFAULT);
    } else if (!strcmp(name,"gup-visible-range")) {
        struct pt_regs r=remote_regs(&mm,0x1000,2,NULL,NULL);
        assert(!remote_fire(&kp_gup_remote,&r));
    } else if (!strcmp(name,"gup-gap-boundaries")) {
        unsigned long visible[]={0,0x2000,0x2fff,0x5000,0x6000,0x8000,0xffff};
        for (size_t i=0;i<ARRAY_SIZE(visible);i++)
            assert(single_page_consumer(&kp_gup_remote,&mm,visible[i])==16);
        assert(single_page_consumer(&kp_gup_remote,&mm,0x3000)==-EFAULT);
        assert(single_page_consumer(&kp_gup_remote,&mm,0x4fff)==-EFAULT);
    } else if (!strcmp(name,"gup-zero-pages")) {
        struct pt_regs r=remote_regs(&mm,0x3000,0,NULL,NULL);
        assert(!remote_fire(&kp_gup_remote,&r)); assert(!host_vma_lookups);
        assert(!remote_fire(&HOST_SECOND_REMOTE,&r)); assert(!host_vma_lookups);
    } else if (!strcmp(name,"gup-root-control")) {
        assert(single_page_consumer(&kp_gup_remote,&mm,0x1000)==16);
        host_uid=0; int lookups=host_vma_lookups;
        assert(single_page_consumer(&kp_gup_remote,&mm,0x3000)==16);
        assert(single_page_consumer(&HOST_SECOND_REMOTE,&mm,0x3000)==16);
        host_uid=2000; assert(single_page_consumer(&kp_gup_remote,&mm,0x3000)==16);
        assert(host_vma_lookups==lookups);
    } else if (!strcmp(name,"gup-output-lock-preservation")) {
        for(size_t i=4;i<6;i++) {
            struct page *pages[4]={&real_page,NULL,NULL,NULL}; int locked=1;
            struct pt_regs r=remote_regs(&mm,0x3000,4,pages,&locked);
            assert(remote_fire(map_probes[i],&r)); assert((long)r.regs[0]==-EFAULT);
            assert(pages[0]==&real_page && !pages[1] && !pages[2] && !pages[3]);
            assert(locked==1 && mm.read_locked);
        }
    } else if (!strcmp(name,"gup-null-anonymous")) {
        struct pt_regs r=remote_regs(NULL,0x3000,1,NULL,NULL);
        assert(!remote_fire(&kp_gup_remote,&r)); assert(!host_vma_lookups);
        assert(single_page_consumer(&kp_gup_remote,&mm,0x7000)==16);
        target.inode=NULL; assert(single_page_consumer(&kp_gup_remote,&mm,0x3000)==16);
        target.inode=&host_ino[66]; assert(single_page_consumer(&kp_gup_remote,&mm,0x3000)==16);
    } else if (!strcmp(name,"gup-restoration")) {
        for(int i=0;i<3;i++) {
            assert(single_page_consumer(&kp_gup_remote,&mm,0x3000)==-EFAULT);
            assert(!command("del /file0")); int lookups=host_vma_lookups;
            assert(single_page_consumer(&kp_gup_remote,&mm,0x3000)==16);
            assert(host_vma_lookups==lookups); assert(!command("add /file0"));
        }
    } else if (!strcmp(name,"pin-optional-retry")) {
        assert(!HOST_SECOND_REMOTE.host_registered);
        assert(single_page_consumer(&HOST_SECOND_REMOTE,&mm,0x3000)==16);
        fail_name=NULL; assert(!command("add /file0"));
        assert(HOST_SECOND_REMOTE.host_registered);
        assert(single_page_consumer(&HOST_SECOND_REMOTE,&mm,0x3000)==-EFAULT);
    } else assert(!"unknown remote case");
    return true;
}
static void test_walk(const char *name)
{
    struct file hidden={&host_ino[0]},visible={&host_ino[1]};
    struct vm_area_struct vmas[]={
        {.vm_file=&visible,.vm_start=0x1000,.vm_end=0x2000},
        {.vm_start=0x3000,.vm_end=0x4000},
        {.vm_file=&hidden,.vm_start=0x5000,.vm_end=0x6000}};
    struct mm_struct mm={.vmas=vmas,.count=3,.read_locked=true};
    if(strcmp(name,"walk-empty"))assert(!command("add /file0"));
    unsigned long output[3]={13,17,19};
    struct pt_regs r={.regs={[0]=(unsigned long)&mm,[1]=0x1000,[2]=0x6000,
        [3]=(unsigned long)sus_map_ops_pagemap,[4]=(unsigned long)output,[30]=0x1234},.pc=0x4321};
    if(!strcmp(name,"walk-visible"))r.regs[2]=0x5000;
    if(!strcmp(name,"walk-other-ops"))r.regs[3]=0xdead;
    if(!strcmp(name,"walk-root"))host_uid=0;
    if(!strcmp(name,"walk-smaps"))r.regs[3]=(unsigned long)sus_map_ops_smaps;
    if(!strcmp(name,"walk-vma")) {
        r.regs[0]=(unsigned long)&vmas[2];r.regs[1]=(unsigned long)sus_map_ops_pagemap;
        assert(sus_map_skip_walk_vma_pre(&kp_map_walk_vma,&r)==1);
        assert((long)r.regs[0]==-EFAULT && r.pc==0x1234);
        r.regs[0]=(unsigned long)&vmas[2];r.regs[1]=(unsigned long)sus_map_ops_smaps;
        assert(sus_map_skip_walk_vma_pre(&kp_map_walk_vma,&r)==1 && r.regs[0]==0);
    } else {
        struct pt_regs before=r;
        int rc=sus_map_skip_walk_pre(&kp_map_walk,&r);
        bool skip=!strcmp(name,"walk-mixed") || !strcmp(name,"walk-smaps");
        assert(rc==skip);
        if(skip)assert(r.pc==0x1234 && (long)r.regs[0]==(!strcmp(name,"walk-smaps")?0:-EFAULT));
        else assert(!memcmp(&r,&before,sizeof(r)));
        for(int i=1;i<31;i++)assert(r.regs[i]==before.regs[i]);
    }
    assert(output[0]==13 && output[1]==17 && output[2]==19 && mm.read_locked);
}
static void *writer(void *arg)
{
    uintptr_t id = (uintptr_t)arg;
    char add[32], del[32];
    snprintf(add, sizeof(add), "add /file%lu", (unsigned long)id);
    snprintf(del, sizeof(del), "del /file%lu", (unsigned long)id);
    for (int i = 0; i < 2000; i++) { assert(!command(add)); assert(!command(del)); }
    return NULL;
}
static void *reader(void *arg)
{
    for (int i = 0; i < 40000; i++) {
        (void)sus_map_lookup(100, 11);
        (void)sus_map_lookup(101, 11);
        assert(!sus_map_lookup(100, 22));
        assert(!sus_map_lookup(101, 22));
    }
    return NULL;
}
int main(int argc, char **argv)
{
    assert(argc == 2);
    for (int i = 0; i < 68; i++) {
        host_ino[i] = (struct inode){100+(unsigned long)i, &host_sb[0]};
        host_dentry[i].inode = &host_ino[i];
    }
    host_ino[66] = (struct inode){100, &host_sb[1]};
    host_ino[67].i_ino = 0;
    const char *name = argv[1];
    if (!strcmp(name,"unavailable")) {
        assert(command("add /file0") == -ENODEV);
        assert(command("clear") == -ENODEV);
        ready(); susfs_sus_map_exit();
        assert(command("del /file0") == -ENODEV);
    } else {
        ready();
        if (!strcmp(name,"empty-fast-path")) {
            int before=atomic_load(&host_table_locks);
            int calls=atomic_read(&n_maps_calls);
            struct pt_regs regs={0};
            assert(!sus_map_lookup(100,11));
            assert(!sus_map_skip_vma_pre(&kp_map,&regs));
            assert(atomic_load(&host_table_locks)==before&&atomic_read(&n_maps_calls)==calls);
            assert(command("add /file0")==0);assert(sus_map_lookup(100,11));
            assert(command("clear")==0);before=atomic_load(&host_table_locks);
            assert(!sus_map_lookup(100,11)&&atomic_load(&host_table_locks)==before);
        } else if (!strncmp(name,"walk-",5)) {
            test_walk(name);
        } else if (test_remote(name)) {
            /* Remote-page cases use the same rule lifecycle and teardown. */
        } else if (!strcmp(name,"maps-inlined-formatter")) {
            struct file f={&host_ino[0]},control={&host_ino[1]};
            struct vm_area_struct v={.vm_file=&f},cv={.vm_file=&control};
            assert(maps_seq_row(&v)==1); assert(!command("add /file0"));
            assert(maps_seq_row(&v)==0 && maps_seq_row(&cv)==1);
            host_uid=0; assert(maps_seq_row(&v)==1); host_uid=10362;
            assert(!command("del /file0")); assert(maps_seq_row(&v)==1);
        } else if (!strcmp(name,"add-delete")) {
            assert(!command("add /file0")); assert(nmap==1 && sus_map_lookup(100,11));
            assert(!command("del /file0")); assert(nmap==0 && !sus_map_lookup(100,11));
            assert(command("del /file0")==-ENOENT);
        } else if (!strcmp(name,"device-isolation")) {
            assert(!command("add /file0")); assert(!sus_map_lookup(100,22));
            assert(!command("add /file66")); assert(nmap==2);
            assert(!command("del /file0")); assert(sus_map_lookup(100,22));
            assert(!sus_map_lookup(100,11));
        } else if (!strcmp(name,"duplicates")) {
            for(int i=0;i<100;i++) assert(!command("add /file0"));
            assert(nmap==1); assert(!command("del /file0")); assert(nmap==0);
        } else if (!strcmp(name,"capacity-reuse")) {
            char c[32];
            for(int i=0;i<64;i++){snprintf(c,sizeof(c),"add /file%d",i);assert(!command(c));}
            assert(command("add /file64")==-ENOSPC); assert(!command("add /file0"));
            assert(!command("del /file0")); assert(!command("add /file64"));
            assert(nmap==64 && !sus_map_lookup(100,11) && sus_map_lookup(164,11));
        } else if (!strcmp(name,"clear")) {
            assert(!command("add /file0")); assert(!command("add /file1"));
            assert(!command("clear\n")); assert(nmap==0);
            assert(!sus_map_lookup(100,11) && !sus_map_lookup(101,11));
            assert(!command("clear")); assert(!command("add /file0"));
        } else if (!strcmp(name,"maps-root-exclusion")) {
            struct file f={&host_ino[0]}; struct vm_area_struct v={.vm_file=&f};
            assert(!command("add /file0")); assert(fire(&kp_map,&v)==1 && fire(&kp_map_smap,&v)==1);
            host_uid=0; assert(!fire(&kp_map,&v) && !fire(&kp_map_smap,&v));
            host_uid=2000; assert(!fire(&kp_map,&v));
        } else if (!strcmp(name,"sentinel")) {
            assert(!command("add /file0")); assert(!fire(&kp_map,(void *)1));
            assert(!fire(&kp_map,NULL)); struct vm_area_struct v={0}; assert(!fire(&kp_map,&v));
        } else if (!strcmp(name,"restore-callback")) {
            struct file f={&host_ino[0]}, control={&host_ino[1]};
            struct vm_area_struct v={.vm_file=&f}, cv={.vm_file=&control};
            for(int i=0;i<3;i++){
                assert(!command("add /file0")); assert(fire(&kp_map,&v)==1);
                assert(!fire(&kp_map,&cv)); assert(!command("del /file0"));
                assert(!fire(&kp_map,&v) && !fire(&kp_map_smap,&v));
            }
        } else if (!strcmp(name,"supercall-add-delete")) {
            struct st_susfs_sus_map info={.target_pathname="/file0",.err=123}; void *p=&info;
            susfs_sus_map_supercall(&p); assert(!info.err && nmap==1);
            susfs_sus_map_supercall(&p); assert(!info.err && nmap==1);
            assert(!command("del /file0")); assert(nmap==0);
        } else if (!strcmp(name,"invalid-input")) {
            assert(command("")==-EINVAL && command("del file0")==-EINVAL);
            assert(command("add /missing")==-ENOENT && command("add /file67")==-ENOENT);
            char large[300]; memset(large,'x',sizeof(large));large[299]=0;
            assert(command(large)==-ENAMETOOLONG);
            struct st_susfs_sus_map info; memset(&info,'x',sizeof(info));void *p=&info;
            susfs_sus_map_supercall(&p); assert(info.err==-ENAMETOOLONG && !nmap);
        } else if (!strcmp(name,"failed-registration") || !strcmp(name,"retry-registration")) {
            fail_name=kp_map.symbol_name;
            assert(command("add /file0")==-EINVAL); assert(!nmap && !sus_map_lookup(100,11));
            if(!strcmp(name,"retry-registration")){
                fail_name=NULL; assert(!command("add /file0"));
                struct file f={&host_ino[0]};struct vm_area_struct v={.vm_file=&f};assert(fire(&kp_map,&v)==1);
            }
        } else if (!strcmp(name,"optional-retry")) {
            fail_name="show_smap";assert(command("add /file0")==-EINVAL && !nmap);assert(!map_probe_armed[1]);
            fail_name=NULL;assert(!command("add /file0"));assert(map_probe_armed[1] && nmap==1);
        } else if (!strcmp(name,"repeat-lifecycle")) {
            for(int i=0;i<16;i++){
                assert(!command("add /file0"));struct file f={&host_ino[0]};struct vm_area_struct v={.vm_file=&f};
                assert(fire(&kp_map,&v)==1 && map_files_installed);
                susfs_sus_map_exit();assert(!live_probes && !nmap && !map_files_installed);ready();
            }
        } else if (!strcmp(name,"required-walk-ops")) {
            fail_walk_ops=true;assert(command("add /file0")==-EOPNOTSUPP && !nmap);
            fail_walk_ops=false;assert(!command("add /file0") && nmap==1);
        } else if (!strcmp(name,"required-map-files")) {
            fail_name="map_files";
            assert(command("add /file0")==-EIO && !nmap);
            fail_name=NULL;
            assert(!command("add /file0") && nmap==1 && map_files_installed);
        } else if (!strcmp(name,"concurrent-rules")) {
            pthread_t threads[3];assert(!pthread_create(&threads[0],NULL,writer,(void *)0));
            assert(!pthread_create(&threads[1],NULL,writer,(void *)1));
            assert(!pthread_create(&threads[2],NULL,reader,NULL));
            for(int i=0;i<3;i++) {
                assert(!pthread_join(threads[i],NULL));
            }
            assert(!nmap);
        } else { assert(!"unknown case"); }
        char buf[PAGE_SIZE];int n=sus_map_rules_show(buf,NULL);assert(n>0 && n<PAGE_SIZE);
        susfs_sus_map_exit();assert(!live_probes && !nmap);
    }
    printf("PASS %s\n",name);
    return 0;
}
