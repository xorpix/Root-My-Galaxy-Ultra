#!/usr/bin/env python3
"""Exercise production SUS_MAP rules, maps and remote-page hooks with kernel stubs."""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-dir', type=Path, default=Path(__file__).resolve().parents[2])
parser.add_argument('--sanitizers', action='store_true')
parser.add_argument('--json', type=Path)
args = parser.parse_args()
here = Path(__file__).resolve().parent
source = (args.source_dir / 'kernel/sus_map.c').read_text()

def function(name):
    match = re.search(r'^(?:static )?[^\n]*\b' + re.escape(name) +
                      r'\([^;{]*\)\n\{\n.*?^\}\n', source, re.M | re.S)
    if not match:
        raise ValueError('Missing production function: ' + name)
    return match.group()

start = source.index('#define SUS_MAP_MAX')
end = source.index('/* ---- the read gate', start)
fragment = source[start:end]
fragment += function('sus_map_gate_ok') + function('sus_map_skip_vma_pre')
for name in ('sus_map_walk_ops_ours','sus_map_walk_answer','sus_map_find_vma',
             'sus_map_skip_walk_pre','sus_map_skip_walk_vma_pre'):
    fragment += function(name)
for name in ('kp_map', 'kp_map_smap'):
    match = re.search(r'^static struct kprobe ' + name + r' = \{\n.*?^\};\n', source, re.M | re.S)
    fragment += match.group()
gup = source[source.index('static atomic_t n_gup_calls'):source.index('/* ---- /proc/<pid>/map_files/')]
fragment += gup
fragment += source[source.index('/* Kept in one table so init and exit cannot drift apart.'):]
# Keep the CP12 source usable as a negative control for the same caller tests.
fragment += '\n#define HOST_SECOND_REMOTE ' + ('kp_pin_remote' if 'kp_pin_remote' in gup else 'kp_gup_remote_inner') + '\n'

cases = ['empty-fast-path', 'add-delete', 'device-isolation', 'duplicates', 'capacity-reuse',
         'clear', 'maps-root-exclusion', 'sentinel', 'restore-callback',
         'supercall-add-delete', 'invalid-input', 'unavailable',
         'failed-registration', 'retry-registration', 'optional-retry',
         'repeat-lifecycle', 'concurrent-rules', 'gup-return-contract',
         'pin-return-contract', 'gup-gap-boundaries', 'gup-zero-pages',
         'gup-root-control', 'gup-output-lock-preservation',
         'gup-null-anonymous', 'gup-restoration', 'pin-optional-retry',
         'maps-inlined-formatter', 'required-map-files', 'required-walk-ops',
         'gup-cross-vma','pin-cross-vma','gup-overflow','gup-tagged',
         'gup-visible-range','walk-mixed','walk-visible','walk-smaps',
         'walk-other-ops','walk-root','walk-empty','walk-vma']
results = []
with tempfile.TemporaryDirectory(prefix='susfs-map-host-') as temp:
    temp = Path(temp)
    production = temp / 'production.h'
    production.write_text(fragment)
    exe = temp / 'map-hooks'
    flags = (['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-no-pie']
             if args.sanitizers else ['-O2'])
    subprocess.run([os.environ.get('CC', 'cc'), '-std=gnu11', '-Wall', '-Wextra', '-Werror',
                    '-Wno-unused-function', '-Wno-unused-parameter', '-Wno-unused-variable',
                    '-pthread', *flags, '-I', str(here), '-DPRODUCTION="' + str(production) + '"',
                    str(here / 'map_test.c'), '-o', str(exe)], check=True)
    for name in cases:
        env = dict(os.environ)
        if args.sanitizers:
            env.update(ASAN_OPTIONS='detect_leaks=0:abort_on_error=1', UBSAN_OPTIONS='halt_on_error=1')
        run = subprocess.run([str(exe), name], capture_output=True, text=True, env=env, timeout=25)
        results.append({'case': name, 'exit_code': run.returncode,
                        'stdout': run.stdout.strip(), 'stderr': run.stderr.strip()})
        print(run.stdout.strip() or 'FAIL ' + name + ': ' + run.stderr.strip())
if args.json:
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps({'kind': 'production C with host kernel API stubs',
                                    'sanitizers': args.sanitizers, 'hardware_validated': False,
                                    'results': results}, indent=2) + '\n')
raise SystemExit(any(r['exit_code'] for r in results))
