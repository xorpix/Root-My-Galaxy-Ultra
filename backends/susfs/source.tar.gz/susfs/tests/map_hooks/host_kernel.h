/* SPDX-License-Identifier: GPL-2.0 */
#include <assert.h>
#include <errno.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>
#include <sys/types.h>

#define __user
#define PAGE_SIZE 4096
#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
#define READ_ONCE(v) __atomic_load_n(&(v), __ATOMIC_RELAXED)
#define smp_load_acquire(p) __atomic_load_n(p, __ATOMIC_ACQUIRE)
#define smp_store_release(p, v) __atomic_store_n(p, v, __ATOMIC_RELEASE)
#define DEFINE_SPINLOCK(n) pthread_mutex_t n = PTHREAD_MUTEX_INITIALIZER
#define DEFINE_MUTEX(n) pthread_mutex_t n = PTHREAD_MUTEX_INITIALIZER
static _Atomic int host_table_locks;
#define spin_lock_irqsave(l, f) ((f) = 0, (void)atomic_fetch_add(&host_table_locks,1), (void)pthread_mutex_lock(l))
#define spin_unlock_irqrestore(l, f) ((void)(f), (void)pthread_mutex_unlock(l))
#define mutex_lock(l) ((void)pthread_mutex_lock(l))
#define mutex_unlock(l) ((void)pthread_mutex_unlock(l))
#define module_param_named(...)
#define module_param_cb(...)
typedef _Atomic int atomic_t;
#define ATOMIC_INIT(v) (v)
static void atomic_inc(atomic_t *v) { atomic_fetch_add(v, 1); }
static int atomic_read(atomic_t *v) { return atomic_load(v); }
static void host_log(const char *fmt, ...) { (void)fmt; }
#define pr_warn host_log
#define pr_info_ratelimited host_log
#define SUSFS_LOGI host_log
static int scnprintf(char *buf, size_t cap, const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(buf, cap, fmt, ap);
    va_end(ap);
    return n < 0 ? 0 : (size_t)n >= cap ? (int)cap - 1 : n;
}
static ssize_t strscpy(char *dst, const char *src, size_t cap)
{
    size_t n = strlen(src);
    if (!cap) return -E2BIG;
    size_t copy = n < cap - 1 ? n : cap - 1;
    memcpy(dst, src, copy);
    dst[copy] = 0;
    return n < cap ? (ssize_t)n : -E2BIG;
}
static char *strim(char *s)
{
    while (*s && isspace((unsigned char)*s)) s++;
    size_t n = strlen(s);
    while (n && isspace((unsigned char)s[n-1])) s[--n] = 0;
    return s;
}
static bool susfs_abi_path_ok(const char *s, size_t cap) { return s[0] && strnlen(s, cap) < cap; }
struct kernel_param { int unused; };
struct kernel_param_ops {
    int (*set)(const char *, const struct kernel_param *);
    int (*get)(char *, const struct kernel_param *);
};
struct super_block { dev_t s_dev; };
struct inode { unsigned long i_ino; struct super_block *i_sb; };
struct dentry { struct inode *inode; };
struct path { struct dentry *dentry; };
struct file { struct inode *inode; };
struct vm_area_struct {
    struct file *vm_file;
    unsigned long vm_start, vm_end;
};
struct mm_struct {
    struct vm_area_struct *vmas;
    size_t count;
    bool read_locked;
};
static int host_vma_lookups;
static struct vm_area_struct *find_vma(struct mm_struct *mm, unsigned long addr)
{
    assert(mm->read_locked);
    host_vma_lookups++;
    for (size_t i = 0; i < mm->count; i++)
        if (mm->vmas[i].vm_end > addr) return &mm->vmas[i];
    return NULL;
}
struct pt_regs { unsigned long regs[31]; unsigned long pc; };
struct kprobe {
    const char *symbol_name;
    void *addr;
    unsigned int flags;
    bool host_registered;
    int (*pre_handler)(struct kprobe *, struct pt_regs *);
};
struct kretprobe { struct kprobe kp; };
#define KPROBE_FLAG_DISABLED 2U
static const char *fail_name;
static int live_probes;
static int register_kprobe(struct kprobe *kp)
{
    if (!kp->symbol_name || kp->addr) return -EINVAL;
    assert(!kp->host_registered);
    kp->flags &= KPROBE_FLAG_DISABLED;
    kp->addr = (void *)(uintptr_t)0x8000;
    if (fail_name && !strcmp(fail_name, kp->symbol_name)) return -EINVAL;
    kp->host_registered = true;
    live_probes++;
    return 0;
}
static void unregister_kprobe(struct kprobe *kp)
{
    assert(kp->host_registered);
    kp->host_registered = false;
    kp->flags |= KPROBE_FLAG_DISABLED;
    live_probes--;
}
static int register_kretprobe(struct kretprobe *kr) { return register_kprobe(&kr->kp); }
static void unregister_kretprobe(struct kretprobe *kr) { unregister_kprobe(&kr->kp); }
static unsigned int host_uid = 10362;
typedef struct { unsigned int val; } kuid_t;
static kuid_t current_uid(void) { return (kuid_t){host_uid}; }
static void regs_set_return_value(struct pt_regs *r, unsigned long v) { r->regs[0] = v; }
static struct inode *file_inode(struct file *f) { return f->inode; }
static struct inode *d_backing_inode(struct dentry *d) { return d->inode; }
#define LOOKUP_FOLLOW 1
static struct super_block host_sb[2] = {{11}, {22}};
static struct inode host_ino[68];
static struct dentry host_dentry[68];
static int kern_path(const char *name, int flags, struct path *p)
{
    unsigned int id;
    char extra;
    if (sscanf(name, "/file%u%c", &id, &extra) != 1 || id >= 68) return -ENOENT;
    p->dentry = &host_dentry[id];
    return 0;
}
static void path_put(struct path *p) { (void)p; }
struct st_susfs_sus_map { char target_pathname[256]; int err; };
static int copy_from_user(void *dst, const void *src, size_t n)
{ if (!src) return 1; memcpy(dst, src, n); return 0; }
static int copy_to_user(void *dst, const void *src, size_t n)
{ if (!dst) return 1; memcpy(dst, src, n); return 0; }
static atomic_t n_walk_seen, n_walk_seen_vma, n_walk_skip, n_walk_ops_hit;
static atomic_t n_walk_scan_fail, n_walk_nofile, n_walk_nomatch;
static atomic_t n_getlink_calls, n_getlink_skip, n_getlink_nomatch, n_map_files_hides;
static void *sus_map_ops_smaps, *sus_map_ops_smaps_shmem, *sus_map_ops_pagemap;
static void sus_map_resolve_walk_ops(void) { sus_map_ops_smaps = (void *)(uintptr_t)0x9000; }
static bool sus_map_walk_ops_any(void) { return sus_map_ops_smaps != NULL; }
static struct kprobe kp_map_walk = {.symbol_name = "walk_page_range"};
static struct kprobe kp_map_walk_vma = {.symbol_name = "walk_page_vma"};
/* Native callback bodies and rollback/drain run in tests/map_files. This
 * lifecycle harness checks that map rule publication requires installation. */
static bool map_files_installed;
static int map_files_probe_slot = -1, map_files_probe_error;
static atomic_t n_map_files_iterate, n_map_files_entries_hidden;
static atomic_t n_map_files_readlink, n_map_files_follow;
static atomic_t n_map_files_lookup, n_map_files_lookup_hides;
static atomic_t n_map_files_revalidate, n_map_files_revalidate_hides, n_map_files_revalidate_rcu;
static atomic_t n_map_files_paths, n_map_files_puts, n_map_files_jumps;
static int sus_map_files_install(void)
{
    if (fail_name && !strcmp(fail_name, "map_files"))
        return -EIO;
    map_files_installed = true;
    return 0;
}
static void sus_map_files_remove(void) { map_files_installed = false; }

static atomic_t n_map_files_diverted, n_map_files_bypassed;
