# SUS_MAP management and remote-page regressions

The harness extracts production rule operations, the maps/smaps pre-handler,
the actual remote-page pre-handler and both public wrapper declarations, probe
registration, init/exit, the upstream add-supercall handler and root-only sysfs
control. Kernel API stubs model retained kprobe addresses/disabled flags,
filesystem identity, credentials, VMA gaps and the caller-held mmap read lock.

Twenty-seven cases cover exact inode/device isolation, deduplication, capacity and
slot reuse, delete/clear, app filtering with root exclusion, sentinel rejection,
restoration, ABI input errors, failed registration without rule publication,
partial retries, sixteen init/exit cycles, and concurrent readers/writers.
The CP15 case rejects publication when native map_files installation fails.
The remote-page cases exercise the Linux 6.12 `get_user_page_vma_remote()`
consumer contract: only a negative result prevents consumption of its page
output. A poison page output exposes CP12's unsafe zero return as an assertion,
without dereferencing it or executing a kernel module. They also check gap and
VMA boundaries, zero-page passthrough, root/control exclusion, untouched page
outputs and lock state, anonymous mappings, restoration and pin-probe retries.
The maps dispatch case models the real `show_map` seq callback with its
`show_map_vma` formatter inlined. A helper-only probe cannot hide its row;
the case fails with CP13 source while root, control and restoration stay visible.

```sh
python3 tests/map_hooks/run.py
python3 tests/map_hooks/run.py --sanitizers
# Negative control: the CP12 source must fail the new contract cases.
python3 tests/map_hooks/run.py --source-dir /path/to/checkpoint12/susfs
```

Page-walk callback bodies are outside this host harness. The actual native
map_files bodies and path ownership run separately in `tests/map_files/run.py`.
Phone effects are checked by `tests/phone/rmgu-susfs-map-test.py`. Host passes
do not establish live Samsung symbol reachability, VMA layout or filtering.
