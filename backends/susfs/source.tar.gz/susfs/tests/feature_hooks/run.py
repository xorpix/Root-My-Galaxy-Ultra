#!/usr/bin/env python3
"""Exercise the production syscall dispatcher and fdinfo hooks with host kernel stubs."""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-dir', type=Path, default=Path(__file__).resolve().parents[2])
parser.add_argument('--sanitizers', action='store_true')
parser.add_argument('--only-syscall', action='store_true')
parser.add_argument('--json', type=Path)
args = parser.parse_args()
here = Path(__file__).resolve().parent
kernel = args.source_dir.resolve() / 'kernel'

def function(source, name):
    # Production definitions have their final brace at column zero; nested blocks do not.
    match = re.search(r'^static [^\n]*\b' + re.escape(name) + r'\([^;{]*\)\n\{\n.*?^\}\n',
                      source, re.M | re.S)
    if not match:
        raise ValueError('Missing production function: ' + name)
    return match.group()

stat = (kernel / 'susfs_kstat.c').read_text()
counter_start = stat.index('struct kstat_call_counters {')
counter_end = stat.index('/* Rewrite the requested fields of the native user statbuf.', counter_start)
constants = '\n'.join(re.findall(r'^#define (?:COMPAT_\w+_NR|KSTAT_NR_\w+)\b[^\n]*', stat, re.M))
stat_fragment = constants + '\n' + stat[counter_start:counter_end]
stat_fragment += '\n' + function(stat, 'kstat_sys_exit')
cases = {'syscall': ['cross-abi', 'native-stat', 'compat-stat', 'dirent',
                     'errors-null', 'ordinary-syscalls', 'legacy-wrap']}
fragments = {'syscall': stat_fragment}
if not args.only_syscall:
    redirect = (kernel / 'susfs_open_redirect.c').read_text()
    start = redirect.index('static atomic_t or_rev_fdinfo_hits')
    end = redirect.index('static bool or_registered;', start)
    fragments['fdinfo'] = redirect[start:end]
    cases['fdinfo'] = ['duplicates-lifecycle', 'partial-failures', 'phone-leak',
                       'file-credentials', 'decimal-width', 'decimal-bounds']

results = []
with tempfile.TemporaryDirectory(prefix='susfs-feature-host-') as temp:
    temp = Path(temp)
    for group, names in cases.items():
        production = temp / (group + '-production.h')
        production.write_text(fragments[group])
        exe = temp / group
        flags = ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-no-pie'] if args.sanitizers else ['-O2']
        subprocess.run([os.environ.get('CC', 'cc'), '-std=gnu11', '-Wall', '-Wextra', '-Werror',
                        '-Wno-unused-function', '-Wno-unused-parameter', *flags,
                        '-I', str(here), '-DPRODUCTION="' + str(production) + '"',
                        str(here / (group + '_test.c')), '-o', str(exe)], check=True)
        for name in names:
            env = dict(os.environ)
            if args.sanitizers:
                env.update(ASAN_OPTIONS='detect_leaks=0:abort_on_error=1', UBSAN_OPTIONS='halt_on_error=1')
            run = subprocess.run([str(exe), name], capture_output=True, text=True, env=env, timeout=20)
            results.append({'case': group + '/' + name, 'exit_code': run.returncode,
                            'stdout': run.stdout.strip(), 'stderr': run.stderr.strip()})
            print(run.stdout.strip() or 'FAIL ' + group + '/' + name + ': ' + run.stderr.strip())
if args.json:
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps({'kind': 'production C with host kernel API stubs',
                                    'sanitizers': args.sanitizers, 'hardware_validated': False,
                                    'results': results}, indent=2) + '\n')
raise SystemExit(any(result['exit_code'] for result in results))
