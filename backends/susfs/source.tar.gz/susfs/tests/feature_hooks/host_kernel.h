/* SPDX-License-Identifier: GPL-2.0 */
#include <assert.h>
#include <errno.h>
#include <limits.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef uint32_t u32;
typedef struct { unsigned int value; } atomic_t;
#define ATOMIC_INIT(n) { .value = (n) }
static void atomic_inc(atomic_t *v) { v->value++; }
static int atomic_inc_return(atomic_t *v) { v->value++; return (int)v->value; }
static int atomic_read(const atomic_t *v) { return (int)v->value; }
#define WRITE_ONCE(p, v) ((p) = (v))
#define READ_ONCE(p) (p)
#define pr_warn(...) ((void)0)
#define SUSFS_LOGI(...) ((void)0)

struct pt_regs { unsigned long regs[31], args[6]; long nr, ret; };
static unsigned long regs_return_value(struct pt_regs *r) { return (unsigned long)r->ret; }
