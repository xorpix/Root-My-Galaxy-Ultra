/* SPDX-License-Identifier: GPL-2.0 */
#include "host_kernel.h"

/* Linux arm64 native table; AArch32 cases below are checked independently against
 * arch/arm64/tools/syscall_32.tbl, including collisions with native operations. */
#define __NR_newfstatat 79
#define __NR_fstat 80
#define __NR_statx 291
static bool task_compat;
static int arg_reads, dirent_calls, rewrites, return_writes, layout_seen;
static long dirent_nr, dirent_result;
static unsigned long ptr_seen;
static u32 mask_seen;
static bool compat_seen;
#define current NULL
static bool is_compat_task(void) { return task_compat; }
static void *compat_ptr(u32 p) { return (void *)(uintptr_t)p; }
static long syscall_get_nr(void *task, struct pt_regs *r) { return r->nr; }
static void syscall_get_arguments(void *task, struct pt_regs *r, unsigned long *args)
{ arg_reads++; memcpy(args, r->args, sizeof(r->args)); }
static void syscall_set_return_value(void *task, struct pt_regs *r, int err, long value)
{ assert(err == 0); return_writes++; r->ret = value; }
static long sus_path_dirent_filter(long nr, unsigned long ptr, long ret)
{ dirent_calls++; dirent_nr = nr; ptr_seen = ptr; return dirent_result; }
struct kstat_call_state;
static bool susfs_kstat_spoof_statbuf(struct kstat_call_state *, unsigned long);
static bool susfs_kstat_spoof_compat_statbuf(struct kstat_call_state *, unsigned long);
static bool susfs_kstat_spoof_statx(struct kstat_call_state *, unsigned long, u32);
static bool susfs_kstat_spoof_compat_stat(struct kstat_call_state *, unsigned long);
#define __maybe_unused __attribute__((unused))
static int fault_depth;
static void pagefault_disable(void) { assert(!fault_depth); fault_depth++; }
static void pagefault_enable(void) { assert(fault_depth == 1); fault_depth--; }
#include PRODUCTION

static struct kstat_call_counters *counter_seen;
static bool record(struct kstat_call_state *st, unsigned long ptr, int layout)
{
    assert(fault_depth == 1); rewrites++; ptr_seen = ptr; compat_seen = st->compat;
    counter_seen = st->cnt; layout_seen = layout; return true;
}
static bool susfs_kstat_spoof_statbuf(struct kstat_call_state *st, unsigned long p)
{ return record(st, p, 1); }
static bool susfs_kstat_spoof_compat_statbuf(struct kstat_call_state *st, unsigned long p)
{ return record(st, p, 2); }
static bool susfs_kstat_spoof_compat_stat(struct kstat_call_state *st, unsigned long p)
{ return record(st, p, 4); }
static bool susfs_kstat_spoof_statx(struct kstat_call_state *st, unsigned long p, u32 mask)
{ mask_seen = mask; return record(st, p, 3); }

static struct pt_regs regs(long nr)
{
    struct pt_regs r = { .nr = nr, .args = {11, 0x11111111, 0x22222222, 0x33333333, 0x44444444, 55} };
    return r;
}
static void reset(void)
{
    assert(!fault_depth); arg_reads = dirent_calls = rewrites = return_writes = layout_seen = 0;
    ptr_seen = mask_seen = 0; counter_seen = NULL;
}
static void ignored(long nr, bool compat)
{
    struct pt_regs r = regs(nr);
    unsigned int unlisted = n_kstat_unlisted.value;
    reset(); task_compat = compat; kstat_sys_exit(NULL, &r, 42);
    assert(!arg_reads && !dirent_calls && !rewrites && !return_writes);
    assert(n_kstat_unlisted.value == unlisted);
}
static void stat_call(long nr, bool compat, int layout, int arg)
{
    struct pt_regs r = regs(nr);
    reset(); task_compat = compat;
    r.args[arg] |= 0xdeadbeef00000000UL;
    kstat_sys_exit(NULL, &r, 0);
    assert(arg_reads == 1 && rewrites == 1 && !dirent_calls);
    assert(layout_seen == layout && compat_seen == compat);
    assert(ptr_seen == (compat ? (u32)r.args[arg] : r.args[arg]));
    assert(counter_seen && atomic_read(&counter_seen->calls) > 0 && !fault_depth);
    if (layout == 3) assert(mask_seen == (u32)r.args[3]);
}
int main(int argc, char **argv)
{
    assert(argc == 2);
    const char *name = argv[1];
    if (!strcmp(name, "cross-abi")) {
        /* Before CP9 these native operations enter compat getdents/stat handlers. */
        long native[] = {141, 217, 195, 196, 197, 327, 397, 106, 107, 108};
        long compat[] = {61, 79, 80, 291, 293};
        for (size_t i = 0; i < sizeof(native)/sizeof(*native); i++) ignored(native[i], false);
        for (size_t i = 0; i < sizeof(compat)/sizeof(*compat); i++) ignored(compat[i], true);
    } else if (!strcmp(name, "native-stat")) {
        stat_call(79, false, 1, 2); assert(counter_seen == &cnt_nfstatat);
        stat_call(80, false, 1, 1); assert(counter_seen == &cnt_nfstat);
        stat_call(291, false, 3, 4); assert(counter_seen == &cnt_statx);
    } else if (!strcmp(name, "compat-stat")) {
        stat_call(195, true, 2, 1); assert(counter_seen == &cnt_stat64);
        stat_call(196, true, 2, 1); assert(counter_seen == &cnt_lstat64);
        stat_call(197, true, 2, 1); assert(counter_seen == &cnt_fstat64);
        stat_call(327, true, 2, 2); assert(counter_seen == &cnt_fstatat64);
        stat_call(397, true, 3, 4);
    } else if (!strcmp(name, "dirent")) {
        long numbers[] = {61, 141, 217};
        for (int i = 0; i < 3; i++) {
            struct pt_regs r = regs(numbers[i]);
            reset(); task_compat = i != 0; r.args[1] |= 0xdeadbeef00000000UL;
            dirent_result = 128; r.ret = 256;
            kstat_sys_exit(NULL, &r, 256);
            assert(arg_reads == 1 && dirent_calls == 1 && !rewrites);
            assert(dirent_nr == numbers[i] && r.ret == 128 && return_writes == 1);
            assert(ptr_seen == (task_compat ? (u32)r.args[1] : r.args[1]));
            reset(); dirent_result = 0; kstat_sys_exit(NULL, &r, 0);
            assert(!return_writes);
        }
    } else if (!strcmp(name, "errors-null")) {
        struct pt_regs r = regs(80);
        task_compat = false;
        kstat_sys_exit(NULL, &r, -EFAULT);
        assert(atomic_read(&cnt_nfstat.ret_err) == 1 && !arg_reads && !rewrites);
        r.args[1] = 0; kstat_sys_exit(NULL, &r, 0);
        assert(atomic_read(&cnt_nfstat.no_buf) == 1 && arg_reads == 1 && !rewrites);
        reset(); task_compat = true; r = regs(197); r.args[1] = 0x100000000UL;
        kstat_sys_exit(NULL, &r, 0);
        assert(atomic_read(&cnt_fstat64.no_buf) == 1 && !rewrites);
    } else if (!strcmp(name, "ordinary-syscalls")) {
        for (long nr = -1; nr <= 600; nr++) {
            if (nr != 61 && nr != 79 && nr != 80 && nr != 291) ignored(nr, false);
            if (nr != 106 && nr != 107 && nr != 108 && nr != 141 && nr != 195 &&
                nr != 196 && nr != 197 && nr != 217 && nr != 327 && nr != 397)
                ignored(nr, true);
        }
    } else if (!strcmp(name, "legacy-wrap")) {
        stat_call(106, true, 4, 1); assert(counter_seen == &cnt_compat_stat);
        stat_call(107, true, 4, 1); assert(counter_seen == &cnt_compat_lstat);
        stat_call(108, true, 4, 1); assert(counter_seen == &cnt_compat_fstat);
        assert(atomic_read(&n_kstat_unlisted) == 0);
    } else return 2;
    printf("PASS syscall/%s\n", name);
    return 0;
}
