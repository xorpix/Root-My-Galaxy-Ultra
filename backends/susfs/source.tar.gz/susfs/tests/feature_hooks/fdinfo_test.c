/* SPDX-License-Identifier: GPL-2.0 */
#include "host_kernel.h"

struct dentry { struct dentry *d_parent; struct { const char *name; } d_name; };
struct file { struct { struct dentry *dentry; } f_path; };
struct seq_file { char *buf; size_t count, size; struct file *file; };
struct kretprobe_instance { void *data; };
struct kretprobe {
    struct { void *addr; } kp;
    int (*entry_handler)(struct kretprobe_instance *, struct pt_regs *);
    int (*handler)(struct kretprobe_instance *, struct pt_regs *);
    size_t data_size;
    int maxactive;
    bool registered;
};
static bool visible = true;
static bool or_reverse_visible(void) { return visible; }
static bool susfs_ptr_plausible(const void *p)
{ return (uintptr_t)p >= 4096 && (uintptr_t)p < (uintptr_t)-4095; }
static unsigned long found[8] = {0x1000, 0x2000, 0x3000, 0x4000};
static int found_count = 4, register_calls, unregister_calls;
static unsigned int fail_mask;
static unsigned long source_ino = 973554, dest_ino = 739134, source_mnt = 15712;
static bool susfs_open_redirect_spoof_ids(unsigned long old, unsigned long *ino, unsigned long *mnt)
{
    if (old != dest_ino) return false;
    *ino = source_ino; *mnt = source_mnt; return true;
}
static int ksu_find_symbol_all(const char *name, unsigned long *addrs, int max)
{
    assert(!strcmp(name, "seq_show") && max == 8);
    memcpy(addrs, found, sizeof(*addrs) * (size_t)found_count);
    return found_count;
}
static int register_kretprobe(struct kretprobe *p)
{
    assert(!p->registered && p->kp.addr);
    assert(p->entry_handler && p->handler && p->data_size == sizeof(struct seq_file *));
    register_calls++;
    int index = ((uintptr_t)p->kp.addr / 0x1000) - 1;
    if (fail_mask & (1U << index)) return -EINVAL;
    p->registered = true; return 0;
}
static void unregister_kretprobe(struct kretprobe *p)
{ assert(p->registered); unregister_calls++; p->registered = false; }
#include PRODUCTION

static struct dentry parent = { .d_name = { .name = "fdinfo" } };
static struct dentry child = { .d_parent = &parent };
static struct file procfile = { .f_path = { .dentry = &child } };
static void init_seq(struct seq_file *m, char *buf, size_t size, const char *text)
{
    assert(strlen(text) < size); strcpy(buf, text);
    *m = (struct seq_file){ .buf = buf, .size = size, .count = strlen(text), .file = &procfile };
}
static void callback(struct kretprobe *p, struct seq_file *m)
{
    struct seq_file *slot = NULL;
    struct kretprobe_instance ri = { .data = &slot };
    struct pt_regs r = { .regs = {(uintptr_t)m} };
    if (!p->entry_handler(&ri, &r)) p->handler(&ri, &r);
}
static void text_eq(struct seq_file *m, const char *text)
{ assert(m->count == strlen(text) && !memcmp(m->buf, text, m->count)); }

int main(int argc, char **argv)
{
    assert(argc == 2);
    const char *name = argv[1];
    if (!strcmp(name, "duplicates-lifecycle")) {
        assert(!or_fdinfo_arm());
        assert(or_fdinfo_registered && or_fdinfo_probes == 4 && register_calls == 4);
        for (int i = 0; i < 4; i++) assert((uintptr_t)kr_or_fdinfo[i].kp.addr == found[i]);
        assert(!or_fdinfo_arm() && register_calls == 4);
        or_fdinfo_disarm();
        assert(!or_fdinfo_registered && !or_fdinfo_probes && unregister_calls == 4);
        or_fdinfo_disarm(); assert(unregister_calls == 4);
        assert(!or_fdinfo_arm() && register_calls == 8);
        or_fdinfo_disarm(); assert(unregister_calls == 8);
    } else if (!strcmp(name, "partial-failures")) {
        fail_mask = (1U << 0) | (1U << 2);
        assert(or_fdinfo_arm()==-EIO && !or_fdinfo_registered && !or_fdinfo_probes && !or_fdinfo_candidates);
        assert(!kr_or_fdinfo[0].kp.addr && !kr_or_fdinfo[2].kp.addr);
        or_fdinfo_disarm(); assert(unregister_calls == 2);
        fail_mask = 15;
        assert(or_fdinfo_arm() == -EIO && !or_fdinfo_registered && !or_fdinfo_probes);
        or_fdinfo_disarm(); assert(unregister_calls == 2);
        found_count = 0;
        assert(or_fdinfo_arm() == -ENOENT && !or_fdinfo_candidates);
        fail_mask = 0; found_count = 4;
        assert(!or_fdinfo_arm() && or_fdinfo_probes == 4);
        or_fdinfo_disarm(); assert(unregister_calls == 6);
    } else if (!strcmp(name, "phone-leak")) {
        struct seq_file m; char buf[256];
        assert(!or_fdinfo_arm());
        init_seq(&m, buf, sizeof(buf), "pos:\t0\nflags:\t0400000\nmnt_id:\t15712\nino:\t739134\n");
        /* fdinfo is the fourth duplicate, not the first one resolved by a name probe. */
        callback(&kr_or_fdinfo[3], &m);
        text_eq(&m, "pos:\t0\nflags:\t0400000\nmnt_id:\t15712\nino:\t973554\n");
        assert(atomic_read(&or_rev_fdinfo_hits) == 1 && atomic_read(&or_rev_fdinfo_rewrites) == 1);
        or_fdinfo_disarm();
    } else if (!strcmp(name, "file-credentials")) {
        struct seq_file m; char buf[256];
        assert(!or_fdinfo_arm());
        const char *text = "mnt_id:\t15712\nino:\t739134\n";
        init_seq(&m, buf, sizeof(buf), text);
        parent.d_name.name = "net"; callback(&kr_or_fdinfo[0], &m); text_eq(&m, text);
        assert(!atomic_read(&or_rev_fdinfo_hits));
        parent.d_name.name = "fdinfo";
        visible = false; callback(&kr_or_fdinfo[3], &m); text_eq(&m, text);
        assert(!atomic_read(&or_rev_fdinfo_hits)); visible = true;
        struct seq_file *slot = NULL; struct kretprobe_instance ri = { .data = &slot };
        struct pt_regs r = { .regs = {1} };
        assert(or_fdinfo_entry(&ri, &r) == 1 && slot == NULL);
        m.file = NULL; callback(&kr_or_fdinfo[3], &m); text_eq(&m, text);
        assert(!atomic_read(&or_rev_fdinfo_hits));
        or_fdinfo_disarm();
    } else if (!strcmp(name, "decimal-width")) {
        struct seq_file m; char buf[256]; size_t pos, len; unsigned long val;
        init_seq(&m, buf, sizeof(buf), "mnt_id:\t15712\nino:\t739134\n");
        assert(or_fdinfo_find_dec(&m, "ino:\t", 5, &pos, &len, &val) && val == 739134);
        assert(or_fdinfo_write_dec(&m, pos, len, ULONG_MAX));
        assert(or_fdinfo_find_dec(&m, "ino:\t", 5, &pos, &len, &val) && val == ULONG_MAX);
        assert(or_fdinfo_write_dec(&m, pos, len, 0));
        text_eq(&m, "mnt_id:\t15712\nino:\t0\n");
        assert(or_fdinfo_find_dec(&m, "ino:\t", 5, &pos, &len, &val) && val == 0);
        assert(or_fdinfo_write_dec(&m, pos, len, 4294967296UL));
        assert(or_fdinfo_find_dec(&m, "ino:\t", 5, &pos, &len, &val) && val == 4294967296UL);
    } else if (!strcmp(name, "decimal-bounds")) {
        struct seq_file m; char buf[256]; size_t pos, len; unsigned long val;
        const char *invalid[] = {"xino:\t42\n", "ino:\t\n", "ino:\t12x\n", "ino:\t12", "ino:\t18446744073709551616\n"};
        for (size_t i = 0; i < sizeof(invalid)/sizeof(*invalid); i++) {
            init_seq(&m, buf, sizeof(buf), invalid[i]);
            assert(!or_fdinfo_find_dec(&m, "ino:\t", 5, &pos, &len, &val));
        }
        init_seq(&m, buf, sizeof(buf), "ino:\t1\n");
        assert(or_fdinfo_find_dec(&m, "ino:\t", 5, &pos, &len, &val));
        m.size = m.count + 1;
        assert(!or_fdinfo_write_dec(&m, pos, len, ULONG_MAX)); text_eq(&m, "ino:\t1\n");
        assert(!or_fdinfo_write_dec(&m, SIZE_MAX, len, 1));
        assert(!or_fdinfo_write_dec(&m, pos, SIZE_MAX, 1));
        m.count = m.size;
        assert(!or_fdinfo_find_dec(&m, "ino:\t", 5, &pos, &len, &val));
        assert(!or_fdinfo_write_dec(&m, pos, len, 1));
    } else return 2;
    printf("PASS fdinfo/%s\n", name);
    return 0;
}
