# Syscall dispatch and redirect fdinfo regressions

Run `python3 tests/feature_hooks/run.py` and repeat with `--sanitizers` for ASan/UBSan.
The runner extracts the production dispatcher, its actual counters/constants, and the
production fdinfo hook functions. It compiles those fragments with host kernel API stubs.

The seven syscall cases check cross-ABI collisions, native and compat stat argument/layout
selection, compat statx 397, directory return-value updates, failed/null-buffer calls,
irrelevant syscall numbers across both tables, and diagnostic-ring wrap. The old checkpoint-8
dispatcher fails the collision, compat-stat, null-buffer, and unrelated-syscall regressions:

```sh
python3 tests/feature_hooks/run.py --only-syscall --source-dir /path/to/checkpoint-8/susfs
```

The six fdinfo cases check enumeration of duplicate symbols, partial/all registration failure,
idempotent registration and exact cleanup/rearming, the reported 739134 → 973554 inode leak
with fdinfo as the fourth symbol, unrelated files/root exclusion, 64-bit decimal values, and
buffer/overflow boundaries.

The model checks production control flow and formatting. It does not execute a kernel module,
establish Samsung hook reachability, model real credential transitions or kretprobe concurrency,
or certify all stat rewrites. The unchanged phone feature runner must confirm the fdinfo fix.
