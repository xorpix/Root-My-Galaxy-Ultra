#!/usr/bin/env python3
"""Exercise the production proc snapshot/iterator with explicit host kernel shims."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('extract', ROOT / 'tests/path_creds/run.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


def fragments(source):
    text = (source / 'kernel/sus_path.c').read_text()
    parts = []
    for name in ('SUS_PATH_MAX_ENTRIES', 'SUS_PATH_LEN', 'SUS_PATH_LIST_SLACK',
                 'SUS_PATH_SNAPSHOT_RETRIES', 'SUS_PATH_SNAPSHOT_RESERVE'):
        parts.append(re.search(r'^#define ' + name + r' .*$', text, re.M)[0])
    for name in ('sus_path_entry', 'sus_path_snapshot_row', 'sus_path_snapshot'):
        start = text.index('struct ' + name + ' {')
        parts.append(text[start:text.index('\n};', start) + 3])
    for line in text.splitlines():
        if re.match(r'static (?:LIST_HEAD\(sus_path_list|DEFINE_SPINLOCK\(sus_path_lock|'
                    r'unsigned int sus_path_count|int (?:hide_from_apps|n_lsm_ext_fail)|'
                    r'const char \*first_lsm_ext_fail|atomic_t (?:n_enoent_|n_identity_hits|'
                    r'sus_path_n_pending|sus_path_pend_))', line):
            parts.append(line)
    for name in ('sus_path_list_puts', 'sus_path_format_header', 'sus_path_format_list',
                 'sus_path_snapshot_create', 'sus_path_snapshot_start', 'sus_path_snapshot_next',
                 'sus_path_snapshot_stop', 'sus_path_proc_show'):
        parts.append(extract.function(text, name))
    start = text.index('static const struct seq_operations sus_path_snapshot_ops =')
    parts.append(text[start:text.index('\n};', start) + 3])
    for name in ('sus_path_proc_open', 'sus_path_proc_release'):
        parts.append(extract.function(text, name))
    return '\n\n'.join(parts)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-dir', type=Path, default=ROOT)
    parser.add_argument('--sanitizers', action='store_true')
    parser.add_argument('--json', type=Path)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    cases = ['empty', 'multi-page', 'maximum-table', 'short-reads-seek', 'immutable-after-delete',
             'pending-protected-values', 'allocation-failure', 'growth-retry', 'growth-exhaustion',
             'count-mismatch', 'capacity-overflow', 'seq-open-failure', 'app-denial', 'write-only',
             'sysfs-bounds']
    results = []
    with tempfile.TemporaryDirectory(prefix='susfs-path-listing-') as directory:
        root = Path(directory)
        production = root / 'production.h'
        production.write_text(fragments(args.source_dir))
        exe = root / 'test'
        flags = ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-no-pie'] if args.sanitizers else ['-O2']
        command = [os.environ.get('CC', 'cc'), '-std=gnu11', '-Wall', '-Wextra', '-Werror',
                   '-Wno-unused-function', '-Wno-unused-variable', '-Wno-unused-parameter',
                   '-Wno-sign-compare', *flags, '-I', str(here),
                   '-DPRODUCTION="' + str(production) + '"', str(here / 'path_listing_test.c'), '-o', str(exe)]
        subprocess.run(command, check=True)
        env = dict(os.environ, ASAN_OPTIONS='detect_leaks=0:abort_on_error=1', UBSAN_OPTIONS='halt_on_error=1')
        for case in cases:
            run = subprocess.run([str(exe), case], capture_output=True, text=True, timeout=20, env=env)
            results.append(dict(case=case, exit_code=run.returncode, stdout=run.stdout.strip(), stderr=run.stderr.strip()))
            print(run.stdout.strip() or 'FAIL ' + case + ': ' + run.stderr.strip())
        # A compiled runtime negative control: cap iteration to the first ten
        # rows. A large listing must fail its exact row/byte checks.
        original = production.read_text()
        needle = 'if (!snapshot || *pos < 0 || *pos > snapshot->count + 1)'
        assert original.count(needle) == 1
        production.write_text(original.replace(needle, 'if (!snapshot || *pos < 0 || *pos > 10)'))
        subprocess.run(command, check=True)
        run = subprocess.run([str(exe), 'multi-page'], capture_output=True, text=True, timeout=20, env=env)
        negative = dict(case='missing-tail', passed=run.returncode != 0 and 'Assertion' in run.stderr,
                        exit_code=run.returncode, stderr=run.stderr.replace(directory, '<temporary>').strip())
        print(('PASS ' if negative['passed'] else 'FAIL ') + 'missing-tail negative control')
    report = dict(kind='production path snapshot C with host allocator/list/seq_file API models',
                  hardware_validated=False, linux_seq_core_emulated=True, sanitizers=args.sanitizers,
                  results=results, negative_control=negative)
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(report, indent=2) + '\n')
    return int(any(item['exit_code'] for item in results) or not negative['passed'])


if __name__ == '__main__':
    raise SystemExit(main())
