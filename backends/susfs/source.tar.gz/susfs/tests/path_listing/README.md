# Complete proc path-rule snapshots

`python3 tests/path_listing/run.py --sanitizers` compiles the production snapshot,
iterator, open/release and bounded sysfs formatter from `kernel/sus_path.c`.

The host shims model allocator failures, rule growth at allocation boundaries,
record emission, short byte reads and replay after seeking. Every allocation,
free and seq output operation asserts that the table spinlock is not held.
Cases include the full 8,192-rule capacity, maximum path/name lengths and 64-bit
values, an open snapshot after live deletion/replacement, access refusal, and
failure cleanup. A compiled missing-tail negative control must fail exact rows.

This exercises production callbacks with host models, not Linux's seq_file core
or the Samsung kernel. The pinned kernel build checks real API compatibility;
phone acceptance remains required.
