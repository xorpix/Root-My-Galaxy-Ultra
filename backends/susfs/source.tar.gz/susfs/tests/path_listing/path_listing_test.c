/* SPDX-License-Identifier: GPL-2.0 */
#include "host_kernel.h"
#include PRODUCTION

static void add_rows(unsigned int count,bool wide) {
    for(unsigned int i=0;i<count;++i) {
        struct sus_path_entry *e=calloc(1,sizeof(*e));assert(e);
        if(wide) {
            memset(e->path,'p',sizeof(e->path)-1);e->path[0]='/';
            snprintf(e->path+sizeof(e->path)-10,10,"%08u",sus_path_count);
            memset(e->name,'n',sizeof(e->name)-1);
            e->dev=~0ULL-i;e->ino=~0ULL-sus_path_count;
        } else {
            snprintf(e->path,sizeof(e->path),"/owned/rule/%08u",sus_path_count);
            snprintf(e->name,sizeof(e->name),"%08u",sus_path_count);
            e->dev=65105;e->ino=100000+sus_path_count;
        }
        e->self_protect=(sus_path_count%11)==0;
        e->inode=(sus_path_count%7)==0?NULL:(struct inode *)(uintptr_t)0x1000;
        list_add_tail(&e->list,&sus_path_list);++sus_path_count;
    }
}
static void clear_rows(void) {
    while(sus_path_list.next!=&sus_path_list) {
        struct sus_path_entry *e=entry(sus_path_list.next,struct sus_path_entry,list);
        list_del(&e->list);free(e);
    }
    sus_path_count=0;
}
static void grow(void) {
    if(grows_left){--grows_left;add_rows(SUS_PATH_SNAPSHOT_RESERVE+1,false);}
}
static char *read_all(struct seq_file *m,size_t chunk,size_t *length) {
    size_t size=0,capacity=8192;
    char *out=malloc(capacity),*buf=malloc(chunk);assert(out && buf);
    for(size_t n;(n=host_read(m,buf,chunk));) {
        if(size+n+1>capacity){capacity=(size+n+1)*2;out=realloc(out,capacity);assert(out);}
        memcpy(out+size,buf,n);size+=n;
    }
    free(buf);out[size]=0;*length=size;return out;
}
static void exact_rows(const char *text,unsigned int expected) {
    const char *next=text;
    unsigned int count=0;
    struct sus_path_entry *e;
    list_for_each_entry(e,&sus_path_list,list) {
        char row[1024];
        snprintf(row,sizeof(row),"path=%s  dev=%llu ino=%llu name=%s%s%s\n",
                 e->path[0]?e->path:"(?)",e->dev,e->ino,e->name,
                 e->self_protect?"  [ours: clear/del refuse it]":"",
                 e->inode?"":"  (pending: no inode yet)");
        next=strstr(next,"path=");assert(next && !strncmp(next,row,strlen(row)));
        next+=strlen(row);++count;
    }
    assert(count==expected && !strstr(next,"path=") && !strstr(text,"truncated:"));
    char footer[96],header[96];
    snprintf(footer,sizeof(footer),"listing_end: rules=%u\n",expected);
    snprintf(header,sizeof(header),"listing: checkpoint=24 snapshot=1 rules=%u\n",expected);
    assert(strstr(text,header) && strstr(next,footer) && !strcmp(strstr(next,footer),footer));
}

int main(int argc,char **argv) {
    assert(argc==2);const char *test=argv[1];
    /* The watchdog bounds every case; the maximum-table round needs the larger
     * budget the sanitizers genuinely cost on the same work. */
#ifndef __has_feature
#define __has_feature(x) 0
#endif
#if defined(__SANITIZE_ADDRESS__) || __has_feature(address_sanitizer)
    alarm(120);
#else
    alarm(15);
#endif
    struct file file={.f_mode=FMODE_READ};
    if(!strcmp(test,"app-denial")) {
        reader_uid=10362;assert(sus_path_proc_open(NULL,&file)==-ENOENT && !allocations && !file.private_data);
    } else if(!strcmp(test,"allocation-failure")) {
        fail_alloc=1;assert(sus_path_proc_open(NULL,&file)==-ENOMEM && !file.private_data && !allocations);
    } else if(!strcmp(test,"capacity-overflow")) {
        sus_path_count=SUS_PATH_MAX_ENTRIES+1;
        assert(sus_path_proc_open(NULL,&file)==-EOVERFLOW && !allocations);sus_path_count=0;
    } else if(!strcmp(test,"count-mismatch")) {
        add_rows(3,false);--sus_path_count;
        assert(sus_path_proc_open(NULL,&file)==-EIO && !file.private_data);
    } else if(!strcmp(test,"growth-exhaustion")) {
        grows_left=SUS_PATH_SNAPSHOT_RETRIES;allocation_hook=grow;
        assert(sus_path_proc_open(NULL,&file)==-EAGAIN && allocations==SUS_PATH_SNAPSHOT_RETRIES && !file.private_data);
    } else if(!strcmp(test,"seq-open-failure")) {
        add_rows(100,false);fail_open=1;
        assert(sus_path_proc_open(NULL,&file)==-ENOMEM && allocations==1 && frees==1 && !file.private_data);
    } else if(!strcmp(test,"sysfs-bounds")) {
        add_rows(200,true);
        unsigned char buf[PAGE_SIZE+32];memset(buf,0xa5,sizeof(buf));
        int n=sus_path_format_list((char *)buf,PAGE_SIZE);assert(n>0 && n<PAGE_SIZE);
        for(unsigned int i=PAGE_SIZE;i<sizeof(buf);++i)assert(buf[i]==0xa5);
        assert(!allocations);
    } else if(!strcmp(test,"write-only")) {
        add_rows(SUS_PATH_MAX_ENTRIES,true);file.f_mode=0;fail_alloc=1;
        assert(!sus_path_proc_open(NULL,&file) && !allocations);
        assert(((struct seq_file *)file.private_data)->private==NULL);
        assert(!sus_path_proc_release(NULL,&file));
    } else {
        unsigned int count=0;
        if(!strcmp(test,"maximum-table"))count=SUS_PATH_MAX_ENTRIES;
        else if(strcmp(test,"empty"))count=200;
        add_rows(count,!strcmp(test,"maximum-table") || !strcmp(test,"pending-protected-values"));
        if(!strcmp(test,"growth-retry")){grows_left=1;allocation_hook=grow;}
        assert(!sus_path_proc_open(NULL,&file));
        struct seq_file *m=file.private_data;
        if(!strcmp(test,"growth-retry"))assert(allocations==2 && frees==1);
        size_t len;char *full=read_all(m,65536,&len);
        exact_rows(full,sus_path_count);
        if(count)assert(len>PAGE_SIZE);
        if(!strcmp(test,"empty"))assert(strstr(full,"(no paths registered)\n"));
        if(!strcmp(test,"immutable-after-delete")) {
            clear_rows();add_rows(5,true);
            /* Advance live diagnostics too: open snapshots must remain stable. */
            n_identity_hits=17;sus_path_pend_ticks=91;
            host_rewind(m);size_t copy_len;char *copy=read_all(m,7,&copy_len);
            assert(copy_len==len && !memcmp(full,copy,len));free(copy);
        }
        if(!strcmp(test,"short-reads-seek")) {
            for(unsigned int chunk=1;chunk<2048;chunk=chunk*3+1) {
                host_rewind(m);size_t copy_len;char *copy=read_all(m,chunk,&copy_len);
                assert(copy_len==len && !memcmp(full,copy,len));free(copy);
            }
            /* Replay a seek to a non-record byte offset. */
            host_rewind(m);size_t off=PAGE_SIZE+17;char *skip=malloc(off),suffix[23];assert(skip);
            assert(host_read(m,skip,off)==off && host_read(m,suffix,sizeof(suffix))==sizeof(suffix));
            assert(!memcmp(suffix,full+off,sizeof(suffix)));free(skip);
        }
        free(full);assert(!sus_path_proc_release(NULL,&file) && !file.private_data);
    }
    clear_rows();assert(allocations==frees && !spin_depth);
    printf("PASS %s\n",test);return 0;
}
