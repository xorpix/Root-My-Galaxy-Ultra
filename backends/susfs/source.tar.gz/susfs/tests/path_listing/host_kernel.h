/* SPDX-License-Identifier: GPL-2.0 */
#include <assert.h>
#include <errno.h>
#include <limits.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

typedef unsigned long long u64;
typedef unsigned short umode_t;
typedef int atomic_t;
#define ATOMIC_INIT(x) (x)
#define atomic_read(p) (*(p))
#define PAGE_SIZE 4096
#define GFP_KERNEL 0
#define READ_ONCE(x) (x)
#define min(a,b) ((a) < (b) ? (a) : (b))
#define struct_size(p,m,n) (sizeof(*(p)) + sizeof((p)->m[0]) * (n))
#define ERR_PTR(x) ((void *)(intptr_t)(x))
#define PTR_ERR(x) ((long)(intptr_t)(x))
#define IS_ERR(x) ((uintptr_t)(x) >= (uintptr_t)-4095)
#define FMODE_READ 1
#define SEQ_START_TOKEN ((void *)1)

struct list_head { struct list_head *next, *prev; };
#define LIST_HEAD(n) struct list_head n={&n,&n}
static void list_add_tail(struct list_head *n,struct list_head *h) { n->prev=h->prev;n->next=h;h->prev->next=n;h->prev=n; }
static void list_del(struct list_head *n) { n->prev->next=n->next;n->next->prev=n->prev; }
#define entry(p,t,m) ((t *)((char *)(p)-__builtin_offsetof(t,m)))
#define list_for_each_entry(e,h,m) for(e=entry((h)->next,__typeof__(*e),m); &e->m!=(h);e=entry(e->m.next,__typeof__(*e),m))
static int spin_depth;
#define DEFINE_SPINLOCK(n) int n
#define spin_lock(p) do { assert(spin_depth==0); ++spin_depth; } while(0)
#define spin_unlock(p) do { assert(spin_depth==1); --spin_depth; } while(0)
struct inode { int unused; };
struct file { unsigned int f_mode; void *private_data; };
struct seq_file;
struct seq_operations {
    void *(*start)(struct seq_file *,loff_t *);
    void *(*next)(struct seq_file *,void *,loff_t *);
    void (*stop)(struct seq_file *,void *);
    int (*show)(struct seq_file *,void *);
};
struct seq_file {
    void *private;
    const struct seq_operations *ops;
    loff_t pos;
    char buffer[PAGE_SIZE];
    size_t size, used;
    bool eof;
};
static unsigned int reader_uid;
static struct { unsigned int val; } current_uid(void) { return (__typeof__(current_uid())){reader_uid}; }
static int allocations, frees, fail_alloc, fail_open, grows_left;
static void (*allocation_hook)(void);
static void *kvzalloc(size_t n,int flags) {
    assert(!spin_depth);
    if(fail_alloc)return NULL;
    void *p=calloc(1,n);assert(p);++allocations;
    if(allocation_hook)allocation_hook();
    return p;
}
static void kvfree(void *p) { assert(!spin_depth);if(p){++frees;free(p);} }
static int seq_open(struct file *file,const struct seq_operations *ops) {
    assert(!spin_depth);
    if(fail_open)return -ENOMEM;
    struct seq_file *m=calloc(1,sizeof(*m));assert(m);m->ops=ops;file->private_data=m;return 0;
}
static int seq_release(struct inode *inode,struct file *file) {
    assert(!spin_depth);struct seq_file *m=file->private_data;assert(!m->private);free(m);file->private_data=NULL;return 0;
}
static void seq_write(struct seq_file *m,const char *s,size_t n) {
    assert(!spin_depth && m->size+n<sizeof(m->buffer));memcpy(m->buffer+m->size,s,n);m->size+=n;m->buffer[m->size]=0;
}
static void seq_printf(struct seq_file *m,const char *fmt,...) {
    assert(!spin_depth);va_list args;va_start(args,fmt);
    int n=vsnprintf(m->buffer+m->size,sizeof(m->buffer)-m->size,fmt,args);va_end(args);
    assert(n>=0 && (size_t)n<sizeof(m->buffer)-m->size);m->size+=(size_t)n;
}
static void seq_puts(struct seq_file *m,const char *s) { seq_write(m,s,strlen(s)); }
static int sus_path_cred_count(void) { return 0; }
static bool sus_path_cred_active(void) { return false; }

/* Byte-stream/seek harness. This deliberately does not claim to be the Linux
 * seq_file core; the production callbacks and their lifetime are exercised. */
static size_t host_read(struct seq_file *m,char *out,size_t length) {
    size_t n=0;
    while(n<length) {
        if(m->used==m->size) {
            if(m->eof)break;
            m->size=m->used=0;
            void *v=m->ops->start(m,&m->pos);
            if(!v){m->eof=true;m->ops->stop(m,v);break;}
            assert(m->ops->show(m,v)==0);
            (void)m->ops->next(m,v,&m->pos);
            m->ops->stop(m,v);
        }
        size_t take=min(length-n,m->size-m->used);
        memcpy(out+n,m->buffer+m->used,take);m->used+=take;n+=take;
    }
    return n;
}
static void host_rewind(struct seq_file *m) { m->pos=0;m->used=m->size=0;m->eof=false; }
