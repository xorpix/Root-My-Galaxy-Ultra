/* SPDX-License-Identifier: GPL-2.0 */
#include <assert.h>
#include <errno.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

typedef uint64_t u64;
typedef unsigned short umode_t;
typedef atomic_int atomic_t;
typedef atomic_int refcount_t;
#define ATOMIC_INIT(x) (x)
#define atomic_read(x) atomic_load(x)
#define atomic_set(x, v) atomic_store(x, v)
#define atomic_inc(x) ((void)atomic_fetch_add(x, 1))
#define atomic_dec(x) ((void)atomic_fetch_sub(x, 1))
#define atomic_inc_return(x) (atomic_fetch_add(x, 1) + 1)
static void refcount_set(refcount_t *r, int n) { atomic_store(r, n); }
static void refcount_inc(refcount_t *r) { assert(atomic_fetch_add(r, 1) > 0); }
static bool refcount_dec_and_test(refcount_t *r) { int n=atomic_fetch_sub(r,1); assert(n>0); return n==1; }
#define GFP_KERNEL 0
#define NAME_MAX 255
#define S_IRWXU 0700
#define S_IRWXG 0070
#define S_IRWXO 0007
#define LOOKUP_FOLLOW 1
#define HZ 100
#define __user
#define READ_ONCE(x) (x)
#define WRITE_ONCE(x, v) ((x)=(v))
#define SUSFS_LOGI(...) ((void)0)
#define pr_warn(...) ((void)0)
#define CMD_SUSFS_ADD_SUS_PATH 0x55550
#define CMD_SUSFS_ADD_SUS_PATH_LOOP 0x55553

struct list_head { struct list_head *next, *prev; };
#define LIST_HEAD(n) struct list_head n={&n,&n}
#define INIT_LIST_HEAD(n) ((n)->next=(n)->prev=(n))
static void list_add_tail(struct list_head *n,struct list_head *h) { n->prev=h->prev;n->next=h;h->prev->next=n;h->prev=n; }
static void list_add(struct list_head *n,struct list_head *h) { n->next=h->next;n->prev=h;h->next->prev=n;h->next=n; }
static void list_del(struct list_head *n) { n->prev->next=n->next;n->next->prev=n->prev; }
#define entry(p,t,m) ((t *)((char *)(p)-__builtin_offsetof(t,m)))
#define list_for_each_entry(e,h,m) for(e=entry((h)->next,__typeof__(*e),m); &e->m!=(h);e=entry(e->m.next,__typeof__(*e),m))
#define list_for_each_entry_safe(e,t,h,m) for(e=entry((h)->next,__typeof__(*e),m),t=entry(e->m.next,__typeof__(*e),m);&e->m!=(h);e=t,t=entry(t->m.next,__typeof__(*t),m))
static void list_splice_init(struct list_head *from,struct list_head *to) {
    if(from->next==from)return;
    from->next->prev=to;from->prev->next=to->next;to->next->prev=from->prev;to->next=from->next;INIT_LIST_HEAD(from);
}
#define DEFINE_SPINLOCK(n) pthread_mutex_t n=PTHREAD_MUTEX_INITIALIZER
#define DEFINE_MUTEX(n) pthread_mutex_t n=PTHREAD_MUTEX_INITIALIZER
static _Thread_local int spin_depth;
#define spin_lock(n) (pthread_mutex_lock(n),++spin_depth)
#define spin_unlock(n) (--spin_depth,pthread_mutex_unlock(n))
#define mutex_lock(n) pthread_mutex_lock(n)
#define mutex_unlock(n) pthread_mutex_unlock(n)
#define mutex_trylock(n) (pthread_mutex_trylock(n)==0)

struct cred {
    atomic_int usage;
    int subscribers;
    unsigned tag, uid, gid, groups, namespace_id, secid;
    int non_rcu;
};
struct task_struct { const struct cred *cred; };
static _Thread_local struct task_struct task;
#define current (&task)
struct super_block { u64 s_dev; };
struct inode { struct super_block *i_sb; u64 i_ino; umode_t i_mode; atomic_int refs; };
struct dentry { struct inode *inode; struct { char *name; } d_name; };
struct path { struct dentry *dentry; };
struct delayed_work { int unused; };
struct st_susfs_sus_path { char target_pathname[256]; unsigned long inode_number; unsigned int i_uid; int err; };
static struct inode *d_inode(struct dentry *d) { return d->inode; }
static void ihold(struct inode *i) { atomic_fetch_add(&i->refs,1); }
static void iput(struct inode *i) { assert(spin_depth==0);assert(atomic_fetch_sub(&i->refs,1)>0); }
static size_t strscpy(char *to,const char *from,size_t n) { size_t k=strnlen(from,n-1);memcpy(to,from,k);to[k]=0;return k; }
static bool susfs_abi_path_ok(const char *p,size_t n) { return p[0]=='/' && memchr(p,0,n); }
static int fail_alloc_at, allocation_calls, fail_prepare;
static atomic_int allocations, prepared, aborted, overrides, reverted, scheduled;
static void *kzalloc(size_t n,int f) { assert(!spin_depth);if(++allocation_calls==fail_alloc_at)return NULL;void *p=calloc(1,n);assert(p);atomic_fetch_add(&allocations,1);return p; }
static void kfree(void *p) { assert(!spin_depth);if(p){assert(atomic_fetch_sub(&allocations,1)>0);free(p);} }
static void *kvmalloc(size_t n,int f) { return kzalloc(n,f); }
static int schedule_delayed_work(struct delayed_work *w,int delay) { assert(!spin_depth);atomic_fetch_add(&scheduled,1);return 1; }
static void sus_path_hooks_arm(void) {}
static int sus_path_add_hidden(const char *p) { return -ENOSYS; }
static unsigned long copy_from_user(void *to,const void *from,size_t n) { memcpy(to,from,n);return 0; }
static unsigned long copy_to_user(void *to,const void *from,size_t n) { memcpy(to,from,n);return 0; }
static struct cred *prepare_creds(void);
static void abort_creds(struct cred *new);
static const struct cred *override_creds(const struct cred *new);
static void revert_creds(const struct cred *old);
static int kern_path(const char *name,int flags,struct path *p);
static void path_put(struct path *p) { iput(p->dentry->inode); }
