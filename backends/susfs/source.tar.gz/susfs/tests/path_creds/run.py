#!/usr/bin/env python3
"""Exercise production LOOP registration/resolution with explicit host API models."""
import argparse
import json
import os
from pathlib import Path
import re
import resource
import subprocess
import tempfile


def function(source, name):
    # Keep original C bytes while using a same-length comment/string mask for braces.
    mask = re.sub(r'/\*.*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',
                  lambda m: ' ' * len(m[0]), source, flags=re.S)
    match = re.search(r'^((?:static )?(?:inline )?[\w *]+\b' + name + r'\([^;]*?\))\s*\{', mask, re.M)
    if not match:
        raise RuntimeError('Missing production function ' + name)
    depth = 1
    end = match.end()
    while depth:
        depth += (mask[end] == '{') - (mask[end] == '}')
        end += 1
    return source[match.start():end]


def fragments(source):
    text = (source / 'kernel/sus_path.c').read_text()
    parts = []
    for name in ('SUS_PATH_MAX_ENTRIES', 'SUS_PATH_LEN', 'SUS_PATH_PENDING_RETRY_S',
                 'SUS_PATH_PENDING_TRIES', 'SUS_PATH_PENDING_BUDGET', 'DIRENT_BUF_SIZE'):
        parts.append(re.search(r'^#define ' + name + r' .*$', text, re.M)[0])
    parts.append(text[text.index('struct sus_path_entry {'):text.index('/* Caller holds sus_path_lock, while the rule remains published.')])
    for line in text.splitlines():
        if re.match(r'static (?:LIST_HEAD\(sus_path_list|DEFINE_SPINLOCK\(sus_path_lock|'
                    r'DEFINE_MUTEX\(sus_path_pending_lock|atomic_t sus_path_(?:n_pending|pending_tries|'
                    r'used_caller_cred|pend_)|unsigned int sus_path_(?:count|pass_gen)|'
                    r'struct task_struct \*sus_path_resolver)', line):
            parts.append(line)
    parts.append((source / 'kernel/sus_path_index.h').read_text())
    parts.append('static struct delayed_work sus_path_pending_wq;\nstatic char *dirent_tmp;\nstatic bool sus_path_ready=true, sus_path_exiting;')
    for name in ('sus_path_prepare_release', 'sus_path_entry_free',
                 'sus_path_entry_set_path', 'sus_path_basename', 'sus_path_resolve_pending',
                 'sus_path_pending_arm', 'sus_path_del_path_impl', 'sus_path_del_path', 'sus_path_path_is_ours',
                 'sus_path_command_impl', 'sus_path_command', 'sus_path_supercall_impl', 'sus_path_supercall'):
        parts.append(function(text, name))
    return '\n\n'.join(parts)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-dir', type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument('--sanitizers', action='store_true')
    parser.add_argument('--json', type=Path)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    cases = ['protected-caller', 'caller-exit', 'allocation-failure', 'prepare-failure',
             'duplicate', 'capacity', 'per-rule-callers', 'resolve-release',
             'manual-complete', 'delete-during-lookup', 'clear-during-lookup',
             'replace-during-lookup', 'lookup-errors', 'cleanup',
             'mode-unchanged', 'chmod-preserved', 'setid-clear-preserved',
             'detached-reference', 'shutdown-reference', 'late-control']
    results = []
    with tempfile.TemporaryDirectory(prefix='susfs-path-creds-') as temp:
        root = Path(temp)
        include = root / 'linux'
        include.mkdir()
        for header in ('slab', 'refcount', 'atomic', 'cred'):
            (include / (header + '.h')).write_text('/* Explicit host API model in host_kernel.h. */\n')
        production = root / 'production.h'
        production.write_text(fragments(args.source_dir))
        exe = root / 'test'
        flags = ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-no-pie'] if args.sanitizers else ['-O2']
        command = [os.environ.get('CC', 'cc'), '-std=gnu11', '-Wall', '-Wextra', '-Werror',
                   '-Wno-unused-function', '-Wno-unused-variable', '-Wno-unused-parameter',
                   '-Wno-sign-compare', '-pthread', *flags, '-I', str(root), '-I', str(here),
                   '-I', str(args.source_dir / 'kernel'),
                   '-DPRODUCTION="' + str(production) + '"',
                   '-DCREDS="' + str(args.source_dir / 'kernel/sus_path_creds.c') + '"',
                   str(here / 'path_creds_test.c'), '-o', str(exe)]
        subprocess.run(command, check=True)
        # This host denies LSAN's /proc task enumeration. Explicit allocation,
        # credential ownership and override counters still assert exact balance.
        env = dict(os.environ, ASAN_OPTIONS='detect_leaks=0:abort_on_error=1', UBSAN_OPTIONS='halt_on_error=1')
        for case in cases:
            run = subprocess.run([str(exe), case], capture_output=True, text=True, timeout=15, env=env)
            results.append(dict(case=case, exit_code=run.returncode, stdout=run.stdout.strip(), stderr=run.stderr.strip()))
            print(run.stdout.strip() or 'FAIL ' + case + ': ' + run.stderr.strip())
        # A runtime regression check: remove the production borrow increment. The
        # code must compile and fail the deletion race, not merely reject a source grep.
        production.write_text(production.read_text().replace('sus_path_cred_get(borrowed);', '/* missing borrower reference */'))
        subprocess.run(command, check=True)
        run = subprocess.run([str(exe), 'delete-during-lookup'], capture_output=True, text=True, timeout=15, env=env)
        negative = dict(case='missing-borrow-reference', passed=run.returncode != 0 and
                        ('Assertion' in run.stderr or 'AddressSanitizer' in run.stderr),
                        exit_code=run.returncode, stderr=run.stderr.replace(temp, '<temporary>').strip())
        print(('PASS ' if negative['passed'] else 'FAIL ') + 'missing-borrow-reference negative control')
    report = dict(kind='production LOOP C and credential holder with host kernel/native credential models',
                  hardware_validated=False, sanitizers=args.sanitizers, results=results, negative_control=negative)
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(report, indent=2) + '\n')
    return int(any(r['exit_code'] for r in results) or not negative['passed'])


if __name__ == '__main__':
    raise SystemExit(main())
