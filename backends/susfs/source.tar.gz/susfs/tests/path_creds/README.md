# Pending-path credential tests

Run `python3 tests/path_creds/run.py` and repeat with `--sanitizers`.
The harness extracts the production registration, resolver, deletion and clear
functions and includes the complete production credential holder. Kernel APIs
are explicit host models; this does not execute Samsung code.

The caller credential is an actual read-only mmap. Tests cover caller exit,
wrapper/native allocation failure before publication, duplicates, capacity,
separate callers, automatic/manual resolution, deletion and clear during a
paused lookup, replacement during that lookup, errors and exact cleanup.
The negative control removes the production borrow increment: it must compile
and then fail the deletion race. Compile failure is not a passing control.

ASan and UBSan check memory access and undefined behavior. LeakSanitizer is
disabled because this host cannot enumerate its /proc task lists. Independent
allocation, preparation/release and override/revert counters must balance.

The ARM64 build and artifact review are separate checks. Protected credential
behavior and background VFS access on the Samsung kernel require the focused
CP23 device probe after a reviewed candidate has been packaged.
