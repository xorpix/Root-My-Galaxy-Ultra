/* SPDX-License-Identifier: GPL-2.0 */
#include "host_kernel.h"
#include CREDS
#include PRODUCTION

static pthread_mutex_t control=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t cond=PTHREAD_COND_INITIALIZER;
static bool block_walk, entered, released;
static const char *block_name;
static atomic_int last_lookup_tag;
static struct cred worker={.usage=ATOMIC_INIT(2),.tag=999};
static struct super_block sb={.s_dev=65105};
static struct { const char *path; unsigned tag; bool exists; struct inode inode; struct dentry dentry; } files[4];

static struct cred *prepare_creds(void)
{
    assert(!spin_depth);
    if(fail_prepare)return NULL;
    struct cred *new=malloc(sizeof(*new));assert(new);
    memcpy(new,current->cred,sizeof(*new));
    atomic_init(&new->usage,1);new->subscribers=0;new->non_rcu=0;
    atomic_fetch_add(&prepared,1);return new;
}
static void abort_creds(struct cred *new)
{
    assert(!spin_depth && new!=current->cred);
    assert(atomic_load(&new->usage)==1 && new->subscribers==0);
    atomic_fetch_add(&aborted,1);free(new);
}
static const struct cred *override_creds(const struct cred *p)
{
    struct cred *new=(struct cred *)p;
    assert(!spin_depth && atomic_load(&new->usage)>=1);
    const struct cred *old=current->cred;
    atomic_fetch_add(&new->usage,1);++new->subscribers;current->cred=new;
    atomic_fetch_add(&overrides,1);return old;
}
static void revert_creds(const struct cred *old)
{
    struct cred *new=(struct cred *)current->cred;
    assert(!spin_depth && new->subscribers==1);
    current->cred=old;--new->subscribers;assert(atomic_fetch_sub(&new->usage,1)>1);
    atomic_fetch_add(&reverted,1);
}
static const struct cred *protected_caller(unsigned tag)
{
    struct cred *p=mmap(NULL,4096,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    assert(p!=MAP_FAILED);*p=(struct cred){.usage=ATOMIC_INIT(2),.tag=tag,.uid=tag,.gid=tag+1,.groups=tag+2,.namespace_id=tag+3,.secid=tag+4};
    assert(mprotect(p,4096,PROT_READ)==0);return p;
}
static void drop_caller(const struct cred *p) { assert(munmap((void *)p,4096)==0);current->cred=&worker; }
static int add(const char *path,unsigned cmd)
{
    struct st_susfs_sus_path info={0};strscpy(info.target_pathname,path,sizeof(info.target_pathname));
    void *p=&info;sus_path_supercall(cmd,&p);return info.err;
}
static int kern_path(const char *name,int flags,struct path *p)
{
    assert(!spin_depth);
    for(unsigned i=0;i<4;++i) {
        if(strcmp(name,files[i].path))continue;
        if(!files[i].exists)return -ENOENT;
        if(current->cred->tag!=files[i].tag)return -EACCES;
        if(current->cred!=&worker) {
            assert(current->cred->uid==files[i].tag && current->cred->gid==files[i].tag+1);
            assert(current->cred->groups==files[i].tag+2 && current->cred->namespace_id==files[i].tag+3 && current->cred->secid==files[i].tag+4);
        }
        unsigned checked_tag=current->cred->tag;
        if(sus_path_resolver==current)
            atomic_store(&last_lookup_tag,checked_tag);
        pthread_mutex_lock(&control);
        if(block_walk && sus_path_resolver==current && !strcmp(name,block_name)) {
            entered=true;pthread_cond_broadcast(&cond);
            while(!released)pthread_cond_wait(&cond,&control);
            assert(current->cred->tag==checked_tag);
        }
        pthread_mutex_unlock(&control);
        p->dentry=&files[i].dentry;ihold(p->dentry->inode);return 0;
    }
    return -ENOENT;
}
static void *resolve(void *unused) { current->cred=&worker;sus_path_resolve_pending();assert(current->cred==&worker);return NULL; }
static struct sus_path_entry *find(const char *p) {
    struct sus_path_entry *e;list_for_each_entry(e,&sus_path_list,list)if(!strcmp(e->path,p))return e;return NULL;
}
static void setup(void) {
    const char *names[]={"/owned/a","/owned/b","/owned/c","/owned/d"};
    for(unsigned i=0;i<4;++i) { files[i].path=names[i];files[i].tag=i+10;files[i].inode=(struct inode){.i_sb=&sb,.i_ino=100+i,.i_mode=0600,.refs=ATOMIC_INIT(1)};files[i].dentry=(struct dentry){.inode=&files[i].inode,.d_name={.name=(char *)names[i]+7}}; }
}
static void verify_index(void) {
    unsigned indexed=0,resolved=0;
    struct sus_path_entry *e;
    for(unsigned b=0;b<SUS_PATH_INDEX_SIZE;b++) {
        for(e=sus_path_index[b];e;e=e->index_next) {
            assert(e->inode&&sus_path_index_bucket(e->ino)==b&&find(e->path)==e);
            assert(++indexed<=sus_path_count);
        }
    }
    list_for_each_entry(e,&sus_path_list,list) if(e->inode) resolved++;
    assert(indexed==resolved);
}
static void clean(void) {
    verify_index();
    assert(sus_path_command("clear",NULL)==0);verify_index();assert(sus_path_count==0 && atomic_read(&sus_path_n_pending)==0);
    assert(!sus_path_cred_active() && atomic_load(&prepared)==atomic_load(&aborted));
    assert(atomic_load(&overrides)==atomic_load(&reverted));
    for(unsigned i=0;i<4;++i)assert(atomic_load(&files[i].inode.refs)==1 && files[i].inode.i_mode==0600);
    kfree(dirent_tmp);dirent_tmp=NULL;assert(atomic_load(&allocations)==0);
}
int main(int argc,char **argv)
{
    assert(argc==2);alarm(12);setup();const char *name=argv[1];
    const struct cred *caller=protected_caller(10);current->cred=caller;
    if(!strcmp(name,"allocation-failure") || !strcmp(name,"prepare-failure")) {
        if(!strcmp(name,"prepare-failure"))fail_prepare=1;else fail_alloc_at=2;
        assert(add(files[0].path,CMD_SUSFS_ADD_SUS_PATH_LOOP)==-ENOMEM);
        assert(sus_path_count==0 && !sus_path_cred_active() && atomic_load(&scheduled)==0);fail_prepare=0;
    } else if(!strcmp(name,"capacity")) {
        sus_path_count=SUS_PATH_MAX_ENTRIES;
        assert(add(files[0].path,CMD_SUSFS_ADD_SUS_PATH_LOOP)==-ENOSPC);
        assert(!sus_path_cred_active() && atomic_load(&prepared)==atomic_load(&aborted));sus_path_count=0;
    } else {
        assert(add(files[0].path,CMD_SUSFS_ADD_SUS_PATH_LOOP)==0);assert(find(files[0].path));
        assert(atomic_load(&caller->usage)==2 && caller->non_rcu==0 && sus_path_cred_active());
        if(!strcmp(name,"duplicate")) {
            int a=atomic_load(&aborted);assert(add(files[0].path,CMD_SUSFS_ADD_SUS_PATH_LOOP)==0);
            assert(sus_path_count==1 && atomic_load(&aborted)==a+1);
        } else if(!strcmp(name,"per-rule-callers")) {
            const struct cred *other=protected_caller(11);current->cred=other;
            assert(add(files[1].path,CMD_SUSFS_ADD_SUS_PATH_LOOP)==0);drop_caller(other);
            files[0].exists=files[1].exists=true;sus_path_resolve_pending();
            assert(atomic_read(&sus_path_n_pending)==0 && !sus_path_cred_active());
            current->cred=caller;
        } else if(!strcmp(name,"manual-complete")) {
            files[0].exists=true;assert(add(files[0].path,CMD_SUSFS_ADD_SUS_PATH)==0);
            assert(find(files[0].path)->inode && !sus_path_cred_active());
        } else if(strstr(name,"during-lookup")) {
            files[0].exists=true;block_name=files[0].path;block_walk=true;
            pthread_t t;assert(!pthread_create(&t,NULL,resolve,NULL));
            pthread_mutex_lock(&control);while(!entered)pthread_cond_wait(&cond,&control);pthread_mutex_unlock(&control);
            int a=atomic_load(&aborted);
            if(!strcmp(name,"clear-during-lookup"))assert(sus_path_command("clear",NULL)==0);
            else assert(sus_path_del_path(files[0].path)==1);
            assert(atomic_load(&aborted)==a && sus_path_cred_active());
            if(!strcmp(name,"replace-during-lookup")) {
                const struct cred *replacement=protected_caller(20);
                current->cred=replacement;files[0].exists=false;
                assert(add(files[0].path,CMD_SUSFS_ADD_SUS_PATH_LOOP)==0);
                drop_caller(replacement);current->cred=caller;
                files[0].tag=20;files[0].exists=true;
            }
            pthread_mutex_lock(&control);released=true;pthread_cond_broadcast(&cond);pthread_mutex_unlock(&control);assert(!pthread_join(t,NULL));
            if(!strcmp(name,"replace-during-lookup")) {
                /* The same pass may pick up the replacement after rejecting the
                 * retired entry's result; it must use the replacement caller. */
                assert(find(files[0].path)->inode && atomic_load(&last_lookup_tag)==20);
            }
        } else if(!strcmp(name,"lookup-errors")) {
            current->cred=&worker;assert(sus_path_resolve_pending()==0);
            files[0].exists=true;files[0].tag=20;assert(sus_path_resolve_pending()==0 && atomic_read(&sus_path_pend_last_rc)==-EACCES);
            assert(current->cred==&worker && !sus_path_resolver);current->cred=caller;
        } else if(!strcmp(name,"resolve-release") || !strcmp(name,"caller-exit")) {
            if(!strcmp(name,"caller-exit")){drop_caller(caller);caller=NULL;}
            else current->cred=&worker;
            files[0].exists=true;assert(sus_path_resolve_pending()==1 && !sus_path_cred_active());
        }
    }
    if(caller)
        drop_caller(caller);
    clean();
    printf("PASS %s\n",name);
    return 0;
}
