/* Compile against the pinned Android NDK AArch64 UAPI; no host surrogate ABI. */
#include <asm/statfs.h>
#include <asm/unistd.h>
#include <stddef.h>
#include <sys/xattr.h>

_Static_assert(sizeof(void *) == 8, "Native AArch64 pointers");
_Static_assert(__NR_statfs == 43 && __NR_fstatfs == 44, "Native syscall numbers");
_Static_assert(sizeof(struct statfs) == 120, "Native statfs payload size");
_Static_assert(offsetof(struct statfs, f_type) == 0, "type offset");
_Static_assert(offsetof(struct statfs, f_bsize) == 8, "block size offset");
_Static_assert(offsetof(struct statfs, f_blocks) == 16, "dynamic counts start");
_Static_assert(offsetof(struct statfs, f_fsid) == 56, "fsid offset");
_Static_assert(offsetof(struct statfs, f_namelen) == 64, "name length offset");
_Static_assert(offsetof(struct statfs, f_frsize) == 72, "fragment size offset");
_Static_assert(offsetof(struct statfs, f_flags) == 80, "flags offset");
_Static_assert(offsetof(struct statfs, f_spare) == 88, "spare offset");
_Static_assert(sizeof(ssize_t) == 8, "Native xattr signed return width");
_Static_assert(sizeof(size_t) == 8, "Native xattr buffer length width");

/* These assignments fail compilation if the typed ctypes signatures differ. */
ssize_t (*rmgu_fgetxattr_signature)(int, const char *, void *, size_t) = fgetxattr;
int (*rmgu_fsetxattr_signature)(int, const char *, const void *, size_t, int) = fsetxattr;
