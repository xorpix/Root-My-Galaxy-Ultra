#include <assert.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define OR_APP_UID_MIN 10000
#define READ_ONCE(value) (value)
#define smp_rmb() ((void)0)
#define IS_ERR_OR_NULL(value) (!(value) || (uintptr_t)(value) >= (uintptr_t)-4095)
struct super_block { unsigned int s_dev; };
struct inode { unsigned long i_ino; struct super_block *i_sb; unsigned int i_generation; };
struct dentry { struct inode *inode; };
struct path { void *mnt; struct dentry *dentry; };
struct kretprobe_instance { void *data; };
struct pt_regs { unsigned long regs[31]; };
struct kuid { unsigned int val; };
struct kstatfs { long f_blocks; };
static unsigned int uid;
static struct kuid current_uid(void) { return (struct kuid){uid}; }
static struct inode *d_backing_inode(struct dentry *dentry) { return dentry->inode; }
typedef int atomic_t;
static void atomic_inc(atomic_t *value) { ++*value; }
static int atomic_read(const atomic_t *value) { return *value; }
static void rcu_read_lock(void) { }
static void rcu_read_unlock(void) { }
static int susfs_ptr_plausible(const void *p) { return (uintptr_t)p > 4096; }
/* The statfs face copies the answer into per-instance state between the entry handler and the
 * return handler, so the host models the pair struct both fragments share. */
struct or_statfs_args { struct kstatfs *buf; struct kstatfs kstatfs; bool hit; };
static bool susfs_or_entry_armed(void) { return true; }
static unsigned int susfs_open_redirect_rules;
struct sus_or_entry {
    char target_pathname[256], redirected_pathname[256];
    unsigned long target_ino, redirected_ino, target_mnt_id;
    unsigned int target_dev, redirected_dev;
    unsigned int target_igen, redirected_igen;
    struct kstatfs spoofed_kstatfs;
    int uid_scheme;
    bool dead;
};
static struct sus_or_entry or_entries[64];
static int nor, or_lock;
static bool or_dpath_registered, or_statfs_registered, or_maps_registered, or_fdinfo_registered;
static atomic_t or_rev_statfs_hits, or_rev_dpath_hits, or_rev_maps_hits, or_rev_maps_rewrites, or_rev_maps_names;
static atomic_t or_rev_fdinfo_hits, or_rev_fdinfo_rewrites;
static unsigned int or_su_sid = 3203;
static int or_fdinfo_probes = 4, or_fdinfo_candidates = 4;
struct seq_file { char data[8192]; size_t used; };
static void mutex_lock(int *value) { (void)value; }
static void mutex_unlock(int *value) { (void)value; }
static void seq_printf(struct seq_file *seq, const char *format, ...) {
    va_list arguments; va_start(arguments, format);
    int count = vsnprintf(seq->data + seq->used, sizeof(seq->data) - seq->used, format, arguments);
    va_end(arguments);
    assert(count >= 0 && (size_t)count < sizeof(seq->data) - seq->used);
    seq->used += (size_t)count;
}
static void seq_puts(struct seq_file *seq, const char *text) { seq_printf(seq, "%s", text); }


/* Host model of the load-time umount gate (issue #34): nothing resolves on the host, so the gate
 * answers the pre-#34 way - app uids and nothing else.  The extracted production fragment's gate
 * calls this replica instead of ksu_umount_gate.h's inline, keeping every other expectation here
 * byte-identical to what it tested before the KSU integration landed in the kernel sources. */
static inline bool susfs_is_current_proc_umounted_app(void)
{
    return current_uid().val >= 10000;
}
#include PRODUCTION

static struct super_block superblock = {22};
static struct inode inode = {99, &superblock, 55};
static struct dentry dentry = {&inode};
static struct path destination = {NULL, &dentry};

static void initialize(void) {
    nor = 1; uid = 10362; susfs_open_redirect_rules = 1;
    strcpy(or_entries[0].target_pathname, "/data/adb/source");
    strcpy(or_entries[0].redirected_pathname, "/dev/owned/destination");
    or_entries[0].target_ino = 71; or_entries[0].target_dev = 266338385;
    or_entries[0].target_igen = 7;
    or_entries[0].redirected_ino = 99; or_entries[0].redirected_dev = 22;
    or_entries[0].redirected_igen = 55;
    or_entries[0].target_mnt_id = 8123; or_entries[0].uid_scheme = 4;
    or_entries[0].spoofed_kstatfs.f_blocks = 7777;
    or_dpath_registered = or_statfs_registered = or_maps_registered = or_fdinfo_registered = true;
}

static void require_unchanged(const struct path *path) {
    struct or_statfs_args data = {0};
    struct kretprobe_instance ri = {&data};
    struct pt_regs entry_regs = {{0}}, ret_regs = {{0}};
    struct kstatfs caller = {512};
    int before = or_rev_statfs_hits;

    entry_regs.regs[0] = (unsigned long)path;
    entry_regs.regs[1] = (unsigned long)&caller;
    assert(or_statfs_entry(&ri, &entry_regs) == 0);
    assert(!data.hit && !data.buf);
    assert(or_statfs_ret(&ri, &ret_regs) == 0);
    assert(caller.f_blocks == 512);
    assert(or_rev_statfs_hits == before);
}

int main(int argc, char **argv) {
    assert(argc == 2); initialize(); const char *test = argv[1];
    if (!strcmp(test, "app-match")) {
        for (unsigned int reader = 10000; reader <= 10362; reader += 362) {
            struct or_statfs_args data = {0};
            struct kretprobe_instance ri = {&data};
            struct pt_regs entry_regs = {{0}}, ret_regs = {{0}};
            struct kstatfs caller = {512};

            uid = reader;
            entry_regs.regs[0] = (unsigned long)&destination;
            entry_regs.regs[1] = (unsigned long)&caller;
            assert(or_statfs_entry(&ri, &entry_regs) == 0);
            assert(data.hit && data.buf == &caller);
            assert(data.kstatfs.f_blocks == or_entries[0].spoofed_kstatfs.f_blocks);
            ret_regs.regs[0] = 0;
            assert(or_statfs_ret(&ri, &ret_regs) == 0);
            assert(caller.f_blocks == or_entries[0].spoofed_kstatfs.f_blocks);
        }
        assert(or_rev_statfs_hits == 2);
    } else if (!strcmp(test, "kernel-error")) {
        /* The kernel answered the statfs with an error: the return half must leave the caller's
         * answer standing even though the entry half matched and counted the hit. */
        struct or_statfs_args data = {0};
        struct kretprobe_instance ri = {&data};
        struct pt_regs entry_regs = {{0}}, ret_regs = {{0}};
        struct kstatfs caller = {512};

        entry_regs.regs[0] = (unsigned long)&destination;
        entry_regs.regs[1] = (unsigned long)&caller;
        assert(or_statfs_entry(&ri, &entry_regs) == 0);
        assert(data.hit);
        ret_regs.regs[0] = (unsigned long)-13;      /* -EACCES */
        assert(or_statfs_ret(&ri, &ret_regs) == 0);
        assert(caller.f_blocks == 512);
    } else if (!strcmp(test, "root-exclusion")) {
        uid = 0; require_unchanged(&destination); uid = 9999; require_unchanged(&destination);
    } else if (!strcmp(test, "inode-device-control")) {
        inode.i_ino++; require_unchanged(&destination); inode.i_ino--;
        superblock.s_dev++; require_unchanged(&destination); superblock.s_dev--;
        inode.i_generation++; require_unchanged(&destination); inode.i_generation--;
        inode.i_ino = or_entries[0].target_ino; superblock.s_dev = or_entries[0].target_dev;
        inode.i_generation = or_entries[0].target_igen;     /* the FORWARD target's full identity:
                                                             * the reverse face keys on the file the
                                                             * redirection really opened instead */
        require_unchanged(&destination);
    } else if (!strcmp(test, "dead-and-empty")) {
        or_entries[0].dead = true; require_unchanged(&destination);
        or_entries[0].dead = false; nor = 0; require_unchanged(&destination);
    } else if (!strcmp(test, "invalid-paths")) {
        require_unchanged(NULL); require_unchanged((void *)-2);
        destination.dentry = NULL; require_unchanged(&destination);
        destination.dentry = &dentry; dentry.inode = NULL; require_unchanged(&destination);
    } else if (!strncmp(test, "proc-", 5)) {
        struct seq_file seq = {{0}, 0};
        if (!strcmp(test, "proc-empty")) { nor = 0; susfs_open_redirect_rules = 0; }
        else if (!strcmp(test, "proc-dead")) { or_entries[0].dead = true; susfs_open_redirect_rules = 0; }
        else assert(!strcmp(test, "proc-live"));
        assert(or_proc_show(&seq, NULL) == 0); fputs(seq.data, stdout); return 0;
    } else abort();
    puts("PASS"); return 0;
}
