# CP21 redirect filesystem qualification

`../phone/build_redirect_statfs_runner.py` builds the standalone
`../phone/rmgu-susfs-redirect-statfs-test.py`. It retains the bounded root-call
implementation from the native metadata runner and process identity from the
mapping observer. Run it through ordinary Termux with the existing CP21 module.

The phone fixture uses ordinary app-created files in Termux home and an exclusive
private directory under the existing `/dev` filesystem. The root helper labels
and assigns only its newly created directory and two files to the app. Ordinary
app access, matching root baselines, distinct backing devices and distinct
filesystem identities must succeed before either rule is added. A blocked
fixture is reported as BLOCKED and sends no feature controls. No mounts,
SELinux policy, feature flags, global rule clear, or module changes are needed.

Revision 1 stopped on the phone before feature controls because Termux Python
does not expose `os.getxattr`. Revision 2 uses typed libc `fgetxattr`/`fsetxattr`
calls through ctypes, with a bounded guarded buffer and exact label readback.
Labels are copied through open descriptors to the owned objects, including the
directory. The source labels are checked again and every setup descriptor is
closed. A known partial setup failure returns ownership receipts for cleanup;
a failed/missing label verification still blocks before ADD. A separate host
suite tests the real native xattr functions without Python xattr APIs, using
owned `user.*` attributes instead of host SELinux changes.

Two scheme-3 cycles verify native statfs/fstatfs, original and redirected content,
fresh and held descriptors, proc-fd statfs, and root/unrelated controls. A source
descriptor held before ADD keeps the original backing file. A descriptor opened
while redirected continues to read the destination after DEL, but must then show
the native destination filesystem. Original foreign rules are preserved exactly.
Only a confirmed owned row may be removed during recovery. Unknown root-command
outcomes stop all further root/control commands and retain the fixture receipt.

All native statfs fields plus spare words and raw ABI buffers are recorded.
Comparisons cover type, block size, fsid, name length, fragment size, flags and
spare bytes. Free-block/file counts can change due to unrelated writes and are
not compared exactly. Their presence is not a separate correctness claim.
Cleanup verifies inode/device/owner/mode identities and exact directory children,
then unlinks only the known names. Kernel retired-rule path references remain
until module teardown as in the existing implementation; this test does not
claim those references are released. Never unload or replace the live module.

Host validation:

```sh
python3 tests/phone/build_redirect_statfs_runner.py
python3 tests/phone/test_redirect_statfs_runner.py
python3 tests/phone/test_redirect_statfs_xattr.py
python3 tests/redirect_statfs/run.py --sanitizers
```

The native host observer reads two real filesystems and checks guards and error
semantics. The workflow tests explicitly model phone credentials, namespaces and
proc controls; they detect effect leaks and recovery failures, but do not qualify
Samsung reachability. The C harness compiles unchanged production callback,
lookup, UID gate and proc formatter functions with named kernel API stubs. Its
proc output feeds the same phone parser, including dead-slot empty tables and
scheme-4 foreign rows. The user's completed revision-2 phone run on 9 October
2026 now qualifies the tested native statfs scope, including the owned label
copying and two restoration cycles. See the normalized phone evidence and
`docs/cp21-redirect-maps-followup.md`; redirect mapping identity remains pending.

`check_android_abi.c` is also compiled against the pinned Android NDK AArch64
headers to check the syscall numbers, 120-byte payload, every decoded offset,
and the typed descriptor-xattr prototypes and return/length widths.
AddressSanitizer and UndefinedBehaviorSanitizer cover the host C callbacks;
LeakSanitizer is disabled because this executor cannot read its numeric proc PID
paths. No leak or device-lifetime qualification is implied.
