#!/usr/bin/env python3
"""Test the production reverse-statfs entry/return pair and exact proc formatter."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--sanitizers', action='store_true')
parser.add_argument('--json', type=Path)
args = parser.parse_args()
here = Path(__file__).resolve().parent
source = (here.parents[1] / 'kernel/susfs_open_redirect.c').read_text()
names = ('or_reverse_visible', 'or_find_by_redirected_inode', 'or_statfs_entry', 'or_statfs_ret', 'or_proc_show')
fragments = []
for name in names:
    match = re.search(r'^static [^\n]*\b' + name + r'\([^;{]*\)\n\{\n.*?^\}\n', source, re.M | re.S)
    if not match: raise RuntimeError('Production function missing: ' + name)
    fragments.append(match[0])
production = '\n'.join(fragments)
spec = importlib.util.spec_from_file_location('redirect_statfs_runner', here.parent / 'phone/rmgu-susfs-redirect-statfs-test.py')
runner = importlib.util.module_from_spec(spec); spec.loader.exec_module(runner)
cases = ('app-match', 'kernel-error', 'root-exclusion', 'inode-device-control', 'dead-and-empty',
         'invalid-paths', 'proc-empty', 'proc-live', 'proc-dead')
results = []
with tempfile.TemporaryDirectory(prefix='susfs-redirect-statfs-host-') as directory:
    directory = Path(directory); header = directory / 'production.h'; header.write_text(production)
    exe = directory / 'statfs-test'
    flags = ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-no-pie'] if args.sanitizers else ['-O2']
    subprocess.run([os.environ.get('CC', 'cc'), '-std=gnu11', '-Wall', '-Wextra', '-Werror',
                    '-Wno-unused-function', '-Wno-unused-parameter', *flags, '-DPRODUCTION="' + str(header) + '"',
                    str(here / 'statfs_test.c'), '-o', str(exe)], check=True)
    environment = dict(os.environ)
    if args.sanitizers:
        # This executor's numeric proc PID paths do not match its PID namespace.
        # Match the retained harnesses: ASan/UBSan enabled, LSan not qualified.
        environment.update(ASAN_OPTIONS='detect_leaks=0:abort_on_error=1', UBSAN_OPTIONS='halt_on_error=1')
    for case in cases:
        run = subprocess.run([str(exe), case], capture_output=True, text=True, timeout=20, env=environment)
        if run.returncode: raise RuntimeError(case + ': ' + run.stderr)
        if case.startswith('proc-'):
            value = runner.parse_redirect(run.stdout)
            if case == 'proc-live':
                expected = '/data/adb/source -> /dev/owned/destination uid=4 (ino=71 dev=266338385 mnt=8123 | rev: ino=99 dev=22)'
                if value['rules'] != [expected]: raise RuntimeError('Production rule format mismatch')
            elif value['rules']: raise RuntimeError('Empty/dead production slots parsed as live')
        results.append({'case': case, 'exit_code': run.returncode, 'stdout': run.stdout.strip()})
        print('PASS ' + case)
receipt = {'kind': 'unchanged production C with named host kernel API stubs', 'hardware_validated': False,
           'sanitizers': args.sanitizers, 'production_functions': list(names),
           'leak_sanitizer': False,
           'production_fragment_sha256': hashlib.sha256(production.encode()).hexdigest(), 'results': results}
if args.json: args.json.write_text(json.dumps(receipt, indent=2) + '\n')
