/* SPDX-License-Identifier: GPL-2.0-only */
#include "../mshow_filter/host_kernel.h"

static unsigned long find_kernel_symbol_exact(const char *name);
static int ksu_symbol_is_start(unsigned long addr, const char *name);
static int register_kprobe(struct kprobe *p);
static void unregister_kprobe(struct kprobe *p);
#include PRODUCTION

static struct seq_operations ops, other_ops;
static struct module subject;
static struct seq_file reader;
static u32 code[64] __attribute__((aligned(4)));
static unsigned long named_addr, valid_addr;
static const char *table_name="modules_op", *symbol_name="m_show";
static bool missing_table, unreadable_table, unreadable_body, vendor_bti_adjust;
static int registration_error, registered, unregistered;
static int registered_live;
struct readable { const void *p; size_t n; };
static struct readable memory[8];
static unsigned int n_memory;

static void readable(const void *p, size_t n)
{
    assert(n_memory < ARRAY_SIZE(memory));
    memory[n_memory++] = (struct readable){p,n};
}
static int copy_from_kernel_nofault(void *to, const void *from, size_t n)
{
    uintptr_t p=(uintptr_t)from;
    host_nofault_calls++;
    if (unreadable_body && p==valid_addr) return -EFAULT;
    for (unsigned int i=0;i<n_memory;i++) {
        uintptr_t base=(uintptr_t)memory[i].p;
        if (p>=base && p-base<=memory[i].n && n<=memory[i].n-(p-base)) {
            memcpy(to,from,n);return 0;
        }
    }
    return -EFAULT;
}
static unsigned long find_kernel_symbol_exact(const char *name)
{
    assert(!strcmp(name,table_name));
    return missing_table ? 0 : (unsigned long)&ops;
}
static int ksu_symbol_is_start(unsigned long addr, const char *name)
{
    assert(!strcmp(name,symbol_name));
    return addr==valid_addr;
}
static void callback_must_be_inert(struct kprobe *p)
{
    struct pt_regs r={.regs={[0]=1,[1]=(unsigned long)&subject.list,[30]=0x1000},.pc=0x2000};
    int reads=host_nofault_calls;
    assert(!p->pre_handler(p,&r));
    assert(r.pc==0x2000 && r.regs[0]==1);
    assert(reads==host_nofault_calls);
}
static int register_kprobe(struct kprobe *p)
{
    assert(!registered_live);
    if (p->symbol_name) assert(!p->addr && !strcmp(p->symbol_name,symbol_name));
    else assert(p->addr);
    assert(!(p->flags & KPROBE_FLAG_DISABLED));
    assert(!modules_show_ready);
    registered++;
    p->addr=(void *)((p->symbol_name ? named_addr : (unsigned long)p->addr)+p->offset);
    if (vendor_bti_adjust && (*p->addr==0xd503245f || *p->addr==0xd50324df)) p->addr++;
    if (registration_error) return registration_error;
    registered_live=1;
    /* An indirect call must still land on BTI while the probe is armed. */
    if (*(u32 *)valid_addr==0xd503245f || *(u32 *)valid_addr==0xd50324df) {
        assert(p->addr==(u32 *)(valid_addr+4));
        assert(p->offset==4);
    }
    p->opcode=*p->addr;
    *p->addr=0xd4200000; /* real entry instruction is patched during registration */
    callback_must_be_inert(p);
    return 0;
}
static void unregister_kprobe(struct kprobe *p)
{
    assert(registered_live && !modules_show_ready);
    callback_must_be_inert(p);
    *p->addr=p->opcode;
    p->flags |= KPROBE_FLAG_DISABLED;
    registered_live=0;unregistered++;
}
static int sus_path_add_self_hidden(const char *path) { (void)path;return 0; }
static int sus_path_del_path(const char *path) { (void)path;return 0; }

static int invoke(unsigned long arg)
{
    struct pt_regs r={.regs={[0]=(unsigned long)&reader,[1]=arg,[30]=0x1000},.pc=0x2000};
    int before=atomic_read(&n_modlines_skipped);
    int rc=hide_syms_m_show_pre(&kp_m_show,&r);
    assert(rc==0 || rc==1);
    if (rc) {
        assert(r.pc==0x1000 && !r.regs[0]);
        assert(atomic_read(&n_modlines_skipped)==before+1);
    } else {
        assert(r.pc==0x2000 && r.regs[0]==(unsigned long)&reader);
        assert(atomic_read(&n_modlines_skipped)==before);
    }
    return rc;
}
static void branch(u32 *from, u32 *to, bool call)
{
    intptr_t displacement=(char *)to-(char *)from;
    assert(!(displacement & 3));
    *from=(call ? 0x94000000 : 0x14000000) | ((displacement/4)&0x03ffffff);
}
int main(int argc, char **argv)
{
    assert(argc==2);
    const char *c=argv[1];
    for (unsigned int i=0;i<ARRAY_SIZE(code);i++) code[i]=0xd503201f;
    valid_addr=(unsigned long)&code[16];named_addr=valid_addr;
    ops.show=(void *)valid_addr;
    strscpy(subject.name,"susfs_guard_lkm",sizeof(subject.name));
    strscpy(hide_modules[0],subject.name,MODULE_NAME_LEN);n_hide_modules=1;
    reader.op=&other_ops; /* deliberately different from modules_op: BZIG regression */
    readable(&subject,sizeof(subject));readable(code,sizeof(code));
    if (!strncmp(c,"s-show-",7)) {
        struct kprobe probe={.pre_handler=hide_syms_m_show_pre};
        const struct seq_operations *resolved_ops;
        table_name="kallsyms_op";symbol_name="s_show";
        readable(&ops,sizeof(ops));
        code[16]=!strcmp(c,"s-show-bti-jc") ? 0xd50324df :
                 !strcmp(c,"s-show-pac") ? 0xd503233f : 0xd503245f;
        code[17]=0xd503233f;
        u32 original=code[16];
        assert(!hide_syms_resolve_show(&probe,table_name,symbol_name,&resolved_ops));
        assert(resolved_ops==&ops && (unsigned long)probe.addr==valid_addr);
        assert(probe.offset==(!strcmp(c,"s-show-pac") ? 0 : 4));
        assert(!register_kprobe(&probe));
        if (probe.offset) assert(code[16]==original);
        unregister_kprobe(&probe);
        assert(code[16]==original && code[17]==0xd503233f);
        printf("PASS %s\n",c);return 0;
    }
    int expected=0;
    if (!strcmp(c,"wrong-body")) { named_addr=(unsigned long)&code[40];expected=-EINVAL; }
    else if (!strcmp(c,"missing-table")) { missing_table=true;expected=-ENOENT; }
    else if (!strcmp(c,"unreadable-table")) { unreadable_table=true;expected=-EFAULT; }
    else if (!strcmp(c,"null-show")) { ops.show=NULL;expected=-EINVAL; }
    else if (!strcmp(c,"unaligned-show")) { ops.show=(void *)(valid_addr+1);expected=-EINVAL; }
    else if (!strcmp(c,"unproven-body")) { ops.show=(void *)&code[40];expected=-EINVAL; }
    else if (!strcmp(c,"unreadable-body")) { unreadable_body=true;expected=-EFAULT; }
    else if (!strcmp(c,"cfi-stub") || !strcmp(c,"cfi-stub-bti") || !strcmp(c,"call-stub") || !strcmp(c,"wrong-stub")) {
        code[0]=0xd503245f;branch(&code[1],!strcmp(c,"wrong-stub")?&code[40]:&code[16],!strcmp(c,"call-stub"));
        ops.show=(void *)&code[0];
        if (!strcmp(c,"cfi-stub-bti")) code[16]=0xd503245f;
        else if (strcmp(c,"cfi-stub")) expected=-EINVAL;
    } else if (!strcmp(c,"cfi-negative-branch")) {
        branch(&code[40],&code[16],false);ops.show=(void *)&code[40];
    } else if (!strcmp(c,"register-failure")) { registration_error=-EIO;expected=-EIO; }
    else if (!strcmp(c,"bti-adjustment") || !strcmp(c,"bti-jc-adjustment") || !strcmp(c,"bti-vendor-adjustment")) {
        code[16]=!strcmp(c,"bti-jc-adjustment")?0xd50324df:0xd503245f;
        vendor_bti_adjust=!strcmp(c,"bti-vendor-adjustment");
    } else if (!strcmp(c,"bti-pac") || !strcmp(c,"bti-restart")) {
        code[16]=0xd503245f;code[17]=0xd503233f;
    } else if (!strcmp(c,"pac-adjustment")) { code[16]=0xd503233f;named_addr+=4;expected=-EINVAL; }
    else if (!strcmp(c,"offset-adjustment")) { named_addr+=8;expected=-EINVAL; }
    if (!unreadable_table) readable(&ops,sizeof(ops));
    if (!strcmp(c,"not-ready")) {
        assert(!invoke((unsigned long)&subject.list));assert(!host_nofault_calls);
        puts("PASS not-ready");return 0;
    }
    assert(hide_syms_modules_show_start()==expected);
    if (expected) {
        assert(!modules_show_ready && !m_show_registered && !registered_live && !modules_op_target);
        assert(!kp_m_show.addr && !(kp_m_show.flags & KPROBE_FLAG_DISABLED));
        assert(!invoke((unsigned long)&subject.list));
        if (!strcmp(c,"wrong-body") || !strcmp(c,"pac-adjustment") || !strcmp(c,"offset-adjustment"))
            assert(registered==1 && unregistered==1);
        else if (!strcmp(c,"register-failure")) assert(registered==1 && !unregistered);
        else assert(!registered);
    } else {
        assert(modules_show_ready && m_show_registered && registered_live);
        if (!strcmp(c,"nomount-reader-policy")) {
            strscpy(hide_modules[1],"kernelsu",MODULE_NAME_LEN);
            strscpy(hide_modules[2],"nomount",MODULE_NAME_LEN);n_hide_modules=3;
            const struct { unsigned int uid,euid;const char *name;int hidden; } cases[] = {
                {0,0,"nomount",0}, {10000,10000,"nomount",1},
                {10000,0,"nomount",0}, {0,10000,"nomount",1},
                {0,0,"kernelsu",1}, {10000,10000,"kernelsu",1},
                {0,0,"susfs_guard_lkm",1}, {10000,10000,"susfs_guard_lkm",1},
                {0,0,"qca_cld3_peach_v2",0}, {10000,10000,"qca_cld3_peach_v2",0},
                {10000,10000,"nomount_extra",0}
            };
            for (unsigned int i=0;i<ARRAY_SIZE(cases);i++) {
                host_uid.val=cases[i].uid;host_euid.val=cases[i].euid;
                strscpy(subject.name,cases[i].name,sizeof(subject.name));
                assert(invoke((unsigned long)&subject.list)==cases[i].hidden);
            }
            n_hide_modules=2;strscpy(subject.name,"nomount",sizeof(subject.name));
            assert(!invoke((unsigned long)&subject.list)); /* not implicitly enlisted */
        }
        else if (!strcmp(c,"unreadable-module")) assert(!invoke((unsigned long)0x12345678));
        else if (!strcmp(c,"underflow")) assert(!invoke(1));
        else if (!strcmp(c,"unterminated-name")) { memset(subject.name,'x',sizeof(subject.name));assert(!invoke((unsigned long)&subject.list)); }
        else if (!strcmp(c,"prefix-lookalike")) { strscpy(subject.name,"susfs_guard_lkm_extra",sizeof(subject.name));assert(!invoke((unsigned long)&subject.list)); }
        else assert(invoke((unsigned long)&subject.list));
        hide_syms_modules_show_stop();
        assert(!modules_show_ready && !m_show_registered && !registered_live && !kp_m_show.addr);
        assert(!invoke((unsigned long)&subject.list));
        if (!strcmp(c,"stop-and-restart") || !strcmp(c,"bti-restart")) {
            assert(!hide_syms_modules_show_start());assert(invoke((unsigned long)&subject.list));
            hide_syms_modules_show_stop();assert(registered==2 && unregistered==2);
        }
        if (!strcmp(c,"bti-restart")) {
            code[16]=0xd503233f;
            assert(!hide_syms_modules_show_start());assert(!kp_m_show.offset);
            hide_syms_modules_show_stop();assert(registered==3 && unregistered==3);
        }
    }
    printf("PASS %s\n",c);return 0;
}
