#!/usr/bin/env python3
"""Verify real modules-hook registration, callback admission and fault boundaries."""
import argparse
import importlib.util
import os
from pathlib import Path
import re
import resource
import subprocess
import tempfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--source-dir', type=Path, default=Path(__file__).resolve().parents[2])
p.add_argument('--sanitizers', action='store_true')
a = p.parse_args()
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
here = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('extract', here.parent / 'path_creds/run.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
s = (a.source_dir / 'kernel/susfs_hide_syms.c').read_text()
kh = (a.source_dir / 'kernel/susfs_kprobe.h').read_text()
globals_ = '''#define HIDE_MODULES_MAX 16
static char hide_modules[HIDE_MODULES_MAX][MODULE_NAME_LEN];
static int n_hide_modules;
static DEFINE_SPINLOCK(hide_modules_lock);
static atomic_t n_modlines_skipped;
static const struct seq_operations *modules_op_target;
static bool modules_show_ready, m_show_registered;
'''
names = ['hide_module_name_match', 'hide_syms_m_show_pre']
fragment = globals_ + '\n'.join(extract.function(s, n) for n in names)
fragment += '\n' + re.search(r'^static struct kprobe kp_m_show = \{.*?^\};', s, re.M | re.S)[0]
fragment += '\n' + extract.function(kh, 'susfs_kp_forget_addr')
for n in ['hide_syms_resolve_show', 'hide_syms_modules_probe_matches',
          'hide_syms_modules_show_stop', 'hide_syms_modules_show_start']:
    fragment += '\n' + extract.function(s, n)
cases = ['ordinary', 'foreign-seq-ops', 'wrong-body', 'missing-table',
         'unreadable-table', 'null-show', 'unaligned-show', 'unproven-body',
         'cfi-stub', 'cfi-negative-branch', 'call-stub', 'wrong-stub',
         'register-failure', 'bti-adjustment', 'bti-jc-adjustment',
         'pac-adjustment', 'offset-adjustment', 'not-ready', 'unreadable-module',
         'underflow', 'unterminated-name', 'prefix-lookalike', 'stop-and-restart',
         'nomount-reader-policy']
flags = ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-no-pie'] if a.sanitizers else ['-O2']
env = dict(os.environ, ASAN_OPTIONS='detect_leaks=0:abort_on_error=1', UBSAN_OPTIONS='halt_on_error=1')
with tempfile.TemporaryDirectory(prefix='susfs-mshow-identity-') as t:
    t = Path(t)
    def build(text, label):
        header = t / (label + '.h')
        header.write_text(text)
        exe = t / label
        subprocess.run(['cc', '-std=gnu11', '-Wall', '-Wextra', '-Werror',
                        '-Wno-unused-function', '-Wno-unused-variable', '-Wno-unused-parameter',
                        '-pthread', *flags, '-DMSHOW_IDENTITY_TEST', '-I', str(here),
                        '-DPRODUCTION="' + str(header) + '"', str(here / 'identity_test.c'), '-o', str(exe)], check=True)
        return exe
    exe = build(fragment, 'production')
    for case in cases:
        subprocess.run([str(exe), case], check=True, timeout=10, env=env)
    # Each mutation removes a distinct safety property; the corresponding
    # real-world failure case must reject the mutated implementation.
    mutations = [
        ('unverified-target', '!hide_syms_modules_probe_matches(expected)', '(false && hide_syms_modules_probe_matches(expected))', 'wrong-body'),
        ('early-callback', '!smp_load_acquire(&modules_show_ready) || ', '', 'ordinary'),
        ('samsung-gate', '|| !m || !p)', '|| !m || (modules_op_target && m->op != modules_op_target) || !p)', 'foreign-seq-ops'),
        ('root-installer-hidden', 'uid_eq(current_euid(), GLOBAL_ROOT_UID)', 'false', 'nomount-reader-policy'),
        ('real-uid-confused', 'uid_eq(current_euid(), GLOBAL_ROOT_UID)', 'uid_eq(current_uid(), GLOBAL_ROOT_UID)', 'nomount-reader-policy'),
    ]
    for label, old, new, case in mutations:
        assert old in fragment
        mutant = build(fragment.replace(old, new), label)
        run = subprocess.run([str(mutant), case], capture_output=True, timeout=10, env=env)
        assert run.returncode != 0, label + ' escaped the regression test'
        print('PASS negative control: ' + label)
print('PASS verified modules callback, Samsung compatibility and failure cleanup')
