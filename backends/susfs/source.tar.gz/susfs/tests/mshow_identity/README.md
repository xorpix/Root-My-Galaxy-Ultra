# Verified modules callback regressions

Run `python3 tests/mshow_identity/run.py`, optionally with `--sanitizers`.
The harness compiles the production name matcher, modules callback, show-body
resolver, probe-address validator, registration and teardown helpers. The
kprobe model preserves the resolved address after registration failures and
the disabled flag after unregister, and delivers callbacks during registration
and teardown to verify that admission is closed at both boundaries.

Twenty-three cases cover correct/duplicate targets, unavailable or malformed
callback tables, CFI entry stubs and signed branch displacements, an invalid
call stub, permitted BTI adjustments, rejected PAC/other adjustments, failed
registration, unreadable and unterminated module names, pointer underflow,
exact name matching, and stop/restart. A different live `seq_file.op` must
still hide a selected module once the callback entry was verified; this
preserves the Samsung BZIG behavior without accepting an unverified target.

Three mutations must fail: bypass target validation, admit callbacks before
registration validation, and restore the live table-pointer gate that caused
the Samsung regression. The adjacent `mshow_filter` suite separately compares
readable module-list invocations with the frozen phone-qualified handler.

These are host models. They do not execute ARM64 code or establish that the
callback table and entry can be resolved on the device. Phone validation must
check root `/proc/modules` visibility, ordinary module rows, kallsyms behavior,
and unload/restoration before a stable release.
