/* SPDX-License-Identifier: GPL-2.0 */
/* Compile the actual production files; replace kernel APIs and feature bodies. */
#include "host_kernel.h"
#include PRODUCTION_DISPATCHER
#include PRODUCTION_MAIN

/* The tests replace the umount-gate layer: its init is a no-op that leaves the gates on the
 * pre-#34 answer, and the ask helper is a stub the flow only reaches if a layer violates it. */
bool susfs_ksu_umount_gate_off = true;
bool susfs_ksu_umount_ask(uid_t uid) { (void)uid; return true; }
int susfs_ksu_umount_gate_init(void) { return 0; }
struct module host_module;
_Thread_local struct task_struct host_task;
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
static struct kprobe *registered;
static atomic_int allocations, grace_calls, unregister_calls, resolver_calls;
static atomic_int feature_exits, dispatches;
static atomic_bool alive[12];
static int allocation_fail_at, allocation_calls, registration_error;
static bool enqueue_error, copy_in_error, copy_out_error, probe_during_init;
static bool block_handler, handler_entered, release_handler;
static bool block_tail, tail_entered, release_tail, grace_entered;
static int callback_frames;
static int probe_frames;

bool module_is_coming(struct module *m)
{
    return atomic_load(&m->state) == MODULE_STATE_COMING;
}

bool try_module_get(struct module *m)
{
    bool ok;
    /* Models the core's atomic ref acquisition vs normal deletion decision. */
    pthread_mutex_lock(&lock);
    ok = atomic_load(&m->state) != MODULE_STATE_GOING;
    if (ok) atomic_fetch_add(&m->refs, 1);
    pthread_mutex_unlock(&lock);
    return ok;
}

void module_put(struct module *m)
{
    pthread_mutex_lock(&lock);
    assert(atomic_fetch_sub(&m->refs, 1) > 0);
    /* Controlled host pause models preemption in the final return tail.
     * Real module_put is not made to sleep by the production patch. */
    if (block_tail) {
        tail_entered = true;
        pthread_cond_broadcast(&cond);
        while (!release_tail) pthread_cond_wait(&cond, &lock);
    }
    pthread_mutex_unlock(&lock);
}

static int request(unsigned int cmd, void *payload)
{
    /* Model kprobe entry/unregistration lifetime as well as module references. */
    pthread_mutex_lock(&lock);
    if (!registered) {
        pthread_mutex_unlock(&lock);
        return 0;
    }
    ++probe_frames;
    pthread_mutex_unlock(&lock);
    struct pt_regs args = {0}, regs = {0};
    args.regs[0] = KSU_INSTALL_MAGIC1;
    args.regs[1] = SUSFS_MAGIC;
    args.regs[2] = cmd;
    args.regs[3] = (unsigned long)payload;
    regs.regs[0] = (unsigned long)&args;
    regs.regs[30] = 123;
    int result = reboot_pre(&reboot_kp, &regs);
    pthread_mutex_lock(&lock);
    --probe_frames;
    pthread_cond_broadcast(&cond);
    pthread_mutex_unlock(&lock);
    if (result) assert(regs.pc == 123 && regs.regs[0] == 0);
    else assert(regs.pc == 0 && regs.regs[0] == (unsigned long)&args);
    return result;
}

int register_kprobe(struct kprobe *kp)
{
    if (registration_error) return registration_error;
    assert(!registered);
    registered = kp;
    if (probe_during_init) {
        struct st_susfs_version payload = { .err = 126 };
        assert(request(CMD_SUSFS_SHOW_VERSION, &payload) == 0);
        assert(payload.err == 126 && !current->pending);
        assert(atomic_load(&host_module.refs) == 0);
    }
    return 0;
}

void unregister_kprobe(struct kprobe *kp)
{
    pthread_mutex_lock(&lock);
    assert(registered == kp);
    registered = NULL;
    while (probe_frames) pthread_cond_wait(&cond, &lock);
    pthread_mutex_unlock(&lock);
    atomic_fetch_add(&unregister_calls, 1);
}

int task_work_add(struct task_struct *task, struct callback_head *work, int mode)
{
    assert(mode == TWA_RESUME);
    if (enqueue_error) return -ESRCH;
    work->next = task->pending;
    task->pending = work;
    return 0;
}

void synchronize_rcu_tasks(void)
{
    /* Contract model, not an implementation/test of Linux Tasks RCU. */
    pthread_mutex_lock(&lock);
    assert(!registered);
    atomic_fetch_add(&grace_calls, 1);
    grace_entered = true;
    pthread_cond_broadcast(&cond);
    while (callback_frames) pthread_cond_wait(&cond, &lock);
    pthread_mutex_unlock(&lock);
}

void *kzalloc(size_t n, int flags)
{
    (void)flags;
    if (++allocation_calls == allocation_fail_at) return NULL;
    void *p = calloc(1, n);
    assert(p);
    atomic_fetch_add(&allocations, 1);
    return p;
}
void kfree(void *p)
{
    if (p) { assert(atomic_fetch_sub(&allocations, 1) > 0); free(p); }
}
unsigned long copy_from_user(void *to, const void *from, size_t n)
{
    if (copy_in_error) return n;
    memcpy(to, from, n);
    return 0;
}
unsigned long copy_to_user(void *to, const void *from, size_t n)
{
    if (copy_out_error) return n;
    memcpy(to, from, n);
    return 0;
}

static int feature_init(int id) { atomic_store(&alive[id], true); return 0; }
static void feature_exit(int id)
{
    /* Independent behavioral check: entry point and callback tail are gone. */
    assert(!registered && !callback_frames);
    assert(atomic_load(&host_module.refs) == 0);
    atomic_store(&alive[id], false);
    atomic_fetch_add(&feature_exits, 1);
}
#define FEATURE(name, id) \
    int name##_init(void) { return feature_init(id); } \
    void name##_exit(void) { feature_exit(id); }
void ksu_lsm_hook_init(void) { (void)feature_init(0); }
void ksu_lsm_hook_exit(void) { feature_exit(0); }
/* The layer table refuses the load on a false answer; here the host never refuses. */
bool ksu_lsm_hook_ready(void) { return true; }
FEATURE(sus_path, 1)
FEATURE(susfs_uname, 2)
FEATURE(susfs_kstat, 3)
FEATURE(susfs_sus_map, 4)
FEATURE(susfs_sus_mount, 5)
FEATURE(susfs_spoof_cmdline, 6)
FEATURE(susfs_open_redirect, 7)
FEATURE(susfs_enable_log, 8)
FEATURE(susfs_avc_spoof, 9)
FEATURE(susfs_hide_syms, 10)
/* fp_hook installs nothing itself (susfs_fp_init only resolves the sys_call_table), so
 * there is no exit and nothing to mark: not a FEATURE. */
int susfs_fp_init(void) { return 0; }
/* patch_memory resolves the kernel flush helper by name at load; stubbed present here so
 * susfs_init() proceeds to the layer sequence this deck exercises. */
int ksu_patch_memory_init(void) { return 0; }
FEATURE(susfs_create_gate, 11)
void ksu_init_symbol_resolver(void) { atomic_fetch_add(&resolver_calls, 1); }
int sus_path_add_self_hidden(const char *path) { (void)path; return 0; }
bool susfs_log_enabled(void) { return false; }
bool susfs_hide_modules_active(void) { return atomic_load(&alive[10]); }
bool susfs_hide_syms_active(void) { return atomic_load(&alive[10]); }
bool sus_path_lsm_active(void) { return atomic_load(&alive[1]); }

static void handler(void)
{
    pthread_mutex_lock(&lock);
    assert(atomic_load(&host_module.refs) > 0);
    assert(atomic_load(&alive[10]));
    atomic_fetch_add(&dispatches, 1);
    handler_entered = true;
    pthread_cond_broadcast(&cond);
    while (block_handler && !release_handler) pthread_cond_wait(&cond, &lock);
    assert(atomic_load(&alive[10]));
    pthread_mutex_unlock(&lock);
}
#define HANDLER(name) void name(void **arg) { (void)arg; handler(); }
HANDLER(susfs_uname_supercall)
HANDLER(susfs_enable_log_supercall)
HANDLER(susfs_avc_spoof_supercall)
HANDLER(susfs_spoof_cmdline_supercall)
HANDLER(susfs_sus_map_supercall)
HANDLER(susfs_open_redirect_supercall)
HANDLER(susfs_sus_mount_supercall)
void sus_path_supercall(unsigned int cmd, void **arg) { (void)cmd; (void)arg; handler(); }
void susfs_kstat_supercall(unsigned int cmd, void **arg) { (void)cmd; (void)arg; handler(); }

static void run_pending(void)
{
    while (current->pending) {
        struct callback_head *cb = current->pending;
        current->pending = cb->next;
        pthread_mutex_lock(&lock);
        ++callback_frames;
        pthread_mutex_unlock(&lock);
        cb->func(cb);
        pthread_mutex_lock(&lock);
        --callback_frames;
        pthread_cond_broadcast(&cond);
        pthread_mutex_unlock(&lock);
    }
}

static void initialize(void)
{
    atomic_store(&host_module.state, MODULE_STATE_COMING);
    current->uid = 0;
    assert(susfs_init() == 0);
    atomic_store(&host_module.state, MODULE_STATE_LIVE);
}

static bool remove_normally(void)
{
    pthread_mutex_lock(&lock);
    bool allowed = atomic_load(&host_module.state) == MODULE_STATE_LIVE &&
                   atomic_load(&host_module.refs) == 0;
    if (allowed) atomic_store(&host_module.state, MODULE_STATE_GOING);
    pthread_mutex_unlock(&lock);
    if (allowed) susfs_exit();
    return allowed;
}

static void check_released(void)
{
    assert(!registered && !current->pending);
    assert(atomic_load(&host_module.refs) == 0);
    assert(atomic_load(&allocations) == 0);
    for (size_t i = 0; i < ARRAY_SIZE(alive); ++i) assert(!atomic_load(&alive[i]));
}

static void test_queued(void)
{
    initialize();
    struct st_susfs_version payload = { .err = 126 };
    assert(request(CMD_SUSFS_SHOW_VERSION, &payload) == 1);
    assert(!remove_normally());
    assert(payload.err == 126 && atomic_load(&host_module.refs) == 1);
    run_pending();
    assert(payload.err == 0 && !strcmp(payload.susfs_version, SUSFS_VERSION_STR));
    assert(remove_normally());
    assert(atomic_load(&grace_calls) == 1);
    check_released();
}

static void test_init_window(void)
{
    probe_during_init = true;
    initialize();
    assert(remove_normally());
    check_released();
}

static void test_failure(const char *which)
{
    initialize();
    if (!strcmp(which, "allocation")) allocation_fail_at = allocation_calls + 1;
    else enqueue_error = true;
    struct st_susfs_version payload = { .err = 126 };
    assert(request(CMD_SUSFS_SHOW_VERSION, &payload) == 0);
    assert(payload.err == 126 && !current->pending);
    assert(atomic_load(&host_module.refs) == 0 && atomic_load(&allocations) == 0);
    assert(remove_normally());
    check_released();
}

static void test_rejected(void)
{
    initialize();
    struct st_susfs_version payload = { .err = 126 };
    assert(request(0, &payload) == 0);
    current->uid = 10000;
    assert(request(CMD_SUSFS_SHOW_VERSION, &payload) == 0);
    current->uid = 0;
    atomic_store(&host_module.state, MODULE_STATE_GOING);
    assert(request(CMD_SUSFS_SHOW_VERSION, &payload) == 0);
    assert(!current->pending && payload.err == 126);
    susfs_exit();
    check_released();
}

static void test_payload_errors(void)
{
    initialize();
    struct st_susfs_version payload = { .err = 126 };
    copy_in_error = true;
    assert(request(CMD_SUSFS_SHOW_VERSION, &payload) == 1);
    run_pending();
    assert(payload.err == -EFAULT && atomic_load(&host_module.refs) == 0);
    copy_in_error = false;
    copy_out_error = true;
    assert(request(CMD_SUSFS_SHOW_VERSION, &payload) == 1);
    run_pending();
    assert(atomic_load(&host_module.refs) == 0);
    copy_out_error = false;
    struct st_susfs_enabled_features features = {0};
    assert(request(CMD_SUSFS_SHOW_ENABLED_FEATURES, &features) == 1);
    allocation_fail_at = allocation_calls + 1;
    run_pending();
    assert(features.err == -ENOMEM && atomic_load(&host_module.refs) == 0);
    assert(remove_normally());
    check_released();
}

static void test_multiple(void)
{
    initialize();
    struct st_susfs_version payloads[32] = {0};
    for (size_t i = 0; i < ARRAY_SIZE(payloads); ++i)
        assert(request(CMD_SUSFS_SHOW_VERSION, &payloads[i]) == 1);
    assert(atomic_load(&host_module.refs) == 32 && !remove_normally());
    run_pending();
    assert(atomic_load(&host_module.refs) == 0);
    assert(remove_normally());
    check_released();
}

static void *worker(void *unused)
{
    (void)unused;
    current->uid = 0;
    assert(request(CMD_SUSFS_ENABLE_LOG, NULL) == 1);
    run_pending();
    return NULL;
}
static void *remover(void *unused)
{
    (void)unused;
    assert(remove_normally());
    return NULL;
}

static void test_sleeping(void)
{
    initialize();
    block_handler = true;
    pthread_t thread;
    assert(!pthread_create(&thread, NULL, worker, NULL));
    pthread_mutex_lock(&lock);
    while (!handler_entered) pthread_cond_wait(&cond, &lock);
    pthread_mutex_unlock(&lock);
    assert(!remove_normally() && atomic_load(&feature_exits) == 0);
    pthread_mutex_lock(&lock);
    release_handler = true;
    pthread_cond_broadcast(&cond);
    pthread_mutex_unlock(&lock);
    assert(!pthread_join(thread, NULL));
    assert(remove_normally());
    check_released();
}

static void test_return_tail(void)
{
    initialize();
    block_tail = true;
    pthread_t work_thread, remove_thread;
    assert(!pthread_create(&work_thread, NULL, worker, NULL));
    pthread_mutex_lock(&lock);
    while (!tail_entered) pthread_cond_wait(&cond, &lock);
    assert(atomic_load(&host_module.refs) == 0 && callback_frames == 1);
    pthread_mutex_unlock(&lock);
    assert(!pthread_create(&remove_thread, NULL, remover, NULL));
    pthread_mutex_lock(&lock);
    while (!grace_entered) pthread_cond_wait(&cond, &lock);
    assert(atomic_load(&feature_exits) == 0);
    release_tail = true;
    pthread_cond_broadcast(&cond);
    pthread_mutex_unlock(&lock);
    assert(!pthread_join(work_thread, NULL));
    assert(!pthread_join(remove_thread, NULL));
    check_released();
}

static void test_rollback(void)
{
    current->uid = 0;
    atomic_store(&host_module.state, MODULE_STATE_COMING);
    registration_error = -EIO;
    assert(susfs_init() == -EIO);
    assert(atomic_load(&feature_exits) > 0);
    assert(atomic_load(&grace_calls) == 0 && atomic_load(&unregister_calls) == 0);
    check_released();
}

static void test_partial_failures(void)
{
    current->uid = 0;
    atomic_store(&host_module.state, MODULE_STATE_COMING);
    for (int i = 1; i <= (int)ARRAY_SIZE(susfs_layers); ++i) {
        fail_layer = i;
        int rc = susfs_init();
        if (susfs_layers[i - 1].fatal) {
            /* A fatal row's forced failure rolls the load back before anything
             * responds: no command becomes reachable, and the version request
             * keeps the 126 sentinel. */
            assert(rc == -EIO);
            assert(!registered && !current->pending);
            struct st_susfs_version payload = { .err = 126 };
            assert(request(CMD_SUSFS_SHOW_VERSION, &payload) == 0);
            assert(payload.err == 126);
            check_released();
        } else {
            /* Non-fatal rows (ksu_umount_gate, create_gate) fail with the module
             * staying up: the load completes and every later layer still arms,
             * so the reboot kprobe is live - which is exactly what "that feature
             * stays off" means, and why their failure is not a refusal. */
            assert(rc == 0 && registered && !current->pending);
            atomic_store(&host_module.state, MODULE_STATE_LIVE);
            assert(remove_normally());
            check_released();
        }
        atomic_store(&host_module.state, MODULE_STATE_COMING);
    }
}

static pthread_barrier_t race_start;
static atomic_bool race_removed;
static void *race_request(void *unused)
{
    (void)unused;
    current->uid = 0;
    struct st_susfs_version payload = { .err = 126 };
    pthread_barrier_wait(&race_start);
    if (request(CMD_SUSFS_SHOW_VERSION, &payload)) {
        run_pending();
        assert(payload.err == 0);
    } else assert(payload.err == 126);
    return NULL;
}
static void *race_remove(void *unused)
{
    (void)unused;
    pthread_barrier_wait(&race_start);
    atomic_store(&race_removed, remove_normally());
    return NULL;
}
static void test_admission_race(void)
{
    for (int i = 0; i < 200; ++i) {
        initialize();
        assert(!pthread_barrier_init(&race_start, NULL, 3));
        pthread_t requester, deleter;
        assert(!pthread_create(&requester, NULL, race_request, NULL));
        assert(!pthread_create(&deleter, NULL, race_remove, NULL));
        pthread_barrier_wait(&race_start);
        assert(!pthread_join(requester, NULL));
        assert(!pthread_join(deleter, NULL));
        if (!atomic_load(&race_removed)) assert(remove_normally());
        check_released();
        assert(!pthread_barrier_destroy(&race_start));
    }
}

int main(int argc, char **argv)
{
    alarm(15);
    assert(argc == 2);
    if (!strcmp(argv[1], "no-tasks-rcu")) {
        assert(!CONFIG_TASKS_RCU);
        assert(susfs_init() == -EOPNOTSUPP);
        assert(atomic_load(&resolver_calls) == 0 && !registered);
        check_released();
    } else if (!strcmp(argv[1], "queued")) test_queued();
    else if (!strcmp(argv[1], "init-window")) test_init_window();
    else if (!strcmp(argv[1], "allocation") || !strcmp(argv[1], "enqueue")) test_failure(argv[1]);
    else if (!strcmp(argv[1], "rejected")) test_rejected();
    else if (!strcmp(argv[1], "payload-errors")) test_payload_errors();
    else if (!strcmp(argv[1], "multiple")) test_multiple();
    else if (!strcmp(argv[1], "sleeping")) test_sleeping();
    else if (!strcmp(argv[1], "return-tail")) test_return_tail();
    else if (!strcmp(argv[1], "rollback")) test_rollback();
    else if (!strcmp(argv[1], "partial-failures")) test_partial_failures();
    else if (!strcmp(argv[1], "admission-race")) test_admission_race();
    else abort();
    printf("PASS %s\n", argv[1]);
    return 0;
}
