/* SPDX-License-Identifier: GPL-2.0 */
/* Host API model only. This is not a set of kernel headers or an ABI check. */
#ifndef SUSFS_LIFECYCLE_HOST_KERNEL_H
#define SUSFS_LIFECYCLE_HOST_KERNEL_H
#include <assert.h>
#include <stdatomic.h>
typedef atomic_int atomic_t;
typedef struct { int unused; } wait_queue_head_t;
#include <errno.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define __user
#define __init
#define __exit
#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
#define BUILD_BUG_ON(c) _Static_assert(!(c), #c)
#define container_of(p, type, member) ((type *)((char *)(p) - offsetof(type, member)))
#define READ_ONCE(x) __atomic_load_n(&(x), __ATOMIC_ACQUIRE)
#define IS_ENABLED(c) (c)
#define PAGE_SIZE 4096
#define IS_ERR(p) ((uintptr_t)(p) >= (uintptr_t)-4095)
#define __NEW_UTS_LEN 64
#define GFP_ATOMIC 1
#define GFP_KERNEL 2
#define TWA_RESUME 1
#define KERNEL_VERSION(a,b,c) (((a) << 16) | ((b) << 8) | (c))
#define LINUX_VERSION_CODE KERNEL_VERSION(6,12,0)
#define module_param_named(...)
#define module_param(...)
#define module_init(...)
#define module_exit(...)
#define MODULE_LICENSE(...)
#define MODULE_IMPORT_NS(...)
#define MODULE_DESCRIPTION(...)

/* The feature bitmap the supercall arms once a layer's init returned (susfs_supercall.c)
 * and reads back before serving a command.  Atomics, because the admission-race test
 * arms on one thread while another races a request through the kprobe. */
#define DECLARE_BITMAP(name, bits) \
    unsigned long name[((bits) + sizeof(long) * 8 - 1) / (sizeof(long) * 8)]
#define set_bit(nr, addr) \
    ((void)__atomic_fetch_or((unsigned long *)(addr) + (nr) / (sizeof(long) * 8), \
                             1UL << ((nr) % (sizeof(long) * 8)), __ATOMIC_RELEASE))
#define test_bit(nr, addr) \
    (__atomic_load_n((unsigned long *)(addr) + (nr) / (sizeof(long) * 8), \
                     __ATOMIC_ACQUIRE) & (1UL << ((nr) % (sizeof(long) * 8))))

/* The tests replace the LSM layer, not its private kernel layouts. */
#define __SUSFS_LSM_HOOK_H
void ksu_lsm_hook_init(void);
void ksu_lsm_hook_exit(void);
bool ksu_lsm_hook_ready(void);

enum { MODULE_STATE_COMING, MODULE_STATE_LIVE, MODULE_STATE_GOING };
struct module { atomic_int state; atomic_int refs; };
extern struct module host_module;
#define THIS_MODULE (&host_module)
bool module_is_coming(struct module *m);
bool try_module_get(struct module *m);
void module_put(struct module *m);

struct callback_head { struct callback_head *next; void (*func)(struct callback_head *); };
struct task_struct { struct callback_head *pending; unsigned int uid; };
extern _Thread_local struct task_struct host_task;
#define current (&host_task)
typedef struct { unsigned int val; } kuid_t;
static inline kuid_t current_uid(void) { return (kuid_t){ current->uid }; }
struct pt_regs { unsigned long regs[31]; unsigned long pc; };
struct kprobe { const char *symbol_name; int (*pre_handler)(struct kprobe *, struct pt_regs *); };
int register_kprobe(struct kprobe *kp);
void unregister_kprobe(struct kprobe *kp);
int task_work_add(struct task_struct *task, struct callback_head *work, int mode);
void synchronize_rcu_tasks(void);
void *kzalloc(size_t n, int flags);
void kfree(void *p);
unsigned long copy_from_user(void *to, const void *from, size_t n);
unsigned long copy_to_user(void *to, const void *from, size_t n);
static inline long strscpy(char *to, const char *from, size_t n)
{
    size_t len = strlen(from);
    if (!n) return -E2BIG;
    memcpy(to, from, len < n ? len : n - 1);
    to[len < n ? len : n - 1] = '\0';
    return len < n ? (long)len : -E2BIG;
}
static inline void host_log(const char *fmt, ...) { (void)fmt; }
#define pr_warn(...) host_log(__VA_ARGS__)
#define pr_warn_ratelimited(...) host_log(__VA_ARGS__)
#define pr_info(...) host_log(__VA_ARGS__)
#define pr_err(...) host_log(__VA_ARGS__)
#endif
