# Host lifecycle tests

Run from the **susfs4ksu-lkm source root**, using Linux or WSL with Python 3 and
a C compiler with pthread support:

```sh
python3 tests/lifecycle/run.py
python3 tests/lifecycle/run.py --sanitizers
```

These commands build and run temporary host executables. They do not build a
kernel module, invoke root, contact the phone, or execute a feature handler.
Temporary build files are removed automatically.

Optional arguments:

- `--json result.json`: save every test's result.
- `--source-dir /path/to/another/susfs/source`: check that source with this harness.
- `--leak-check --sanitizers`: also run LeakSanitizer on hosts that support it.
- `CC=...`: choose the compiler executable.

The two production C files are included directly by the test translation unit.
`host_kernel.h` and the generated empty Linux headers substitute an API model.
Feature bodies are inert test functions. Actual upstream ABI assertions are
compiled, but this is **not** a kernel-header or Samsung ABI compilation check.

The concurrency tests use controlled waits; the admission race additionally runs
200 iterations. A process alarm and subprocess timeout bound a deadlocked test.
ASan/UBSan runs disable LeakSanitizer unless explicitly requested because some
containers do not permit its `/proc` task enumeration.

See `docs/lifecycle/README.md` for the ownership contract, results, and remaining
target-kernel requirements.
