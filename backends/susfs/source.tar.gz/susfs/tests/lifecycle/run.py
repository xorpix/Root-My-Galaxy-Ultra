#!/usr/bin/env python3
"""Exercise edited production C with a host API model; never build/load a module."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-dir', type=Path, default=Path(__file__).resolve().parents[2])
parser.add_argument('--sanitizers', action='store_true')
parser.add_argument('--leak-check', action='store_true',
                    help='Also enable LeakSanitizer; requires access to /proc task lists')
parser.add_argument('--json', type=Path)
args = parser.parse_args()
if args.leak_check and not args.sanitizers:
    parser.error('--leak-check requires --sanitizers')
tests = ['queued', 'init-window', 'allocation', 'enqueue', 'rejected',
         'payload-errors', 'multiple', 'sleeping', 'return-tail', 'rollback',
         'partial-failures', 'admission-race']
here = Path(__file__).resolve().parent
source = args.source_dir.resolve()
cc = os.environ.get('CC', 'cc')
results = []
negative_results = []
with tempfile.TemporaryDirectory(prefix='susfs-lifecycle-host-') as temp:
    tmp = Path(temp)
    include = tmp / 'include/linux'
    include.mkdir(parents=True)
    for name in ['module', 'kprobes', 'task_work', 'rcupdate', 'slab', 'uaccess',
                 'cred', 'syscalls', 'string', 'types', 'utsname', 'printk',
                 'err', 'mm', 'kernel', 'init', 'version', 'bitmap', 'atomic', 'wait']:
        (include / (name + '.h')).write_text('/* Host shim: see host_kernel.h. */\n')
    (tmp / 'include/asm').mkdir()
    (tmp / 'include/asm/unistd.h').write_text('/* Host syscall number fixture. */\n')
    selection = ['table-preferred', 'fallback', 'bti-c', 'bti-jc', 'unknown-entry',
                 'unreadable-entry', 'both-fail', 'rollback-before-fallback']
    matrix = [(case, route) for case in tests for route in ['table', 'kprobe']]
    matrix += [(case, 'table') for case in selection +
               ['table-forward', 'sleeping-original', 'wrapper-tail', 'repeat-routes']]
    matrix += [('null-probe-regs', 'kprobe')]
    for config, bti, cases in [(1, 0, matrix), (0, 0, [('no-tasks-rcu', 'table')]),
                               (1, 1, [('bti-config', 'kprobe'), ('table-preferred', 'table')])]:
        exe = tmp / f'lifecycle-{config}-{bti}'
        flags = ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-no-pie'] if args.sanitizers else ['-O2']
        command = [cc, '-std=gnu11', '-Wall', '-Wextra', '-Werror',
                   '-Wno-unused-parameter', '-Wno-sign-compare', '-pthread', *flags,
                   f'-DCONFIG_TASKS_RCU={config}',
                   f'-DCONFIG_ARM64_BTI_KERNEL={bti}',
                   f'-DPRODUCTION_DISPATCHER="{source / "kernel/susfs_supercall.c"}"',
                   f'-DPRODUCTION_MAIN="{source / "kernel/susfs_main.c"}"',
                   '-I', str(tmp / 'include'), '-I', str(here),
                   '-I', str(source / 'kernel'),
                   str(here / 'lifecycle_test.c'), '-o', str(exe)]
        if config == 1 and bti == 0:
            negative_command = list(command)
        subprocess.run(command, check=True)
        for case, route in cases:
            env = dict(os.environ)
            if args.sanitizers:
                env['ASAN_OPTIONS'] = f'detect_leaks={int(args.leak_check)}:abort_on_error=1'
                env['UBSAN_OPTIONS'] = 'halt_on_error=1'
            run = subprocess.run([str(exe), case, route], capture_output=True, text=True,
                                 timeout=20, env=env)
            result = {'case': case, 'route': route, 'config_tasks_rcu': config,
                      'config_bti_kernel': bti,
                      'exit_code': run.returncode, 'stdout': run.stdout.strip(),
                      'stderr': run.stderr.strip()}
            results.append(result)
            print(run.stdout.strip() or f'FAIL {case}: {run.stderr.strip()}')
    # Each negative control removes a production safeguard. Its behavioral case
    # must then fail; a host model that merely repeats the implementation passes
    # these broken versions and cannot establish the contract being checked.
    original = (source / 'kernel/susfs_supercall.c').read_text()
    controls = [
        ('init-admission', 'init-window',
         [('module_is_coming(THIS_MODULE) || !try_module_get(THIS_MODULE)',
           '!try_module_get(THIS_MODULE)')]),
        ('sleeping-wrapper', 'sleeping-original',
         [('susfs_fp_callback_enter(&reboot_hook);', '(void)0;'),
          ('return susfs_fp_callback_return(&reboot_hook, result);', 'return result;')]),
        ('task-work-tail', 'return-tail',
         [('synchronize_rcu_tasks();', '(void)0;')]),
        ('bti-fallback', 'bti-c',
         [('if (instruction == 0xd503245fU || instruction == 0xd50324dfU)',
           'if (false)')]),
    ]
    for label, case, replacements in controls:
        changed = original
        for before, after in replacements:
            if changed.count(before) != 1:
                raise ValueError('Negative control no longer targets one safeguard: ' + label)
            changed = changed.replace(before, after, 1)
        production = tmp / (label + '.c')
        production.write_text(changed)
        exe = tmp / ('negative-' + label)
        command = [f'-DPRODUCTION_DISPATCHER="{production}"' if item.startswith('-DPRODUCTION_DISPATCHER=')
                   else item for item in negative_command]
        command[-1] = str(exe)
        subprocess.run(command, check=True)
        run = subprocess.run([str(exe), case, 'table'], capture_output=True,
                             text=True, timeout=20, env=env)
        negative_results.append({'control': label, 'exit_code': run.returncode,
                                 'rejected': run.returncode != 0,
                                 'stderr': run.stderr.strip()})
        print(('PASS rejected ' if run.returncode else 'FAIL accepted ') + label)
if args.json:
    args.json.write_text(json.dumps({'kind': 'host API model', 'sanitizers': args.sanitizers,
                                    'leak_check': args.leak_check,
                                    'results': results,
                                    'negative_controls': negative_results}, indent=2) + '\n')
raise SystemExit(any(result['exit_code'] for result in results) or
                 any(not result['rejected'] for result in negative_results))
