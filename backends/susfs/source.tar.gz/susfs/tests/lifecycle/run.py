#!/usr/bin/env python3
"""Exercise edited production C with a host API model; never build/load a module."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-dir', type=Path, default=Path(__file__).resolve().parents[2])
parser.add_argument('--sanitizers', action='store_true')
parser.add_argument('--leak-check', action='store_true',
                    help='Also enable LeakSanitizer; requires access to /proc task lists')
parser.add_argument('--json', type=Path)
args = parser.parse_args()
if args.leak_check and not args.sanitizers:
    parser.error('--leak-check requires --sanitizers')
tests = ['queued', 'init-window', 'allocation', 'enqueue', 'rejected',
         'payload-errors', 'multiple', 'sleeping', 'return-tail', 'rollback',
         'partial-failures', 'admission-race']
here = Path(__file__).resolve().parent
source = args.source_dir.resolve()
cc = os.environ.get('CC', 'cc')
results = []
with tempfile.TemporaryDirectory(prefix='susfs-lifecycle-host-') as temp:
    tmp = Path(temp)
    include = tmp / 'include/linux'
    include.mkdir(parents=True)
    for name in ['module', 'kprobes', 'task_work', 'rcupdate', 'slab', 'uaccess',
                 'cred', 'syscalls', 'string', 'types', 'utsname', 'printk',
                 'err', 'mm', 'kernel', 'init', 'version', 'bitmap', 'atomic', 'wait']:
        (include / (name + '.h')).write_text('/* Host shim: see host_kernel.h. */\n')
    for config, cases in [(1, tests), (0, ['no-tasks-rcu'])]:
        exe = tmp / f'lifecycle-{config}'
        flags = ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-no-pie'] if args.sanitizers else ['-O2']
        command = [cc, '-std=gnu11', '-Wall', '-Wextra', '-Werror',
                   '-Wno-unused-parameter', '-Wno-sign-compare', '-pthread', *flags,
                   f'-DCONFIG_TASKS_RCU={config}',
                   f'-DPRODUCTION_DISPATCHER="{source / "kernel/susfs_supercall.c"}"',
                   f'-DPRODUCTION_MAIN="{source / "kernel/susfs_main.c"}"',
                   '-I', str(tmp / 'include'), '-I', str(here),
                   str(here / 'lifecycle_test.c'), '-o', str(exe)]
        subprocess.run(command, check=True)
        for case in cases:
            env = dict(os.environ)
            if args.sanitizers:
                env['ASAN_OPTIONS'] = f'detect_leaks={int(args.leak_check)}:abort_on_error=1'
                env['UBSAN_OPTIONS'] = 'halt_on_error=1'
            run = subprocess.run([str(exe), case], capture_output=True, text=True,
                                 timeout=20, env=env)
            result = {'case': case, 'config_tasks_rcu': config,
                      'exit_code': run.returncode, 'stdout': run.stdout.strip(),
                      'stderr': run.stderr.strip()}
            results.append(result)
            print(run.stdout.strip() or f'FAIL {case}: {run.stderr.strip()}')
if args.json:
    args.json.write_text(json.dumps({'kind': 'host API model', 'sanitizers': args.sanitizers,
                                    'leak_check': args.leak_check,
                                    'results': results}, indent=2) + '\n')
raise SystemExit(any(result['exit_code'] for result in results))
