#!/usr/bin/env python3
"""Repair regressions using the audit's controlled schedules and actual production C."""
import argparse,json,os,re,subprocess,tempfile
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--sanitizers',action='store_true');p.add_argument('--json',type=Path)
a=p.parse_args();here=Path(__file__).resolve().parent;root=here.parents[1]
def fn(s,n):
    m=re.search(r'^(?:static )?[^\n]*\b'+re.escape(n)+r'\([^;{]*\)\n\{\n.*?^\}\n',s,re.M|re.S)
    if not m:raise RuntimeError('Missing production function '+n)
    return m[0]
mount=(root/'kernel/sus_mount.c').read_text()
syms=(root/'kernel/susfs_hide_syms.c').read_text()
stat=(root/'kernel/susfs_kstat.c').read_text()
fragment='#define SUS_KSTAT_MAX 32\n#define KSTAT_PATH_MAX 256\n'
fragment+=stat[stat.index('struct sus_kstat_entry {'):stat.index('/* arm64 asm-generic struct stat offsets')]
fragment+=''.join(fn(stat,n) for n in ('susfs_kstat_gate_ok','susfs_kstat_table_empty','susfs_kstat_lookup'))
start=stat.index('struct kstat_call_counters {');fragment+=stat[start:stat.index('#define KSTAT_COUNTERS',start)]
start=stat.index('struct kstat_call_state {');fragment+=stat[start:stat.index('/* Rewrite the requested fields',start)]
fragment+='\n'.join(re.findall(r'^#define STAT64_ST_.*$',stat,re.M))+'\n'+fn(stat,'susfs_kstat_spoof_compat_statbuf')
groups={
 'mount-control':(''.join(fn(mount,n) for n in ('sus_mount_register_named_kprobe','sus_mount_register_named_kretprobe','sus_mount_register','sus_mount_unregister','susfs_sus_mount_supercall_impl','susfs_sus_mount_supercall')),['enable-disable']),
 'late-control':(syms[syms.index('#define HIDE_MODULES_MAX'):syms.index('/* ---- the two frontends ---- */')]+fn(syms,'susfs_hide_syms_exit'),['ordinary','after-teardown']),
 'stat64-key':(fragment,['low-inode','high-inode','same-low-bits']),
}
prefix=mount[mount.index('#define SUS_MOUNT_KEEP_MAX'):mount.index('/* All three mount-table hooks')]
prefix+=''.join(fn(mount,n) for n in ('sus_mount_keep_parse','sus_mount_keep_commit','sus_mount_keep_rescan','sus_mount_keep_command_impl','sus_mount_keep_command'))
groups['mount-parameter']=(prefix,['default','custom','clear'])
# Module parameters are parsed before init. Protect that phase boundary as well
# as exercising the actual initializer and setter above.
init=fn(mount,'susfs_sus_mount_init')
assert not re.search(r'\bn_mount_keep\s*=|strscpy\(mount_keep|memset\(mount_keep',init), 'init overwrites parsed mount prefixes'
results=[];env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
with tempfile.TemporaryDirectory(prefix='susfs-repairs-') as td:
    td=Path(td)
    for group,(text,cases) in groups.items():
        h=td/(group+'.h');h.write_text(text);exe=td/group
        flags=['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-no-pie'] if a.sanitizers else ['-O2']
        subprocess.run(['cc','-std=gnu11','-Wall','-Wextra','-Werror','-Wno-unused-function','-Wno-unused-variable','-Wno-unused-parameter','-Wno-sign-compare',*flags,'-pthread','-I',str(root),'-DPRODUCTION="'+str(h)+'"',str(here/(group+'.c')),'-o',str(exe)],check=True)
        for case in cases:
            r=subprocess.run([str(exe),case],capture_output=True,text=True,env=env,timeout=15)
            results.append(dict(group=group,case=case,exit_code=r.returncode,stderr=r.stderr))
            print(('PASS ' if not r.returncode else 'FAIL ')+group+'/'+case,flush=True)
            if r.returncode: print(r.stderr)
if a.json:a.json.write_text(json.dumps(dict(hardware_validated=False,results=results),indent=2)+'\n')
raise SystemExit(any(x['exit_code'] for x in results))
