/* SPDX-License-Identifier: GPL-2.0 */
/* Compile the actual policy, LSM callback and enter/return/original macros. */
#include <assert.h>
#include <errno.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

typedef uint64_t u64;
typedef _Atomic int atomic_t;
#define ATOMIC_INIT(x) (x)
#define atomic_inc(p) ((void)atomic_fetch_add(p, 1))
#define atomic_read(p) atomic_load(p)
#define READ_ONCE(x) (x)
#define smp_rmb() atomic_thread_fence(memory_order_acquire)
#define KERNEL_VERSION(a,b,c) (((a) << 16) + ((b) << 8) + (c))
#if HOST_KERNEL == 612
#define LINUX_VERSION_CODE KERNEL_VERSION(6,12,0)
#else
#define LINUX_VERSION_CODE KERNEL_VERSION(6,1,0)
#endif

struct list_head { struct list_head *next, *prev; };
#define LIST_HEAD(n) struct list_head n = { &(n), &(n) }
#define entry(p,t,m) ((t *)((char *)(p) - offsetof(t,m)))
#define list_for_each_entry(e,h,m) \
    for (e=entry((h)->next,typeof(*e),m); &(e)->m!=(h); e=entry((e)->m.next,typeof(*e),m))
static void list_add(struct list_head *n, struct list_head *h)
{ n->next=h->next; n->prev=h; h->next->prev=n; h->next=n; }
static LIST_HEAD(sus_path_list);
static pthread_mutex_t sus_path_lock = PTHREAD_MUTEX_INITIALIZER;
#define spin_lock(p) assert(!pthread_mutex_lock(p))
#define spin_unlock(p) assert(!pthread_mutex_unlock(p))
struct file_system_type { int id; };
struct super_block { u64 s_dev; struct file_system_type *s_type; };
typedef struct { unsigned int val; } kuid_t;
struct inode { struct super_block *i_sb; u64 i_ino; kuid_t i_uid; };
struct dentry { struct inode *inode; };
#define d_inode(d) ((d)->inode)
struct sus_path_entry {
    struct sus_path_entry *index_next;
    struct list_head list;
    struct inode *inode;
    u64 dev, ino;
    bool self_protect;
};
#include "../../kernel/sus_path_index.h"
static unsigned int uid=10000, sus_path_count=1;
static bool umounted_app=true, resolver;
static int hide_from_apps=1;
static atomic_t n_identity_hits, n_enoent_readlink_lsm;
static kuid_t current_uid(void) { return (kuid_t){ uid }; }
static bool susfs_is_current_proc_umounted_app(void) { return umounted_app; }
static bool sus_path_is_resolver(void) { return resolver; }
union security_list_options { int (*inode_readlink)(struct dentry *); };
struct ksu_lsm_hook { void *original; atomic_t active_callbacks; };
static struct ksu_lsm_hook sus_path_readlink_hook;
static atomic_t enters, exits, original_calls;
static void ksu_lsm_callback_enter(struct ksu_lsm_hook *h)
{ atomic_inc(&h->active_callbacks); atomic_inc(&enters); }
static void ksu_lsm_callback_exit(struct ksu_lsm_hook *h)
{ assert(atomic_fetch_sub(&h->active_callbacks,1)>0); atomic_inc(&exits); }
#include PRODUCTION

static int original_error=-EACCES;
static bool block_original, original_waiting, release_original;
static pthread_mutex_t wait_lock=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t wait_cond=PTHREAD_COND_INITIALIZER;
static int selinux_readlink(struct dentry *dentry)
{
    (void)dentry;
    atomic_inc(&original_calls);
    /* 6.12 calls the saved SELinux body inside our live callback; 6.1's
     * dispatcher continues to the untouched SELinux node after our return. */
    assert(atomic_read(&sus_path_readlink_hook.active_callbacks)==(HOST_KERNEL==612));
    if (block_original) {
        assert(!pthread_mutex_lock(&wait_lock));
        original_waiting=true;
        assert(!pthread_cond_broadcast(&wait_cond));
        while (!release_original) assert(!pthread_cond_wait(&wait_cond,&wait_lock));
        assert(!pthread_mutex_unlock(&wait_lock));
    }
    return original_error;
}
static int dispatch(struct dentry *dentry)
{
    int rc=sus_path_lsm_readlink(dentry);
#if HOST_KERNEL != 612
    if (!rc) rc=selinux_readlink(dentry);
#endif
    return rc;
}
static void *reader(void *opaque)
{ assert(dispatch(opaque)==-EACCES); return NULL; }

int main(int argc, char **argv)
{
    assert(argc==2);
    const char *test=argv[1];
    struct file_system_type proc={1}, other={2};
    struct super_block sb={1,&proc}, alternate={2,&proc}, unrelated={2,&other};
    struct inode target={&sb,11,{0}}, clone=target;
    struct dentry dentry={&target}, *subject=&dentry;
    struct sus_path_entry rule={.inode=&target,.dev=1,.ino=11};
    list_add(&rule.list,&sus_path_list);
    sus_path_readlink_hook.original=selinux_readlink;
    bool hidden=true;
    if (!strcmp(test,"visible-denied") || !strcmp(test,"visible-allowed") ||
        !strcmp(test,"visible-retry") || !strcmp(test,"visible-other-error") ||
        !strcmp(test,"sleeping-original")) {
        clone.i_ino=22; dentry.inode=&clone; hidden=false;
        if (!strcmp(test,"visible-allowed")) original_error=0;
        if (!strcmp(test,"visible-retry")) original_error=-ECHILD;
        if (!strcmp(test,"visible-other-error")) original_error=-EINVAL;
    } else if (!strcmp(test,"umount-bypass")) { umounted_app=false; hidden=false;
    } else if (!strcmp(test,"owner-bypass")) { target.i_uid.val=uid; hidden=false;
    } else if (!strcmp(test,"root-bypass")) { uid=0; umounted_app=false; hidden=false;
    } else if (!strcmp(test,"gate-disabled")) { uid=0; hide_from_apps=0; umounted_app=false;
    } else if (!strcmp(test,"self-protected-shell")) { uid=2000; rule.self_protect=true; umounted_app=false;
    } else if (!strcmp(test,"self-protected-root")) { uid=0; rule.self_protect=true; hidden=false;
    } else if (!strcmp(test,"same-identity")) { dentry.inode=&clone;
    } else if (!strcmp(test,"other-mount")) { clone.i_sb=&alternate; dentry.inode=&clone; hidden=false;
    } else if (!strcmp(test,"self-protected-proc-instance")) {
        uid=1000; rule.self_protect=true; clone.i_sb=&alternate; dentry.inode=&clone;
    } else if (!strcmp(test,"unrelated-filesystem")) {
        rule.self_protect=true; clone.i_sb=&unrelated; dentry.inode=&clone; hidden=false;
    } else if (!strcmp(test,"pending")) { rule.inode=NULL; rule.ino=0; hidden=false;
    } else if (!strcmp(test,"negative-dentry")) { dentry.inode=NULL; hidden=false;
    } else if (!strcmp(test,"null-dentry")) { subject=NULL; hidden=false;
    } else if (!strcmp(test,"resolver")) { resolver=true; hidden=false;
    } else if (!strcmp(test,"empty-table")) { sus_path_count=0; hidden=false;
    } else assert(!strcmp(test,"hidden"));

    sus_path_index_add(&rule);
    if (!strcmp(test,"sleeping-original")) {
        pthread_t thread;
        block_original=true;
        assert(!pthread_create(&thread,NULL,reader,subject));
        assert(!pthread_mutex_lock(&wait_lock));
        while (!original_waiting) assert(!pthread_cond_wait(&wait_cond,&wait_lock));
        assert(atomic_read(&sus_path_readlink_hook.active_callbacks)==(HOST_KERNEL==612));
        release_original=true;
        assert(!pthread_cond_broadcast(&wait_cond));
        assert(!pthread_mutex_unlock(&wait_lock));
        assert(!pthread_join(thread,NULL));
    } else assert(dispatch(subject)==(hidden ? -ENOENT : original_error));
    assert(atomic_read(&original_calls)==!hidden);
    assert(atomic_read(&n_enoent_readlink_lsm)==hidden);
    assert(!atomic_read(&sus_path_readlink_hook.active_callbacks));
    assert(atomic_read(&enters)==1 && atomic_read(&exits)==1);
    printf("PASS %d %s\n",HOST_KERNEL,test);
    return 0;
}
