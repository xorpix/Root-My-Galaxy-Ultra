#!/usr/bin/env python3
"""Exercise the production readlink LSM hook, caller gate and callback lifetime."""
import argparse
import importlib.util
import os
from pathlib import Path
import re
import resource
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('extract', ROOT / 'tests/path_creds/run.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


def fragments(source):
    text = (source / 'kernel/sus_path.c').read_text()
    # These are the real macros, including the >= 6.12 original-call exit.
    start = text.index('#define LSM_HOOK_FN_TYPE')
    parts = [text[start:text.index('static_assert(', start)]]
    for name in ('sus_path_gate_ok', 'sus_path_entry_gate_inode',
                 'sus_path_inode_hidden', 'sus_path_dentry_hidden', 'sus_path_lsm_readlink'):
        parts.append(extract.function(text, name))
    for name in ('sus_path_init', 'sus_path_exit'):
        assert '&sus_path_readlink_hook,' in extract.function(text, name), name
    assert re.search(r'KSU_LSM_HOOK_INSERT\(inode_readlink, sus_path_lsm_readlink\)', text)
    return '\n\n'.join(parts)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-dir', type=Path, default=ROOT)
    parser.add_argument('--sanitizers', action='store_true')
    args = parser.parse_args()
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    here = Path(__file__).resolve().parent
    cases = ['hidden', 'visible-denied', 'visible-allowed', 'visible-retry',
             'visible-other-error', 'umount-bypass', 'owner-bypass', 'root-bypass',
             'gate-disabled', 'self-protected-shell', 'self-protected-root',
             'same-identity', 'other-mount', 'self-protected-proc-instance',
             'unrelated-filesystem', 'pending', 'negative-dentry', 'null-dentry',
             'resolver', 'empty-table', 'sleeping-original']
    env = dict(os.environ, ASAN_OPTIONS='detect_leaks=0:abort_on_error=1',
               UBSAN_OPTIONS='halt_on_error=1')
    with tempfile.TemporaryDirectory(prefix='susfs-readlink-lsm-') as directory:
        root = Path(directory)
        production = root / 'production.h'
        original = fragments(args.source_dir)
        flags = (['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-no-pie']
                 if args.sanitizers else ['-O2'])
        for version in (601, 612):
            production.write_text(original)
            exe = root / str(version)
            command = [os.environ.get('CC', 'cc'), '-std=gnu11', '-Wall', '-Wextra', '-Werror',
                       '-Wno-unused-function', '-Wno-unused-parameter', '-pthread', *flags,
                       f'-DHOST_KERNEL={version}', '-DPRODUCTION="' + str(production) + '"',
                       str(here / 'readlink_test.c'), '-o', str(exe)]
            subprocess.run(command, check=True)
            for case in cases:
                subprocess.run([str(exe), case], env=env, check=True, timeout=10)
            # Removing the early denial must reproduce the SELinux errno leak.
            needle = 'if (sus_path_dentry_hidden(dentry)) {'
            assert original.count(needle) == 1
            production.write_text(original.replace(needle, 'if (false && sus_path_dentry_hidden(dentry)) {'))
            subprocess.run(command, check=True)
            run = subprocess.run([str(exe), 'hidden'], env=env, capture_output=True, text=True, timeout=10)
            assert run.returncode != 0 and 'Assertion' in run.stderr, run.stderr
            print(f'PASS {version} missing-readlink-denial negative control')
            if version == 612:
                needle = 'ksu_lsm_callback_exit(&(hook));'
                # The pass-through decrement is distinct from SUS_LSM_RETURN's decrement.
                start = original.index('#define SUS_LSM_PASS_ORIG')
                mutated = original[:start] + original[start:].replace(needle, '(void)0;', 1)
                assert mutated != original
                production.write_text(mutated)
                subprocess.run(command, check=True)
                run = subprocess.run([str(exe), 'visible-denied'], env=env,
                                     capture_output=True, text=True, timeout=10)
                assert run.returncode != 0 and 'Assertion' in run.stderr, run.stderr
                print('PASS 612 missing-original-call-exit negative control')
    print('PASS production readlink LSM: 42 cases, 3 runtime negative controls')


if __name__ == '__main__':
    main()
