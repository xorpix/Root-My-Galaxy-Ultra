/* SPDX-License-Identifier: GPL-2.0 */
/* Production entry/actor code, with process context, ownership and probe shims. */
#include <assert.h>
#include <errno.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#define __user
#define __nocfi
#define noinline __attribute__((noinline))
#define ARRAY_SIZE(x) (sizeof(x)/sizeof((x)[0]))
#define READ_ONCE(x) __atomic_load_n(&(x),__ATOMIC_ACQUIRE)
#define WRITE_ONCE(x,v) __atomic_store_n(&(x),(v),__ATOMIC_RELEASE)
#define container_of(p,t,m) ((t *)((char *)(p)-offsetof(t,m)))
#define static_assert _Static_assert
#define __same_type(a,b) __builtin_types_compatible_p(a,b)
#define smp_mb__before_atomic() atomic_thread_fence(memory_order_seq_cst)
#define smp_mb__after_atomic() atomic_thread_fence(memory_order_seq_cst)
#define unlikely(x) (x)
#define NAME_MAX 255
#define PROC_SUPER_MAGIC 0x9fa0
#define O_PATH 010000000
#define FMODE_ATOMIC_POS 1
#define LOOKUP_EMPTY 1
#define LOOKUP_REVAL 2
#define ERR_PTR(x) ((void *)(intptr_t)(x))
#define IS_ERR(x) ((uintptr_t)(x)>=(uintptr_t)-4095)
typedef uint64_t u64;
typedef int64_t s64;
typedef uint32_t compat_ulong_t;
typedef uint32_t compat_uptr_t;
static void *compat_ptr(compat_uptr_t p) { return (void *)(uintptr_t)p; }
static bool host_end_cookie_fault;
#define put_user(v,p) (host_end_cookie_fault ? -EFAULT : (*(p)=(v),0))
typedef _Atomic int atomic_t;
#define ATOMIC_INIT(x) (x)
static void atomic_inc(atomic_t *p) { atomic_fetch_add(p,1); }
static int atomic_read(atomic_t *p) { return atomic_load(p); }
static bool atomic_dec_and_test(atomic_t *p) { return atomic_fetch_sub(p,1)==1; }
struct waitq { pthread_mutex_t lock; pthread_cond_t cond; };
#define DECLARE_WAIT_QUEUE_HEAD(n) struct waitq n={PTHREAD_MUTEX_INITIALIZER,PTHREAD_COND_INITIALIZER}
static void wake_up_all(struct waitq *q) { pthread_mutex_lock(&q->lock);pthread_cond_broadcast(&q->cond);pthread_mutex_unlock(&q->lock); }
static atomic_t tasks_graces;
static void synchronize_rcu_tasks(void) { atomic_inc(&tasks_graces); }
#define wait_event(q,c) do { pthread_mutex_lock(&(q).lock);while(!(c))pthread_cond_wait(&(q).cond,&(q).lock);pthread_mutex_unlock(&(q).lock); } while(0)
struct list_head { struct list_head *next,*prev; };
#define LIST_HEAD(n) struct list_head n={&(n),&(n)}
static void list_add(struct list_head *n,struct list_head *h) { n->next=h->next;n->prev=h;h->next->prev=n;h->next=n; }
static void list_del(struct list_head *n) { n->prev->next=n->next;n->next->prev=n->prev; }
#define list_for_each_entry(p,h,m) for(p=container_of((h)->next,typeof(*p),m);&(p)->m!=(h);p=container_of((p)->m.next,typeof(*p),m))
#define DEFINE_SPINLOCK(n) pthread_mutex_t n=PTHREAD_MUTEX_INITIALIZER
#define spin_lock(n) pthread_mutex_lock(n)
#define spin_unlock(n) pthread_mutex_unlock(n)
#define spin_lock_irqsave(n,f) do { (f)=0;spin_lock(n); } while(0)
#define spin_unlock_irqrestore(n,f) do { (void)(f);spin_unlock(n); } while(0)
struct task_struct { int unused; };
static _Thread_local struct task_struct host_task;
#define current (&host_task)
static _Thread_local bool in_probe;
struct file_system_type { int identity; };
struct super_block { u64 s_dev;struct file_system_type *s_type;unsigned long s_magic; };
typedef struct { uid_t val; } kuid_t;
struct inode_operations { int (*readlink)(void); };
struct inode { struct super_block *i_sb;u64 ino;kuid_t i_uid;struct inode_operations *i_op;bool symlink; };
struct dentry { struct inode *inode; };
struct path { struct dentry *dentry; };
struct file { struct inode *inode;struct path path;unsigned int f_flags,f_mode;loff_t f_pos;pthread_mutex_t f_pos_lock; };
struct linux_dirent64 { u64 d_ino;s64 d_off;unsigned short d_reclen;unsigned char d_type;char d_name[]; };
struct dir_context { bool (*actor)(struct dir_context *,const char *,int,loff_t,u64,unsigned int);loff_t pos; };
#define file_inode(f) ((f)->inode)
#define d_backing_inode(d) ((d)->inode)
#define d_is_symlink(d) ((d)->inode->symlink)
struct filename { char *name; };
struct pt_regs { unsigned long regs[31],pc; };
struct kprobe { void *addr;int (*pre_handler)(struct kprobe *,struct pt_regs *); };
static struct kprobe *live[5];
static int reg_calls,fail_reg,duplicate_symbol,missing_helper;
static int register_kprobe(struct kprobe *p) { int i=reg_calls++%5;if(fail_reg==i+1)return -EINVAL;live[i]=p;return 0; }
static void unregister_kprobe(struct kprobe *p) { for(int i=0;i<5;i++)if(live[i]==p)live[i]=NULL; }
static void instruction_pointer_set(struct pt_regs *r,unsigned long pc) { r->pc=pc; }
static int dispatch(int slot,struct pt_regs *r) { struct kprobe *p=live[slot];if(!p)return 0;assert(!in_probe);in_probe=true;int rc=p->pre_handler(p,r);in_probe=false;return rc; }
static int iterate_dir(struct file *,struct dir_context *);
static struct filename *getname_flags(const char *,int);
static void putname(struct filename *);
static int security_inode_readlink(struct dentry *);
static void touch_atime(const struct path *);
static int vfs_readlink(struct dentry *,char *,int);
static int filename_lookup(int,struct filename *,unsigned int,struct path *,struct path *);
static struct file *fget(unsigned int);
static void fput(struct file *);
static bool filldir64(struct dir_context *,const char *,int,loff_t,u64,unsigned int);
static bool compat_filldir(struct dir_context *,const char *,int,loff_t,u64,unsigned int);
static int host_fd_refs,host_pos_locks;
static void mutex_lock(pthread_mutex_t *p) { assert(!in_probe);assert(!pthread_mutex_lock(p));host_pos_locks++; }
static void mutex_unlock(pthread_mutex_t *p) { host_pos_locks--;assert(!pthread_mutex_unlock(p)); }
static void *ksu_resolve_symbol_for_functable_hook(const char *n)
{
    if(missing_helper)return NULL;
#define BIND(f) if(!strcmp(n,#f))return f
    BIND(iterate_dir);BIND(getname_flags);BIND(putname);BIND(filename_lookup);
    BIND(security_inode_readlink);BIND(touch_atime);BIND(vfs_readlink);
    BIND(fget);BIND(fput);BIND(filldir64);BIND(compat_filldir);
#undef BIND
    return NULL;
}
static int ksu_find_symbol_all(const char *n,unsigned long *a,int max) { (void)n;(void)max;a[0]=1;return duplicate_symbol?2:1; }
static struct file_system_type proc_type={1},other_type={2};
static struct super_block sb={1,&proc_type,PROC_SUPER_MAGIC},same_dev_sb={1,&proc_type,PROC_SUPER_MAGIC},
    other_sb={2,&proc_type,PROC_SUPER_MAGIC},unrelated_sb={3,&other_type,0};
static struct inode_operations iops;
static struct inode inode={&sb,100,{0},&iops,false};
static struct dentry dentry={&inode};
static int uid=10000,no_extra,hide_from_apps=1;
static kuid_t current_uid(void) { return (kuid_t){uid}; }
static bool host_umount=true;
bool susfs_ksu_umount_gate_off;
bool susfs_ksu_umount_ask(uid_t caller) { (void)caller; return host_umount; }
#include "../../kernel/ksu_umount_gate.h"
static unsigned int sus_path_count=1;
static char hide_name[NAME_MAX+1];
struct sus_path_entry { struct sus_path_entry *index_next; struct list_head list;struct inode *inode;u64 dev,ino;bool self_protect;char name[NAME_MAX+1]; };
static LIST_HEAD(sus_path_list);
static DEFINE_SPINLOCK(sus_path_lock);
#include "../../kernel/sus_path_index.h"
static bool sus_path_is_resolver(void) { return false; }
static bool sus_path_gate_uid_ok(void) { return uid>=10000; }
static bool sus_path_entry_gate_any(const struct sus_path_entry *e) { return e->self_protect?uid!=0:susfs_is_current_proc_umounted_app()&&uid!=e->inode->i_uid.val; }
static bool sus_path_inode_hidden(struct inode *i) { struct sus_path_entry *e;bool hit=false;spin_lock(&sus_path_lock);list_for_each_entry(e,&sus_path_list,list)if(e->inode==i&&sus_path_entry_gate_any(e))hit=true;spin_unlock(&sus_path_lock);return hit; }
static void path_put(struct path *p);
static bool retry_estale(int error,unsigned int flags) { return error==-ESTALE&&!(flags&LOOKUP_REVAL); }
#include PRODUCTION

static int name_refs,path_refs,lookup_calls,lookup_error,security_error,security_calls,link_calls,opened;
static bool stale_once,iterate_override_credentials;
static bool skip_iterate_probe,host_inode_overflow,host_signal;
static int host_iterate_error,host_total_entries=3,host_emit_calls;
static struct file *host_fd_file;
static unsigned int last_flags;
static struct filename *getname_flags(const char *p,int flags) { (void)flags;assert(!in_probe);if(!p)return ERR_PTR(-EFAULT);struct filename *n=malloc(sizeof(*n));n->name=strdup(p);name_refs++;return n; }
static void putname(struct filename *n) { assert(!in_probe);if(IS_ERR(n))return;name_refs--;free(n->name);free(n); }
static int filename_lookup(int fd,struct filename *n,unsigned int flags,struct path *p,struct path *root) { (void)fd;(void)root;assert(!in_probe);lookup_calls++;last_flags=flags;if(IS_ERR(n))return -EFAULT;if(lookup_error)return lookup_error;p->dentry=&dentry;path_refs++;return 0; }
static void path_put(struct path *p) { (void)p;assert(!in_probe);path_refs--;assert(path_refs>=0); }
static int security_inode_readlink(struct dentry *d) { (void)d;assert(!in_probe);security_calls++;return security_error; }
static void touch_atime(const struct path *p) { (void)p;assert(!in_probe); }
static int vfs_readlink(struct dentry *d,char *b,int len) { (void)d;assert(!in_probe);link_calls++;if(stale_once){stale_once=false;return -ESTALE;}if(len<4)return -EINVAL;memcpy(b,"link",4);return 4; }
struct emit_buf { struct dir_context ctx;char names[80];int count,capacity; };
static bool emit(struct dir_context *ctx,const char *name,int len,loff_t off,u64 ino,unsigned int type) { (void)off;(void)ino;(void)type;struct emit_buf *b=container_of(ctx,struct emit_buf,ctx);assert(!in_probe);if(b->count==b->capacity)return false;assert(b->count+len<80);memcpy(b->names+b->count,name,len);b->count+=len;return true; }
static int iterate_dir(struct file *f,struct dir_context *ctx)
{
    struct pt_regs r={.regs={(unsigned long)f,(unsigned long)ctx}};
    if(!skip_iterate_probe&&dispatch(0,&r))return ((typeof(&iterate_dir))r.pc)(f,ctx);
    assert(!in_probe);
    if(host_iterate_error)return host_iterate_error;
    int saved_uid=uid;
    if (iterate_override_credentials) uid=0;
    char raw[3]={'x','q','Z'}; /* deliberately no NUL */
    ctx->pos=f->f_pos;
    while(ctx->pos<host_total_entries) {
        u64 ino=ctx->pos<2?100:200;
        if(host_inode_overflow&&ctx->pos==2)ino=UINT64_C(1)<<33;
        if(!ctx->actor(ctx,raw,2,ctx->pos,ino,8))break;
        ctx->pos++;
    }
    f->f_pos=ctx->pos;uid=saved_uid;return 0;
}
static struct file *fget(unsigned int fd) { assert(!in_probe);if(fd!=42||!host_fd_file||(host_fd_file->f_flags&O_PATH))return NULL;host_fd_refs++;return host_fd_file; }
static void fput(struct file *f) { assert(!in_probe&&f==host_fd_file&&host_fd_refs>0&&!host_pos_locks);host_fd_refs--; }
/* Model the native actor contract, including partial reads and per-ABI errors;
 * the real-header checker separately verifies the callback/record layouts. */
static bool filldir64(struct dir_context *ctx,const char *name,int len,loff_t off,u64 ino,unsigned int type)
{
    struct sp_getdents_callback64 *b=container_of(ctx,struct sp_getdents_callback64,ctx);
    int reclen=(offsetof(struct linux_dirent64,d_name)+len+1+7)&~7;
    assert(!in_probe&&host_fd_refs==1&&host_pos_locks==1);host_emit_calls++;
    b->error=-EINVAL;if(reclen>b->count)return false;
    if(b->prev_reclen&&host_signal)return false;
    if(!b->current_dir){b->error=-EFAULT;return false;}
    struct linux_dirent64 *p=(void *)b->current_dir-b->prev_reclen;
    p->d_off=off;b->current_dir->d_ino=ino;b->current_dir->d_reclen=reclen;b->current_dir->d_type=type;
    memcpy(b->current_dir->d_name,name,len);b->current_dir->d_name[len]=0;
    b->prev_reclen=reclen;b->current_dir=(void *)b->current_dir+reclen;b->count-=reclen;return true;
}
static bool compat_filldir(struct dir_context *ctx,const char *name,int len,loff_t off,u64 ino,unsigned int type)
{
    struct sp_compat_getdents_callback *b=container_of(ctx,struct sp_compat_getdents_callback,ctx);
    int reclen=(offsetof(struct sp_compat_linux_dirent,d_name)+len+2+3)&~3;
    assert(!in_probe&&host_fd_refs==1&&host_pos_locks==1);host_emit_calls++;
    b->error=-EINVAL;if(reclen>b->count)return false;
    if((compat_ulong_t)ino!=ino){b->error=-EOVERFLOW;return false;}
    if(b->prev_reclen&&host_signal)return false;
    if(!b->current_dir){b->error=-EFAULT;return false;}
    struct sp_compat_linux_dirent *p=(void *)b->current_dir-b->prev_reclen;
    p->d_off=off;b->current_dir->d_ino=ino;b->current_dir->d_reclen=reclen;
    memcpy(b->current_dir->d_name,name,len);b->current_dir->d_name[len]=0;((char *)b->current_dir)[reclen-1]=type;
    b->prev_reclen=reclen;b->current_dir=(void *)b->current_dir+reclen;b->count-=reclen;return true;
}
static long directory_syscall(bool compat,unsigned long fd,void *buf,unsigned long count)
{
    struct pt_regs args={.regs={fd,(unsigned long)buf,count}};
    struct pt_regs entry={.regs={(unsigned long)&args}};
    assert(dispatch(compat?4:3,&entry));
    long result=((long (*)(const struct pt_regs *))entry.pc)(&args);
    assert(!host_fd_refs&&!host_pos_locks&&!atomic_read(&sp_entry_callbacks));return result;
}
static long open_path(struct path *p,struct file *f) { struct pt_regs r={.regs={(unsigned long)p,(unsigned long)f}};if(dispatch(1,&r))return ((int (*)(const struct path *,struct file *))r.pc)(p,f);opened++;return 7; }
static int read_link(const char *name,char *buf,int len) { struct pt_regs r={.regs={(unsigned long)-100,(unsigned long)name,(unsigned long)buf,(unsigned long)len}};assert(dispatch(2,&r));return ((int (*)(int,const char *,char *,int))r.pc)(-100,name,buf,len); }
static void *remove_thread(void *unused) { (void)unused;sp_entry_remove();return NULL; }

int main(void)
{
    struct sus_path_entry rule={.inode=&inode,.dev=sb.s_dev,.ino=100};list_add(&rule.list,&sus_path_list);sus_path_index_add(&rule);
    assert(sp_entry_install()==0);assert(sp_entry_install()==0);
    struct file file={.inode=&inode};
    struct emit_buf b={.ctx={.actor=emit},.capacity=80};
    assert(iterate_dir(&file,&b.ctx)==0);assert(b.count==2&&!memcmp(b.names,"xq",2));assert(b.ctx.pos==3&&file.f_pos==3);
    b=(struct emit_buf){.ctx={.actor=emit},.capacity=0};file.f_pos=0;
    assert(iterate_dir(&file,&b.ctx)==0);assert(b.count==0&&file.f_pos==2); /* hidden stretch doesn't claim EOF */
    b.capacity=80;assert(iterate_dir(&file,&b.ctx)==0);assert(b.count==2&&file.f_pos==3);
    /* A filesystem may override current credentials before calling the actor.
     * Hiding must still use the original directory caller, including for ours. */
    iterate_override_credentials=true;rule.self_protect=true;
    b=(struct emit_buf){.ctx={.actor=emit},.capacity=80};file.f_pos=0;
    assert(iterate_dir(&file,&b.ctx)==0);assert(b.count==2&&file.f_pos==3);
    rule.self_protect=false;
    b=(struct emit_buf){.ctx={.actor=emit},.capacity=80};file.f_pos=0;
    assert(iterate_dir(&file,&b.ctx)==0);assert(b.count==2&&file.f_pos==3);
    host_umount=false;
    b=(struct emit_buf){.ctx={.actor=emit},.capacity=80};file.f_pos=0;
    assert(iterate_dir(&file,&b.ctx)==0);assert(b.count==6);
    strcpy(hide_name,"xq");
    b=(struct emit_buf){.ctx={.actor=emit},.capacity=80};file.f_pos=0;
    assert(iterate_dir(&file,&b.ctx)==0);assert(b.count==6);hide_name[0]=0;
    rule.self_protect=true;
    b=(struct emit_buf){.ctx={.actor=emit},.capacity=80};file.f_pos=0;
    assert(iterate_dir(&file,&b.ctx)==0);assert(b.count==2);
    rule.self_protect=false;host_umount=true;
    /* An app-owned ordinary rule stays visible under the same override. */
    inode.i_uid.val=uid;
    b=(struct emit_buf){.ctx={.actor=emit},.capacity=80};file.f_pos=0;
    assert(iterate_dir(&file,&b.ctx)==0);assert(b.count==6);
    hide_from_apps=0;
    b=(struct emit_buf){.ctx={.actor=emit},.capacity=80};file.f_pos=0;
    assert(iterate_dir(&file,&b.ctx)==0);assert(b.count==2);
    hide_from_apps=1;inode.i_uid.val=0;
    uid=10000;rule.self_protect=false;rule.name[0]=0;
    iterate_override_credentials=false;
    /* Procfs instances in different mount namespaces share the control node's
     * globally allocated inode number, but not s_dev or the superblock pointer.
     * Ordinary rules must stay scoped to their device; only our controls get
     * the existing by-inode layer's (filesystem type, inode) fallback. */
    assert(!sp_dirent_is_hidden(&other_sb,100,"xqZ",2,uid,susfs_is_current_proc_umounted_app()));
    rule.self_protect=true;uid=2000;
    assert(sp_dirent_is_hidden(&other_sb,100,"xqZ",2,uid,susfs_is_current_proc_umounted_app()));
    assert(!sp_dirent_is_hidden(&unrelated_sb,100,"xqZ",2,uid,susfs_is_current_proc_umounted_app()));
    assert(!sp_dirent_is_hidden(&other_sb,101,"xqZ",2,uid,susfs_is_current_proc_umounted_app()));
    uid=0;assert(!sp_dirent_is_hidden(&other_sb,100,"xqZ",2,uid,susfs_is_current_proc_umounted_app()));
    uid=10000;
    struct inode alternate_inode=inode;alternate_inode.i_sb=&other_sb;
    struct file alternate_file={.inode=&alternate_inode};
    struct emit_buf alternate_buf={.ctx={.actor=emit},.capacity=80};
    assert(iterate_dir(&alternate_file,&alternate_buf.ctx)==0);
    assert(alternate_buf.count==2&&alternate_file.f_pos==3);
    rule.self_protect=false;
    assert(sp_dirent_is_hidden(&same_dev_sb,100,"xqZ",2,uid,susfs_is_current_proc_umounted_app()));
    rule.ino=0;assert(!sp_dirent_is_hidden(&sb,0,"xqZ",2,uid,susfs_is_current_proc_umounted_app()));rule.ino=100;
    uid=inode.i_uid.val;assert(!sp_dirent_is_hidden(&sb,100,"xqZ",2,uid,susfs_is_current_proc_umounted_app()));uid=10000;
    strcpy(hide_name,"xq");assert(sp_dirent_is_hidden(&other_sb,999,"xqZ",2,uid,susfs_is_current_proc_umounted_app()));assert(!sp_dirent_is_hidden(&other_sb,999,"xqZ",1,uid,susfs_is_current_proc_umounted_app()));hide_name[0]=0;
    file.f_flags=O_PATH;struct path path={&dentry};assert(open_path(&path,&file)==-ENOENT&&opened==0);
    file.f_flags=0;assert(open_path(&path,&file)==7&&opened==1);
    uid=0;file.f_flags=O_PATH;assert(open_path(&path,&file)==7&&opened==2);uid=10000;
    char buf[16]={0};assert(read_link("hidden",buf,16)==-ENOENT);assert(!name_refs&&!path_refs&&!link_calls);
    security_error=-EACCES;
    assert(read_link("hidden",buf,16)==-ENOENT);
    inode.symlink=true;assert(read_link("hidden-link",buf,16)==-ENOENT);inode.symlink=false;
    assert(!security_calls&&!link_calls&&!name_refs&&!path_refs);security_error=0;
    assert(read_link("hidden",buf,0)==-EINVAL);assert(!name_refs&&!path_refs);
    uid=0;assert(read_link("plain",buf,16)==-EINVAL);assert(read_link("",buf,16)==-ENOENT);
    inode.symlink=true;assert(read_link("visible",buf,16)==4&&!memcmp(buf,"link",4));
    security_error=-EACCES;assert(read_link("visible",buf,16)==-EACCES);security_error=0;
    stale_once=true;int before=lookup_calls;assert(read_link("visible",buf,16)==4);assert(lookup_calls==before+2&&(last_flags&LOOKUP_REVAL));
    lookup_error=-ENOENT;assert(read_link("absent",buf,16)==-ENOENT);lookup_error=0;assert(read_link(NULL,buf,16)==-EFAULT);assert(!name_refs&&!path_refs);
    /* Reproduce the phone's inlined-iterate bypass. The syscall entry must
     * enforce policy even when the out-of-line iterate probe is never hit. */
    uid=10000;skip_iterate_probe=true;file.f_mode=FMODE_ATOMIC_POS;file.f_flags=0;
    pthread_mutex_init(&file.f_pos_lock,NULL);host_fd_file=&file;
    b=(struct emit_buf){.ctx={.actor=emit},.capacity=80};file.f_pos=0;
    assert(iterate_dir(&file,&b.ctx)==0&&b.count==6); /* Test3 leak */
    unsigned char *records=mmap(NULL,4096,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS|MAP_32BIT,-1,0);
    assert(records!=MAP_FAILED&&(uintptr_t)records<=UINT32_MAX);
    for(int compat=0;compat<2;compat++) {
        memset(records,0xa5,4096);file.f_pos=0;host_emit_calls=0;
        long size=compat?16:24;
        assert(directory_syscall(compat,42,records,4096)==size);
        assert(file.f_pos==3&&host_emit_calls==1); /* hidden bytes never reach emitter */
        if(compat){struct sp_compat_linux_dirent *d=(void *)records;assert(d->d_ino==200&&d->d_off==3&&d->d_reclen==size&&!strcmp(d->d_name,"xq"));}
        else{struct linux_dirent64 *d=(void *)records;assert(d->d_ino==200&&d->d_off==3&&d->d_reclen==size&&!strcmp(d->d_name,"xq"));}
        for(int i=size;i<4096;i++)assert(records[i]==0xa5);
        assert(directory_syscall(compat,42,records,4096)==0);
        file.f_pos=0;assert(directory_syscall(compat,42,records,size-1)==-EINVAL&&file.f_pos==2);
        assert(directory_syscall(compat,42,records,size)==size&&file.f_pos==3);
        file.f_pos=0;assert(directory_syscall(compat,42,NULL,4096)==-EFAULT&&file.f_pos==2);
        file.f_pos=0;host_end_cookie_fault=true;
        assert(directory_syscall(compat,42,records,4096)==-EFAULT&&file.f_pos==3);host_end_cookie_fault=false;
        host_iterate_error=-EACCES;assert(directory_syscall(compat,42,records,4096)==-EACCES);
        host_iterate_error=-ENOTDIR;assert(directory_syscall(compat,42,records,4096)==-ENOTDIR);host_iterate_error=0;
        assert(directory_syscall(compat,41,records,4096)==-EBADF);
        file.f_flags=O_PATH;assert(directory_syscall(compat,42,records,4096)==-EBADF);file.f_flags=0;
        file.f_pos=0;host_total_entries=2;memset(records,0xa5,4096);
        assert(directory_syscall(compat,42,records,4096)==0&&file.f_pos==2);
        for(int i=0;i<4096;i++)assert(records[i]==0xa5);
        host_total_entries=3;
        uid=0;file.f_pos=0;assert(directory_syscall(compat,42,records,size)==size&&file.f_pos==1);uid=10000;
        /* Visible first record + pending signal returns the completed bytes. */
        rule.ino=999;file.f_pos=0;host_signal=true;
        assert(directory_syscall(compat,42,records,4096)==size&&file.f_pos==1);host_signal=false;rule.ino=100;
        file.f_pos=0;assert(directory_syscall(compat,UINT64_C(1)<<32|42,records,UINT64_C(1)<<32|4096)==size);
    }
    host_inode_overflow=true;file.f_pos=0;
    assert(directory_syscall(true,42,records,4096)==-EOVERFLOW&&file.f_pos==2);
    file.f_pos=0;assert(directory_syscall(false,42,records,4096)==24);host_inode_overflow=false;
    munmap(records,4096);skip_iterate_probe=false;uid=0;
    /* Counter starts at diversion, before the replacement can be scheduled. */
    struct pt_regs regs={0};assert(dispatch(2,&regs));assert(atomic_read(&sp_entry_callbacks)==1);
    pthread_t t;assert(!pthread_create(&t,NULL,remove_thread,NULL));
    while(READ_ONCE(sp_entry_installed))sched_yield();
    assert(atomic_read(&sp_entry_callbacks)==1);assert(sp_readlink(-100,"visible",buf,16)==4);assert(!pthread_join(t,NULL));
    assert(!atomic_read(&sp_entry_callbacks)&&atomic_read(&tasks_graces)>=2);
    for(int i=0;i<5;i++)assert(!live[i]);
    reg_calls=0;assert(sp_entry_install()==0);
    unsigned char final_records[128];file.f_pos=0;
    struct pt_regs syscall_args={.regs={42,(unsigned long)final_records,sizeof(final_records)}};
    struct pt_regs syscall_entry={.regs={(unsigned long)&syscall_args}};
    assert(dispatch(3,&syscall_entry)&&atomic_read(&sp_entry_callbacks)==1);
    assert(!pthread_create(&t,NULL,remove_thread,NULL));
    while(READ_ONCE(sp_entry_installed))sched_yield();
    assert(atomic_read(&sp_entry_callbacks)==1);
    assert(sp_getdents64(&syscall_args)==72);assert(!pthread_join(t,NULL));
    assert(!host_fd_refs&&!host_pos_locks&&!atomic_read(&sp_entry_callbacks));
    for(int fail=1;fail<=5;fail++){reg_calls=0;fail_reg=fail;assert(sp_entry_install()==-EINVAL);for(int i=0;i<5;i++)assert(!live[i]);}
    reg_calls=0;fail_reg=0;duplicate_symbol=1;assert(sp_entry_install()==-ENOENT);duplicate_symbol=0;
    missing_helper=1;assert(sp_entry_install()==-ENOENT);missing_helper=0;
    reg_calls=0;assert(sp_entry_install()==0);sp_entry_remove();
    assert(!name_refs&&!path_refs);
    puts("PASS production path entry: dirent byte lengths/identity/owner/position, O_PATH pre-install denial, readlink native errors/retry/reference ownership, probe rollback and diverted-entry teardown");
}
