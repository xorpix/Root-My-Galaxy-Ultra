#!/usr/bin/env python3
"""Exercise the production Samsung path-entry header under ASan/UBSan."""
import argparse
import os
from pathlib import Path
import subprocess
import tempfile

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--sanitizers',action='store_true')
a=p.parse_args()
here=Path(__file__).resolve().parent
source=here.parents[1]/'kernel/sus_path_entry.h'
with tempfile.TemporaryDirectory(prefix='susfs-path-entry-') as temporary:
    exe=Path(temporary)/'test'
    flags=['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-no-pie'] if a.sanitizers else ['-O2']
    subprocess.run(['cc','-std=gnu11','-Wall','-Wextra','-Werror','-Wno-unused-function','-Wno-unused-parameter','-Wno-sign-compare','-pthread',*flags,'-DPRODUCTION="'+str(source)+'"',str(here/'entry_test.c'),'-o',str(exe)],check=True)
    subprocess.run([str(exe)],env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1'),check=True,timeout=25)
