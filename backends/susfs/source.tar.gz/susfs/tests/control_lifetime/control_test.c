/* SPDX-License-Identifier: GPL-2.0-only */
#include <assert.h>
#include <errno.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdatomic.h>
#include <stdio.h>
#include <time.h>
#define DEFINE_MUTEX(n) pthread_mutex_t n=PTHREAD_MUTEX_INITIALIZER
#define mutex_lock(p) assert(!pthread_mutex_lock(p))
#define mutex_unlock(p) assert(!pthread_mutex_unlock(p))
#define WARN_ON_ONCE(v) (v)
#define READ_ONCE(v) __atomic_load_n(&(v),__ATOMIC_ACQUIRE)
struct host_waitq {pthread_mutex_t lock;pthread_cond_t changed;};
#define DECLARE_WAIT_QUEUE_HEAD(n) struct host_waitq n={PTHREAD_MUTEX_INITIALIZER,PTHREAD_COND_INITIALIZER}
static pthread_mutex_t schedule=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t changed=PTHREAD_COND_INITIALIZER;
static bool waiting;
static atomic_bool finished;
static int grace_periods;
static void synchronize_rcu_tasks(void) {grace_periods++;}
static void wake_up_all(struct host_waitq *q) {
    assert(!pthread_mutex_lock(&q->lock));pthread_cond_broadcast(&q->changed);assert(!pthread_mutex_unlock(&q->lock));
}
#define wait_event(q,condition) do { \
    assert(!pthread_mutex_lock(&(q).lock)); \
    assert(!pthread_mutex_lock(&schedule));waiting=true;pthread_cond_broadcast(&changed);assert(!pthread_mutex_unlock(&schedule)); \
    while(!(condition))assert(!pthread_cond_wait(&(q).changed,&(q).lock)); \
    assert(!pthread_mutex_unlock(&(q).lock)); \
} while(0)
#include PRODUCTION
static void *shutdown_worker(void *unused) {
    (void)unused;susfs_control_shutdown();atomic_store(&finished,true);return NULL;
}
int main(void) {
    assert(!susfs_control_get());assert(!susfs_control_get());
    pthread_t shutdown;assert(!pthread_create(&shutdown,NULL,shutdown_worker,NULL));
    assert(!pthread_mutex_lock(&schedule));
    struct timespec limit;assert(!clock_gettime(CLOCK_REALTIME,&limit));limit.tv_sec+=5;
    while(!waiting)assert(!pthread_cond_timedwait(&changed,&schedule,&limit));
    assert(!pthread_mutex_unlock(&schedule));
    assert(!atomic_load(&finished) && susfs_control_get()==-ENODEV);
    susfs_control_put();
    assert(!atomic_load(&finished) && susfs_control_get()==-ENODEV);
    susfs_control_put();assert(!pthread_join(shutdown,NULL));
    assert(atomic_load(&finished) && grace_periods==1 && !control_active);
    assert(susfs_control_get()==-ENODEV);
    susfs_control_shutdown();assert(grace_periods==2);
    puts("PASS control barrier: nested admission, shutdown drain, late rejection and idempotent closure");
}
