#!/usr/bin/env python3
"""Exercise the actual common configuration admission/shutdown barrier."""
import argparse
import os
from pathlib import Path
import subprocess
import tempfile

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--sanitizers',action='store_true')
a=p.parse_args()
here=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix='susfs-control-') as d:
    d=Path(d);(d/'linux').mkdir()
    for name in ['errno','mutex','rcupdate','wait','kernel','sched']:
        (d/'linux'/f'{name}.h').write_text('/* Explicit host API model in control_test.c */\n')
    (d/'linux/errno.h').write_text('#include_next <linux/errno.h>\n')
    flags=['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-no-pie'] if a.sanitizers else ['-O2']
    exe=d/'control'
    subprocess.run([os.environ.get('CC','cc'),'-std=gnu11','-Wall','-Wextra','-Werror',
        '-pthread',*flags,'-I',str(d),'-DPRODUCTION="'+str(here.parents[1]/'kernel/susfs_control.c')+'"',
        str(here/'control_test.c'),'-o',str(exe)],check=True)
    subprocess.run([str(exe)],check=True,timeout=15,
        env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1'))
