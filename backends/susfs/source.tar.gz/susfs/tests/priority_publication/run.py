#!/usr/bin/env python3
"""Deterministic two-writer ownership test of the production priority publisher."""
import argparse
import os
from pathlib import Path
import re
import resource
import subprocess
import tempfile

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--sanitizers',action='store_true')
a=p.parse_args()
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
here=Path(__file__).resolve().parent
source=(here.parents[1]/'kernel/susfs_priority_filter.c').read_text()
fragment=re.search(r'^static [^\n]*\bprio_commit_locked\([^;{]*\)\n\{\n.*?^\}\n',source,re.M|re.S)[0]
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
with tempfile.TemporaryDirectory(prefix='susfs-publication-') as d:
    d=Path(d)
    def run(label,text,sanitizers):
        header=d/(label+'.h');header.write_text(text);exe=d/label
        flags=['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-no-pie'] if sanitizers else ['-O2']
        subprocess.run([os.environ.get('CC','cc'),'-std=gnu11','-Wall','-Wextra','-Werror',
            '-pthread',*flags,'-DPRODUCTION="'+str(header)+'"',str(here/'publication_test.c'),'-o',str(exe)],check=True)
        return subprocess.run([str(exe)],capture_output=True,text=True,env=env,timeout=15)
    good=run('production',fragment,a.sanitizers)
    assert good.returncode==0,good.stderr
    print('PASS production publication survives a second writer retiring the first value',flush=True)
    before='if (next->count || next->automatic)\n        next = NULL;\n    mutex_unlock(&prio_config_lock);'
    assert before in fragment
    mutant=fragment.replace(before,'mutex_unlock(&prio_config_lock);\n    if (next->count || next->automatic)\n        next = NULL;',1)
    bad=run('unsafe-after-unlock',mutant,True)
    assert bad.returncode!=0 and 'AddressSanitizer: heap-use-after-free' in bad.stderr,bad.stderr
    print('PASS deterministic publication-UAF negative control detected')
