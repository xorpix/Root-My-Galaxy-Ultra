/* SPDX-License-Identifier: GPL-2.0 */
#include "../feature_hooks/host_kernel.h"
#include <stddef.h>
#include "../../kernel/susfs_abi.h"
typedef uint64_t u64;
typedef int64_t s64;
typedef int32_t s32;
#define static_assert _Static_assert
#define __user
#define DEFINE_MUTEX(name) int name
#define DEFINE_SPINLOCK(name) int name
static int lock_depth;
#define spin_lock_irqsave(lock, flags) do { (void)(lock); (flags)=0; assert(!lock_depth); lock_depth++; } while(0)
#define spin_unlock_irqrestore(lock, flags) do { (void)(lock); (void)(flags); assert(lock_depth==1); lock_depth--; } while(0)
struct timespec64 { s64 tv_sec; long tv_nsec; };
static struct { unsigned int val; } uid = {10362};
#define current_uid() uid
/* ARM64's little-endian compat_stat type. The production offsetof/width asserts
 * are also compiled against the actual pinned kernel headers by the module build. */
struct compat_stat {
    u32 st_dev, st_ino;
    uint16_t st_mode, st_nlink, st_uid, st_gid;
    u32 st_rdev;
    s32 st_size, st_blksize, st_blocks, st_atime;
    u32 st_atime_nsec;
    s32 st_mtime;
    u32 st_mtime_nsec;
    s32 st_ctime;
    u32 st_ctime_nsec, unused[2];
};
static struct { unsigned char before[16]; struct compat_stat value; unsigned char after[16]; } buffer;
static int reads, writes, fail_read, fail_write;
static void bounds(const void *ptr, size_t n)
{
    uintptr_t p=(uintptr_t)ptr, start=(uintptr_t)&buffer.value;
    assert(!lock_depth && p>=start && n<=sizeof(buffer.value) && p-start<=sizeof(buffer.value)-n);
}
static unsigned long copy_from_user(void *to, const void *from, size_t n)
{ bounds(from,n); if (++reads==fail_read) return n; memcpy(to,from,n); return 0; }
static unsigned long copy_to_user(void *to, const void *from, size_t n)
{ bounds(to,n); if (++writes==fail_write) return n; memcpy(to,from,n); return 0; }

/* Host model of the load-time umount gate (issue #34): nothing resolves on the host, so the gate
 * answers the pre-#34 way - app uids and nothing else.  The extracted production fragment's gate
 * calls this replica instead of ksu_umount_gate.h's inline, keeping every other expectation here
 * byte-identical to what it tested before the KSU integration landed in the kernel sources. */
static inline bool susfs_is_current_proc_umounted_app(void)
{
    return current_uid().val >= 10000;
}
#include PRODUCTION
static struct kstat_call_counters cnt;
static struct kstat_call_state state={.cnt=&cnt,.compat=true};
static void reset(void)
{
    memset(&buffer,0xd7,sizeof(buffer)); memset(&cnt,0,sizeof(cnt)); memset(kstat_entries,0,sizeof(kstat_entries));
    reads=writes=fail_read=fail_write=0; uid.val=10362; nkstat=1;
    buffer.value.st_dev=65105; buffer.value.st_ino=784642;
    kstat_entries[0]=(struct sus_kstat_entry){.target_ino=784642,.target_dev=65105,
        .spoofed_ino=100784643,.spoofed_dev=1234,.spoofed_nlink=7,.spoofed_size=4115,
        .spoofed_blksize=65536,.spoofed_blocks=48,
        .spoofed_atime_tv_sec=-123,.spoofed_atime_tv_nsec=1234567,
        .spoofed_mtime_tv_sec=1791800000,.spoofed_mtime_tv_nsec=2345678,
        .spoofed_ctime_tv_sec=77,.spoofed_ctime_tv_nsec=3456789};
}
static bool rewrite(void)
{
    bool r=susfs_kstat_spoof_compat_stat(&state,(unsigned long)&buffer.value);
    for(size_t i=0;i<16;i++) assert(buffer.before[i]==0xd7 && buffer.after[i]==0xd7);
    assert(!lock_depth); return r;
}
int main(void)
{
    reset(); struct compat_stat expected=buffer.value;
    kstat_entries[0].flags=KSTAT_SPOOF_INO|KSTAT_SPOOF_DEV|KSTAT_SPOOF_NLINK|KSTAT_SPOOF_SIZE|
        KSTAT_SPOOF_BLKSIZE|KSTAT_SPOOF_BLOCKS|KSTAT_SPOOF_ATIME_TV_SEC|KSTAT_SPOOF_ATIME_TV_NSEC|
        KSTAT_SPOOF_MTIME_TV_SEC|KSTAT_SPOOF_MTIME_TV_NSEC|KSTAT_SPOOF_CTIME_TV_SEC|KSTAT_SPOOF_CTIME_TV_NSEC;
    expected.st_ino=100784643; expected.st_dev=1234; expected.st_nlink=7; expected.st_size=4115;
    expected.st_blksize=65536; expected.st_blocks=48; expected.st_atime=-123; expected.st_atime_nsec=1234567;
    expected.st_mtime=1791800000; expected.st_mtime_nsec=2345678; expected.st_ctime=77; expected.st_ctime_nsec=3456789;
    assert(rewrite() && !memcmp(&expected,&buffer.value,sizeof(expected)) && cnt.rewrite.value==1);
    reset(); expected=buffer.value; kstat_entries[0].flags=KSTAT_SPOOF_INO|KSTAT_SPOOF_NLINK|KSTAT_SPOOF_SIZE;
    kstat_entries[0].spoofed_ino=0x100000000UL; kstat_entries[0].spoofed_nlink=65536; kstat_entries[0].spoofed_size=0x80000000LL;
    assert(!rewrite() && cnt.narrow.value==3 && !writes && !memcmp(&expected,&buffer.value,sizeof(expected)));
    reset(); kstat_entries[0].flags=KSTAT_SPOOF_SIZE; kstat_entries[0].spoofed_size=-1;
    assert(!rewrite() && cnt.narrow.value==1 && !writes);
    reset(); kstat_entries[0].flags=KSTAT_SPOOF_INO|KSTAT_SPOOF_NLINK|KSTAT_SPOOF_SIZE;
    kstat_entries[0].spoofed_ino=0xffffffffUL; kstat_entries[0].spoofed_nlink=65535; kstat_entries[0].spoofed_size=0x7fffffffLL;
    assert(rewrite() && !cnt.narrow.value && buffer.value.st_ino==0xffffffffU && buffer.value.st_nlink==65535 && buffer.value.st_size==0x7fffffff);
    for(int i=1;i<=2;i++) { reset(); expected=buffer.value; fail_read=i; kstat_entries[0].flags=KSTAT_SPOOF_INO;
        assert(!rewrite() && cnt.uaccess.value==1 && !writes && !memcmp(&expected,&buffer.value,sizeof(expected))); }
    reset(); expected=buffer.value; fail_write=1; kstat_entries[0].flags=KSTAT_SPOOF_INO;
    assert(!rewrite() && cnt.uaccess.value==1 && !memcmp(&expected,&buffer.value,sizeof(expected)));
    reset(); buffer.value.st_dev++; kstat_entries[0].flags=KSTAT_SPOOF_INO;
    assert(!rewrite() && cnt.miss_lookup.value==1 && !writes);
    reset(); uid.val=1000; assert(!rewrite() && cnt.miss_gate.value==1 && !reads && !writes);
    reset(); nkstat=0; assert(!rewrite() && cnt.miss_empty.value==1 && !reads && !writes);
    reset(); assert(!rewrite() && cnt.match_noflag.value==1 && !writes);
    puts("PASS compat_stat: all fields/canaries, exact-width boundaries, overflow refusal, read/write faults, identity, gate and empty/no-flag rules");
}
