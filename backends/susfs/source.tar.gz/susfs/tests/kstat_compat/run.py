#!/usr/bin/env python3
"""Run the production legacy compat_stat rewriter under ASan/UBSan."""
from pathlib import Path
import json, os, re, subprocess, tempfile
root=Path(__file__).resolve().parents[2]
text=(root/'kernel/susfs_kstat.c').read_text()
def function(name):
    m=re.search(r'^static [^\n]*\b'+name+r'\([^;{]*\)\n\{\n.*?^\}\n',text,re.M|re.S)
    assert m,name
    return m.group()
fragment='#define SUS_KSTAT_MAX 32\n#define KSTAT_PATH_MAX 256\n'
fragment+=text[text.index('struct sus_kstat_entry {'):text.index('/* arm64 asm-generic struct stat offsets')]
for name in ('susfs_kstat_gate_ok','susfs_kstat_table_empty','susfs_kstat_lookup'): fragment+=function(name)
a=text.index('struct kstat_call_counters {');fragment+=text[a:text.index('#define KSTAT_COUNTERS',a)]
a=text.index('struct kstat_call_state {');fragment+=text[a:text.index('/* Rewrite the requested fields',a)]
a=text.index('/* struct compat_stat (the AArch32 stat()/lstat()/fstat() layout');fragment+=text[a:text.index('/* ARM EABI syscall numbers',a)]
fragment+=function('susfs_kstat_spoof_compat_stat')
with tempfile.TemporaryDirectory() as d:
    d=Path(d); (d/'production.h').write_text(fragment)
    subprocess.run(['cc','-std=gnu11','-Wall','-Wextra','-Werror','-Wno-unused-function','-Wno-unused-variable',
        '-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-no-pie',
        '-DPRODUCTION="'+str(d/'production.h')+'"',str(root/'tests/kstat_compat/compat_test.c'),'-o',str(d/'test')],check=True)
    env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
    r=subprocess.run([str(d/'test')],capture_output=True,text=True,env=env,check=True)
    print(r.stdout.strip())
