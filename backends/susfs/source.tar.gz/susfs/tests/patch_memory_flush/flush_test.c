/* SPDX-License-Identifier: GPL-2.0 */
/* Drives ksu_patch_memory_init() + ksu_flush_dcache()/ksu_flush_icache() against a
 * modelled kernel symbol table.  Each case declares which of the four flush spellings
 * the "kernel" exports; the test then checks that init resolves new-first, returns
 * -EOPNOTSUPP only when NO dcache spelling exists, and that each wrapper calls the
 * right underlying helper with the right argument shape ((start,end) for the new
 * dcache / both icache spellings, (addr,size) for the old dcache). */
#include "host_kernel.h"
#include PRODUCTION

/* Which spellings this case's "kernel" exports. */
static int has_dnew, has_dold, has_inew, has_iold;

/* Recorder: the last underlying helper the wrappers dispatched to, and its args. */
static const char *last_fn;
static unsigned long last_a0, last_a1;
static int ncalls;

static void rec(const char *who, unsigned long a0, unsigned long a1)
{
	last_fn = who;
	last_a0 = a0;
	last_a1 = a1;
	ncalls++;
}

/* The modelled kernel helpers (addresses handed back by the resolver). */
static void k_dnew(unsigned long start, unsigned long end) { rec("dnew", start, end); }
static void k_dold(void *addr, size_t size) { rec("dold", (unsigned long)addr, (unsigned long)size); }
static void k_inew(unsigned long start, unsigned long end) { rec("inew", start, end); }
static void k_iold(unsigned long start, unsigned long end) { rec("iold", start, end); }

unsigned long find_kernel_symbol_exact(const char *name)
{
	if (!strcmp(name, "dcache_clean_inval_poc")) return has_dnew ? (unsigned long)&k_dnew : 0;
	if (!strcmp(name, "__flush_dcache_area"))    return has_dold ? (unsigned long)&k_dold : 0;
	if (!strcmp(name, "caches_clean_inval_pou")) return has_inew ? (unsigned long)&k_inew : 0;
	if (!strcmp(name, "__flush_icache_range"))   return has_iold ? (unsigned long)&k_iold : 0;
	return 0;
}

#define START 0x1000UL
#define SZ    0x40UL

int main(int argc, char **argv)
{
	if (argc != 2) { fprintf(stderr, "usage: %s <case>\n", argv[0]); return 2; }
	const char *c = argv[1];

	/* case -> exported spellings */
	if      (!strcmp(c, "both-dcache"))    { has_dnew = 1; has_dold = 1; has_inew = 1; }
	else if (!strcmp(c, "new-preferred"))  { has_dnew = 1; has_dold = 1; }              /* both dcache, new must win */
	else if (!strcmp(c, "old-only"))       { has_dold = 1; has_iold = 1; }              /* vendor keeps old names */
	else if (!strcmp(c, "no-dcache"))      { has_inew = 1; }                            /* neither dcache spelling */
	else if (!strcmp(c, "icache-fallback")){ has_dnew = 1; has_iold = 1; }              /* no caches_clean_inval_pou */
	else if (!strcmp(c, "no-icache"))      { has_dnew = 1; }                            /* dcache ok, no icache at all */
	else { fprintf(stderr, "unknown case %s\n", c); return 2; }

	int init_ret = ksu_patch_memory_init();

	/* dcache dispatch */
	last_fn = "none"; last_a0 = last_a1 = 0; ncalls = 0;
	ksu_flush_dcache(START, SZ);
	const char *d_fn = last_fn; unsigned long d_a0 = last_a0, d_a1 = last_a1; int d_n = ncalls;

	/* icache dispatch */
	last_fn = "none"; last_a0 = last_a1 = 0; ncalls = 0;
	ksu_flush_icache(START, START + SZ);
	const char *i_fn = last_fn; int i_n = ncalls;

	printf("OBS init=%d d_fn=%s d_a0=0x%lx d_a1=0x%lx d_n=%d i_fn=%s i_n=%d\n",
	       init_ret, d_fn, d_a0, d_a1, d_n, i_fn, i_n);
	return 0;
}
