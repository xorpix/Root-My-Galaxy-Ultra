#!/usr/bin/env python3
"""Does patch_memory resolve the cache-flush helper by name, new-first, with a fallback?

5.14 renamed __flush_dcache_area/__flush_icache_range to
dcache_clean_inval_poc/caches_clean_inval_pou, but which spelling a kernel carries is
not decided by its version number - a Samsung vendor kernel can keep the old name, and
a module that baked the new spelling at build time then fails to load there with
"Unknown symbol dcache_clean_inval_poc" (upstream 11e692c / issue #77).

The live fragment (the three helper pointers, ksu_patch_memory_init, and the two
__nocfi flush wrappers) is extracted from kernel/patch_memory.c and compiled against a
modelled kernel symbol table.  Each case declares which spellings the kernel exports;
the test checks that init resolves new-first, returns -EOPNOTSUPP only when NO dcache
spelling exists, and that each wrapper calls the right underlying helper with the right
argument shape (new dcache + both icache: (start,end); old dcache: (addr,size)).

The hardware path in ksu_patch_text_nosync() is not host-testable; a source guard
confirms its refuse-before-store check is present, which the init return above drives.
Real validation of the whole file is the DDK build + CI (upstream validated this exact
change compile-level only, across the eight variants).
"""
import argparse, json, os, subprocess, tempfile
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-dir', type=Path, default=Path(__file__).resolve().parents[2])
parser.add_argument('--json', type=Path)
parser.add_argument('--sanitizers', action='store_true')
args = parser.parse_args()

here = Path(__file__).resolve().parent
source = (args.source_dir / 'kernel/patch_memory.c').read_text()

# live fragment: the pointers, the init, and the two wrappers
b = source.index('static void (*ksu_dcache_new_fn)')
e = source.index('struct patch_text_info {')
fragment = source[b:e].rstrip() + '\n'

# source guards: by-name resolution, no build-time macro left, refuse-before-store present
guard_resolve = 'find_kernel_symbol_exact("dcache_clean_inval_poc")' in source
guard_no_macro = 'KSU_NEW_DCACHE_FLUSH' not in source
guard_refuse = ('(flags & KSU_PATCH_TEXT_FLUSH_DCACHE) && !ksu_dcache_new_fn && !ksu_dcache_old_fn' in source
                and '(flags & KSU_PATCH_TEXT_FLUSH_ICACHE) && !ksu_icache_fn' in source)
guards = {'resolves by name': guard_resolve,
          'no build-time KSU_NEW_DCACHE_FLUSH macro': guard_no_macro,
          'ksu_patch_text_nosync refuses before the store': guard_refuse}

START, SZ = 0x1000, 0x40
# case -> (init_ret, d_fn, d_a0, d_a1, d_n, i_fn, i_n)
EXPECT = {
    'both-dcache':     (0, 'dnew', START, START + SZ, 1, 'inew', 1),
    'new-preferred':   (0, 'dnew', START, START + SZ, 1, 'none', 0),   # new wins over old; no icache exported
    'old-only':        (0, 'dold', START, SZ,         1, 'iold', 1),   # (addr,size) shape, old spelling
    'no-dcache':       (-95, 'none', 0, 0, 0, 'inew', 1),   # -EOPNOTSUPP; no dcache spelling exported
    'icache-fallback': (0, 'dnew', START, START + SZ, 1, 'iold', 1),   # __flush_icache_range fallback
    'no-icache':       (0, 'dnew', START, START + SZ, 1, 'none', 0),   # dcache ok, icache absent -> no-op
}

results, ok = [], True


def obs(exe, case):
    r = subprocess.run([str(exe), case], capture_output=True, text=True, timeout=30)
    if r.returncode:
        return None
    line = next((l for l in r.stdout.splitlines() if l.startswith('OBS ')), None)
    if not line:
        return None
    kv = dict(x.split('=', 1) for x in line.split()[1:])
    return (int(kv['init']), kv['d_fn'], int(kv['d_a0'], 16), int(kv['d_a1'], 16),
            int(kv['d_n']), kv['i_fn'], int(kv['i_n']))


with tempfile.TemporaryDirectory(prefix='susfs-pm-flush-host-') as tmp:
    prod = Path(tmp) / 'fragment.h'
    prod.write_text(fragment)
    flags = (['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-no-pie']
             if args.sanitizers else ['-O2'])
    build = subprocess.run(
        [os.environ.get('CC', 'cc'), '-std=gnu11', '-Wall', '-Wextra', '-Werror'] + flags +
        ['-Wno-unused-function', '-Wno-unused-variable', '-Wno-unused-parameter', '-Wno-sign-compare',
         '-I', str(here), '-DPRODUCTION="' + str(prod) + '"',
         str(here / 'flush_test.c'), '-o', str(Path(tmp) / 'flush')],
        capture_output=True, text=True)
    if build.returncode:
        raise RuntimeError('fragment did not compile: ' + build.stderr)
    exe = Path(tmp) / 'flush'

    for label, good in guards.items():
        print(('PASS ' if good else 'FAIL ') + 'guard: ' + label)
        ok = ok and good

    for case, want in EXPECT.items():
        got = obs(exe, case)
        passed = got == want
        print(('PASS ' if passed else 'FAIL ') + case)
        results.append({'case': case, 'passed': passed, 'expected': want, 'observed': got})
        ok = ok and passed

summary = ('PASS flush helper resolved by name, new-first, with fallback and clean refusal'
           if ok else 'FAIL flush-helper resolution diverges')
print(summary)
if args.json:
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps({'kind': 'patch_memory by-name flush resolution over the live fragment',
                                     'hardware_validated': False,
                                     'guards': guards,
                                     'sanitizers': args.sanitizers,
                                     'results': results,
                                     'summary': summary}, indent=2) + '\n')
raise SystemExit(0 if ok else 1)
