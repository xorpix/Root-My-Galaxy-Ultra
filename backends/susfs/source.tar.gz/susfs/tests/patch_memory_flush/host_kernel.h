/* SPDX-License-Identifier: GPL-2.0 */
/* Host shims for the patch_memory flush-resolution fragment (ksu_patch_memory_init +
 * the two __nocfi flush wrappers).  The fragment resolves the dcache/icache helper by
 * name via find_kernel_symbol_exact() and dispatches to it; this models the resolver
 * and the underlying kernel helpers so the new-first / fallback / refuse logic and the
 * per-spelling call signature can be checked on the host.  The hardware path in
 * ksu_patch_text_nosync() is NOT part of the fragment and is not modelled. */
#include <assert.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define __nocfi
#define noinline __attribute__((noinline))
#define EOPNOTSUPP 95
#define pr_warn(...) ((void)0)

/* Defined in the test: the resolver, controlled per case by which spellings "exist". */
unsigned long find_kernel_symbol_exact(const char *name);
