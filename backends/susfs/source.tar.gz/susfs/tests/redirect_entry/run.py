#!/usr/bin/env python3
"""Does the open_redirect forward wrapper redirect the right opens and hand the rest back?

The forward direction moved to the open syscall entries at 7565d75 (kernel/susfs_or_entry.c).
or_entry_redirect() has to reproduce, per entry kind, exactly which opens the kernel would have
answered with an error - because a call it does NOT redirect still opens the real file, so
answering one the kernel refuses, or redirecting one it would have errored, is a leak or a wrong
result.  None of this is exercised by the rest of the deck (which compiles susfs_open_redirect.c,
not susfs_or_entry.c), and normal on-device use never reaches the adversarial edges.

The live fragment (or_lookup_flags + the fn-pointer slots + or_entry_redirect) is extracted and
compiled against modelled open primitives.  Each case asserts PASS vs redirect vs error, and on a
redirect that filp_open() was asked for the target with O_LARGEFILE set only where the kernel sets
it (native openat/openat2 and compat openat2, not the compat open/openat, not O_PATH), O_CLOEXEC
stripped from the open and applied to the descriptor, the descriptor reserved before the open, and
fd_install after the fsnotify notification (the wrapper tolerates a kernel without fsnotify_open,
and one case pins that the notification is simply skipped there).  All five entry kinds are
redirected, each wrapper forwards its own kind to or_entry_redirect(), and the two symbols the
wrapper was built to tolerate missing (fsnotify_open, check_zeroed_user) cost only what its init()
logs.

Built with -D__aarch64__ (the O_LARGEFILE branch is arm64-only) and -DLOOKUP_CACHED.
"""
import argparse, json, os, subprocess, tempfile
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-dir', type=Path, default=Path(__file__).resolve().parents[2])
parser.add_argument('--json', type=Path)
parser.add_argument('--sanitizers', action='store_true')
args = parser.parse_args()

here = Path(__file__).resolve().parent
source = (args.source_dir / 'kernel/susfs_or_entry.c').read_text()

# live fragment: open_how + flag/resolve macros + or_lookup_flags + the fn-pointer slots + the
# helper wrappers + or_entry_redirect, up to (not including) the five syscall wrappers.
b = source.index('struct susfs_open_how {')
e = source.index('/* The five wrappers.')
fragment = source[b:e].rstrip() + '\n'

# source guards: the two security-relevant properties must be present in the source itself.
guard_trunc = '(unsigned int)regs->regs[2]' in source           # 32-bit flag truncation on the int-flag entries
guard_largefile = ('#ifdef __aarch64__' in source
                   and 'flags |= O_LARGEFILE;' in source)         # O_LARGEFILE added for the native entries
# and the wrapper wiring below the fragment: each of the five entries passes its OWN kind, else a
# compat open could be served the native rules (or the reverse) with the same PASS semantics.
after = source[e:]
kinds = ('OPENAT', 'OPENAT2', 'COMPAT_OPEN', 'COMPAT_OPENAT', 'COMPAT_OPENAT2')
guard_wrappers = all('or_entry_redirect(regs, SUSFS_OR_ENTRY_%s);' % k in after for k in kinds)
guards = {'32-bit flag truncation (no high-bit bypass)': guard_trunc,
          'O_LARGEFILE added on arm64': guard_largefile,
          'each wrapper forwards its own entry kind': guard_wrappers}

# case -> expectation. Fields: cls (PASS|FD|ERR), and for a redirect the recorder expectations.
# A tuple means (cls, ret-or-None, filp, getfd, putfd, install, largefile, cloexec_in_open).
# largefile/cloexec_in_open are -1 when filp_open was not called.
R = 'FD'
EXPECT = {
    # redirecting cases: fd returned, open+install happened, descriptor before open
    'openat-redirect':        ('FD', 7, 1, 1, 0, 1, 1, 0),
    'openat-highbit-flag':    ('FD', 7, 1, 1, 0, 1, 1, 0),   # the (1<<32) bit is truncated: still redirects
    'openat-unknown-flag':    ('FD', 7, 1, 1, 0, 1, 1, 0),   # unknown bit masked on the older entry: still redirects
    'openat-opath':           ('FD', 7, 1, 1, 0, 1, 0, 0),   # O_PATH: no O_LARGEFILE
    'openat-cloexec':         ('FD', 7, 1, 1, 0, 1, 1, 0),   # CLOEXEC not in the open flags
    'openat-redirect-nonotify':('FD', 7, 1, 1, 0, 1, 1, 0),   # fsnotify_open absent: still an fd, no IN_OPEN
    'copen-redirect':         ('FD', 7, 1, 1, 0, 1, 0, 0),   # compat open: no O_LARGEFILE
    'copenat-redirect':       ('FD', 7, 1, 1, 0, 1, 0, 0),   # compat openat: no O_LARGEFILE
    'copenat2-redirect':      ('FD', 7, 1, 1, 0, 1, 1, 0),   # compat openat2: served by the native impl -> O_LARGEFILE
    'openat2-redirect':       ('FD', 7, 1, 1, 0, 1, 1, 0),
    'openat2-largerzeroed':   ('FD', 7, 1, 1, 0, 1, 1, 0),   # larger struct, tail zeroed -> redirect
    # handed back to the kernel (PASS): nothing opened
    'openat-tmpfile':         ('PASS', None, 0, 0, 0, 0, -1, -1),
    'openat-miss':            ('PASS', None, 0, 0, 0, 0, -1, -1),
    'openat-empty-target':    ('PASS', None, 0, 0, 0, 0, -1, -1),
    'openat-lookup-fails':    ('PASS', None, 0, 0, 0, 0, -1, -1),
    'openat-not-ready':       ('PASS', None, 0, 0, 0, 0, -1, -1),
    'openat-not-active':      ('PASS', None, 0, 0, 0, 0, -1, -1),
    'openat2-short':          ('PASS', None, 0, 0, 0, 0, -1, -1),
    'openat2-unknown-resolve':('PASS', None, 0, 0, 0, 0, -1, -1),
    'openat2-beneath-inroot': ('PASS', None, 0, 0, 0, 0, -1, -1),
    'openat2-cached-create':  ('PASS', None, 0, 0, 0, 0, -1, -1),
    'openat2-unknown-flag':   ('PASS', None, 0, 0, 0, 0, -1, -1),
    'openat2-bad-mode':       ('PASS', None, 0, 0, 0, 0, -1, -1),
    'openat2-opath-extraflag':('PASS', None, 0, 0, 0, 0, -1, -1),
    'openat2-largernonzero':  ('PASS', None, 0, 0, 0, 0, -1, -1),
    'openat2-larger-nochecker':('PASS', None, 0, 0, 0, 0, -1, -1),  # larger struct, check_zeroed_user absent
    # kernel errors, propagated: the descriptor is taken first, so an EMFILE opens nothing, and a
    # filp_open failure returns the descriptor it reserved.
    'openat-filp-error':      ('ERR', -13, 1, 1, 1, 0, 1, 0),    # filp_open called (O_LARGEFILE) then failed -> put_unused_fd, no install
    'openat-emfile':          ('ERR', -24, 0, 1, 0, 0, -1, -1),   # get_unused_fd failed -> no filp_open
}

results, ok = [], True


def obs(exe, case):
    r = subprocess.run([str(exe), case], capture_output=True, text=True, timeout=30)
    if r.returncode:
        return None
    line = next((l for l in r.stdout.splitlines() if l.startswith('OBS ')), None)
    if not line:
        return None
    return dict(x.split('=', 1) for x in line.split()[1:])


with tempfile.TemporaryDirectory(prefix='susfs-or-entry-host-') as tmp:
    prod = Path(tmp) / 'fragment.h'
    prod.write_text(fragment)
    flags = (['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-no-pie']
             if args.sanitizers else ['-O2'])
    build = subprocess.run(
        [os.environ.get('CC', 'cc'), '-std=gnu11', '-Wall', '-Wextra', '-Werror',
         '-Wno-unused-function', '-Wno-unused-variable', '-Wno-unused-parameter', '-Wno-sign-compare',
         '-D__aarch64__'] + flags +
        ['-I', str(here), '-DPRODUCTION="' + str(prod) + '"',
         str(here / 'entry_test.c'), '-o', str(Path(tmp) / 'entry')],
        capture_output=True, text=True)
    if build.returncode:
        raise RuntimeError('fragment did not compile: ' + build.stderr)
    exe = Path(tmp) / 'entry'

    for label, good in guards.items():
        print(('PASS ' if good else 'FAIL ') + 'guard: ' + label)
        ok = ok and good

    for case, want in EXPECT.items():
        o = obs(exe, case)
        got = None
        if o:
            ret = int(o['ret'])
            cls = o['cls']
            got = (cls,
                   ret if want[1] is not None else None,
                   int(o['filp']), int(o['getfd']), int(o['putfd']), int(o['install']),
                   int(o['largefile']), int(o['cloexec_in_open']))
            # order invariants must hold on every redirect; the notification is expected on all
            # of them except the missing-fsnotify case, which must skip it silently
            if cls == 'FD':
                bad = []
                if o['order_ok'] != '1':
                    bad.append('FD_ORDER')
                if case == 'openat-redirect-nonotify':
                    if o['fsnotify'] != '0':
                        bad.append('NOTIFY_FIRED')
                elif o['notify_order'] != '1':
                    bad.append('NOTIFY_ORDER')
                got = got + tuple(bad)
        passed = got == want
        print(('PASS ' if passed else 'FAIL ') + case + ('' if passed else f'  want={want} got={got}'))
        results.append({'case': case, 'passed': passed, 'expected': want, 'observed': got})
        ok = ok and passed

summary = ('PASS forward wrapper redirects the right opens, hands the rest back, orders fd/open/install correctly'
           if ok else 'FAIL forward wrapper diverges')
print(summary)
if args.json:
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps({'kind': 'open_redirect forward wrapper (or_entry_redirect) over the live fragment',
                                     'hardware_validated': False,
                                     'guards': guards,
                                     'sanitizers': args.sanitizers,
                                     'results': results,
                                     'summary': summary}, indent=2) + '\n')
raise SystemExit(0 if ok else 1)
