/* SPDX-License-Identifier: GPL-2.0 */
/* Host shims for the open_redirect forward wrapper (or_entry_redirect + or_lookup_flags)
 * extracted from kernel/susfs_or_entry.c.  The wrapper reaches the kernel only through
 * runtime-resolved function pointers and through susfs_open_redirect_match_path(); the test
 * (entry_test.c) supplies all of those, so this header only models the plain types,
 * flag/mode constants and inline helpers the fragment names.
 *
 * Compiled with -D__aarch64__ so the arm64 O_LARGEFILE branch is live, and with
 * -DLOOKUP_CACHED so the resolve->lookup mapping compiles the modern way. */
#include <assert.h>
#include <limits.h>
#include <stdarg.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* From susfs_or_entry.h (the extraction starts after its #include). */
enum susfs_or_entry_kind {
	SUSFS_OR_ENTRY_OPENAT = 0,
	SUSFS_OR_ENTRY_OPENAT2,
	SUSFS_OR_ENTRY_COMPAT_OPEN,
	SUSFS_OR_ENTRY_COMPAT_OPENAT,
	SUSFS_OR_ENTRY_COMPAT_OPENAT2,
	SUSFS_OR_ENTRY_KIND_COUNT,
};
#define SUSFS_OR_ENTRY_PASS LONG_MIN
#define PAGE_SIZE 4096
#define EOPNOTSUPP 95

typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t __u64;
typedef unsigned short umode_t;

#define __user
#define __force
#define __nocfi
#define noinline __attribute__((noinline))
#define module_param_named(a, b, c, d)
#define SUSFS_LOGI(...) ((void)0)
#define pr_warn(...) ((void)0)

typedef _Atomic int atomic_t;
#define ATOMIC_INIT(v) (v)
static inline void atomic_inc(atomic_t *p) { atomic_fetch_add(p, 1); }
static inline int atomic_read(atomic_t *p) { return atomic_load(p); }

/* The pathname width every open_redirect ABI/rule field shares (kernel/susfs.h). */
#define SUSFS_OR_PATH_MAX 256

/* Opaque kernel objects: the fragment only ever holds pointers to these. */
struct file;
struct filename;
struct inode;
struct path { void *mnt; void *dentry; };

/* arm64 pt_regs, as the wrapper reads it: syscall args live in regs[0..5]. */
struct pt_regs { unsigned long long regs[31]; unsigned long long sp; unsigned long long pc; };

/* susfs_fp_hook.h's syscall-entry pointer type; the or_orig_* slots in the fragment are of it
 * (unused by or_entry_redirect itself - only the five wrappers below it call them). */
typedef long (*susfs_syscall_fn_t)(const struct pt_regs *regs);

/* ---- flag / mode / lookup constants (asm-generic values; only the bit relationships matter) ---- */
#define O_RDONLY       00000000
#define O_WRONLY       00000001
#define O_RDWR         00000002
#define O_CREAT        00000100
#define O_EXCL         00000200
#define O_NOCTTY       00000400
#define O_TRUNC        00001000
#define O_APPEND       00002000
#define O_NONBLOCK     00004000
#define O_NDELAY       O_NONBLOCK
#define O_DSYNC        00010000
#define FASYNC         00020000
#define O_DIRECT       00040000
#define O_LARGEFILE    00100000
#define O_DIRECTORY    00200000
#define O_NOFOLLOW     00400000
#define O_NOATIME      01000000
#define O_CLOEXEC      02000000
#define __O_SYNC       04000000
#define O_SYNC         (__O_SYNC | O_DSYNC)
#define O_PATH         010000000
#define __O_TMPFILE    020000000
#define O_TMPFILE      (__O_TMPFILE | O_DIRECTORY)
#define FMODE_NONOTIFY 0x4000000u   /* masked off openat2 flags; distinct from the O_ bits above */

#define S_IALLUGO      0007777
#define AT_FDCWD       -100

#define LOOKUP_FOLLOW        0x0001
#define LOOKUP_DIRECTORY     0x0002
#define LOOKUP_NO_XDEV       0x010000
#define LOOKUP_NO_MAGICLINKS 0x020000
#define LOOKUP_NO_SYMLINKS   0x040000
#define LOOKUP_BENEATH       0x080000
#define LOOKUP_IN_ROOT       0x100000
#define LOOKUP_CACHED        0x200000

/* err.h */
#define MAX_ERRNO 4095
static inline bool IS_ERR(const void *p) { return (unsigned long)p >= (unsigned long)-MAX_ERRNO; }
static inline bool IS_ERR_OR_NULL(const void *p) { return !p || IS_ERR(p); }
static inline long PTR_ERR(const void *p) { return (long)p; }
static inline void *ERR_PTR(long e) { return (void *)e; }

static inline int strscpy(char *out, const char *in, size_t size)
{
	size_t n = strlen(in);
	if (!size)
		return -7;
	if (n >= size) {
		memcpy(out, in, size - 1);
		out[size - 1] = 0;
		return -7;
	}
	memcpy(out, in, n);
	out[n] = 0;
	return (int)n;
}

/* The wrapper copies the open_how in from "user" memory; the test points regs[2] at a real
 * struct, so this is a plain memcpy. */
static inline unsigned long copy_from_user(void *to, const void __user *from, unsigned long n)
{
	memcpy(to, (const void *)from, n);
	return 0;
}

static inline void path_put(const struct path *p) { (void)p; }

/* Supplied by the test. */
bool susfs_open_redirect_active(void);
bool susfs_open_redirect_match_path(const struct path *path, char *buf, size_t buflen);
