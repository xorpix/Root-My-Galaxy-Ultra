/* SPDX-License-Identifier: GPL-2.0 */
/* Drives or_entry_redirect() against modelled open primitives.  Each case sets the syscall
 * registers for one entry kind and asserts the OUTCOME: PASS (fall back to the real syscall),
 * a redirected fd, or a kernel error - plus, on a redirect, that filp_open() was asked for the
 * rule's target with the right flags (O_LARGEFILE present/absent, O_CLOEXEC stripped), that the
 * descriptor was reserved BEFORE the file was opened, and that fd_install happened after the
 * fsnotify notification.
 *
 * The security-relevant checks: a flag in the high 32 bits must NOT bypass the redirect on the
 * 32-bit entries (the (unsigned int) truncation), and every structure/flag edge openat2 would
 * answer with an error must be handed back rather than opened.
 *
 * The edges of the wrapper's own runtime-environment are pinned too: a compat openat2 redirect
 * carries O_LARGEFILE exactly like the native one (the kernel serves it from the native
 * implementation), while the compat open/openat pair does not; and the two symbols the wrapper
 * was built to tolerate missing (fsnotify_open, check_zeroed_user) only cost what the file's
 * own init() logs - an fsnotify-less redirect still hands out the fd, and an open_how this
 * kernel is too small for is handed back when the zero-check helper is missing. */
#include "host_kernel.h"
#include PRODUCTION

/* ---- test-controlled inputs ---- */
static const char *g_match;      /* redirect target match_path returns, or NULL for a miss */
static bool g_active = true;     /* susfs_open_redirect_active() */
static int g_lookup_err;         /* filename_lookup return */
static long g_filp_err;          /* if set, filp_open returns ERR_PTR(this) */
static int g_getfd_ret = 7;      /* get_unused_fd_flags return (a fd, or <0 for an error) */
static int g_zeroed_ret = 1;     /* check_zeroed_user return (>0 = fully zeroed) */
static bool g_null_zeroed_fn;    /* drop the check_zeroed_user symbol */
static bool g_null_fsnotify_fn;  /* drop the fsnotify_open symbol */

/* ---- recorders ---- */
static int g_seq;
static bool g_filp_called;  static int g_filp_flags;  static char g_filp_name[SUSFS_OR_PATH_MAX];  static int g_filp_seq;
static bool g_getfd_called; static unsigned g_getfd_flags; static int g_getfd_seq;
static bool g_putfd_called;
static bool g_install_called; static int g_install_seq;
static bool g_fsnotify_called; static int g_fsnotify_seq;
static bool g_putname_called;

static char g_file_obj, g_filename_obj;   /* stand-ins for a struct file / struct filename */

/* ---- modelled kernel open primitives (addresses handed to the fragment's fn pointers) ---- */
static struct filename *k_getname(const char __user *name, int flags, int *empty)
{ (void)name; (void)flags; (void)empty; return (struct filename *)&g_filename_obj; }

static int k_filename_lookup(int dfd, struct filename *n, unsigned flags, struct path *p, struct path *root)
{ (void)dfd; (void)n; (void)flags; (void)root; if (p) { p->mnt = p->dentry = (void *)1; } return g_lookup_err; }

static void k_putname(struct filename *n) { (void)n; g_putname_called = true; }

static struct file *k_filp_open(const char *name, int flags, umode_t mode)
{
	(void)mode;
	g_filp_called = true; g_filp_flags = flags; g_filp_seq = ++g_seq;
	strscpy(g_filp_name, name, sizeof(g_filp_name));
	if (g_filp_err)
		return (struct file *)ERR_PTR(g_filp_err);
	return (struct file *)&g_file_obj;
}

static int k_get_unused_fd_flags(unsigned flags)
{ g_getfd_called = true; g_getfd_flags = flags; g_getfd_seq = ++g_seq; return g_getfd_ret; }

static void k_fd_install(unsigned int fd, struct file *file) { (void)fd; (void)file; g_install_called = true; g_install_seq = ++g_seq; }
static void k_put_unused_fd(unsigned int fd) { (void)fd; g_putfd_called = true; }
static void k_fsnotify_open(struct file *file) { (void)file; g_fsnotify_called = true; g_fsnotify_seq = ++g_seq; }
static int k_check_zeroed_user(const void __user *from, unsigned long count) { (void)from; (void)count; return g_zeroed_ret; }

/* ---- the two functions the fragment imports from the rest of the module ---- */
bool susfs_open_redirect_active(void) { return g_active; }
bool susfs_open_redirect_match_path(const struct path *path, char *buf, size_t buflen)
{
	(void)path;
	if (!g_match)
		return false;
	return strscpy(buf, g_match, buflen) > 0;
}

static void wire(void)
{
	or_getname_flags_fn = k_getname;
	or_filename_lookup_fn = k_filename_lookup;
	or_putname_fn = k_putname;
	or_filp_open_fn = k_filp_open;
	or_get_unused_fd_flags_fn = k_get_unused_fd_flags;
	or_fd_install_fn = k_fd_install;
	or_put_unused_fd_fn = k_put_unused_fd;
	or_fsnotify_open_fn = g_null_fsnotify_fn ? NULL : k_fsnotify_open;
	or_check_zeroed_user_fn = g_null_zeroed_fn ? NULL : k_check_zeroed_user;
	or_entry_ready = true;
}

/* open_how laid out in "user" memory for the openat2 cases. */
static struct susfs_open_how g_how;

enum { K_OPENAT, K_OPENAT2, K_COMPAT_OPEN, K_COMPAT_OPENAT, K_COMPAT_OPENAT2 };

int main(int argc, char **argv)
{
	if (argc != 2) { fprintf(stderr, "usage: %s <case>\n", argv[0]); return 2; }
	const char *c = argv[1];
	struct pt_regs regs;
	int kind = K_OPENAT;

	memset(&regs, 0, sizeof regs);
	g_match = "/data/redir/target";   /* default: a rule matches */

	/* defaults an openat case uses: dfd, name, flags=O_RDONLY, mode=0 */
#define SET_OPENAT(fl, md)  do { kind = K_OPENAT;  regs.regs[0] = (unsigned long long)(long long)AT_FDCWD; regs.regs[1] = 0x1000; regs.regs[2] = (fl); regs.regs[3] = (md); } while (0)
#define SET_COPEN(fl, md)   do { kind = K_COMPAT_OPEN; regs.regs[0] = 0x1000; regs.regs[1] = (fl); regs.regs[2] = (md); } while (0)
#define SET_COPENAT(fl, md) do { kind = K_COMPAT_OPENAT; regs.regs[0] = (unsigned long long)(long long)AT_FDCWD; regs.regs[1] = 0x1000; regs.regs[2] = (fl); regs.regs[3] = (md); } while (0)
#define SET_OPENAT2(kd, resolve_, flags_, mode_, usize_) do { \
		kind = (kd); g_how.flags = (flags_); g_how.mode = (mode_); g_how.resolve = (resolve_); \
		regs.regs[0] = (unsigned long long)(long long)AT_FDCWD; regs.regs[1] = 0x1000; \
		regs.regs[2] = (unsigned long long)(uintptr_t)&g_how; regs.regs[3] = (usize_); } while (0)

	if (!strcmp(c, "openat-redirect"))            { SET_OPENAT(O_RDONLY, 0); }
	else if (!strcmp(c, "openat-highbit-flag"))   { SET_OPENAT(O_RDONLY | (1ULL << 32), 0); }   /* must still redirect */
	else if (!strcmp(c, "openat-unknown-flag"))   { SET_OPENAT(O_RDONLY | (1U << 28), 0); }      /* unknown bit masked away, still redirect */
	else if (!strcmp(c, "openat-tmpfile"))        { SET_OPENAT(O_RDWR | __O_TMPFILE, 0); }        /* PASS */
	else if (!strcmp(c, "openat-opath"))          { SET_OPENAT(O_PATH, 0); }                      /* redirect, no O_LARGEFILE */
	else if (!strcmp(c, "openat-miss"))           { g_match = NULL; SET_OPENAT(O_RDONLY, 0); }    /* PASS */
	else if (!strcmp(c, "openat-empty-target"))   { g_match = ""; SET_OPENAT(O_RDONLY, 0); }      /* PASS */
	else if (!strcmp(c, "openat-lookup-fails"))   { g_lookup_err = -2; SET_OPENAT(O_RDONLY, 0); } /* PASS */
	else if (!strcmp(c, "openat-filp-error"))     { g_filp_err = -13; SET_OPENAT(O_RDONLY, 0); }  /* -EACCES, put_unused_fd */
	else if (!strcmp(c, "openat-emfile"))         { g_getfd_ret = -24; SET_OPENAT(O_RDONLY, 0); } /* -EMFILE, no filp_open */
	else if (!strcmp(c, "openat-cloexec"))        { SET_OPENAT(O_RDONLY | O_CLOEXEC, 0); }        /* fd gets CLOEXEC, filp_open does not */
	else if (!strcmp(c, "openat-redirect-nonotify")) { g_null_fsnotify_fn = true; SET_OPENAT(O_RDONLY, 0); } /* no fsnotify_open: still an fd, just no IN_OPEN */
	else if (!strcmp(c, "openat-not-ready"))      { SET_OPENAT(O_RDONLY, 0); }                    /* ready cleared below */
	else if (!strcmp(c, "openat-not-active"))     { g_active = false; SET_OPENAT(O_RDONLY, 0); }  /* PASS */
	else if (!strcmp(c, "copen-redirect"))        { SET_COPEN(O_RDONLY, 0); }                     /* redirect, no O_LARGEFILE */
	else if (!strcmp(c, "copenat-redirect"))      { SET_COPENAT(O_RDONLY, 0); }                   /* redirect, no O_LARGEFILE */
	else if (!strcmp(c, "copenat2-redirect"))     { SET_OPENAT2(K_COMPAT_OPENAT2, 0, O_RDONLY, 0, sizeof(g_how)); } /* redirect, O_LARGEFILE: the kernel serves it from the native impl */
	else if (!strcmp(c, "openat2-redirect"))      { SET_OPENAT2(K_OPENAT2, 0, O_RDONLY, 0, sizeof(g_how)); } /* redirect, O_LARGEFILE */
	else if (!strcmp(c, "openat2-short"))         { SET_OPENAT2(K_OPENAT2, 0, O_RDONLY, 0, sizeof(g_how) - 1); } /* PASS */
	else if (!strcmp(c, "openat2-unknown-resolve")){ SET_OPENAT2(K_OPENAT2, 0x40, O_RDONLY, 0, sizeof(g_how)); }  /* PASS */
	else if (!strcmp(c, "openat2-beneath-inroot")) { SET_OPENAT2(K_OPENAT2, SUSFS_RESOLVE_BENEATH | SUSFS_RESOLVE_IN_ROOT, O_RDONLY, 0, sizeof(g_how)); } /* PASS */
	else if (!strcmp(c, "openat2-cached-create"))  { SET_OPENAT2(K_OPENAT2, SUSFS_RESOLVE_CACHED, O_CREAT, 0, sizeof(g_how)); } /* PASS */
	else if (!strcmp(c, "openat2-unknown-flag"))   { SET_OPENAT2(K_OPENAT2, 0, O_RDONLY | (1U << 28), 0, sizeof(g_how)); } /* PASS (openat2 is strict) */
	else if (!strcmp(c, "openat2-bad-mode"))       { SET_OPENAT2(K_OPENAT2, 0, O_CREAT, 0x8000 /* ~S_IALLUGO */, sizeof(g_how)); } /* PASS */
	else if (!strcmp(c, "openat2-opath-extraflag")){ SET_OPENAT2(K_OPENAT2, 0, O_PATH | O_APPEND, 0, sizeof(g_how)); } /* PASS */
	else if (!strcmp(c, "openat2-largerzeroed"))   { SET_OPENAT2(K_OPENAT2, 0, O_RDONLY, 0, sizeof(g_how) + 8); }  /* redirect (tail zeroed) */
	else if (!strcmp(c, "openat2-largernonzero"))  { g_zeroed_ret = 0; SET_OPENAT2(K_OPENAT2, 0, O_RDONLY, 0, sizeof(g_how) + 8); } /* PASS */
	else if (!strcmp(c, "openat2-larger-nochecker")) { g_null_zeroed_fn = true; SET_OPENAT2(K_OPENAT2, 0, O_RDONLY, 0, sizeof(g_how) + 8); } /* PASS: no zero-check helper, no answer */
	else { fprintf(stderr, "unknown case %s\n", c); return 2; }

	wire();
	if (!strcmp(c, "openat-not-ready"))
		or_entry_ready = false;

	long r = or_entry_redirect(&regs, kind);

	/* classify the return */
	const char *cls = (r == SUSFS_OR_ENTRY_PASS) ? "PASS"
			: (r >= 0) ? "FD"
			: "ERR";
	/* for a redirect, was O_LARGEFILE in the filp_open flags? was CLOEXEC stripped? order ok? */
	int largefile = g_filp_called ? ((g_filp_flags & O_LARGEFILE) ? 1 : 0) : -1;
	int cloexec_in_open = g_filp_called ? ((g_filp_flags & O_CLOEXEC) ? 1 : 0) : -1;
	int order_ok = (g_getfd_called && g_filp_called) ? (g_getfd_seq < g_filp_seq) : -1;
	int notify_order = (g_fsnotify_called && g_install_called) ? (g_fsnotify_seq < g_install_seq) : -1;

	printf("OBS cls=%s ret=%ld filp=%d getfd=%d putfd=%d install=%d largefile=%d cloexec_in_open=%d order_ok=%d notify_order=%d fsnotify=%d\n",
	       cls, r, g_filp_called, g_getfd_called, g_putfd_called, g_install_called,
	       largefile, cloexec_in_open, order_ok, notify_order, g_fsnotify_called);
	return 0;
}
