/* SPDX-License-Identifier: GPL-2.0 */
#include "host_kernel.h"
#include PRODUCTION

static struct mount make_mount(struct super_block *sb, struct dentry *root,
                               const char *devname, int id, struct mount *parent)
{
    return (struct mount){ .mnt = { .mnt_root = root, .mnt_sb = sb },
                           .mnt_devname = devname, .mnt_id = id, .mnt_parent = parent };
}

static void identity_case(const char *name)
{
    struct inode data_ino = { 3 }, bind_ino = { 817448 }, other_ino = { 817500 };
    struct dentry data_root = { &data_ino }, bind_root = { &bind_ino }, other_root = { &other_ino };
    struct super_block sb = { 65105 }, other_sb = { 65106 };
    struct mount data = make_mount(&sb, &data_root, "/dev/block/dm-81", 12688, NULL);
    data.mnt_parent = &data;
    struct mount bind = make_mount(&sb, &bind_root, "/dev/block/dm-81", 2000000000, &data);
    struct mount copy = make_mount(&sb, &bind_root, "/dev/block/dm-81", 31368, &data);
    struct mount other = make_mount(&sb, &other_root, "/dev/block/dm-81", 32100, &data);
    sus_mount_ident_add(&bind);
    assert(sus_mount_ident_match(&bind));
    if (!strcmp(name, "bind-parent")) {
        assert(!sus_mount_is_ours(&data));
        assert(sus_mount_is_ours(&copy));
        int shown = sus_mount_shown_id_from(&copy);
        assert(shown == 12688 && !sus_mount_is_ours(&data));
    } else if (!strcmp(name, "namespace-copy")) {
        assert(sus_mount_ident_match(&copy));
        sus_mount_ident_add(&copy);
        assert(n_ident == 1);
    } else if (!strcmp(name, "shared-source")) {
        assert(!sus_mount_ident_match(&other));
        other.mnt_devname = "tmpfs";
        assert(!sus_mount_ident_match(&other));
    } else if (!strcmp(name, "long-source")) {
        char long_a[150], long_b[150];
        memset(long_a, 'a', sizeof(long_a));
        long_a[0] = '/'; long_a[149] = 0;
        memcpy(long_b, long_a, sizeof(long_a)); long_b[100] = 'b';
        bind.mnt_devname = long_a;
        n_ident = 0;
        sus_mount_ident_add(&bind);
        other.mnt_devname = long_b;
        assert(!sus_mount_ident_match(&other));
        copy.mnt_devname = long_a;
        assert(sus_mount_ident_match(&copy));
    } else if (!strcmp(name, "device-inode-isolation")) {
        copy.mnt.mnt_sb = &other_sb;
        assert(!sus_mount_ident_match(&copy));
        assert(!sus_mount_ident_match(&other));
    } else if (!strcmp(name, "null-root")) {
        other.mnt.mnt_root = NULL;
        assert(!sus_mount_ident_match(&other));
        sus_mount_ident_add(&other);
        assert(n_ident == 1);
        other.mnt.mnt_root = &other_root; other_root.d_inode = NULL;
        assert(!sus_mount_ident_match(&other));
    } else if (!strcmp(name, "drop-and-reuse")) {
        sus_mount_ident_drop_dev(sb.s_dev);
        assert(!sus_mount_ident_match(&copy));
        sus_mount_ident_add(&other);
        assert(n_ident == 1 && sus_mount_ident_match(&other));
        assert(!sus_mount_ident_match(&copy));
    } else {
        abort();
    }
}

static void assert_armed(int show_count, int total)
{
    assert(mount_registered && n_show_probes == show_count && host_live == total);
    assert(kr_fdinfo_ok && n_fdinfo_probes > 0);
    for (int i = 0; i < SUS_MOUNT_SHOW_N; i++) {
        if (sus_mount_show_armed[i])
            assert(!(sus_mount_show_probes[i]->flags & KPROBE_FLAG_DISABLED));
    }
    struct kretprobe *named[] = { &kr_statx, &kr_statx_do, &kr_clone_ns, &kr_newmnt };
    for (size_t i = 0; i < sizeof(named) / sizeof(named[0]); i++) {
        if (named[i]->kp.host_registered)
            assert(!(named[i]->kp.flags & KPROBE_FLAG_DISABLED));
    }
    if (kp_sb_down_ok) assert(!(kp_sb_down.flags & KPROBE_FLAG_DISABLED));
    for (int i = 0; i < SUS_MOUNT_FDINFO_MAX; i++) {
        if (kr_fdinfo[i].kp.host_registered)
            assert(!(kr_fdinfo[i].kp.flags & KPROBE_FLAG_DISABLED));
    }
}

static void callback_round(void)
{
    struct inode data_ino = { 3 }, bind_ino = { 818827 };
    struct dentry data_root = { &data_ino }, bind_root = { &bind_ino };
    struct super_block sb = { 65105 };
    struct mount data = make_mount(&sb, &data_root, "/dev/block/dm-81", 1596, NULL);
    data.mnt_parent = &data;
    struct mount bind = make_mount(&sb, &bind_root, "/dev/block/dm-81", 2000000001, &data);
    for (int i = 0; i < SUS_MOUNT_SHOW_N; i++) {
        struct pt_regs regs = { .regs = { [0] = 0x1234, [1] = (unsigned long)&bind.mnt,
                                         [30] = 0x9876 }, .pc = 0x1111 };
        host_su_domain = false;
        int hits = n_ident_hits.value;
        assert(host_fire_kprobe(sus_mount_show_probes[i], &regs) == 1);
        assert(regs.pc == 0x9876 && regs.regs[0] == 0);
        assert(n_ident_hits.value == hits + 1);
        regs.pc = 0x1111; regs.regs[0] = 0x1234;
        host_su_domain = true;
        assert(host_fire_kprobe(sus_mount_show_probes[i], &regs) == 0);
        assert(regs.pc == 0x1111 && regs.regs[0] == 0x1234);
        host_su_domain = false;
        regs.regs[1] = (unsigned long)&data.mnt;
        assert(host_fire_kprobe(sus_mount_show_probes[i], &regs) == 0);
        assert(regs.pc == 0x1111 && regs.regs[0] == 0x1234);
    }
}

static void assert_disarmed(void)
{
    assert(!mount_registered && !n_show_probes && !host_live);
    assert(!kr_fdinfo_ok && !n_fdinfo_probes);
    assert(!kr_statx_ok && !kr_statx_do_ok && !kp_sb_down_ok && !kr_clone_ns_ok && !kr_newmnt_ok);
    assert(!kp_mnt_free_ok && !kr_statfs_ok && !host_allocations && !n_idmap);
    for (int i = 0; i < SUS_MOUNT_SHOW_N; i++) assert(!sus_mount_show_armed[i]);
}

static void lifecycle_case(const char *name)
{
    if (!strcmp(name, "callback-second-enable")) {
        for (int i = 0; i < 3; i++) {
            assert(sus_mount_register() == 0);
            callback_round();
            sus_mount_unregister(); assert_disarmed();
        }
    } else if (!strcmp(name, "fdinfo-second-enable")) {
        for (int i = 0; i < 3; i++) {
            assert(sus_mount_register() == 0);
            assert(n_fdinfo_probes == 4);
            for (int j = 0; j < SUS_MOUNT_FDINFO_MAX; j++) {
                if (kr_fdinfo[j].kp.host_registered)
                    assert(!(kr_fdinfo[j].kp.flags & KPROBE_FLAG_DISABLED));
            }
            sus_mount_unregister(); assert_disarmed();
        }
    } else if (!strcmp(name, "repeat-enable")) {
        for (int i = 0; i < 16; i++) {
            assert(sus_mount_register() == 0);
            assert_armed(3, 14);
            assert(n_fdinfo_probes == 4);
            sus_mount_unregister();
            assert_disarmed();
        }
    } else if (!strcmp(name, "partial-retry")) {
        for (int i = 0; i < SUS_MOUNT_SHOW_N; i++) {
            fail_names[0] = sus_mount_show_names[i];
            assert(sus_mount_register() == -EINVAL);
            assert_disarmed();
            sus_mount_unregister(); assert_disarmed();
            memset(fail_names, 0, sizeof(fail_names));
            assert(sus_mount_register() == 0); assert_armed(3, 14);
            callback_round();
            sus_mount_unregister(); assert_disarmed();
        }
    } else if (!strcmp(name, "failed-registration-retry")) {
        fail_names[0] = "show_vfsstat"; fail_names[1] = "show_mountinfo"; fail_names[2] = "show_vfsmnt";
        assert(sus_mount_register() == -EINVAL);
        assert_disarmed();
        sus_mount_unregister(); assert_disarmed();
        memset(fail_names, 0, sizeof(fail_names));
        assert(sus_mount_register() == 0); assert_armed(3, 14);
    } else if (!strcmp(name, "optional-retry")) {
        fail_names[0] = "__arm64_sys_statx"; fail_names[1] = "do_statx";
        fail_names[2] = "vfs_statfs"; fail_names[3] = "copy_mnt_ns";
        fail_names[4] = "attach_recursive_mnt";
        assert(sus_mount_register() == 0); assert_armed(3, 9);
        assert(!kr_statx_ok && kp_sb_down_ok && !kr_statfs_ok);
        sus_mount_unregister(); assert_disarmed();
        memset(fail_names, 0, sizeof(fail_names));
        assert(sus_mount_register() == 0); assert_armed(3, 14);
    } else if (!strcmp(name, "fdinfo-partial-retry")) {
        fail_addr_index = 1;
        assert(sus_mount_register() == 0); assert_armed(3, 13);
        assert(n_fdinfo_probes == 3);
        sus_mount_unregister(); assert_disarmed();
        fail_addr_index = -1;
        assert(sus_mount_register() == 0); assert_armed(3, 14);
        assert(n_fdinfo_probes == 4);
    } else if (!strcmp(name, "required-hook-retry")) {
        const char *required[] = {"generic_shutdown_super", "cleanup_mnt"};
        for (int i = 0; i < 2; i++) {
            fail_names[0] = required[i];
            assert(sus_mount_register() == -EINVAL); assert_disarmed();
            memset(fail_names, 0, sizeof(fail_names));
            assert(sus_mount_register() == 0); assert_armed(3, 14);
            sus_mount_unregister(); assert_disarmed();
        }
    } else if (!strcmp(name, "idempotent-enable")) {
        assert(sus_mount_register() == 0); assert_armed(3, 14);
        int registered = host_register_calls;
        for (int i = 0; i < 4; i++) assert(sus_mount_register() == 0);
        assert(host_register_calls == registered); assert_armed(3, 14);
    } else {
        abort();
    }
    sus_mount_unregister(); assert_disarmed();
}

static void builtin_case(const char *name)
{
    struct inode ino = { 817448 };
    struct super_block sb = {65105, OVERLAYFS_SUPER_MAGIC};
    struct dentry root = {&ino, "/", &sb};
    struct mount m = make_mount(&sb, &root, "KSU", 3000, NULL);
    if (!strcmp(name, "ksu-default")) {
        assert(sus_mount_is_ours(&m));
        m.mnt_devname = "KSU-extra"; assert(!sus_mount_is_ours(&m));
        m.mnt_devname = "overlay"; assert(!sus_mount_is_ours(&m));
        m.mnt_devname = "KSU"; sb.s_magic = F2FS_SUPER_MAGIC;
        assert(!sus_mount_is_ours(&m));
    } else {
        m.mnt_devname = "/dev/block/dm-81"; sb.s_magic = F2FS_SUPER_MAGIC;
        assert(!sus_mount_is_ours(&m));
        root.host_path = "/adb/modules/Re-Malwack/system/etc/hosts";
        assert(sus_mount_is_ours(&m));
        sb.s_dev++; assert(!sus_mount_is_ours(&m)); sb.s_dev--;
        root.host_path = "/adb_extra/modules/hosts"; assert(!sus_mount_is_ours(&m));
        root.host_path = "/other/adb/modules/hosts"; assert(!sus_mount_is_ours(&m));
        root.host_path = "/adb/modules/hosts"; mount_data_dev_valid = false;
        assert(!sus_mount_is_ours(&m));
    }
}

static void backing_case(const char *name)
{
    struct inode ino[] = {{1}, {2}, {3}, {4}};
    struct super_block data_sb = {65105, F2FS_SUPER_MAGIC};
    struct super_block overlay_sb = {42, OVERLAYFS_SUPER_MAGIC};
    struct super_block stock_sb = {43, EROFS_SUPER_MAGIC};
    struct dentry data_root = {&ino[0], "/", &data_sb};
    struct dentry backing = {&ino[1], "/adb/custom-mount/upper", &data_sb};
    struct dentry stock_root = {&ino[2], "/", &stock_sb};
    struct dentry overlay_root = {&ino[3], "/", &overlay_sb};
    struct mount data = make_mount(&data_sb, &data_root, "/dev/block/dm-81", 100, NULL);
    struct mount stock = make_mount(&stock_sb, &stock_root, "/dev/block/dm-1", 101, &data);
    struct mount overlay = make_mount(&overlay_sb, &overlay_root, "overlay", 102, &stock);
    struct path upper = {&data.mnt, &backing}, lower = {&stock.mnt, &stock_root};
    data.mnt_parent = &data;
    overlay_root.host_upper = &upper;
    overlay_root.host_lower = &lower;
    bool expected = true;

    if (!strcmp(name, "backing-bind")) {
        struct mount bind = make_mount(&data_sb, &backing, "/dev/block/dm-81", 103, &data);
        assert(sus_mount_is_ours(&bind));
        assert(!sus_mount_is_ours(&data));
        backing.host_path = "/"; assert(!sus_mount_is_ours(&bind));
        return;
    } else if (!strcmp(name, "backing-upper")) {
        /* Stock lower + module upper, with an innocuous source string. */
    } else if (!strcmp(name, "backing-lower")) {
        overlay_root.host_upper = NULL;
        overlay_root.host_lower = &upper;
    } else if (!strcmp(name, "backing-other-device")) {
        data_sb.s_dev++;
        expected = false;
    } else if (!strcmp(name, "backing-lookalike")) {
        backing.host_path = "/adb_backup/upper";
        expected = false;
    } else if (!strcmp(name, "backing-missing-helper")) {
        pfn_ovl_path_upper = NULL;
        expected = false;
    } else if (!strcmp(name, "backing-long-path")) {
        static char long_path[512];
        memset(long_path, 'x', sizeof(long_path) - 1);
        memcpy(long_path, "/adb/", 5);
        backing.host_path = long_path;
        expected = false;
    } else if (!strcmp(name, "backing-cycle")) {
        struct path self = {&overlay.mnt, &overlay_root};
        overlay_root.host_upper = NULL;
        overlay_root.host_lower = &self;
        assert(!sus_mount_is_ours(&overlay));
        return;
    } else if (!strcmp(name, "backing-nested")) {
        struct inode nested_ino = {5};
        struct dentry nested_root = {&nested_ino, "/", &overlay_sb, &lower, &upper};
        struct mount nested = make_mount(&overlay_sb, &nested_root, "overlay", 104, &stock);
        struct path nested_path = {&nested.mnt, &nested_root};
        overlay_root.host_upper = NULL;
        overlay_root.host_lower = &nested_path;
        assert(sus_mount_is_ours(&overlay));
        nested_root.host_upper = NULL;
        nested_root.host_lower = &nested_path;
        assert(!sus_mount_is_ours(&overlay));
        return;
    } else if (!strcmp(name, "backing-cross-view")) {
        assert(sus_mount_register() == 0);
        for (int i = 0; i < SUS_MOUNT_SHOW_N; i++) {
            struct pt_regs regs = {.regs = {[0] = 0x1234,
                [1] = (unsigned long)&overlay.mnt, [30] = 0x9876}, .pc = 0x1111};
            assert(host_fire_kprobe(sus_mount_show_probes[i], &regs) == 1);
            assert(regs.pc == 0x9876 && regs.regs[0] == 0);
        }
        assert(sus_mount_shown_for(overlay.mnt_id) == stock.mnt_id);
        struct path path = {&overlay.mnt, &overlay_root};
        struct sus_mount_statfs_state state = {0};
        struct kretprobe_instance ri = {.data = &state};
        struct pt_regs regs = {.regs = {[0] = (unsigned long)&path}};
        assert(sus_mount_statfs_entry(&ri, &regs) == 0);
        assert(state.lower.mnt == &stock.mnt && state.lower.dentry == &stock_root);
        host_su_domain = true;
        regs.regs[0] = (unsigned long)&path;
        assert(sus_mount_statfs_entry(&ri, &regs) == 1);
        assert(regs.regs[0] == (unsigned long)&path);
        sus_mount_unregister(); assert_disarmed();
        return;
    } else {
        abort();
    }
    assert(sus_mount_is_ours(&overlay) == expected);
    assert(!sus_mount_is_ours(&data) && !sus_mount_is_ours(&stock));
    char buf[256], *why = NULL;
    assert(sus_mount_should_record(&overlay, buf, sizeof(buf), &why) == expected);
}

static void path_boundary_case(void)
{
    strcpy(mount_keep[0], "/data/adb");
    n_mount_keep = 1;
    assert(sus_mount_path_is_ours("/data/adb"));
    assert(sus_mount_path_is_ours("/data/adb/modules/x"));
    assert(!sus_mount_path_is_ours("/data/adb_backup/modules/x"));
    assert(!sus_mount_path_is_ours("x/data/adb/modules/x"));
    assert(!sus_mount_path_is_ours(NULL));
    strcpy(mount_keep[0], "/data/adb/");
    assert(sus_mount_path_is_ours("/data/adb"));
    assert(sus_mount_path_is_ours("/data/adb/modules/x"));
    assert(!sus_mount_path_is_ours("/data/adb_backup/modules/x"));
    strcpy(mount_keep[0], "KSU");
    assert(sus_mount_path_is_ours("KSU"));
    assert(sus_mount_path_is_ours("KSU-module"));
}

static void idmap_case(const char *name)
{
    if (!strcmp(name, "idmap-over64")) {
        for (int i = 1; i <= 512; i++) assert(sus_mount_idmap_add(i, 6000+i, 65105));
        for (int i = 1; i <= 512; i++) assert(sus_mount_shown_for(i) == 6000+i);
        assert(n_idmap == 512 && host_allocations == 512 && n_idmap_peak == 512);
        assert(sus_mount_idmap_add(512, 9000, 65106));
        assert(sus_mount_shown_for(512) == 9000 && n_idmap == 512);
    } else if (!strcmp(name, "idmap-recycle")) {
        struct mount m = {.mnt_id = 31368};
        struct pt_regs regs = {.regs = {[0] = (unsigned long)&m}};
        assert(sus_mount_idmap_add(m.mnt_id, 12688, 65105));
        assert(sus_mount_free_pre(&kp_mnt_free, &regs) == 0);
        assert(!sus_mount_shown_for(m.mnt_id) && !n_idmap && n_idmap_freed.value == 1);
        assert(sus_mount_idmap_add(m.mnt_id, 14000, 65106));
        assert(sus_mount_shown_for(m.mnt_id) == 14000);
    } else if (!strcmp(name, "idmap-drop-dev")) {
        for (int i = 1; i <= 160; i++) assert(sus_mount_idmap_add(i, 200+i, i%2+65105));
        sus_mount_idmap_drop_dev(65105);
        assert(n_idmap == 80 && n_idmap_dropped_dev.value == 80);
        for (int i = 1; i <= 160; i++) assert(sus_mount_shown_for(i) == (i%2 ? 200+i : 0));
    } else if (!strcmp(name, "idmap-cap")) {
        for (int i = 1; i <= SUS_MOUNT_IDMAP_MAX; i++) assert(sus_mount_idmap_add(i, 20000+i, 65105));
        assert(!sus_mount_idmap_add(SUS_MOUNT_IDMAP_MAX+1, 40000, 65105));
        assert(n_idmap_full.value == 1 && n_idmap == SUS_MOUNT_IDMAP_MAX);
        host_kmalloc_fail = true;
        assert(sus_mount_idmap_add(1, 50000, 65105));
        assert(sus_mount_shown_for(1) == 50000);
        host_kmalloc_fail = false;
    } else {
        struct inode ino = {3}; struct super_block sb = {65105, OVERLAYFS_SUPER_MAGIC};
        struct dentry root = {&ino, "/", &sb};
        struct mount parent = make_mount(&sb, &root, "/dev/block/dm-81", 100, NULL);
        parent.mnt_parent = &parent;
        struct mount m = make_mount(&sb, &root, "KSU", 3000, &parent);
        struct pt_regs regs = {.regs = {[0] = 17, [1] = (unsigned long)&m.mnt, [30] = 99}, .pc = 88};
        host_kmalloc_fail = true;
        assert(!sus_mount_note_id(&m) && n_idmap_allocfail.value == 1 && !n_idmap);
        assert(sus_mount_show_pre(&kp_mountinfo, &regs) == 0);
        assert(regs.pc == 88 && regs.regs[0] == 17);
        host_kmalloc_fail = false;
        assert(sus_mount_show_pre(&kp_mountinfo, &regs) == 1);
        assert(sus_mount_shown_for(m.mnt_id) == 100);
    }
    sus_mount_idmap_clear();
    assert(!n_idmap && !host_allocations);
}

static void statfs_case(const char *name)
{
    struct inode ino = {1};
    struct super_block sb = {42, OVERLAYFS_SUPER_MAGIC}, low_sb = {43, EROFS_SUPER_MAGIC};
    struct dentry root = {&ino, "/", &sb}, low_root = {&ino, "/", &low_sb};
    struct mount m = make_mount(&sb, &root, "KSU", 3000, NULL);
    struct mount low = make_mount(&low_sb, &low_root, "/dev/block/dm-1", 200, NULL);
    struct path path = {&m.mnt, &root}, lower = {&low.mnt, &low_root};
    struct sus_mount_statfs_state st;
    struct kretprobe_instance ri = {.data = &st};
    struct pt_regs regs = {.regs = {[0] = (unsigned long)&path}};
    struct super_block end_sb = {44, EROFS_SUPER_MAGIC};
    struct dentry end_root = {&ino, "/", &end_sb};
    struct mount end = make_mount(&end_sb, &end_root, "/dev/block/dm-2", 201, NULL);
    struct path end_path = {&end.mnt, &end_root};
    struct path expected = lower;
    root.host_lower = &lower;
    bool route = true;
    if (!strcmp(name, "statfs-root")) { host_su_domain = true; route = false; }
    if (!strcmp(name, "statfs-ordinary-overlay")) { m.mnt_devname = "overlay"; route = false; }
    if (!strcmp(name, "statfs-upper-only")) { root.host_lower = NULL; route = false; }
    if (!strcmp(name, "statfs-writable-lower")) { low_sb.s_magic = F2FS_SUPER_MAGIC; route = false; }
    if (!strcmp(name, "statfs-cycle")) { root.host_lower = &path; route = false; }
    if (!strcmp(name, "statfs-nested")) {
        low_sb.s_magic = OVERLAYFS_SUPER_MAGIC;
        low_root.host_lower = &end_path;
        expected = end_path;
    }
    int result = sus_mount_statfs_entry(&ri, &regs);
    if (route) {
        assert(result == 0 && regs.regs[0] == (unsigned long)&st.lower);
        assert(st.lower.mnt == expected.mnt && st.lower.dentry == expected.dentry);
        assert(n_statfs_routed.value == 1);
        regs.regs[0] = 0; sus_mount_statfs_ret(&ri, &regs); assert(n_statfs_ok.value == 1);
        regs.regs[0] = (unsigned long)-EACCES; sus_mount_statfs_ret(&ri, &regs);
        assert(n_statfs_err.value == 1 && (long)regs.regs[0] == -EACCES);
    } else {
        assert(result == 1 && regs.regs[0] == (unsigned long)&path);
        assert(!n_statfs_routed.value);
    }
}

static void scan_case(void)
{
    struct inode ino = {1}; struct super_block sb = {42, OVERLAYFS_SUPER_MAGIC};
    struct dentry root = {&ino, "/", &sb};
    struct mount parent = make_mount(&sb, &root, "/dev/block/dm-1", 100, NULL);
    parent.mnt_parent = &parent;
    struct mount mounts[70], *ptrs[70];
    struct mnt_namespace ns = {.mounts = ptrs, .count = 70};
    for (int i = 0; i < 70; i++) {
        mounts[i] = make_mount(&sb, &root, "KSU", 1000+i, &parent);
        mounts[i].mnt_ns = &ns; ptrs[i] = &mounts[i];
    }
    char buf[PATH_MAX];
    assert(sus_mount_scan_ns(&ns, buf) == 70);
    assert(n_idmap == 70);
    for (int i = 0; i < 70; i++) {
        assert(mounts[i].mnt_id == 1000+i);
        assert(sus_mount_shown_for(mounts[i].mnt_id) == 100);
    }
    assert(sus_mount_scan_ns(&ns, buf) == 70 && n_idmap == 70);
    sus_mount_idmap_clear(); assert(!host_allocations);
}

int main(int argc, char **argv)
{
    assert(argc == 2);
    const char *name = argv[1];
    strcpy(mount_keep[0], "/data/adb/");
    strcpy(mount_keep[1], "/data/data/com.termux/files/home/fixture/");
    n_mount_keep = 2;
    if (!strcmp(name, "diagnostics-format")) {
        char buf[PAGE_SIZE];
        n_clone_walks.value = 101; n_clone_learned.value = 202;
        n_clone_queued.value = 303; n_clone_dropped.value = 404;
        kr_clone_ns_ok = true;
        sus_mount_stat_show(buf, NULL);
        assert(strstr(buf, "clone: walks=101 learned=202 (probe=1)\n"));
        assert(strstr(buf, "clone_defer: queued=303 dropped=404\n"));
        assert(strstr(buf, "(live/peak limit=8192)"));
    }
    else if (!strncmp(name, "idmap-", 6)) idmap_case(name);
    else if (!strncmp(name, "statfs-", 7)) statfs_case(name);
    else if (!strncmp(name, "backing-", 8)) backing_case(name);
    else if (!strcmp(name, "path-boundaries")) path_boundary_case();
    else if (!strcmp(name, "ksu-default") || !strcmp(name, "module-hosts")) builtin_case(name);
    else if (!strcmp(name, "scan-stable-ids")) scan_case();
    else if (strstr(name, "enable") || strstr(name, "retry")) lifecycle_case(name);
    else identity_case(name);
    printf("PASS %s\n", name);
    return 0;
}
