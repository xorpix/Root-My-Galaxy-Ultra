/* SPDX-License-Identifier: GPL-2.0 */
#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <stddef.h>

typedef struct { int value; } atomic_t;
#define ATOMIC_INIT(n) { .value = (n) }
static void atomic_inc(atomic_t *v) { v->value++; }
static int atomic_inc_return(atomic_t *v) { return ++v->value; }
static int atomic_read(atomic_t *v) { return v->value; }
#define PAGE_SIZE 4096
#define scnprintf snprintf
struct kernel_param { int unused; };
static int n_mount_keep;
static char mount_keep[8][128];
static int mount_keep_lock;
static bool sus_mount_path_is_ours(const char *s);
#define DEFINE_SPINLOCK(name) int name
#define spin_lock_irqsave(lock, flags) ((void)(lock), (flags) = 0)
#define spin_unlock_irqrestore(lock, flags) ((void)(lock), (void)(flags))
#define smp_load_acquire(p) (*(p))
#define smp_store_release(p, v) (*(p) = (v))
#define READ_ONCE(v) (v)
#define WRITE_ONCE(v, n) ((v) = (n))
#define __nocfi
#define IS_ERR_OR_NULL(p) (!(p) || (intptr_t)(p) < 0)
#define ERR_PTR(n) ((void *)(intptr_t)(n))
#define GFP_ATOMIC 1
#define OVERLAYFS_SUPER_MAGIC 0x794c7630UL
#define EROFS_SUPER_MAGIC 0xe0f5e1e2UL
#define F2FS_SUPER_MAGIC 0xf2f52010UL
#define KERNEL_VERSION(a, b, c) (((a) << 16) | ((b) << 8) | (c))
#define LINUX_VERSION_CODE KERNEL_VERSION(6, 12, 0)
static int host_allocations;
static bool host_kmalloc_fail;
static void *kmalloc(size_t n, int flags)
{
    if (host_kmalloc_fail) return NULL;
    void *p = malloc(n);
    if (p) host_allocations++;
    return p;
}
static void kfree(void *p) { if (p) host_allocations--; free(p); }
struct hlist_node { struct hlist_node *next; struct hlist_node **pprev; };
struct hlist_head { struct hlist_node *first; };
#define DEFINE_HASHTABLE(name, bits) struct hlist_head name[1U << (bits)]
#define HASH_SIZE(t) (sizeof(t) / sizeof((t)[0]))
#define host_entry(n, obj, field) ((typeof(obj))((char *)(n) - offsetof(typeof(*(obj)), field)))
#define hash_for_each_possible(t, obj, field, key) \
    for ((obj) = (t)[(unsigned)(key) % HASH_SIZE(t)].first ? \
         host_entry((t)[(unsigned)(key) % HASH_SIZE(t)].first, obj, field) : NULL; \
         (obj); (obj) = (obj)->field.next ? host_entry((obj)->field.next, obj, field) : NULL)
#define hash_for_each_safe(t, bucket, tmp, obj, field) \
    for ((bucket) = 0; (unsigned)(bucket) < HASH_SIZE(t); (bucket)++) \
        for ((obj) = (t)[bucket].first ? host_entry((t)[bucket].first, obj, field) : NULL; \
             (obj) && (((tmp) = (obj)->field.next), 1); \
             (obj) = (tmp) ? host_entry(tmp, obj, field) : NULL)
#define hash_add(t, node, key) host_hash_add(&(t)[(unsigned)(key) % HASH_SIZE(t)], (node))
static void host_hash_add(struct hlist_head *head, struct hlist_node *node)
{
    node->next = head->first;
    node->pprev = &head->first;
    if (node->next) node->next->pprev = &node->next;
    head->first = node;
}
static void hash_del(struct hlist_node *node)
{
    *node->pprev = node->next;
    if (node->next) node->next->pprev = node->pprev;
}
#define module_param_named(...)
#define SUS_MOUNT_KSU_ID_MIN 2000000000U
static void host_log(const char *fmt, ...) { (void)fmt; }
#define pr_warn host_log
#define pr_err host_log
#define SUSFS_LOGI host_log
static ssize_t strscpy(char *dest, const char *src, size_t size)
{
    size_t len = strlen(src);
    if (size) {
        size_t copy = len < size - 1 ? len : size - 1;
        memcpy(dest, src, copy);
        dest[copy] = 0;
    }
    return len < size ? (ssize_t)len : -E2BIG;
}

struct inode { unsigned long i_ino; };
struct path;
struct dentry { struct inode *d_inode; const char *host_path; struct super_block *d_sb;
                struct path *host_lower; struct path *host_upper; };
struct super_block { dev_t s_dev; unsigned long s_magic; };
struct vfsmount { struct dentry *mnt_root; struct super_block *mnt_sb; };
struct path { struct vfsmount *mnt; struct dentry *dentry; };
struct mount {
    struct vfsmount mnt;
    const char *mnt_devname;
    int mnt_id;
    struct mount *mnt_parent;
    struct mnt_namespace *mnt_ns;
};
struct mnt_namespace { struct mount **mounts; size_t count; };
#define SUS_MOUNT_ITER_TYPE struct mount **
#define SUS_MOUNT_ITER_FOR(ns, it) for ((it) = (ns)->mounts; (it) < (ns)->mounts + (ns)->count; (it)++)
#define SUS_MOUNT_ITER_MOUNT(it) (*(it))
#define SUS_MOUNT_MNT_NOT_IN_NS(r, ns) ((r)->mnt_ns != (ns))
#define SUS_MOUNT_MAX_SCAN 65536
#define PATH_MAX 4096
static bool sus_mount_ns_walk_begin(void) { return true; }
static void sus_mount_ns_walk_end(void) {}
static void rcu_read_lock(void) {}
static void rcu_read_unlock(void) {}
static void sus_mount_learn_stop(void) {}
static char *host_dentry_path_raw(const struct dentry *d, char *buf, int n)
{
    if (!d->host_path || strscpy(buf, d->host_path, n) < 0) return ERR_PTR(-ENAMETOOLONG);
    return buf;
}
static char *(*pfn_dentry_path_raw)(const struct dentry *, char *, int) = host_dentry_path_raw;
static char *(*pfn_d_path)(const struct path *, char *, int);
static void host_ovl_path_lower(struct dentry *d, struct path *p)
{
    *p = d->host_lower ? *d->host_lower : (struct path){0};
}
static void (*pfn_ovl_path_lower)(struct dentry *, struct path *) = host_ovl_path_lower;
static void host_ovl_path_upper(struct dentry *d, struct path *p)
{
    *p = d->host_upper ? *d->host_upper : (struct path){0};
}
static void (*pfn_ovl_path_upper)(struct dentry *, struct path *) = host_ovl_path_upper;
static dev_t mount_data_dev = 65105;
static bool mount_data_dev_valid = true;
static atomic_t n_newmnt_pathfail;
static char *sus_mount_d_path(const struct path *p, char *buf, int n)
{
    return host_dentry_path_raw(p->dentry, buf, n);
}
struct pt_regs { unsigned long regs[31]; unsigned long pc; };
struct kprobe;
struct kretprobe_instance { void *data; };
static unsigned long regs_return_value(struct pt_regs *r) { return r->regs[0]; }
struct kprobe {
    void *addr;
    const char *symbol_name;
    int (*pre_handler)(struct kprobe *, struct pt_regs *);
    unsigned int flags;
    bool host_registered;
};
#define KPROBE_FLAG_DISABLED 2U
#define KPROBE_FLAG_ON_FUNC_ENTRY 16U
struct kretprobe {
    struct kprobe kp;
    int (*entry_handler)(struct kretprobe_instance *, struct pt_regs *);
    int (*handler)(struct kretprobe_instance *, struct pt_regs *);
    size_t data_size;
    int maxactive;
    int nmissed;
};
struct sus_mount_clone_state { int unused; };
struct sus_mount_newmnt_state { int unused; };
struct sus_mount_kretprobe_state { int unused; };
static int host_kprobe_handler(struct kprobe *kp, struct pt_regs *regs) { return 0; }
static int host_kretprobe_handler(struct kretprobe_instance *ri, struct pt_regs *regs) { return 0; }
#define sus_mount_sb_down_pre host_kprobe_handler
#define sus_mount_clone_entry host_kretprobe_handler
#define sus_mount_clone_ret host_kretprobe_handler
#define sus_mount_newmnt_entry host_kretprobe_handler
#define sus_mount_newmnt_ret host_kretprobe_handler
#define sus_mount_statx_entry_sys host_kretprobe_handler
#define sus_mount_statx_entry_do host_kretprobe_handler
#define sus_mount_statx_ret host_kretprobe_handler
#define sus_mount_fdinfo_entry host_kretprobe_handler
#define sus_mount_fdinfo_ret host_kretprobe_handler

static const char *fail_names[8];
static int fail_addr_index = -1;
static int host_live, host_register_calls, host_unregister_calls;
static bool host_su_domain;
static int host_id_notes, host_id_drops;
static bool susfs_ptr_plausible(const void *p) { return p != NULL; }
/* vfsmount is the first member of the host mount, matching container_of(). */
static struct mount *real_mount(struct vfsmount *mnt) { return (struct mount *)mnt; }
static bool sus_mount_is_su_domain(void) { return host_su_domain; }
static uintptr_t host_addresses[] = { 0x1000, 0x2000, 0x3000, 0x4000 };
static int register_kprobe(struct kprobe *kp)
{
    host_register_calls++;
    if ((kp->symbol_name && kp->addr) || (!kp->symbol_name && !kp->addr))
        return -EINVAL;
    assert(!kp->host_registered);
    /* Linux keeps only this user flag, then marks the function entry. */
    kp->flags &= KPROBE_FLAG_DISABLED;
    if (kp->symbol_name) {
        /* Like Linux, even a later registration failure can leave the resolved address. */
        kp->addr = (void *)(uintptr_t)0x8000;
        for (size_t i = 0; i < sizeof(fail_names) / sizeof(fail_names[0]); i++)
            if (fail_names[i] && !strcmp(fail_names[i], kp->symbol_name))
                return -EINVAL;
    } else if (fail_addr_index >= 0 &&
               (uintptr_t)kp->addr == host_addresses[fail_addr_index]) {
        return -EINVAL;
    }
    kp->host_registered = true;
    kp->flags |= KPROBE_FLAG_ON_FUNC_ENTRY;
    host_live++;
    return 0;
}
static void unregister_kprobe(struct kprobe *kp)
{
    assert(kp->host_registered);
    assert(kp->addr);
    /* __unregister_kprobe_top() calls __disable_kprobe(), retaining this bit. */
    kp->flags |= KPROBE_FLAG_DISABLED;
    kp->host_registered = false;
    host_live--;
    host_unregister_calls++;
    /* Successful Linux unregister retains both kp.addr and the disabled bit. */
}
static int host_fire_kprobe(struct kprobe *kp, struct pt_regs *regs)
{
    if (!kp->host_registered || (kp->flags & KPROBE_FLAG_DISABLED))
        return 0;
    return kp->pre_handler(kp, regs);
}
static int register_kretprobe(struct kretprobe *kr) { return register_kprobe(&kr->kp); }
static void unregister_kretprobe(struct kretprobe *kr) { unregister_kprobe(&kr->kp); }
static int ksu_find_symbol_all(const char *name, unsigned long *addrs, int cap)
{
    assert(!strcmp(name, "seq_show") && cap >= 4);
    for (int i = 0; i < 4; i++) addrs[i] = host_addresses[i];
    return 4;
}
