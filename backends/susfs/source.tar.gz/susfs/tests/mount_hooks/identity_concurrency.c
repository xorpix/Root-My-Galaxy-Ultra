/* SPDX-License-Identifier: GPL-2.0 */
#include "host_kernel.h"
#include <pthread.h>
#undef DEFINE_SPINLOCK
#undef spin_lock_irqsave
#undef spin_unlock_irqrestore
#define DEFINE_SPINLOCK(n) pthread_mutex_t n=PTHREAD_MUTEX_INITIALIZER
static pthread_mutex_t model=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t changed=PTHREAD_COND_INITIALIZER;
static _Thread_local int role;
static bool reader_locked,writer_waiting,release_reader,writer_done;
static void lock_identity(pthread_mutex_t *p) {
    if(role==2) {
        pthread_mutex_lock(&model);writer_waiting=true;pthread_cond_broadcast(&changed);pthread_mutex_unlock(&model);
    }
    pthread_mutex_lock(p);
    if(role==1) {
        pthread_mutex_lock(&model);reader_locked=true;pthread_cond_broadcast(&changed);
        while(!release_reader)pthread_cond_wait(&changed,&model);
        pthread_mutex_unlock(&model);
    }
}
#define spin_lock_irqsave(p,f) do {(f)=0;lock_identity(p);} while(0)
#define spin_unlock_irqrestore(p,f) do {(void)(f);pthread_mutex_unlock(p);} while(0)
static bool sus_mount_path_is_ours(const char *p) { (void)p;return false; }
#include PRODUCTION
static struct super_block old_sb={.s_dev=1},new_sb={.s_dev=2};
static struct inode old_inode={.i_ino=11},new_inode={.i_ino=99};
static struct dentry old_root={.d_inode=&old_inode},new_root={.d_inode=&new_inode};
static struct mount old_mount={.mnt={.mnt_sb=&old_sb,.mnt_root=&old_root}},
    new_mount={.mnt={.mnt_sb=&new_sb,.mnt_root=&new_root}},
    query={.mnt={.mnt_sb=&new_sb,.mnt_root=&old_root}};
static void *reader(void *p) { (void)p;role=1;assert(!sus_mount_ident_match(&query));return NULL; }
static void *writer(void *p) {
    (void)p;role=2;sus_mount_ident_drop_dev(1);sus_mount_ident_add(&new_mount);
    pthread_mutex_lock(&model);writer_done=true;pthread_cond_broadcast(&changed);pthread_mutex_unlock(&model);return NULL;
}
int main(void) {
    sus_mount_ident_add(&old_mount);assert(!sus_mount_ident_match(&query));
    pthread_t r,w;assert(!pthread_create(&r,NULL,reader,NULL));
    pthread_mutex_lock(&model);while(!reader_locked)pthread_cond_wait(&changed,&model);pthread_mutex_unlock(&model);
    assert(!pthread_create(&w,NULL,writer,NULL));
    pthread_mutex_lock(&model);while(!writer_waiting)pthread_cond_wait(&changed,&model);
    assert(!writer_done);release_reader=true;pthread_cond_broadcast(&changed);pthread_mutex_unlock(&model);
    assert(!pthread_join(r,NULL));assert(!pthread_join(w,NULL));
    assert(!sus_mount_ident_match(&query)&&sus_mount_ident_match(&new_mount));
    puts("PASS identity reader excludes retirement/reuse until its snapshot is complete");return 0;
}
