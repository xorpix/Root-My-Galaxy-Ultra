#!/usr/bin/env python3
"""Run production mount identity and probe lifecycle code with host kernel stubs."""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-dir', type=Path, default=Path(__file__).resolve().parents[2])
parser.add_argument('--sanitizers', action='store_true')
parser.add_argument('--json', type=Path)
args = parser.parse_args()
here = Path(__file__).resolve().parent
source = (args.source_dir / 'kernel/sus_mount.c').read_text()


def function(name, required=True):
    match = re.search(r'^static [^\n]*\b' + re.escape(name) +
                      r'\([^;{]*\)\n\{\n.*?^\}\n', source, re.M | re.S)
    if not match and required:
        raise ValueError('Missing production function: ' + name)
    return match.group() if match else ''


def declaration(kind, name):
    match = re.search(r'^static struct ' + kind + r' ' + name +
                      r' = \{\n.*?^\};\n', source, re.M | re.S)
    if not match:
        raise ValueError('Missing production probe: ' + name)
    return match.group()


start = source.index('#define SUS_MOUNT_IDMAP_BITS')
end = source.index('/* ---- \"is this mount', start)
fragment = source[start:end]
start = source.index('#define SUS_MOUNT_DEVNAME_MAX')
end = source.index('/* generic_shutdown_super(', start)
fragment += source[start:end]
fragment += function('sus_mount_path_is_ours')
fragment += function('sus_mount_data_backing', required=False)
fragment += function('sus_mount_builtin')
fragment += function('sus_mount_is_ours') + function('sus_mount_shown_id_from')
fragment += function('sus_mount_note_id') + function('sus_mount_should_record')
fragment += function('sus_mount_scan_ns')
start = source.index('#define SUS_MOUNT_EROFS_MAGIC')
end = source.index('static int sus_mount_idmap_live(void)', start)
fragment += source[start:end]
fragment += declaration('kprobe', 'kp_sb_down') + 'static bool kp_sb_down_ok;\n'
for name in ('kr_clone_ns', 'kr_newmnt', 'kr_statx', 'kr_statx_do'):
    fragment += declaration('kretprobe', name) + 'static bool ' + name + '_ok;\n'
start = source.index('#define SUS_MOUNT_FDINFO_MAX')
end = source.index('/* ---- statx(2)', start)
fragment += source[start:end]
fragment += function('sus_mount_show_pre')
for name in ('kp_vfsstat', 'kp_mountinfo', 'kp_vfsmnt'):
    fragment += declaration('kprobe', name)
start = source.index('#define SUS_MOUNT_SHOW_N')
end = source.index('/* ---- which mounts count as', start)
fragment += source[start:end]
fragment += 'static int n_show_probes;\nstatic bool mount_registered;\n'
fragment += function('sus_mount_register_named_kprobe', required=False)
fragment += function('sus_mount_register_named_kretprobe', required=False)
fragment += 'static void sus_mount_unregister(void);\n'
fragment += function('sus_mount_register') + function('sus_mount_unregister')
stats = function('sus_mount_stat_show')
for name in set(re.findall(r'atomic_read\(&([a-z_]+)\)', stats)):
    if not re.search(r'\bstatic atomic_t\s+' + name + r'\b', fragment):
        decl = re.search(r'^static atomic_t\s+' + name + r'\s*=\s*ATOMIC_INIT\(0\);', source, re.M)
        if not decl:
            raise ValueError('Missing diagnostic counter: ' + name)
        fragment += decl.group() + '\n'
fragment += function('sus_mount_idmap_live') + function('sus_mount_ident_live') + stats

cases = ['bind-parent', 'namespace-copy', 'shared-source', 'long-source',
         'device-inode-isolation', 'null-root', 'drop-and-reuse',
         'repeat-enable', 'partial-retry', 'failed-registration-retry',
         'optional-retry', 'fdinfo-partial-retry', 'idempotent-enable',
         'callback-second-enable', 'fdinfo-second-enable', 'required-hook-retry',
         'ksu-default', 'module-hosts', 'path-boundaries',
         'backing-bind', 'backing-upper', 'backing-lower', 'backing-nested',
         'backing-other-device', 'backing-lookalike', 'backing-missing-helper',
         'backing-cycle', 'backing-long-path', 'backing-cross-view',
         'idmap-over64', 'idmap-recycle',
         'idmap-drop-dev', 'idmap-allocation-failure', 'idmap-cap',
         'statfs-erofs', 'statfs-root', 'statfs-ordinary-overlay', 'statfs-upper-only',
         'statfs-writable-lower', 'statfs-nested', 'statfs-cycle', 'scan-stable-ids',
         'diagnostics-format']
results = []
with tempfile.TemporaryDirectory(prefix='susfs-mount-host-') as temp:
    temp = Path(temp)
    production = temp / 'production.h'
    production.write_text(fragment)
    exe = temp / 'mount-hooks'
    flags = (['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-no-pie']
             if args.sanitizers else ['-O2'])
    subprocess.run([os.environ.get('CC', 'cc'), '-std=gnu11', '-Wall', '-Wextra', '-Werror',
                    '-Wno-unused-function', '-Wno-unused-parameter', '-Wno-unused-variable',
                    '-Wno-missing-field-initializers',
                    *flags, '-I', str(here),
                    '-DPRODUCTION="' + str(production) + '"', str(here / 'mount_test.c'),
                    '-o', str(exe)], check=True)
    for name in cases:
        env = dict(os.environ)
        if args.sanitizers:
            env.update(ASAN_OPTIONS='detect_leaks=0:abort_on_error=1', UBSAN_OPTIONS='halt_on_error=1')
        run = subprocess.run([str(exe), name], capture_output=True, text=True, env=env, timeout=20)
        results.append({'case': name, 'exit_code': run.returncode,
                        'stdout': run.stdout.strip(), 'stderr': run.stderr.strip()})
        print(run.stdout.strip() or 'FAIL ' + name + ': ' + run.stderr.strip())
    identity = temp / 'identity.h'
    begin = source.index('#define SUS_MOUNT_DEVNAME_MAX')
    end = source.index('/* generic_shutdown_super(', begin)
    identity.write_text(source[begin:end])
    exe = temp / 'identity-concurrency'
    subprocess.run(['cc','-std=gnu11','-Wall','-Wextra','-Werror',
                    '-Wno-unused-function','-Wno-unused-parameter','-Wno-unused-variable',
                    '-pthread',*flags,'-I',str(here),'-DPRODUCTION="'+str(identity)+'"',
                    str(here/'identity_concurrency.c'),'-o',str(exe)],check=True)
    run = subprocess.run([str(exe)],text=True,capture_output=True,env=env,timeout=15)
    results.append(dict(case='identity-concurrency',exit_code=run.returncode,stdout=run.stdout,stderr=run.stderr))
    print(run.stdout.strip() or run.stderr)
if args.json:
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps({'kind': 'production C with host kernel API stubs',
                                    'sanitizers': args.sanitizers, 'hardware_validated': False,
                                    'results': results}, indent=2) + '\n')
raise SystemExit(any(result['exit_code'] for result in results))
