# Mount identity and probe lifecycle regressions

Run `python3 tests/mount_hooks/run.py`, optionally with `--sanitizers` or
`--source-dir /path/to/older/susfs`. The harness extracts the production identity,
ancestor selection, probe declarations, fdinfo registration, and mount
registration/teardown functions and the actual mount-table pre-handler. The
kernel stubs model resolved addresses remaining after successful unregister
and after a later registration failure, plus the disabled flag set by
`__unregister_kprobe_top()` through `__disable_kprobe()` and preserved by
`register_kprobe()`. A registered probe with that bit does not deliver a callback.

The Samsung bind fixture shares `/dev/block/dm-81` with its `/data` parent, but
has a different mount-root inode. These tests require that the parent remain
visible and that a cloned bind still match the recorded device/root identity.
Other cases cover source-name truncation, null roots, different devices,
superblock invalidation, repeated activation, incomplete and failed registration,
optional probe recovery, addressed fdinfo probes, and idempotent enable. The
callback regression verifies actual table skipping, root exclusion and parent
visibility across three activation cycles; every armed probe must be active.

Checkpoint 10's original harness missed the retained disabled bit and checked
registration bookkeeping rather than callback delivery. That expanded harness
had fifteen cases; six failed against checkpoint 10, including callback delivery
and explicitly addressed fdinfo probe reactivation.

This is host regression evidence. It does not execute a kernel module or certify
the Samsung ABI; phone mount listings, fdinfo/statx IDs, and restoration still
need to pass the hardware runner.

The mount-consistency candidate extends the suite to 43 cases. It exercises
rollback and recovery for each missing mount-table hook, anchored path component
boundaries, bind and overlay backing paths, nested/cyclic overlays, absent
helpers, overlong paths, cross-view hiding and EROFS routing. These use extracted
production functions, including the real configurable prefix matcher. Seven
cases fail against the released 1.2.5 source and pass with this change.
