# Priority filter host checks

The runner compiles the entire production priority layer with modeled allocation,
VFS ownership, credentials, native/compat original handlers, callback counts and
RCU reader grace periods. Both compat-enabled and native-only configurations run.
Cases cover transactional replacement/clear, shared UID deduplication, invalid
names and owners, lookup/allocator/copy faults, unterminated payloads, exact UID
and namespace gates, preserved arguments and return values, I/O validation error
ordering, partial installation rollback, sleeping teardown and concurrent writers.

Negative controls remove compat separation, validation, path checks, callback
admission or complete compat coverage. The sanitizer run also reintroduces a
publication-lifetime bug. Each control must be detected. These models do not
establish live kernel behavior or Samsung protected-memory compatibility.
