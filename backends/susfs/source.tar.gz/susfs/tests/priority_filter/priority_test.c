/* Execute the actual priority-filter C with instrumented kernel API models. */
#include <assert.h>
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#define __user
#define __rcu
#define __nocfi
#define noinline __attribute__((noinline))
#define static_assert _Static_assert
#define __same_type(a,b) __builtin_types_compatible_p(a,b)
#define READ_ONCE(v) __atomic_load_n(&(v), __ATOMIC_ACQUIRE)
#define WRITE_ONCE(v,x) __atomic_store_n(&(v),(x),__ATOMIC_RELEASE)
#define ARRAY_SIZE(v) (sizeof(v)/sizeof((v)[0]))
#define BITS_TO_LONGS(n) (((n)+sizeof(long)*8-1)/(sizeof(long)*8))
#define GFP_KERNEL 0
#define PAGE_SIZE 4096
#define __NEW_UTS_LEN 64
#define PRIO_USER 2
#define IOPRIO_WHO_USER 3
#define __NR_getpriority 141
#define __NR_setpriority 140
#define __NR_ioprio_get 31
#define __NR_ioprio_set 30
#define IS_ENABLED(v) (v)
#ifndef CONFIG_ARM64_BTI_KERNEL
#define CONFIG_ARM64_BTI_KERNEL 0
#endif
#define scnprintf snprintf
#define pr_warn(...) ((void)0)
#define cond_resched() sched_yield()
typedef uint32_t u32;
typedef uint64_t u64;
typedef int64_t s64;
typedef struct { unsigned int val; } kuid_t;
static const kuid_t GLOBAL_ROOT_UID = {0};
static _Thread_local unsigned int caller_uid, effective_uid;
static _Thread_local bool root_namespace = true, ksu_umount = true;
static kuid_t current_uid(void) {return (kuid_t){caller_uid};}
static kuid_t current_euid(void) {return (kuid_t){effective_uid};}
static bool uid_eq(kuid_t a,kuid_t b) {return a.val==b.val;}
static int init_user_ns,other_ns;
static void *current_user_ns(void) {return root_namespace?&init_user_ns:&other_ns;}
static unsigned int from_kuid(const void *ns,kuid_t uid) {(void)ns;return uid.val;}
static bool susfs_ksu_umount_gate_off;
static bool root_policy_available=true;
static atomic_uint granted_uid,manager_uid;
bool susfs_ksu_root_available(void) {return root_policy_available;}
bool susfs_ksu_uid_granted_root(uid_t uid) {return uid==atomic_load(&granted_uid)||uid%100000==atomic_load(&manager_uid);}

static bool susfs_ksu_umount_ask(uid_t uid) {(void)uid;return ksu_umount;}
#include GATE

typedef atomic_int atomic_t;
typedef struct {int unused;} wait_queue_head_t;
struct pt_regs {unsigned long regs[31]; unsigned long pc;};
#define atomic_set(p,v) atomic_store(p,v)
#define init_waitqueue_head(p) ((p)->unused=1)
typedef u32 kprobe_opcode_t;
#define KPROBE_FLAG_DISABLED 1
struct kprobe {const char *symbol_name; kprobe_opcode_t *addr; unsigned int flags; int (*pre_handler)(struct kprobe *,struct pt_regs *); void (*post_handler)(struct kprobe *,struct pt_regs *,unsigned long);};
struct kretprobe {struct kprobe kp;};
#include KP
#include FP
#include ABI

static pthread_rwlock_t readers = PTHREAD_RWLOCK_INITIALIZER;
#define rcu_read_lock() assert(!pthread_rwlock_rdlock(&readers))
#define rcu_read_unlock() assert(!pthread_rwlock_unlock(&readers))
#define rcu_dereference(v) READ_ONCE(v)
#define rcu_dereference_protected(v,c) ((void)(c),READ_ONCE(v))
#define rcu_assign_pointer(v,x) WRITE_ONCE(v,x)
static void synchronize_rcu(void) {
    assert(!pthread_rwlock_wrlock(&readers));
    assert(!pthread_rwlock_unlock(&readers));
}
#define DEFINE_MUTEX(n) pthread_mutex_t n=PTHREAD_MUTEX_INITIALIZER
#define mutex_lock(n) assert(!pthread_mutex_lock(n))
#define mutex_unlock(n) assert(!pthread_mutex_unlock(n))
#define lockdep_is_held(n) ((void)(n),1)
static bool test_bit(unsigned int n,const unsigned long *p) {return !!(p[n/(8*sizeof(long))]&(1UL<<(n%(8*sizeof(long)))));}
static bool test_and_set_bit(unsigned int n,unsigned long *p) {bool old=test_bit(n,p);p[n/(8*sizeof(long))]|=1UL<<(n%(8*sizeof(long)));return old;}
static char *strim(char *p) {char *e;while(isspace((unsigned char)*p))p++;e=p+strlen(p);while(e>p&&isspace((unsigned char)e[-1]))*--e=0;return p;}

static atomic_int allocations,lookup_refs;
static _Thread_local int allocation_fail=-1,copy_from_fail,copy_to_fail;
static void *kzalloc(size_t n,int flags) {
    (void)flags;if(allocation_fail==0)return NULL;if(allocation_fail>0)allocation_fail--;
    void *p=calloc(1,n);assert(p);atomic_fetch_add(&allocations,1);return p;
}
#define kvzalloc kzalloc
static void kfree(void *p) {if(p){atomic_fetch_sub(&allocations,1);free(p);}}
#define kvfree kfree
static unsigned long copy_from_user(void *d,const void *s,size_t n) {if(copy_from_fail)return n;memcpy(d,s,n);return 0;}
static unsigned long copy_to_user(void *d,const void *s,size_t n) {if(copy_to_fail)return n;memcpy(d,s,n);return 0;}
struct inode {unsigned int i_mode;kuid_t i_uid;};
struct dentry {struct inode inode;};
struct path {struct dentry *dentry;};
#define LOOKUP_FOLLOW 1
static atomic_int lookup_calls;
static int kern_path(const char *name,int flags,struct path *out) {
    struct dentry *d;
    assert(flags==LOOKUP_FOLLOW);assert(!strncmp(name,"/data/data/",11));
    atomic_fetch_add(&lookup_calls,1);
    if(strstr(name,".missing"))return -ENOENT;
    if(strstr(name,".denied"))return -EACCES;
    d=calloc(1,sizeof(*d));assert(d);d->inode.i_mode=S_IFDIR;
    d->inode.i_uid.val=strstr(name,".second")?10003:10001;
    if(strstr(name,".system"))d->inode.i_uid.val=1000;
    if(strstr(name,".file"))d->inode.i_mode=S_IFREG;
    out->dentry=d;atomic_fetch_add(&lookup_refs,1);return 0;
}
static struct inode *d_backing_inode(struct dentry *d) {return &d->inode;}
static void path_put(struct path *p) {assert(p->dentry);free(p->dentry);atomic_fetch_sub(&lookup_refs,1);p->dentry=NULL;}

static int install_fail=-1,install_calls,install_error=-EIO;
static unsigned long native_table[512],compat_table[512];
static u32 core_entries[4]={0xd503233f,0xd503233f,0xd503233f,0xd503233f};
static bool native_available=true,read_fault,identity_fault;
static int register_fail=-1,register_calls,unregister_calls,drain_calls,change_table_at=-1;
static unsigned int armed_probes,active_table_hooks;
static atomic_int callback_tails;
static atomic_bool pause_tail,tail_entered,release_tail;
static bool compat_available=true,helper_available=true;
unsigned long susfs_fp_syscall_table(void) {return native_available?(unsigned long)native_table:0;}
unsigned long susfs_fp_compat_syscall_table(void) {return compat_available?(unsigned long)compat_table:0;}
static int copy_from_kernel_nofault(void *d,const void *s,size_t n) {if(read_fault)return -EFAULT;memcpy(d,s,n);return 0;}
static int ksu_symbol_is_start(unsigned long address,const char *s) {
 const char *names[]={"__arm64_sys_getpriority","__arm64_sys_setpriority","__arm64_sys_ioprio_get","__arm64_sys_ioprio_set"};
 if(identity_fault)return 0;for(int i=0;i<4;i++)if(!strcmp(s,names[i]))return address==(unsigned long)&core_entries[i];return 0;
}
static int register_kprobe(struct kprobe *p) {
 int i=register_calls++;assert(!active_table_hooks);assert(p->addr&&!p->symbol_name&&!p->flags&&p->pre_handler&&p->post_handler);
 if(i==register_fail){p->flags|=KPROBE_FLAG_DISABLED;return -EBUSY;}
 armed_probes++;if(i==change_table_at)compat_table[96]=native_table[141]=(unsigned long)&core_entries[1];return 0;
}
static void unregister_kprobe(struct kprobe *p) {assert(armed_probes&&p->addr);armed_probes--;unregister_calls++;p->flags|=KPROBE_FLAG_DISABLED;}
static atomic_bool sleep_original,original_entered,release_original,exit_finished;
static _Thread_local struct susfs_fp_hook *expected_hook;
static _Thread_local unsigned int callback_depth;
static _Thread_local int validation_error,validation_calls,original_calls;
static int ioprio_check_cap(int value) {(void)value;validation_calls++;return validation_error;}
static unsigned long find_kernel_symbol_exact(const char *s) {assert(!strcmp(s,"ioprio_check_cap"));return helper_available?(unsigned long)ioprio_check_cap:0;}
static long host_original(const struct pt_regs *r,bool compat) {
    assert(expected_hook&&atomic_load(&expected_hook->active_callbacks)>0);
    original_calls++;
    if(atomic_load(&sleep_original)) {
        atomic_store(&original_entered,true);
        while(!atomic_load(&release_original))sched_yield();
    }
    return compat?202+(long)r->regs[3]:101+(long)r->regs[3];
}
static long native_original(const struct pt_regs *r) {return host_original(r,false);}
static long compat_original(const struct pt_regs *r) {return host_original(r,true);}
int susfs_fp_install(struct susfs_fp_hook *h) {
    int i=install_calls++;atomic_store(&h->active_callbacks,0);init_waitqueue_head(&h->callback_waitq);
    *h->orig_slot=native_original;h->orig=native_original;h->installed=h->native_installed=true;active_table_hooks++;
    if(i==install_fail)return install_error; /* possible publication must roll back */
    if(compat_available){*h->orig_slot_compat=compat_original;h->orig_compat=compat_original;h->compat_installed=true;}
    return 0;
}
void susfs_fp_drain(struct susfs_fp_hook *h) {
 assert(h->callback_waitq.unused);drain_calls++;
 while(atomic_load(&h->active_callbacks)||atomic_load(&callback_tails))sched_yield();
}
void susfs_fp_remove(struct susfs_fp_hook *h) {
    if(!h->installed)return;
    while(atomic_load(&h->active_callbacks))sched_yield();
    h->installed=h->native_installed=h->compat_installed=false;assert(active_table_hooks);active_table_hooks--;
}
void susfs_fp_callback_enter(struct susfs_fp_hook *h) {assert(h==expected_hook&&!callback_depth);callback_depth++;atomic_fetch_add(&h->active_callbacks,1);}
long susfs_fp_callback_return(struct susfs_fp_hook *h,long r) {
 assert(h==expected_hook&&callback_depth==1);callback_depth--;atomic_fetch_add(&callback_tails,1);assert(atomic_fetch_sub(&h->active_callbacks,1)>0);
 if(atomic_load(&pause_tail)){atomic_store(&tail_entered,true);while(!atomic_load(&release_tail))sched_yield();}
 atomic_fetch_sub(&callback_tails,1);return r;
}
struct kernel_param {int unused;};
struct kernel_param_ops {int (*get)(char *,const struct kernel_param *);};
#define module_param_named(name,value,type,mode) static const unsigned int name##_permissions=mode
#define module_param_cb(name,ops,arg,mode) static const unsigned int name##_permissions=mode
#include PRODUCTION

static void as_root(void) {caller_uid=effective_uid=0;root_namespace=ksu_umount=true;}
static void as_app(unsigned int uid) {caller_uid=effective_uid=uid;root_namespace=ksu_umount=true;}
static int apply(const char *text) {
    struct st_susfs_priority_uid_filter *p=calloc(1,sizeof(*p));assert(p);
    assert(strlen(text)<sizeof(p->app_strings));strcpy(p->app_strings,text);p->err=126;
    void *arg=p;susfs_priority_filter_supercall(&arg);int rc=p->err;free(p);return rc;
}
static bool use_probes;
static void reset_tables(void) {
 int n[]={141,140,31,30},c[]={96,97,315,314};for(int i=0;i<4;i++){native_table[n[i]]=compat_table[c[i]]=(unsigned long)&core_entries[i];core_entries[i]=0xd503233f;}
}
static long call(unsigned int op,bool compat,int which,int who,int priority) {
    struct pt_regs r={.regs={(unsigned long)which,(unsigned long)who,(unsigned long)priority,9}};
    struct pt_regs before=r;expected_hook=&prio_hooks[op];
    long out;
    if(prio_probe_mask){
        struct pt_regs outer={.regs={(unsigned long)&r},.pc=(unsigned long)prio_probes[op].addr};
        outer.regs[30]=0x1234;struct pt_regs outer_before=outer;
        int handled=prio_probes[op].pre_handler(&prio_probes[op],&outer);
        assert(handled==0||handled==1);
        if(handled){out=(long)outer.regs[0];outer_before.pc=outer_before.regs[30];outer_before.regs[0]=outer.regs[0];}
        else {out=compat?211:110;original_calls++;prio_probes[op].post_handler(&prio_probes[op],&outer,0);}
        assert(!memcmp(&outer,&outer_before,sizeof(outer)));
    }else out=(compat?prio_hooks[op].compat_wrapper:prio_hooks[op].wrapper)(&r);
    assert(!memcmp(&r,&before,sizeof(r)));assert(!callback_depth);
    return out;
}
static void init_ok(void) {as_root();reset_tables();install_calls=0;register_calls=0;if(use_probes){install_fail=0;install_error=-EFAULT;}assert(!susfs_priority_filter_init());assert(prio_ready);}
static void finish(void) {susfs_priority_filter_exit();assert(!prio_ready&&!prio_count);assert(!atomic_load(&allocations)&&!atomic_load(&lookup_refs));for(int i=0;i<PRIO_OP_COUNT;i++)assert(!prio_hooks[i].installed);assert(!armed_probes&&!prio_probe_mask);}

static void test_configuration(void) {
    init_ok();assert(priority_filter_permissions==0400);
    assert(!apply(" com.hidden,com.shared,com.second,, "));assert(prio_count==2&&prio_generation==1);
    unsigned long generation=prio_generation;
    const char *bad[]={"../com.hidden","com..hidden","com/hidden","com.hidden.","com.1hidden","com.missing","com.denied","com.system","com.file"};
    for(size_t i=0;i<ARRAY_SIZE(bad);i++){assert(apply(bad[i])<0);assert(prio_count==2&&prio_generation==generation);assert(!atomic_load(&lookup_refs));}
    char max_name[NAME_MAX+2];memset(max_name,'a',sizeof(max_name));max_name[NAME_MAX+1]=0;
    assert(apply(max_name)==-EINVAL);max_name[NAME_MAX]=0;assert(!apply(max_name));assert(prio_count==1);
    as_app(10002);int lookups=atomic_load(&lookup_calls);assert(apply("com.second")==-EPERM);assert(atomic_load(&lookup_calls)==lookups);
    as_root();root_namespace=false;assert(apply("com.second")==-EPERM);root_namespace=true;
    assert(!apply(""));assert(!prio_count);finish();
}

static void test_abi_faults(void) {
    init_ok();assert(!apply("com.hidden"));unsigned long generation=prio_generation;
    for(int at=0;at<2;at++){allocation_fail=at;assert(apply("com.second")==-ENOMEM);allocation_fail=-1;assert(prio_count==1&&prio_generation==generation);}
    copy_from_fail=1;assert(apply("com.second")==-EFAULT);copy_from_fail=0;assert(prio_generation==generation);
    struct st_susfs_priority_uid_filter *p=malloc(sizeof(*p));assert(p);memset(p,'a',sizeof(*p));p->err=126;void *arg=p;
    susfs_priority_filter_supercall(&arg);assert(p->err==-EINVAL&&prio_generation==generation);free(p);
    copy_to_fail=1;assert(apply("com.second")==126);copy_to_fail=0;
    assert(prio_generation==generation+1&&prio_count==1); /* commit happened before reply fault */
    assert(!apply(""));finish();
}

static void test_queries(void) {
    init_ok();assert(!apply("com.hidden"));as_app(10002);
    for(unsigned int op=0;op<PRIO_OP_COUNT;op++)for(int compat=0;compat<2;compat++) {
        int cls=op<PRIO_IOGET?PRIO_USER:IOPRIO_WHO_USER;
        validation_error=0;assert(call(op,compat,cls,10001,0)==-ESRCH);
        assert(call(op,compat,cls,10003,0)==(compat?211:110));
        assert(call(op,compat,cls,10002,0)==(compat?211:110));
        assert(call(op,compat,cls,0,0)==(compat?211:110));
        assert(call(op,compat,cls,-10001,0)==(compat?211:110));
        assert(call(op,compat,cls+10,10001,0)==(compat?211:110));
        assert(call(op,compat,cls-1,10001,0)==(compat?211:110));
        assert(call(op,compat,cls,1010001,0)==-ESRCH); /* another Android user, same app ID */
        root_namespace=false;assert(call(op,compat,cls,10001,0)==(compat?211:110));root_namespace=true;
        ksu_umount=false;assert(call(op,compat,cls,10001,0)==(compat?211:110));ksu_umount=true;
        effective_uid=0;assert(call(op,compat,cls,10001,0)==(compat?211:110));as_app(10002);
        susfs_syscall_fn_t *slot=compat?prio_hooks[op].orig_slot_compat:prio_hooks[op].orig_slot;
        if(!prio_probe_mask){susfs_syscall_fn_t saved=*slot;*slot=NULL;assert(call(op,compat,cls,10001,0)==-ENOSYS);*slot=saved;}
    }
    for(unsigned int uid=0;uid<10000;uid+=1000){as_app(uid);assert(call(PRIO_GET,false,PRIO_USER,10001,0)==110);as_app(1000000+uid);assert(call(PRIO_GET,false,PRIO_USER,10001,0)==110);}
    unsigned int app_callers[]={10000,19999,20000,29999,90000,98999,99000,99999};
    for(size_t i=0;i<ARRAY_SIZE(app_callers);i++)for(unsigned int user=0;user<2;user++) {
        as_app(app_callers[i]+user*100000);
        for(unsigned int op=0;op<PRIO_OP_COUNT;op++)for(int compat=0;compat<2;compat++)
            assert(call(op,compat,op<PRIO_IOGET?PRIO_USER:IOPRIO_WHO_USER,10001,0)==-ESRCH);
    }
    as_app(20002);ksu_umount=false;assert(call(PRIO_GET,false,PRIO_USER,10001,0)==110);
    as_app(90002);ksu_umount=false;assert(call(PRIO_GET,false,PRIO_USER,10001,0)==110);
    as_app(1010001);assert(call(PRIO_GET,false,PRIO_USER,10001,0)==110); /* same app across users */
    as_app(99001);ksu_umount=false;assert(call(PRIO_GET,false,PRIO_USER,10001,0)==-ESRCH); /* isolated */
    as_app(10002);ksu_umount=false;susfs_ksu_umount_gate_off=true;
    assert(call(PRIO_GET,false,PRIO_USER,10001,0)==-ESRCH);susfs_ksu_umount_gate_off=false;
    finish();
}

static int automatic(unsigned int enabled,unsigned int appid) {
    struct st_rmgu_susfs_auto_root_apps p={enabled,appid,126};void *arg=&p;
    susfs_priority_auto_supercall(&arg);return p.err;
}
static void test_automatic(void) {
    init_ok();atomic_store(&manager_uid,10004);atomic_store(&granted_uid,10003);
    assert(!automatic(1,10006));assert(prio_enabled&&!prio_count);
    unsigned long generation=prio_generation;assert(!automatic(1,10006));assert(prio_generation==generation);
    as_app(10002);
    for(unsigned int op=0;op<PRIO_OP_COUNT;op++)for(int compat=0;compat<2;compat++) {
        int cls=op<PRIO_IOGET?PRIO_USER:IOPRIO_WHO_USER;
        for(int uid=10003;uid<=10006;uid++)assert(call(op,compat,cls,uid,0)==(uid==10005?(compat?211:110):-ESRCH));
        assert(call(op,compat,cls,10001,0)==(compat?211:110));
    }
    atomic_store(&granted_uid,10007);
    assert(call(PRIO_GET,false,PRIO_USER,10003,0)==110);
    assert(call(PRIO_GET,false,PRIO_USER,10007,0)==-ESRCH);
    atomic_store(&manager_uid,10008);
    assert(call(PRIO_GET,false,PRIO_USER,10004,0)==110);
    assert(call(PRIO_GET,false,PRIO_USER,110008,0)==-ESRCH);
    assert(call(PRIO_GET,false,PRIO_USER,110007,0)==110); /* per-user root grant */
    ksu_umount=false;assert(call(PRIO_GET,false,PRIO_USER,10007,0)==110);ksu_umount=true;
    as_app(10007);assert(call(PRIO_GET,false,PRIO_USER,10007,0)==110);
    assert(automatic(0,0)==-EPERM);as_root();root_namespace=false;assert(automatic(1,10006)==-EPERM);root_namespace=true;
    for(unsigned int bad=0;bad<3;bad++)assert(automatic(bad==0?2:bad==1?1:0,bad==0?10006:bad==1?9999:10000)==-EINVAL);
    allocation_fail=0;assert(automatic(1,10009)==-ENOMEM);allocation_fail=-1;
    copy_from_fail=1;assert(automatic(0,0)==-EFAULT);copy_from_fail=0;
    assert(!apply("com.hidden"));as_app(10002);assert(call(PRIO_GET,false,PRIO_USER,10001,0)==-ESRCH);
    as_root();assert(!apply(""));as_app(10002);assert(call(PRIO_GET,false,PRIO_USER,10001,0)==110);
    assert(call(PRIO_GET,false,PRIO_USER,10007,0)==-ESRCH);
    as_root();root_policy_available=false;assert(automatic(1,10009)==-EOPNOTSUPP);root_policy_available=true;
    assert(!automatic(0,0));assert(!prio_enabled);as_app(10002);assert(call(PRIO_GET,false,PRIO_USER,10007,0)==110);
    finish();as_root();assert(automatic(1,10006)==-ENODEV);assert(!atomic_load(&allocations));
}

static void test_validation(void) {
    init_ok();assert(!apply("com.hidden"));as_app(10002);
    for(int compat=0;compat<2;compat++) {
        validation_error=-EINVAL;assert(call(PRIO_IOSET,compat,IOPRIO_WHO_USER,10001,-1)==-EINVAL);
        validation_error=-EPERM;assert(call(PRIO_IOSET,compat,IOPRIO_WHO_USER,10001,1)==-EPERM);
        validation_error=0;assert(call(PRIO_IOSET,compat,IOPRIO_WHO_USER,10001,0)==-ESRCH);
        assert(call(PRIO_IOGET,compat,IOPRIO_WHO_USER,10001,0)==-ESRCH);
    }
    assert(validation_calls==6);finish();
}

static void test_boot_automatic(void) {
    as_root();prio_boot_auto=true;prio_boot_appid=10006;
    assert(priority_auto_root_permissions==0400&&priority_appid_permissions==0400);
    assert(!susfs_priority_filter_init());assert(prio_ready&&prio_enabled);as_app(10002);
    assert(call(PRIO_GET,false,PRIO_USER,10006,0)==-ESRCH);finish();
    as_root();prio_boot_appid=9999;assert(!susfs_priority_filter_init());assert(prio_ready&&!prio_enabled);finish();
    prio_boot_appid=10006;root_policy_available=false;assert(!susfs_priority_filter_init());assert(prio_ready&&!prio_enabled);finish();
    root_policy_available=true;prio_boot_auto=false;
}

static void test_initialization(void) {
    char report[PAGE_SIZE];
    as_root();helper_available=false;assert(susfs_priority_filter_init()==-EOPNOTSUPP);

    helper_available=true;finish();

    for(int i=0;i<PRIO_OP_COUNT;i++){
        install_fail=i;install_calls=0;assert(susfs_priority_filter_init()==-EIO);finish();

        assert(prio_status_show(report,NULL)>0);
        assert(strstr(report,"ready=0 ")&&!strstr(report,"init_errno="));
        assert(strlen(report)<256);
    }
    install_fail=-1;compat_available=false;install_calls=0;
    int rc=susfs_priority_filter_init();assert(rc==(CONFIG_COMPAT?-EOPNOTSUPP:0));

    finish();compat_available=true;
    for(int i=0;i<20;i++){
        init_ok();
        assert(!apply("com.hidden"));finish();
    }
    assert(apply("com.hidden")==-ENODEV);assert(!atomic_load(&allocations));
}

static void *sleeper(void *arg) {unsigned int op=(uintptr_t)arg;as_app(10002);call(op,false,0,0,0);return NULL;}
static void *exiter(void *arg) {(void)arg;as_root();susfs_priority_filter_exit();atomic_store(&exit_finished,true);return NULL;}
static void test_sleeping_teardown(void) {
    pthread_t worker,exit_thread;init_ok();assert(!apply("com.hidden"));atomic_store(&sleep_original,true);
    pthread_create(&worker,NULL,sleeper,(void *)(uintptr_t)PRIO_GET);
    while(!atomic_load(&original_entered))sched_yield();
    pthread_create(&exit_thread,NULL,exiter,NULL);usleep(20000);assert(!atomic_load(&exit_finished));
    atomic_store(&release_original,true);pthread_join(worker,NULL);pthread_join(exit_thread,NULL);finish();
}

static atomic_bool run_readers;
static void *reader(void *arg) {
    (void)arg;as_app(10002);while(atomic_load(&run_readers)) {
        long r=call(PRIO_GET,false,PRIO_USER,10001,0);assert(r==-ESRCH||r==110);
    }return NULL;
}
static void *writer(void *arg) {
    (void)arg;as_root();for(int i=0;i<1000;i++)assert(!apply(i&1?"com.hidden":"com.second"));return NULL;
}
static void *auto_writer(void *arg) {
    (void)arg;as_root();for(int i=0;i<1000;i++)assert(!automatic(i&1,(i&1)?10006:0));return NULL;
}
static void test_concurrency(void) {
    pthread_t r[2],w[2],a;init_ok();atomic_store(&run_readers,true);
    for(int i=0;i<2;i++){pthread_create(&r[i],NULL,reader,NULL);pthread_create(&w[i],NULL,writer,NULL);}
    pthread_create(&a,NULL,auto_writer,NULL);
    for(int i=0;i<2;i++)pthread_join(w[i],NULL);pthread_join(a,NULL);atomic_store(&run_readers,false);
    for(int i=0;i<2;i++)pthread_join(r[i],NULL);assert(prio_generation>=2000);finish();
}


static void expect_probe_failure(int error,int operation) {
    install_calls=register_calls=0;install_fail=0;install_error=-EFAULT;
    assert(susfs_priority_filter_init()==error);
    assert(!prio_ready&&!prio_probe_mask&&!armed_probes);
    (void)operation;
    assert(!prio_check_cap_fn);for(int i=0;i<4;i++)assert(!prio_hooks[i].installed&&!prio_probes[i].addr&&!(prio_probes[i].flags&KPROBE_FLAG_DISABLED));
    finish();
}
static void test_probe_admission(void) {
    as_root();reset_tables();
    for(int i=0;i<4;i++){register_fail=i;int removed=unregister_calls;int drained=drain_calls;expect_probe_failure(-EBUSY,i);assert(unregister_calls-removed==i&&drain_calls-drained==i);}
    register_fail=-1;use_probes=true;
    for(int i=0;i<4;i++){reset_tables();install_calls=register_calls=0;install_fail=i;install_error=-EFAULT;assert(!susfs_priority_filter_init());assert(prio_probe_mask==15&&!active_table_hooks);finish();}
    native_available=false;expect_probe_failure(-ENOENT,0);native_available=true;
    compat_available=false;
    if(CONFIG_COMPAT)expect_probe_failure(-ENOENT,0);
    compat_available=true;
    identity_fault=true;expect_probe_failure(-EOPNOTSUPP,0);identity_fault=false;
    read_fault=true;expect_probe_failure(-EFAULT,0);read_fault=false;
    for(int i=0;i<4;i++){
        reset_tables();core_entries[i]=0xd503245f;expect_probe_failure(-EOPNOTSUPP,i);
        core_entries[i]=0xd50324df;expect_probe_failure(-EOPNOTSUPP,i);
    }
    reset_tables();
    if(CONFIG_COMPAT){compat_table[315]=native_table[140];expect_probe_failure(-EOPNOTSUPP,2);reset_tables();}
    change_table_at=3;expect_probe_failure(-EOPNOTSUPP,0);change_table_at=-1;
    reset_tables();use_probes=true;
    for(int i=0;i<20;i++){
        int removed=unregister_calls,drained=drain_calls;init_ok();
        char report[PAGE_SIZE];assert(prio_status_show(report,NULL)>0);
        assert(strstr(report,"ready=1 ")&&!strstr(report,"table_errno=")&&strlen(report)<256);
        assert(!apply("com.hidden"));as_app(10002);assert(call(PRIO_GET,false,PRIO_USER,10001,0)==-ESRCH);
        finish();assert(unregister_calls-removed==4&&drain_calls-drained==4);
    }
}
static void *probe_reader(void *arg) {(void)arg;as_app(10002);assert(call(PRIO_GET,false,PRIO_USER,10001,0)==-ESRCH);return NULL;}
static void test_probe_teardown(void) {
    pthread_t worker,exit_thread;use_probes=true;init_ok();assert(!apply("com.hidden"));atomic_store(&pause_tail,true);
    pthread_create(&worker,NULL,probe_reader,NULL);while(!atomic_load(&tail_entered))sched_yield();
    assert(!atomic_load(&prio_hooks[PRIO_GET].active_callbacks));
    pthread_create(&exit_thread,NULL,exiter,NULL);usleep(20000);assert(!atomic_load(&exit_finished));
    atomic_store(&release_tail,true);pthread_join(worker,NULL);pthread_join(exit_thread,NULL);finish();
}
static void test_probe_bti_config(void) {as_root();reset_tables();expect_probe_failure(-EOPNOTSUPP,0);assert(!register_calls);}
int main(int argc,char **argv) {
    assert(argc==2);alarm(30);
    if(!strncmp(argv[1],"probe-",6)&&strcmp(argv[1],"probe-admission")&&strcmp(argv[1],"probe-teardown")&&strcmp(argv[1],"probe-bti-config")){use_probes=true;argv[1]+=6;}
    _Static_assert(sizeof(struct st_susfs_priority_uid_filter)==65540,"priority payload size");
    _Static_assert(offsetof(struct st_susfs_priority_uid_filter,err)==65536,"priority result offset");
    if(!strcmp(argv[1],"probe-admission"))test_probe_admission();
    else if(!strcmp(argv[1],"probe-teardown"))test_probe_teardown();
    else if(!strcmp(argv[1],"probe-bti-config"))test_probe_bti_config();
    else if(!strcmp(argv[1],"configuration"))test_configuration();
    else if(!strcmp(argv[1],"abi-faults"))test_abi_faults();
    else if(!strcmp(argv[1],"queries"))test_queries();
    else if(!strcmp(argv[1],"automatic"))test_automatic();
    else if(!strcmp(argv[1],"boot-automatic"))test_boot_automatic();
    else if(!strcmp(argv[1],"validation"))test_validation();
    else if(!strcmp(argv[1],"initialization"))test_initialization();
    else if(!strcmp(argv[1],"sleeping-teardown"))test_sleeping_teardown();
    else if(!strcmp(argv[1],"concurrency"))test_concurrency();
    else abort();
    puts("PASS priority filter case");return 0;
}
