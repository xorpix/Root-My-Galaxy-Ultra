#!/usr/bin/env python3
"""Run the real priority layer C with ownership, VFS, callback and RCU models."""
import argparse,os,re,subprocess,tempfile
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--sanitizers',action='store_true');a=p.parse_args()
here=Path(__file__).resolve().parent;root=here.parents[1]
def stripped(path):return re.sub(r'^#include[^\n]*\n','',path.read_text(),flags=re.M)
sources={
 'PRODUCTION':stripped(root/'kernel/susfs_priority_filter.c'),
 'ABI':stripped(root/'kernel/susfs_abi.h'),
 'FP':stripped(root/'kernel/susfs_fp_hook.h'),
 'GATE':stripped(root/'kernel/ksu_umount_gate.h'),
 'KP':stripped(root/'kernel/susfs_kprobe.h'),
}
flags=['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-no-pie'] if a.sanitizers else ['-O2']
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
cases=['configuration','abi-faults','queries','automatic','boot-automatic','validation','initialization','sleeping-teardown','concurrency','probe-queries','probe-validation','probe-automatic','probe-concurrency','probe-admission','probe-teardown']
with tempfile.TemporaryDirectory(prefix='susfs-priority-') as d:
 d=Path(d)
 def build(label,production,compat=1,bti=0):
  defines=[]
  for name,text in dict(sources,PRODUCTION=production).items():
   path=d/(label+name+'.h');path.write_text(text);defines.append(f'-D{name}="{path}"')
  exe=d/label
  subprocess.run(['cc','-std=gnu11','-Wall','-Wextra','-Werror','-Wno-unused-function','-Wno-unused-parameter','-Wno-unused-variable','-Wno-sign-compare','-Wno-misleading-indentation','-pthread',*flags,f'-DCONFIG_COMPAT={compat}',f'-DCONFIG_ARM64_BTI_KERNEL={bti}',*defines,str(here/'priority_test.c'),'-o',str(exe)],check=True)
  return exe
 for compat in [1,0]:
  exe=build('production'+str(compat),sources['PRODUCTION'],compat)
  for case in cases:
   r=subprocess.run([str(exe),case],capture_output=True,text=True,env=env,timeout=40)
   if r.returncode:raise RuntimeError(f'compat={compat} {case}:\n{r.stdout}\n{r.stderr}')
   print(f'PASS compat={compat} {case}',flush=True)
 exe=build('bti-config',sources['PRODUCTION'],bti=1)
 subprocess.run([str(exe),'probe-bti-config'],check=True,env=env,timeout=40)
 print('PASS probe CONFIG_ARM64_BTI_KERNEL refusal',flush=True)
 negatives=[
  ('shared-compat-original','READ_ONCE(slot), operation','READ_ONCE(prio_orig_getpriority), operation','queries'),
  ('omit-ioprio-validation','rc = prio_check_cap_fn((int)regs->regs[2]);','rc = 0;','validation'),
  ('skip-package-validation','if (!prio_package_valid(package))','if (false)','configuration'),
  ('omit-callback-entry','susfs_fp_callback_enter(&prio_hooks[operation]);','/* omitted */','queries'),
  ('partial-compat-coverage','IS_ENABLED(CONFIG_COMPAT) && !prio_hooks[i].compat_installed','false','initialization'),
  ('narrow-app-caller-range','if (caller_appid < PRIO_FIRST_APP)','if (!((caller_appid >= PRIO_FIRST_APP && caller_appid <= PRIO_LAST_APP) || susfs_uid_is_isolated(caller)))','queries'),
  ('omit-live-grants','susfs_ksu_uid_granted_root(target)','false','automatic'),
  ('omit-own-app','appid == rules->own_appid','false','automatic'),
  ('probe-compat-proof','if (compat_entry != entry)','if (false)','probe-admission'),
  ('probe-no-post-handler','.post_handler = prio_probe_post','.post_handler = NULL','probe-admission'),
  ('probe-no-tail-drain','susfs_fp_drain(&prio_hooks[i]);','(void)0;','probe-teardown'),
  ('probe-no-core-proof','if (!ksu_symbol_is_start(entry, hook->sym))','if (false)','probe-admission'),
  ('probe-no-bti-proof','if (instruction == 0xd503245fU || instruction == 0xd50324dfU)','if (false)','probe-admission'),
  ('probe-no-unregister','unregister_kprobe(&prio_probes[i]);','(void)0;','probe-admission'),
  ('probe-ioprio-validation','rc = prio_check_cap_fn((int)regs->regs[2]);','rc = 0;','probe-validation'),
 ]
 for label,before,after,case in negatives:
  assert before in sources['PRODUCTION'],label
  exe=build(label,sources['PRODUCTION'].replace(before,after,1))
  r=subprocess.run([str(exe),case],capture_output=True,text=True,env=env,timeout=40)
  if not r.returncode:raise RuntimeError('Negative control was not detected: '+label)
  print('PASS negative/'+label,flush=True)
