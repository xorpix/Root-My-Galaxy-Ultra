#!/usr/bin/env python3
"""Run the real priority layer C with ownership, VFS, callback and RCU models."""
import argparse,os,re,subprocess,tempfile
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--sanitizers',action='store_true');a=p.parse_args()
here=Path(__file__).resolve().parent;root=here.parents[1]
def stripped(path):return re.sub(r'^#include[^\n]*\n','',path.read_text(),flags=re.M)
sources={
 'PRODUCTION':stripped(root/'kernel/susfs_priority_filter.c'),
 'ABI':stripped(root/'kernel/susfs_abi.h'),
 'FP':stripped(root/'kernel/susfs_fp_hook.h'),
 'GATE':stripped(root/'kernel/ksu_umount_gate.h'),
}
flags=['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-no-pie'] if a.sanitizers else ['-O2']
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
cases=['configuration','abi-faults','queries','validation','initialization','sleeping-teardown','concurrency']
with tempfile.TemporaryDirectory(prefix='susfs-priority-') as d:
 d=Path(d)
 def build(label,production,compat=1):
  defines=[]
  for name,text in dict(sources,PRODUCTION=production).items():
   path=d/(label+name+'.h');path.write_text(text);defines.append(f'-D{name}="{path}"')
  exe=d/label
  subprocess.run(['cc','-std=gnu11','-Wall','-Wextra','-Werror','-Wno-unused-function','-Wno-unused-parameter','-Wno-unused-variable','-Wno-sign-compare','-Wno-misleading-indentation','-pthread',*flags,f'-DCONFIG_COMPAT={compat}',*defines,str(here/'priority_test.c'),'-o',str(exe)],check=True)
  return exe
 for compat in [1,0]:
  exe=build('production'+str(compat),sources['PRODUCTION'],compat)
  for case in cases:
   r=subprocess.run([str(exe),case],capture_output=True,text=True,env=env,timeout=40)
   if r.returncode:raise RuntimeError(f'compat={compat} {case}:\n{r.stdout}\n{r.stderr}')
   print(f'PASS compat={compat} {case}',flush=True)
 negatives=[
  ('shared-compat-original','READ_ONCE(slot), operation','READ_ONCE(prio_orig_getpriority), operation','queries'),
  ('omit-ioprio-validation','rc = prio_check_cap_fn((int)regs->regs[2]);','rc = 0;','validation'),
  ('skip-package-validation','if (!prio_package_valid(package))','if (false)','configuration'),
  ('omit-callback-entry','susfs_fp_callback_enter(&prio_hooks[operation]);','/* omitted */','queries'),
  ('partial-compat-coverage','IS_ENABLED(CONFIG_COMPAT) && !prio_hooks[i].compat_installed','false','initialization'),
  ('publication-uaf','if (next->count)\n        next = NULL;\n    mutex_unlock(&prio_config_lock);','mutex_unlock(&prio_config_lock);\n    sched_yield();\n    if (next->count)\n        next = NULL;','concurrency'),
 ]
 for label,before,after,case in negatives:
  if label=='publication-uaf' and not a.sanitizers:continue
  assert before in sources['PRODUCTION'],label
  exe=build(label,sources['PRODUCTION'].replace(before,after,1))
  r=subprocess.run([str(exe),case],capture_output=True,text=True,env=env,timeout=40)
  if not r.returncode:raise RuntimeError('Negative control was not detected: '+label)
  print('PASS negative/'+label,flush=True)
