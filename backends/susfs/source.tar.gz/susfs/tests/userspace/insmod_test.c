#define SUSFS_INSMOD_HOSTTEST
#include "../../tools/susfs_insmod.c"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static int allocation_fails;
static int restore_writes, restore_failure;
sysarg sys6(sysarg n, sysarg a, sysarg b, sysarg c, sysarg d, sysarg e, sysarg f)
{
    (void)c; (void)d; (void)e; (void)f;
    if (n == SYS_mmap) return allocation_fails ? -12 : (sysarg)calloc(1, b);
    if (n == SYS_munmap) { free((void *)a); return 0; }
    if (n == SYS_openat && !strcmp((char *)b, "/proc/sys/kernel/kptr_restrict")) return 91;
    if (n == SYS_close) return 0;
    if (n == SYS_write && a == 91) {
        if (restore_failure) return -13;
        assert(c == 2 && !memcmp((char *)b, "1\n", 2));
        restore_writes++;
        return c;
    }
    if (n == SYS_write) return c;
    if (n == SYS_exit) exit((int)a);
    return -38;
}
static char *fixture(void)
{
    char *image = calloc(1, 1024);
    struct elf64_ehdr *eh = (void *)image;
    struct elf64_shdr *sh;
    static const char info[] = "license=GPL\0vermagic=6.12 SMP modversions aarch64\0name=susfs_guard_lkm\0";
    eh->e_shnum = 4; eh->e_shoff = 64;
    sh = (void *)(image + 64);
    sh[1].sh_type = SHT_PROGBITS; sh[1].sh_offset = 320; sh[1].sh_size = sizeof(info);
    sh[2].sh_type = SHT_SYMTAB; sh[2].sh_offset = 512; sh[2].sh_size = sizeof(struct elf64_sym);
    memcpy(image + 320, info, sizeof(info));
    struct elf64_sym *sym = (void *)(image + 512);
    sym->st_shndx = 1;
    /* Point at name=, beyond the value that grows. */
    sym->st_value = sizeof(info) - sizeof("name=susfs_guard_lkm") - 1;
    memcpy(image + 800, "unchanged code section", 22);
    return image;
}
static void replacement(const char *required)
{
    char *image = fixture(), saved[1024], *value = 0;
    sysarg size = 1024; u64 len = 0;
    memcpy(saved, image, sizeof(saved));
    assert(replace_vermagic(&image, &size, 1, required, strlen(required)) == 0);
    struct elf64_shdr *sh = (void *)(image + 64);
    assert(size > 1024 && sh[1].sh_offset >= 1024);
    assert(modinfo_lookup(image + sh[1].sh_offset, sh[1].sh_size, "vermagic", &value, &len) == 0);
    assert(len == strlen(required) && memcmp(value, required, len) == 0);
    assert(modinfo_lookup(image + sh[1].sh_offset, sh[1].sh_size, "license", &value, &len) == 0);
    assert(len == 3 && !memcmp(value, "GPL", 3));
    assert(modinfo_lookup(image + sh[1].sh_offset, sh[1].sh_size, "name", &value, &len) == 0);
    assert(len == 15 && !memcmp(value, "susfs_guard_lkm", 15));
    assert(!memcmp(image + 800, saved + 800, 22));
    struct elf64_sym *sym = (void *)(image + 512);
    assert(!memcmp(image + sh[1].sh_offset + sym->st_value, "name=", 5));
    free(image);
}
int main(void)
{
    replacement("6.12.69-android16-6-pb4d3caf-abogkiS948BXXS4BZIG-4k SMP preempt mod_unload modversions aarch64");
    replacement("short");
    char *image = fixture(), *original = image; sysarg size = 1024;
    struct elf64_shdr *sh = (void *)(image + 64);
    sh[3].sh_type = 4; sh[3].sh_info = 1;
    assert(replace_vermagic(&image, &size, 1, "full magic", 10) == -8 && image == original);
    sh[3].sh_type = 0;
    allocation_fails = 1;
    assert(replace_vermagic(&image, &size, 1, "full magic", 10) == -12 && image == original);
    assert(replace_vermagic(&image, &size, 9, "x", 1) == -8);
    free(image);
    char broken[] = "vermagic=unterminated"; char *value; u64 len;
    assert(modinfo_lookup(broken, sizeof(broken) - 1, "vermagic", &value, &len) == -1);
    kptr_saved = 1; memcpy(kptr_orig, "1\n", 2); kptr_orig_len = 2;
    restore_failure = 1;
    assert(kptr_restore() == -13 && kptr_saved);
    restore_failure = 0;
    assert(kptr_restore() == 0 && !kptr_saved && restore_writes == 1);
    assert(kptr_restore() == 0 && restore_writes == 1);
    struct elf64_sym symbol = { .st_shndx = SHN_UNDEF };
    undefs[0] = (struct undef){ .name = "example", .len = 7, .sym = &symbol };
    nundef = 1;
    const char *module = "ffff000000004000 T example [kernelsu]";
    ks_record(module, strlen(module), NULL, NULL);
    assert(!undefs[0].resolved && symbol.st_shndx == SHN_UNDEF && ks_module == 1);
    const char *kernel = "ffff000000008000 T example";
    ks_record(kernel, strlen(kernel), NULL, NULL);
    assert(undefs[0].resolved && symbol.st_value == 0xffff000000008000ULL);
    ks_record(module, strlen(module), NULL, NULL);
    assert(symbol.st_value == 0xffff000000008000ULL && ks_module == 2);
    const char *tabbed = "ffff000000004000 T example\t[kernelsu]";
    ks_record(tabbed, strlen(tabbed), NULL, NULL);
    assert(symbol.st_value == 0xffff000000008000ULL && ks_module == 3);
    puts("PASS: kernel-only symbols, long/short magic, metadata, sections, symbols, refusal paths, kptr restoration/retry");
    return 0;
}
