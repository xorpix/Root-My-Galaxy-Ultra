#define SUSFS_STATUS_HOSTTEST
#include "../../tools/rmgu_susfs_status.c"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static int mode;
sysarg status_sys4(sysarg n, sysarg a, sysarg b, sysarg c, sysarg d)
{
    if (n == 64) return fwrite((void *)b, 1, c, stdout);
    assert(n == 142 && (unsigned long)a == MAGIC1 && (unsigned long)b == MAGIC2);
    if (mode == 1) return -22;
    if (mode == 2) return 0; /* kernel never wrote the sentinel */
    if (c == 0x555e2) {
        struct features_reply *r = (void *)d;
        strcpy(r->value, "CONFIG_KSU_SUSFS_SUS_PATH\nCONFIG_KSU_SUSFS_SUS_MAP\n"); r->err = mode == 3 ? -12 : 0;
        if (mode == 4) memset(r->value, 'A', sizeof(r->value));
    } else {
        struct short_reply *r = (void *)d;
        strcpy(r->value, c == 0x555e1 ? "v2.3.0" : "GKI"); r->err = 0;
        if (mode == 5) strcpy(r->value, "GKI\"\\\n");
    }
    return 0;
}
int main(int argc, char **argv)
{
    assert(argc == 2); mode = atoi(argv[1]);
    int rc = status_main();
    assert(rc == ((mode == 0 || mode == 5) ? 0 : 1));
    return 0;
}
