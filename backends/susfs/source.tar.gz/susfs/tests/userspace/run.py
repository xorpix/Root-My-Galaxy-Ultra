#!/usr/bin/env python3
"""Exercise actual freestanding loader/status code through host syscall shims."""
import json
from pathlib import Path
import subprocess
import tempfile
import argparse
import os
parser = argparse.ArgumentParser()
parser.add_argument('--sanitizers', action='store_true')
args = parser.parse_args()
root = Path(__file__).resolve().parent
flags = ['-std=c11', '-Wall', '-Wextra', '-Werror', '-O1' if args.sanitizers else '-O2']
if args.sanitizers:
    flags += ['-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-fno-pie', '-no-pie']
results = []
env = dict(os.environ)
if args.sanitizers:
    # The workspace hides /proc/PID/task from LeakSanitizer. ASan/UBSan still run.
    env.update(ASAN_OPTIONS='detect_leaks=0:abort_on_error=1', UBSAN_OPTIONS='halt_on_error=1')
with tempfile.TemporaryDirectory() as d:
    for tool in ('insmod', 'status'):
        exe = Path(d) / tool
        subprocess.run(['cc', *flags, str(root / f'{tool}_test.c'), '-o', str(exe)], check=True)
        if tool == 'insmod':
            r = subprocess.run([str(exe)], check=True, text=True, capture_output=True, env=env)
            results.append({'case': 'vermagic-preservation', 'result': 'PASS', 'detail': r.stdout.strip()})
        else:
            cases = ['live', 'syscall-refusal', 'unchanged-sentinel', 'feature-error', 'unterminated', 'json-escaping']
            for i, case in enumerate(cases):
                r = subprocess.run([str(exe), str(i)], check=True, text=True, capture_output=True, env=env)
                report = json.loads(r.stdout)
                assert report['schema'] == 1 and report['available'] == (i in (0, 5))
                if i == 5: assert report['variant'] == 'GKI"\\\n'
                if i == 4: assert not report['queries']['features']['terminated']
                results.append({'case': case, 'result': 'PASS'})
print(json.dumps({'sanitizers': args.sanitizers, 'results': results}, indent=2))
