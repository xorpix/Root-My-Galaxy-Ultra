#!/usr/bin/env python3
"""Compile the actual policy bridge against module/reference/RCU models."""
import argparse,os,re,subprocess,tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--sanitizers',action='store_true');a=p.parse_args()
here=Path(__file__).resolve().parent;root=here.parents[1]
strip=lambda p:re.sub(r'^#include[^\n]*\n','',p.read_text(),flags=re.M)
source=strip(root/'kernel/ksu_umount_gate.c');gate=strip(root/'kernel/ksu_umount_gate.h')
flags=['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-no-pie'] if a.sanitizers else ['-O2']
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
with tempfile.TemporaryDirectory(prefix='ksu-policy-') as folder:
 folder=Path(folder);(folder/'gate.h').write_text(gate)
 def build(label,text):
  src=folder/(label+'.h');src.write_text(text);exe=folder/label
  subprocess.run(['cc','-std=gnu11','-Wall','-Wextra','-Werror','-Wno-unused-function','-Wno-unused-variable',*flags,'-DGATE="'+str(folder/'gate.h')+'"','-DPRODUCTION="'+str(src)+'"',str(here/'policy_test.c'),'-o',str(exe)],check=True)
  return exe
 exe=build('production',source)
 for case in ['module','builtin','missing-umount','missing-root','missing-lookup','going','foreign-root','unowned']:
  r=subprocess.run([str(exe),case],capture_output=True,text=True,env=env,timeout=10)
  if r.returncode:raise RuntimeError(case+'\n'+r.stdout+r.stderr)
  print('PASS '+case,flush=True)
 for label,before,after,case in [
  ('omit-owner-ref','if (!try_module_get(owner))','if (false)','module'),
  ('omit-preempt-guard','preempt_disable();','/* omitted */','module'),
  ('foreign-owner','policy_module_address(granted) == owner','true','foreign-root'),
  ('omit-return-drain','synchronize_rcu_tasks();','((void)0);','module'),
  ('unproven-core','umount != core_umount','false','unowned')]:
  assert before in source;exe=build(label,source.replace(before,after,1))
  r=subprocess.run([str(exe),case],capture_output=True,text=True,env=env,timeout=10)
  assert r.returncode,'Negative control not detected: '+label
  print('PASS negative/'+label,flush=True)
