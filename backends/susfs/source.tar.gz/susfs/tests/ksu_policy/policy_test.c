#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#define __nocfi
#define noinline __attribute__((noinline))
#define static_assert _Static_assert
#define __same_type(a,b) __builtin_types_compatible_p(a,b)
#define READ_ONCE(v) (v)
#define WRITE_ONCE(v,x) ((v)=(x))
#define pr_warn(...) ((void)0)
struct module {int refs;bool going;};
static struct module backend,foreign;
static int preempt_depth,graces;
static bool missing_umount,missing_root,missing_lookup,builtin,foreign_root,unowned;
typedef struct {unsigned int val;} kuid_t;
static kuid_t current_uid(void) {return (kuid_t){10002};}
static bool host_umount(uid_t uid) {return uid!=10003;}
static bool host_root(uid_t uid) {return uid==10003;}
static struct module *__module_address(unsigned long addr) {
    assert(preempt_depth==1);
    assert(addr==(unsigned long)host_umount||addr==(unsigned long)host_root);
    return builtin||unowned?NULL:(foreign_root&&addr==(unsigned long)host_root?&foreign:&backend);
}
static unsigned long find_kernel_symbol_exact(const char *name) {
    assert(!preempt_depth);
    if(!strcmp(name,"__module_address"))return missing_lookup?0:(unsigned long)__module_address;
    if(!strcmp(name,"ksu_uid_should_umount"))return builtin&&!missing_umount?(unsigned long)host_umount:0;
    assert(!strcmp(name,"ksu_is_uid_granted_root"));return builtin&&!missing_root?(unsigned long)host_root:0;
}
static unsigned long ksu_kallsyms_lookup_name(const char *name) {
    assert(preempt_depth==1);
    if(!strcmp(name,"ksu_uid_should_umount"))return missing_umount?0:(unsigned long)host_umount;
    assert(!strcmp(name,"ksu_is_uid_granted_root"));return missing_root?0:(unsigned long)host_root;
}
static void preempt_disable(void) {assert(!preempt_depth);preempt_depth=1;}
static void preempt_enable(void) {assert(preempt_depth==1);preempt_depth=0;}
static bool try_module_get(struct module *m) {assert(preempt_depth==1&&m==&backend);if(m->going)return false;m->refs++;return true;}
static void module_put(struct module *m) {assert(!preempt_depth&&m==&backend&&graces==1&&m->refs==1);m->refs--;}
static void synchronize_rcu_tasks(void) {assert(!preempt_depth);graces++;}
#include GATE
#include PRODUCTION
int main(int argc,char **argv) {
    assert(argc==2);const char *which=argv[1];bool enabled=true,root=true;
    if(!strcmp(which,"missing-umount")){missing_umount=true;enabled=root=false;}
    else if(!strcmp(which,"missing-root")){missing_root=true;root=false;}
    else if(!strcmp(which,"missing-lookup")){missing_lookup=true;enabled=root=false;}
    else if(!strcmp(which,"going")){backend.going=true;enabled=root=false;}
    else if(!strcmp(which,"builtin"))builtin=true;
    else if(!strcmp(which,"foreign-root")){foreign_root=true;root=false;}
    else if(!strcmp(which,"unowned")){unowned=true;enabled=root=false;}
    else assert(!strcmp(which,"module"));
    assert(!susfs_ksu_umount_gate_init());assert(!preempt_depth);
    assert(susfs_ksu_umount_gate_off==!enabled);
    assert(backend.refs==(enabled&&!builtin?1:0)&&!foreign.refs);
    assert(susfs_ksu_root_available()==root);
    if(enabled){assert(susfs_ksu_umount_ask(10002));assert(!susfs_ksu_umount_ask(10003));}
    if(root){assert(susfs_ksu_uid_granted_root(10003));assert(!susfs_ksu_uid_granted_root(10002));}
    susfs_ksu_umount_gate_exit();assert(!backend.refs&&!foreign.refs&&susfs_ksu_umount_gate_off);
    assert(!susfs_ksu_root_available()&&graces==(enabled?1:0));
    susfs_ksu_umount_gate_exit();assert(graces==(enabled?1:0));
    puts("PASS retained KernelSU policy");return 0;
}
