/* SPDX-License-Identifier: GPL-2.0 */
#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
typedef int atomic_t;
typedef int wait_queue_head_t;
#define atomic_set(p,n) (*(p)=(n))
#define init_waitqueue_head(p) (*(p)=0)
#define READ_ONCE(x) (x)
#define WRITE_ONCE(x,v) ((x)=(v))
#define smp_wmb() ((void)0)
#define pr_warn(...) ((void)0)
#define pr_warn_ratelimited(...) ((void)0)
typedef uint32_t u32;
#include HEADER
#define __NR_syscalls 512
#define SUSFS_FP_COMPAT_MAX_NR 512
#define SUSFS_ARM64_BTI_C 0xd503245fu
#define SUSFS_ARM64_BTI_JC 0xd50324dfu
#define SUSFS_ARM64_PACIASP 0xd503233fu
#define SUSFS_ARM64_PACIBSP 0xd503237fu
#define KSU_PATCH_TEXT_FLUSH_DCACHE 1
static susfs_syscall_fn_t native[512],compat[512];
static susfs_syscall_fn_t *sys_call_table_ptr=native,*compat_sys_call_table_ptr=compat;
static long original(const struct pt_regs *r) { (void)r;return 1; }
static long compat_original(const struct pt_regs *r) { (void)r;return 2; }
static long foreign(const struct pt_regs *r) { (void)r;return 3; }
static struct susfs_fp_hook *live;
static int calls,fail_call,fail_mode,restore_failures,waits,drains;
static bool foreign_owner;
int susfs_fp_init(void) { return 0; }
static int ksu_patch_text(void *dst,const void *src,size_t n,int flags) {
    (void)flags;++calls;
    susfs_syscall_fn_t next=*(susfs_syscall_fn_t const*)src;
    if(next==live->wrapper||next==live->compat_wrapper) {
        assert(live->installed);
        assert(*(dst==&native[live->nr]?live->orig_slot:live->orig_slot_compat));
    }
    if((next==original||next==compat_original)&&restore_failures) {--restore_failures;return -EIO;}
    if(calls==fail_call) {
        if(fail_mode==1) memcpy(dst,src,n); /* write then failure */
        return fail_mode==2?0:-EIO; /* reported success without a store */
    }
    memcpy(dst,src,n);return 0;
}
static void msleep(int n) {
    assert(n==100&&live->installed);assert(++waits<20);
    if(foreign_owner) {
        assert(!live->compat_installed&&compat[2]==compat_original);
        if(waits==3) native[1]=original;
    }
}
void susfs_fp_drain(struct susfs_fp_hook *h) {
    assert(h->installed&&!h->native_installed&&!h->compat_installed);
    assert(h->active_callbacks==0);++drains;
}
#include PRODUCTION
int main(int argc,char **argv) {
    assert(argc==2);const char *c=argv[1];
    static const u32 pad=SUSFS_ARM64_BTI_C,cpad=SUSFS_ARM64_PACIASP;
    susfs_syscall_fn_t orig=NULL,corig=NULL;
    struct susfs_fp_hook h={.nr=1,.nr_compat=2,.name="test",
      .wrapper=(susfs_syscall_fn_t)(uintptr_t)&pad,
      .compat_wrapper=(susfs_syscall_fn_t)(uintptr_t)&cpad,
      .orig_slot=&orig,.orig_slot_compat=&corig};
    live=&h;native[1]=original;compat[2]=compat_original;
    if(!strcmp(c,"invalid")) {h.nr_compat=512;assert(susfs_fp_install(&h)==-EINVAL&&!calls);puts("PASS invalid");return 0;}
    if(!strcmp(c,"missing-compat")) {h.nr=-1;compat_sys_call_table_ptr=NULL;assert(susfs_fp_install(&h)==-ENOENT&&!h.installed);puts("PASS missing-compat");return 0;}
    bool failed=strstr(c,"fail")||!strcmp(c,"no-store");
    if(failed) {
        fail_call=strstr(c,"native")?1:2;
        fail_mode=strstr(c,"after")?1:(!strcmp(c,"no-store")?2:0);
        if(!strcmp(c,"rollback-fail")) restore_failures=3;
        assert(susfs_fp_install(&h)==-EIO);
    } else {
        assert(!susfs_fp_install(&h));assert(orig==original&&corig==compat_original);
        assert(native[1]==h.wrapper&&compat[2]==h.compat_wrapper);
        if(!strcmp(c,"restore-retry")) restore_failures=3;
        if(!strcmp(c,"foreign-native")) {native[1]=foreign;foreign_owner=true;}
        if(!strcmp(c,"already-restored")) native[1]=original;
        susfs_fp_remove(&h);
    }
    assert(!h.installed&&!h.native_installed&&!h.compat_installed);
    assert(native[1]==original&&compat[2]==compat_original&&drains==1);
    susfs_fp_remove(&h);assert(drains==1);
    printf("PASS %s\n",c);
}
