#!/usr/bin/env python3
"""Fault injection and controlled lifetime interleavings in actual syscall hook C."""
import argparse, importlib.util, os, re, subprocess, tempfile
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--sanitizers',action='store_true');a=p.parse_args()
here=Path(__file__).resolve().parent;root=here.parents[1]
spec=importlib.util.spec_from_file_location('extract',root/'tests/path_creds/run.py');extract=importlib.util.module_from_spec(spec);spec.loader.exec_module(extract)
source=(root/'kernel/susfs_fp_hook.c').read_text()
header=re.sub(r'^#include[^\n]*\n','',(root/'kernel/susfs_fp_hook.h').read_text(),flags=re.M)
flags=['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-no-pie'] if a.sanitizers else ['-O2']
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
with tempfile.TemporaryDirectory(prefix='susfs-fp-') as d:
 d=Path(d);(d/'header.h').write_text(header)
 def build(file,production,extra=()):
  fragment=d/(file.stem+'.h');fragment.write_text(production);exe=d/file.stem
  subprocess.run(['cc','-std=gnu11','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-pthread',*flags,'-I',str(d),'-I',str(here),'-DHEADER="'+str(d/'header.h')+'"','-DPRODUCTION="'+str(fragment)+'"',*extra,str(file),'-o',str(exe)],check=True)
  return exe
 def run(exe,cases):
  for case in cases:subprocess.run([str(exe),case],check=True,env=env,timeout=15)
 funcs=['fp_compat_nr','fp_has_landing_pad','fp_patch_entry','fp_restore_entry','susfs_fp_install','susfs_fp_remove']
 exe=build(here/'restore_test.c','\n\n'.join(extract.function(source,n) for n in funcs))
 run(exe,['success','restore-retry','foreign-native','already-restored','native-fail-before','native-fail-after','compat-fail-before','compat-fail-after','rollback-fail','no-store','invalid','missing-compat'])
 # Reuse the existing explicit Tasks RCU model with the real FP type/helpers.
 host=(root/'tests/lsm_lifetime/host_kernel.h').read_text()
 host=host.replace('struct ksu_lsm_hook { atomic_t active_callbacks; wait_queue_head_t callback_waitq; };','#include "header.h"')
 (d/'host_kernel.h').write_text(host)
 test=(root/'tests/lsm_lifetime/lifetime_test.c').read_text().replace('struct ksu_lsm_hook','struct susfs_fp_hook').replace('ksu_lsm_callback_enter','susfs_fp_callback_enter').replace('ksu_lsm_callback_exit(&hook)','susfs_fp_callback_return(&hook, 0)').replace('ksu_lsm_hook_drain','susfs_fp_drain').replace('PRODUCTION_LIFETIME','PRODUCTION')
 (d/'lifetime_test.c').write_text(test)
 exe=build(d/'lifetime_test.c','\n\n'.join(extract.function(source,n) for n in ['susfs_fp_callback_enter','susfs_fp_callback_return','susfs_fp_drain']))
 run(exe,['empty','sleeping-tail','late-entry','multiple','wake-tail'])
 # Verify every real wrapper balances its own counter on all return paths.
 create=(root/'kernel/susfs_create_gate.c').read_text();opening=(root/'kernel/susfs_or_entry.c').read_text()
 cnames=['mkdirat','mknodat','symlinkat','linkat'];onames=['openat','openat2','compat_open','compat_openat','compat_openat2']
 names=[('create',n,i) for i,n in enumerate(cnames)]+[('create','compat_'+n,i) for i,n in enumerate(cnames)]+[('or',n,i) for i,n in enumerate(onames)]
 decls='\n'.join('static susfs_syscall_fn_t '+pre+'_orig_'+n+';' for pre,n,i in names)
 bodies='\n'.join(extract.function(create if pre=='create' else opening,pre+'_wrap_'+n) for pre,n,i in names)
 checks=[]
 for pre,n,i in names:
  checks += [f'expected=&{pre}_hooks[{i}];hidden_call=0;hidden_at=0;redirect_result=SUSFS_OR_ENTRY_PASS;',f'{pre}_orig_{n}=NULL;assert({pre}_wrap_{n}(&regs)==-ENOSYS);assert(!expected->active_callbacks);',f'{pre}_orig_{n}=original;assert({pre}_wrap_{n}(&regs)==17);assert(!expected->active_callbacks);']
  if pre=='or':
   checks += [f'redirect_result=-EACCES;assert({pre}_wrap_{n}(&regs)==-EACCES);assert(!expected->active_callbacks);',f'redirect_result=42;assert({pre}_wrap_{n}(&regs)==42);assert(!expected->active_callbacks);']
  else:
   checks += [f'hidden_call=0;hidden_at=1;assert({pre}_wrap_{n}(&regs)=='+('-ENOENT' if n.endswith('linkat') and not n.endswith('symlinkat') else '-EACCES')+');assert(!expected->active_callbacks);']
   if n in ('linkat','compat_linkat'): checks += [f'hidden_call=0;hidden_at=2;assert({pre}_wrap_{n}(&regs)==-EACCES);assert(!expected->active_callbacks);']
 code='''#include <assert.h>
#include <errno.h>
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
typedef int atomic_t;
typedef int wait_queue_head_t;
#define __nocfi
#define noinline
#define __user
#define READ_ONCE(x) (x)
struct pt_regs { unsigned long regs[31]; };
#include HEADER
#include ENUM
static struct susfs_fp_hook create_hooks[4],or_hooks[5],*expected;
static int hidden_call,hidden_at;static long redirect_result;
void susfs_fp_callback_enter(struct susfs_fp_hook *h) {assert(h==expected&&!h->active_callbacks);h->active_callbacks++;}
long susfs_fp_callback_return(struct susfs_fp_hook *h,long v) {assert(h==expected&&h->active_callbacks==1);h->active_callbacks--;return v;}
static bool create_name_hidden(int fd,const char *name) {assert(expected->active_callbacks==1);return ++hidden_call==hidden_at;}
static long or_entry_redirect(const struct pt_regs *r,int k) {assert(expected->active_callbacks==1);return redirect_result;}
static long original(const struct pt_regs *r) {assert(expected->active_callbacks==1);return 17;}
'''+decls+'\n'+bodies+'\nint main(void) {struct pt_regs regs={0};\n'+'\n'.join(checks)+'\nputs("PASS all 13 wrappers: balanced lifetime and correct original");}\n'
 (d/'wrappers.c').write_text(code)
 enum=re.sub(r'^#include[^\n]*\n','',(root/'kernel/susfs_or_entry.h').read_text(),flags=re.M);(d/'enum.h').write_text(enum)
 exe=build(d/'wrappers.c','', ['-DENUM="'+str(d/'enum.h')+'"']);run(exe,['all'])
 for n,num in [('MKDIRAT',323),('MKNODAT',324),('LINKAT',330),('SYMLINKAT',331)]:
  assert re.search(r'#define COMPAT_'+n+r'_NR\s+'+str(num)+r'\b',create)
  assert '.compat_wrapper = create_wrap_compat_'+n.lower() in create
print('PASS syscall table numbering and separate native/compat wrappers')
