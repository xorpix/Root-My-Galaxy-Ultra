/* SPDX-License-Identifier: GPL-2.0 */
#include "host_kernel.h"
#include PRODUCTION_LIFETIME

static pthread_mutex_t model = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t changed = PTHREAD_COND_INITIALIZER;
static struct ksu_lsm_hook hook;
static int readers, tails, tasks_graces, entered, body_releases;
static bool release_reader, release_tail, counter_wait, drain_done;
static bool delay_entry, hold_wake, wake_entered;

void synchronize_rcu(void) { }
void synchronize_rcu_tasks(void)
{
    pthread_mutex_lock(&model);
    ++tasks_graces;
    pthread_cond_broadcast(&changed);
    /* Sleeping original handlers are quiescent for this model. Old dispatch
     * readers and runnable callback epilogues remain holdouts. */
    while (readers || tails) pthread_cond_wait(&changed, &model);
    pthread_mutex_unlock(&model);
}
void note_counter_wait(void)
{
    pthread_mutex_lock(&model);
    counter_wait = true;
    pthread_cond_broadcast(&changed);
    pthread_mutex_unlock(&model);
}
void wake_up_all(wait_queue_head_t *q)
{
    pthread_mutex_lock(&q->lock);
    pthread_cond_broadcast(&q->changed);
    pthread_mutex_unlock(&q->lock);
    if (hold_wake) {
        pthread_mutex_lock(&model);
        wake_entered = true;
        pthread_cond_broadcast(&changed);
        while (!release_tail) pthread_cond_wait(&changed, &model);
        pthread_mutex_unlock(&model);
    }
}
static void *callback(void *unused)
{
    (void)unused;
    if (delay_entry) {
        pthread_mutex_lock(&model);
        while (!release_reader) pthread_cond_wait(&changed, &model);
        ksu_lsm_callback_enter(&hook);
        --readers;
        pthread_cond_broadcast(&changed);
        pthread_mutex_unlock(&model);
    } else ksu_lsm_callback_enter(&hook);
    pthread_mutex_lock(&model);
    ++entered;
    pthread_cond_broadcast(&changed);
    while (body_releases == 0) pthread_cond_wait(&changed, &model);
    --body_releases;
    ++tails;
    pthread_mutex_unlock(&model);
    ksu_lsm_callback_exit(&hook);
    /* Model preemption between the final count release and the return from
     * SUS_LSM_RETURN/SUS_LSM_PASS_ORIG; module code is still live here. */
    pthread_mutex_lock(&model);
    pthread_cond_broadcast(&changed);
    while (!release_tail) pthread_cond_wait(&changed, &model);
    --tails;
    pthread_cond_broadcast(&changed);
    pthread_mutex_unlock(&model);
    return NULL;
}
static void *drain(void *unused)
{
    (void)unused;
    ksu_lsm_hook_drain(&hook);
    pthread_mutex_lock(&model);
    drain_done = true;
    pthread_cond_broadcast(&changed);
    pthread_mutex_unlock(&model);
    return NULL;
}
static void initialize(void)
{
    atomic_init(&hook.active_callbacks, 0);
    assert(!pthread_mutex_init(&hook.callback_waitq.lock, NULL));
    assert(!pthread_cond_init(&hook.callback_waitq.changed, NULL));
}
static void test_empty(void)
{
    ksu_lsm_hook_drain(&hook);
    assert(tasks_graces == 2 && atomic_read(&hook.active_callbacks) == 0);
}
static void test_sleeping(int count)
{
    pthread_t workers[2], remover;
    assert(count <= 2);
    if (delay_entry) readers = count;
    for (int i = 0; i < count; ++i)
        assert(!pthread_create(&workers[i], NULL, callback, NULL));
    pthread_mutex_lock(&model);
    if (!delay_entry)
        while (entered != count) pthread_cond_wait(&changed, &model);
    pthread_mutex_unlock(&model);
    assert(!pthread_create(&remover, NULL, drain, NULL));
    pthread_mutex_lock(&model);
    if (delay_entry) {
        while (!tasks_graces) pthread_cond_wait(&changed, &model);
        assert(!drain_done);
        release_reader = true;
        pthread_cond_broadcast(&changed);
    }
    while (!counter_wait || entered != count) pthread_cond_wait(&changed, &model);
    assert(!drain_done && atomic_read(&hook.active_callbacks) == count);
    body_releases = count;
    pthread_cond_broadcast(&changed);
    while (tasks_graces != 2 || (hold_wake && !wake_entered))
        pthread_cond_wait(&changed, &model);
    assert(!drain_done && tails > 0);
    release_tail = true;
    pthread_cond_broadcast(&changed);
    pthread_mutex_unlock(&model);
    for (int i = 0; i < count; ++i) assert(!pthread_join(workers[i], NULL));
    assert(!pthread_join(remover, NULL));
    assert(drain_done && atomic_read(&hook.active_callbacks) == 0);
}
int main(int argc, char **argv)
{
    assert(argc == 2);
    initialize();
    if (!strcmp(argv[1], "empty")) test_empty();
    else if (!strcmp(argv[1], "sleeping-tail")) test_sleeping(1);
    else if (!strcmp(argv[1], "multiple")) test_sleeping(2);
    else if (!strcmp(argv[1], "late-entry")) { delay_entry = true; test_sleeping(1); }
    else if (!strcmp(argv[1], "wake-tail")) { hold_wake = true; test_sleeping(1); }
    else assert(false);
    assert(!pthread_cond_destroy(&hook.callback_waitq.changed));
    assert(!pthread_mutex_destroy(&hook.callback_waitq.lock));
    printf("PASS %s\n", argv[1]);
    return 0;
}
