/* SPDX-License-Identifier: GPL-2.0 */
/* Host synchronization model, not Samsung layouts or an RCU implementation. */
#include <assert.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#define __SUSFS_LSM_HOOK_H
typedef atomic_int atomic_t;
typedef struct { pthread_mutex_t lock; pthread_cond_t changed; } wait_queue_head_t;
struct ksu_lsm_hook { atomic_t active_callbacks; wait_queue_head_t callback_waitq; };
#define atomic_inc(p) atomic_fetch_add((p), 1)
#define atomic_read(p) atomic_load(p)
#define atomic_dec_and_test(p) (atomic_fetch_sub((p), 1) == 1)
#define smp_mb__before_atomic() atomic_thread_fence(memory_order_seq_cst)
#define smp_mb__after_atomic() atomic_thread_fence(memory_order_seq_cst)
void synchronize_rcu(void);
void synchronize_rcu_tasks(void);
void wake_up_all(wait_queue_head_t *q);
void note_counter_wait(void);
#define wait_event(q, condition) do { \
    pthread_mutex_lock(&(q).lock); \
    note_counter_wait(); \
    while (!(condition)) pthread_cond_wait(&(q).changed, &(q).lock); \
    pthread_mutex_unlock(&(q).lock); \
} while (0)
