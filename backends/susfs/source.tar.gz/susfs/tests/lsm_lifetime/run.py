#!/usr/bin/env python3
"""Compile production lifetime helpers with a controlled host API model."""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--source-dir", type=Path, default=Path(__file__).resolve().parents[2])
parser.add_argument("--sanitizers", action="store_true")
parser.add_argument("--case", choices=["empty", "sleeping-tail", "late-entry", "multiple", "wake-tail"])
parser.add_argument("--json", type=Path)
args = parser.parse_args()
here = Path(__file__).resolve().parent
source = args.source_dir.resolve()
results = []
with tempfile.TemporaryDirectory(prefix="susfs-lsm-lifetime-") as tmp_name:
    tmp = Path(tmp_name)
    (tmp / "linux").mkdir()
    (tmp / "linux/rcupdate.h").write_text("/* Host APIs in host_kernel.h */\n")
    production = source / "kernel/lsm_lifetime.c"
    if not production.exists():
        # Test the actual checkpoint-7 definitions, not a second implementation.
        text = (source / "kernel/lsm_hook.c").read_text()
        functions = []
        for name in ["ksu_lsm_callback_enter", "ksu_lsm_callback_exit", "ksu_lsm_hook_drain"]:
            matches = re.findall(r"(?:static )?void " + name + r"\([^;]*?\)\n\{.*?\n\}", text, re.S)
            assert len(matches) == 1, name
            functions.append(matches[0].removeprefix("static "))
        production = tmp / "checkpoint7.c"
        production.write_text("\n".join(functions) + "\n")
    exe = tmp / "lifetime"
    flags = ["-O1", "-g", "-fsanitize=address,undefined", "-fno-omit-frame-pointer", "-no-pie"] if args.sanitizers else ["-O2"]
    cmd = [os.environ.get("CC", "cc"), "-std=gnu11", "-Wall", "-Wextra", "-Werror", "-pthread", *flags,
           f'-DPRODUCTION_LIFETIME="{production}"', "-I", str(tmp), "-I", str(here),
           str(here / "lifetime_test.c"), "-o", str(exe)]
    subprocess.run(cmd, check=True)
    for case in [args.case] if args.case else ["empty", "sleeping-tail", "late-entry", "multiple", "wake-tail"]:
        env = dict(os.environ, ASAN_OPTIONS="detect_leaks=0:abort_on_error=1", UBSAN_OPTIONS="halt_on_error=1")
        try:
            run = subprocess.run([str(exe), case], capture_output=True, text=True, timeout=10, env=env)
            result = {"case": case, "exit_code": run.returncode, "stdout": run.stdout.strip(), "stderr": run.stderr.strip()}
        except subprocess.TimeoutExpired:
            result = {"case": case, "exit_code": 124, "stderr": "Lifetime contract did not complete within 10 seconds"}
        print(result.get("stdout") or f"FAIL {case}: {result['stderr']}")
        results.append(result)
if args.json:
    args.json.write_text(json.dumps({"kind": "host synchronization model", "sanitizers": args.sanitizers,
                                    "source": str(source), "results": results}, indent=2) + "\n")
raise SystemExit(any(r["exit_code"] for r in results))
