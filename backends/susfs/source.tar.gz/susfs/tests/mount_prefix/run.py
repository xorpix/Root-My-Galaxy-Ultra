#!/usr/bin/env python3
"""Exercise production mount-prefix parsing and coherent concurrent snapshots."""
import argparse,os,re,subprocess,tempfile
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--sanitizers',action='store_true')
a=p.parse_args()
s=(Path(__file__).resolve().parents[2]/'kernel/sus_mount.c').read_text()
fragment='\n'.join(re.findall(r'^#define SUS_MOUNT_KEEP_(?:MAX|LEN|CMDLINE) .*$',s,re.M))+'\n'
fragment+='static char mount_keep[SUS_MOUNT_KEEP_MAX][SUS_MOUNT_KEEP_LEN];\nstatic int n_mount_keep;\nstatic pthread_mutex_t mount_keep_lock=PTHREAD_MUTEX_INITIALIZER;\nstatic int n_keep_rescans,n_newmnt_recorded,n_ident_hits,n_ident_learned;\n'
for name in ['sus_mount_keep_parse','sus_mount_keep_commit','sus_mount_keep_format']:
    fragment+=re.search(r'^static [^\n]*\b'+name+r'\([^;{]*\)\n\{\n.*?^\}\n',s,re.M|re.S)[0]
test=r'''
#include <assert.h>
#include <errno.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define GFP_KERNEL 0
#define atomic_read(p) (*(p))
#define spin_lock_irqsave(l,f) do { (f)=0;pthread_mutex_lock(l); } while(0)
#define spin_unlock_irqrestore(l,f) do { (void)(f);pthread_mutex_unlock(l); } while(0)
static bool fail_alloc;
static void *kvmalloc_array(size_t n,size_t len,int flags) { (void)flags;return fail_alloc?NULL:malloc(n*len); }
static void kvfree(void *p) { free(p); }
static int scnprintf(char *b,size_t size,const char *fmt,...) { va_list a;va_start(a,fmt);int n=vsnprintf(b,size,fmt,a);va_end(a);return n<0?0:(size_t)n>=size?(size?size-1:0):n; }
#include PRODUCTION
static char rows[2][SUS_MOUNT_KEEP_MAX][SUS_MOUNT_KEEP_LEN];
static void *writer(void *unused) { (void)unused;for(int k=0;k<5000;k++)sus_mount_keep_commit(rows[k%2],64);return NULL; }
int main(void)
{
    assert(SUS_MOUNT_KEEP_MAX==64);
    char command[SUS_MOUNT_KEEP_CMDLINE]={0},parsed[64][128];
    for(int j=0;j<2;j++)for(int i=0;i<64;i++)snprintf(rows[j][i],128,"/%c/%03d",'A'+j,i);
    for(int i=0;i<64;i++){strcat(command,rows[0][i]);strcat(command," ");}
    assert(sus_mount_keep_parse(command,parsed,64)==64);
    strcat(command,"/overflow");assert(sus_mount_keep_parse(command,parsed,64)==-ENOSPC);
    memset(command,'X',128);command[128]=0;assert(sus_mount_keep_parse(command,parsed,64)==-ENAMETOOLONG);
    sus_mount_keep_commit(rows[0],64);
    char buf[9000];int n=sus_mount_keep_format(buf,sizeof(buf));assert(n>0&&strstr(buf,"64/64")&&strstr(buf,"/A/063")&&!strstr(buf,"truncated"));
    for(int i=0;i<64;i++)memset(rows[0][i]+6,'x',120);
    for(int i=0;i<64;i++)rows[0][i][126]=0;
    sus_mount_keep_commit(rows[0],64);
    memset(buf,'Z',sizeof(buf));n=sus_mount_keep_format(buf,512);assert(n<512&&buf[512]=='Z'&&strstr(buf,"\n(truncated)\n"));
    fail_alloc=true;assert(sus_mount_keep_format(buf,512)==-ENOMEM);fail_alloc=false;
    for(int i=0;i<64;i++)snprintf(rows[0][i],128,"/A/%03d",i);
    sus_mount_keep_commit(rows[0],64);pthread_t thread;assert(!pthread_create(&thread,NULL,writer,NULL));
    for(int k=0;k<5000;k++){n=sus_mount_keep_format(buf,sizeof(buf));assert(n>0);bool A=strstr(buf," /A/")!=NULL,B=strstr(buf," /B/")!=NULL;assert(A!=B);assert(strstr(buf,A?"/A/063":"/B/063"));}
    assert(!pthread_join(thread,NULL));
    sus_mount_keep_commit(rows[0],0);n=sus_mount_keep_format(buf,sizeof(buf));assert(n>0&&strstr(buf,"0/64")&&strstr(buf,"(none"));
    puts("PASS 64 mount prefixes: limits, truncation, allocation failure and coherent concurrent snapshots");
}
'''
with tempfile.TemporaryDirectory(prefix='susfs-prefix-') as d:
    d=Path(d);(d/'production.h').write_text(fragment);(d/'test.c').write_text(test)
    flags=['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-no-pie'] if a.sanitizers else ['-O2']
    subprocess.run(['cc','-std=gnu11','-Wall','-Wextra','-Werror','-Wno-sign-compare','-pthread',*flags,'-DPRODUCTION="'+str(d/'production.h')+'"',str(d/'test.c'),'-o',str(d/'test')],check=True)
    subprocess.run([str(d/'test')],check=True,timeout=25,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1'))
