#include "host_kernel.h"
#include ABI
char *saved_boot_config;
#include BOOT
#include AVC
#include UNAME

static char native[]="native original\n";
static char foreign[]="foreign owner\n";
static void boot_abi(struct st_susfs_spoof_cmdline_or_bootconfig *info) { void *p=info; susfs_spoof_cmdline_supercall(&p); }
static void avc_abi(unsigned byte,int expected) { struct st_susfs_avc_log_spoofing info={.err=126}; *(unsigned char*)&info.enabled=byte; void *p=&info; susfs_avc_spoof_supercall(&p); assert(info.err==expected); }
static void dispatch(struct pt_regs *r) { if(avc_registered && !(kp_avc.flags&1)) avc_audit_post_pre(&kp_avc,r); }
static void *boot_writer(void *unused) { for(int i=0;i<500;i++) { assert(!spoof_set("thread fake")); assert(!spoof_reset()); } return NULL; }
static void *avc_writer(void *unused) { for(int i=0;i<60;i++) { assert(!avc_set_enabled(true)); assert(!avc_set_enabled(false)); } return NULL; }
static void threads(void *(*writer)(void*)) { pthread_t ids[4]; for(int i=0;i<4;i++) assert(!pthread_create(&ids[i],NULL,writer,NULL)); for(int i=0;i<4;i++) assert(!pthread_join(ids[i],NULL)); }
static atomic_bool replacement_done;
static void *replace_boot(void *reset) {
    assert(!(reset?spoof_reset():spoof_set("replacement")));
    atomic_store(&replacement_done,true); return NULL;
}
static int uname_abi_result(const char *release,const char *version) {
    struct st_susfs_uname info={0};
    assert(strscpy(info.release,release,sizeof(info.release))>=0);
    assert(strscpy(info.version,version,sizeof(info.version))>=0);
    void *arg=&info; susfs_uname_supercall(&arg); return info.err;
}
static void uname_abi(const char *r,const char *v) { assert(!uname_abi_result(r,v)); }
static void check_uname(const char *release,const char *version) {
    struct new_utsname got; memset(&got,0xa5,sizeof(got));
    struct uname_args a={.name=&got};
    struct kretprobe_instance ri={.data=&a}; struct pt_regs regs={0};
    kr_newuname_ret(&ri,&regs);
    assert(!strcmp(got.release,release) && !strcmp(got.version,version));
    for(size_t i=strlen(release);i<sizeof(got.release);i++) assert(!got.release[i]);
    for(size_t i=strlen(version);i<sizeof(got.version);i++) assert(!got.version[i]);
    for(size_t i=0;i<sizeof(got.sysname);i++) assert((unsigned char)got.sysname[i]==0xa5);
    for(size_t i=0;i<sizeof(got.machine);i++) assert((unsigned char)got.machine[i]==0xa5);
}
static void switch_uname_pair(void) {
    assert(!pthread_mutex_trylock(&uname_state_lock));
    pthread_mutex_unlock(&uname_state_lock);
    uname_abi("B","B");
}
static void *uname_writer(void *p) {
    for(int i=0;i<10000;i++) uname_abi(p,p);
    return NULL;
}
static void check_uname_writers(void) {
    pthread_t a,b;uname_abi("A","A");
    assert(!pthread_create(&a,NULL,uname_writer,"A"));
    assert(!pthread_create(&b,NULL,uname_writer,"B"));
    for(int i=0;i<20000;i++) {
        struct new_utsname got={0};struct uname_args args={.name=&got};
        struct kretprobe_instance ri={.data=&args};struct pt_regs regs={0};
        kr_newuname_ret(&ri,&regs);
        assert(!strcmp(got.release,got.version));
        assert(!strcmp(got.release,"A")||!strcmp(got.release,"B"));
    }
    assert(!pthread_join(a,NULL));assert(!pthread_join(b,NULL));
}
int main(int argc,char **argv)
{
    assert(argc==2); const char *name=argv[1]; saved_boot_config=native; avc_su_sid=3173; avc_priv_app_sid=4567;
    if(!strcmp(name,"boot-cycle")) {
        assert(!spoof_set("fake one")); assert(!strcmp(saved_boot_config,"fake one"));
        assert(!spoof_set("fake two")); assert(!strcmp(saved_boot_config,"fake two"));
        assert(!spoof_reset()); assert(saved_boot_config==native);
        assert(!spoof_reset()); assert(!spoof_set("fake three"));
        susfs_spoof_cmdline_exit(); assert(saved_boot_config==native);
        assert(bootconfig_values==3 && atomic_load(&live_allocations)==0);
    } else if(!strcmp(name,"boot-null")) {
        saved_boot_config=NULL; assert(!spoof_set("fake")); assert(!spoof_reset()); assert(saved_boot_config==NULL);
        assert(!spoof_set("next")); assert(!spoof_reset()); assert(saved_boot_config==NULL);
    } else if(!strcmp(name,"boot-allocation")) {
        fail_alloc=1; assert(spoof_set("fake")==-ENOMEM); assert(saved_boot_config==native && !original_captured);
        assert(!spoof_set("real fake")); char *p=saved_boot_config;
        fail_alloc=1; assert(spoof_set("failed")==-ENOMEM); assert(saved_boot_config==p); assert(!spoof_reset()); assert(saved_boot_config==native);
    } else if(!strcmp(name,"boot-foreign")) {
        assert(!spoof_set("ours")); char *p=saved_boot_config; saved_boot_config=foreign;
        assert(spoof_set("other")==-EBUSY); assert(saved_boot_config==foreign && spoof_active && fake_boot_config==p);
        assert(spoof_reset()==-EBUSY); assert(saved_boot_config==foreign && spoof_active);
        saved_boot_config=p; assert(!spoof_reset()); assert(saved_boot_config==native);
        saved_boot_config=foreign; assert(spoof_set("later")==-EBUSY); assert(saved_boot_config==foreign);
    } else if(!strcmp(name,"boot-reset-input")) {
        assert(!spoof_set("ours")); char *p=saved_boot_config;
        host_uid=10001; assert(bootconfig_reset_set("1",NULL)==-EPERM); host_uid=0;
        assert(bootconfig_reset_set("0",NULL)==-EINVAL); assert(bootconfig_reset_set("x",NULL)==-EINVAL); assert(saved_boot_config==p);
        assert(!bootconfig_reset_set("1\n",NULL)); assert(saved_boot_config==native);
        char stat[PAGE_SIZE]; bootconfig_stat_get(stat,NULL); assert(strstr(stat,"checkpoint=18 restore=1 active=0 captured=1"));
    } else if(!strcmp(name,"boot-abi-errors")) {
        struct st_susfs_spoof_cmdline_or_bootconfig info={.err=126}; boot_abi(&info); assert(info.err==-EINVAL);
        memset(info.fake_cmdline_or_bootconfig,'x',sizeof(info.fake_cmdline_or_bootconfig)); boot_abi(&info); assert(info.err==-ENAMETOOLONG);
        strcpy(info.fake_cmdline_or_bootconfig,"okay"); copy_fail=1; boot_abi(&info); assert(info.err==-EFAULT); copy_fail=0;
        fail_alloc=1; info.err=126; boot_abi(&info); assert(info.err==-ENOMEM); assert(saved_boot_config==native);
        boot_abi(&info); assert(info.err==0 && !strcmp(saved_boot_config,"okay"));
    } else if(!strcmp(name,"boot-concurrency")) {
        threads(boot_writer); assert(saved_boot_config==native && bootconfig_sets==2000 && bootconfig_values==2000 && bootconfig_conflicts==0);
        assert(atomic_load(&live_allocations)==0);
    } else if(!strcmp(name,"boot-reclaim-bound")) {
        for(int i=0;i<2000;i++) {
            assert(!spoof_set("bounded allocation"));
            assert(atomic_load(&live_allocations)==1);
            assert(live_bootconfig && list_empty(&retired_bootconfigs));
        }
        assert(!spoof_reset()); assert(!live_bootconfig && atomic_load(&live_allocations)==0);
    } else if(!strcmp(name,"boot-reader-replace") || !strcmp(name,"boot-reader-reset")) {
        assert(!spoof_set("reader owns this"));
        assert(!pthread_rwlock_rdlock(&boot_readers)); char *old=saved_boot_config;
        pthread_t writer; bool reset=!strcmp(name,"boot-reader-reset");
        assert(!pthread_create(&writer,NULL,replace_boot,reset?(void*)1:NULL));
        for(int i=0;i<10000 && !atomic_load(&grace_waiting) && !atomic_load(&replacement_done);i++) usleep(100);
        assert(atomic_load(&grace_waiting)>0 && !atomic_load(&replacement_done));
        assert(!strcmp(old,"reader owns this"));
        assert(saved_boot_config!=old);
        assert(atomic_load(&live_allocations)==(reset?1:2));
        /* Readers wait without holding the writer mutex. */
        assert(!pthread_mutex_trylock(&bootconfig_lock)); assert(!pthread_mutex_unlock(&bootconfig_lock));
        assert(!pthread_rwlock_unlock(&boot_readers)); assert(!pthread_join(writer,NULL));
        assert(atomic_load(&live_allocations)==(reset?0:1));
    } else if(!strcmp(name,"boot-foreign-unload")) {
        assert(!spoof_set("foreign may hold this")); char *held=saved_boot_config;
        saved_boot_config=foreign; susfs_spoof_cmdline_exit();
        assert(saved_boot_config==foreign && atomic_load(&live_allocations)==1);
        assert(!strcmp(held,"foreign may hold this"));
        assert(spoof_set("after unload")==-ENODEV);
    } else if(!strcmp(name,"boot-exit")) {
        assert(!spoof_set("live")); susfs_spoof_cmdline_exit();
        assert(saved_boot_config==native && !live_bootconfig && atomic_load(&live_allocations)==0);
        assert(spoof_set("after unload")==-ENODEV && atomic_load(&live_allocations)==0);
    } else if(!strcmp(name,"uname-shorter") || !strcmp(name,"uname-default")) {
        char long_release[65],long_version[65];
        memset(long_release,'R',64); long_release[64]=0;
        memset(long_version,'V',64); long_version[64]=0;
        uname_abi(long_release,long_version); check_uname(long_release,long_version);
        bool defaults=!strcmp(name,"uname-default");
        uname_abi(defaults?"default":"r",defaults?"default":"v");
        check_uname(defaults?native_uts.release:"r",defaults?native_uts.version:"v");
    } else if(!strcmp(name,"uname-snapshot")) {
        uname_abi("A","A");user_copy_hook=switch_uname_pair;
        check_uname("A","A");check_uname("B","B");
    } else if(!strcmp(name,"uname-writers")) {
        check_uname_writers();
    } else if(!strcmp(name,"uname-registration-failure")) {
        uname_register_error=-ENOMEM;
        assert(uname_abi_result("A","A")==-ENOMEM);
        assert(!uname_registered&&!uname_spoof_enabled&&!fake_release[0]&&!fake_version[0]);
        uname_register_error=0;uname_abi("A","A");check_uname("A","A");
    } else if(!strcmp(name,"uname-exit")) {
        uname_abi("A","A");susfs_uname_exit();
        assert(uname_abi_result("B","B")==-ENODEV);
        assert(!uname_registered&&!uname_spoof_enabled&&!strcmp(fake_release,"A"));
    } else if(!strcmp(name,"uname-incomplete")) {
        strcpy(fake_release,"A");uname_spoof_enabled=true;
        assert(!susfs_uname_init());assert(!uname_registered&&!uname_spoof_enabled);
    } else if(!strcmp(name,"uname-initial-parameter")) {
        memset(fake_release,'R',sizeof(fake_release)); memset(fake_version,'V',sizeof(fake_version));
        strcpy(fake_release,"r"); strcpy(fake_version,"v");
        uname_spoof_enabled=true; assert(!susfs_uname_init()); check_uname("r","v");
    } else if(!strcmp(name,"variant-label")) {
        assert(!strcmp(SUSFS_VARIANT_STR,"GKI-LKM"));
        assert(sizeof(SUSFS_VARIANT_STR)<=SUSFS_MAX_VARIANT_BUFSIZE);
    } else if(!strcmp(name,"avc-register-selection")) {
        assert(avc_tsid_arg==1); assert(!avc_set_enabled(true));
        struct pt_regs r={.regs={111,3173,44,55,66,77,88}}; dispatch(&r);
        assert(r.regs[1]==4567 && r.regs[0]==111 && r.regs[2]==44 && r.regs[3]==55 && r.regs[6]==88);
        r.regs[1]=9000; dispatch(&r); assert(r.regs[1]==9000 && atomic_read(&avc_hit_count)==1);
        assert(!avc_set_enabled(false)); r.regs[1]=3173; avc_audit_post_pre(&kp_avc,&r); assert(r.regs[1]==3173);
    } else if(!strcmp(name,"avc-repeat")) {
        for(int i=0;i<8;i++) { assert(!avc_set_enabled(true)); assert(!avc_set_enabled(true)); struct pt_regs r={.regs={1,3173,22}}; dispatch(&r); assert(r.regs[1]==4567 && r.regs[2]==22); assert(!avc_set_enabled(false)); assert(!avc_set_enabled(false)); }
        assert(register_count==8 && unregister_count==8 && atomic_read(&avc_hit_count)==8);
    } else if(!strcmp(name,"avc-sid-unavailable")) {
        avc_su_sid=0; assert(avc_set_enabled(true)==-ENOENT && !avc_registered && !avc_spoof_enabled);
        avc_su_sid=3173; avc_priv_app_sid=0; assert(avc_set_enabled(true)==-ENOENT && register_count==0);
        avc_spoof_enabled=true; struct pt_regs r={.regs={1,3173,22}}; avc_audit_post_pre(&kp_avc,&r); assert(r.regs[1]==3173);
    } else if(!strcmp(name,"avc-register-failure")) {
        register_error=-EINVAL; assert(avc_set_enabled(true)==-EINVAL && !avc_registered && !avc_spoof_enabled);
        assert(avc_proc_write(NULL,"1",1,NULL)==-EINVAL); avc_abi(1,-EINVAL);
        register_error=0; assert(!avc_set_enabled(true)); assert(avc_registered && avc_spoof_enabled); assert(!avc_set_enabled(false));
    } else if(!strcmp(name,"avc-proc-input")) {
        host_uid=10001; assert(avc_proc_write(NULL,"1",1,NULL)==-ENOENT); host_uid=0;
        assert(avc_proc_write(NULL,"",0,NULL)==-EINVAL); assert(avc_proc_write(NULL,"1x",2,NULL)==-EINVAL);
        assert(avc_proc_write(NULL,"1junk",5,NULL)==-EINVAL); assert(!avc_registered && register_count==0);
        copy_fail=1; assert(avc_proc_write(NULL,"1",1,NULL)==-EFAULT); copy_fail=0;
        assert(avc_proc_write(NULL,"1\n",2,NULL)==2); assert(avc_registered && avc_spoof_enabled);
        struct seq_file s; avc_proc_show(&s,NULL); assert(strstr(s.buffer,"registered=1 tsid_arg=1 abi_checked=1 checkpoint=18 last_error=0"));
        assert(avc_proc_write(NULL,"0",1,NULL)==1); assert(!avc_registered && !avc_spoof_enabled);
    } else if(!strcmp(name,"avc-abi-input")) {
        avc_abi(2,-EINVAL); assert(!avc_registered && register_count==0);
        copy_fail=1; avc_abi(1,-EFAULT); copy_fail=0;
        avc_abi(1,0); assert(avc_registered && avc_spoof_enabled); avc_abi(0,0); assert(!avc_registered && !avc_spoof_enabled);
    } else if(!strcmp(name,"avc-concurrency")) {
        threads(avc_writer); assert(!avc_registered && !avc_spoof_enabled); assert(register_count==unregister_count && register_count>0);
    } else if(!strcmp(name,"avc-unload") || !strcmp(name,"avc-unload-disabled")) {
        if(!strcmp(name,"avc-unload")) assert(!avc_set_enabled(true));
        susfs_avc_spoof_exit();
        assert(!avc_registered && !avc_spoof_enabled);
        int previous=register_count;
        assert(avc_set_enabled(true)==-ENODEV);
        assert(avc_proc_write(NULL,"1",1,NULL)==-ENODEV);
        avc_abi(1,-ENODEV);
        assert(register_count==previous && !avc_registered && !avc_spoof_enabled);
    } else abort();
    if(strcmp(name,"boot-foreign-unload")) {
        susfs_spoof_cmdline_exit(); assert(atomic_load(&live_allocations)==0);
    }
    printf("PASS %s\n",name); return 0;
}
