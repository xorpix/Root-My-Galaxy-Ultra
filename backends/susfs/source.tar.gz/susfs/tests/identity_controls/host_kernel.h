#ifndef IDENTITY_HOST_KERNEL
#define IDENTITY_HOST_KERNEL
#include <assert.h>
#include <errno.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
typedef uint32_t u32;
typedef uint16_t u16;
#define __user
#define __NEW_UTS_LEN 64
#define PAGE_SIZE 4096
#define GFP_KERNEL 0
#define static_assert _Static_assert
#define __same_type(a,b) __builtin_types_compatible_p(a,b)
#define module_param_string(...)
#define module_param(...)
#define MODULE_PARM_DESC(...)
#define module_param_cb(...)
#define SUSFS_LOGI(...) ((void)0)
#define pr_warn(...) ((void)0)
#define pr_err(...) ((void)0)
#define pr_warn_ratelimited(...) ((void)0)
#define READ_ONCE(x) __atomic_load_n(&(x),__ATOMIC_ACQUIRE)
#define WRITE_ONCE(x,v) __atomic_store_n(&(x),(v),__ATOMIC_RELEASE)
#define cmpxchg(p,old,new) ({ __typeof__(*(p)) expected_ = (old); __atomic_compare_exchange_n((p),&expected_,(new),false,__ATOMIC_SEQ_CST,__ATOMIC_SEQ_CST); expected_; })
#define DEFINE_MUTEX(x) pthread_mutex_t x = PTHREAD_MUTEX_INITIALIZER
#define mutex_lock(x) assert(!pthread_mutex_lock(x))
#define mutex_unlock(x) assert(!pthread_mutex_unlock(x))
#define DEFINE_SPINLOCK(x) pthread_mutex_t x = PTHREAD_MUTEX_INITIALIZER
#define spin_lock_irqsave(p,f) do { (f)=0; assert(!pthread_mutex_lock(p)); } while (0)
#define spin_unlock_irqrestore(p,f) do { (void)(f); assert(!pthread_mutex_unlock(p)); } while (0)
struct list_head { struct list_head *next,*prev; };
#define LIST_HEAD(x) struct list_head x = { &x,&x }
static void list_add_tail(struct list_head *entry, struct list_head *head) { entry->prev=head->prev; entry->next=head; head->prev->next=entry; head->prev=entry; }
static bool list_empty(const struct list_head *head) { return head->next==head; }
static void list_del(struct list_head *entry) { entry->prev->next=entry->next; entry->next->prev=entry->prev; }
static void list_splice_init(struct list_head *from,struct list_head *to) {
    if(list_empty(from)) return;
    struct list_head *first=from->next,*last=from->prev,*old=to->next;
    to->next=first; first->prev=to; last->next=old; old->prev=last;
    from->next=from->prev=from;
}
#define list_entry(p,type,member) ((type *)((char *)(p)-offsetof(type,member)))
#define list_for_each_entry_safe(pos,n,head,member) \
    for(pos=list_entry((head)->next,__typeof__(*pos),member), \
        n=list_entry(pos->member.next,__typeof__(*pos),member); \
        &pos->member!=(head); \
        pos=n,n=list_entry(n->member.next,__typeof__(*n),member))
/* Model an in-flight native reader; this is not a host RCU implementation. */
static pthread_rwlock_t boot_readers=PTHREAD_RWLOCK_INITIALIZER;
static atomic_int grace_calls,grace_waiting,live_allocations;
static void synchronize_rcu_tasks(void) {
    atomic_fetch_add(&grace_calls,1); atomic_fetch_add(&grace_waiting,1);
    assert(!pthread_rwlock_wrlock(&boot_readers));
    atomic_fetch_sub(&grace_waiting,1);
    assert(!pthread_rwlock_unlock(&boot_readers));
}
static int fail_alloc, copy_fail;
static void *kmalloc(size_t n,int flags) { if(fail_alloc) { fail_alloc--; return NULL; } void *p=malloc(n); if(p) atomic_fetch_add(&live_allocations,1); return p; }
static void *kzalloc(size_t n,int flags) { void *p=kmalloc(n,flags); if(p) memset(p,0,n); return p; }
static void kfree(void *p) { if(p) { assert(atomic_fetch_sub(&live_allocations,1)>0); free(p); } }
static int copy_from_user(void *to,const void *from,size_t n) { if(copy_fail) return 1; memcpy(to,from,n); return 0; }
static void (*user_copy_hook)(void);
static _Thread_local int host_fault_disabled;
static void pagefault_disable(void) { assert(host_fault_disabled++==0); }
static void pagefault_enable(void) { assert(--host_fault_disabled==0); }
static int copy_to_user(void *to,const void *from,size_t n) { memcpy(to,from,n); if(user_copy_hook) { void (*hook)(void)=user_copy_hook;user_copy_hook=NULL;hook(); } return 0; }
static bool susfs_abi_path_ok(const char *value,size_t n) { return memchr(value,0,n)!=NULL; }
struct kernel_param { int unused; };
struct kernel_param_ops { int (*set)(const char *,const struct kernel_param *); int (*get)(char *,const struct kernel_param *); };
static int kstrtobool(const char *value,bool *out) { if(!strcmp(value,"1")||!strcmp(value,"1\n")||!strcmp(value,"Y")) *out=true; else if(!strcmp(value,"0")||!strcmp(value,"N")) *out=false; else return -EINVAL; return 0; }
static int scnprintf(char *buffer,size_t n,const char *fmt,...) { va_list args; va_start(args,fmt); int rc=vsnprintf(buffer,n,fmt,args); va_end(args); return rc<(int)n?rc:(int)n-1; }
static unsigned host_uid;
struct host_kuid { unsigned val; };
static struct host_kuid current_uid(void) { return (struct host_kuid){host_uid}; }
typedef atomic_int atomic_t;
#define ATOMIC_INIT ATOMIC_VAR_INIT
#define atomic_inc(x) ((void)atomic_fetch_add(x,1))
#define atomic_read(x) atomic_load(x)
struct common_audit_data;
int slow_avc_audit(u32,u32,u16,u32,u32,u32,int,struct common_audit_data *);
struct pt_regs { unsigned long regs[31]; long ret; };
static long regs_return_value(const struct pt_regs *r) { return r->ret; }
struct kprobe { const char *symbol_name; int (*pre_handler)(struct kprobe *,struct pt_regs *); unsigned flags; void *addr; };
static int register_error, register_count, unregister_count;
static atomic_int lifecycle_active;
static int register_kprobe(struct kprobe *p) { assert(atomic_fetch_add(&lifecycle_active,1)==0); usleep(100); register_count++; if(!register_error) p->addr=(void*)0x1234; assert(atomic_fetch_sub(&lifecycle_active,1)==1); return register_error; }
static void unregister_kprobe(struct kprobe *p) { assert(atomic_fetch_add(&lifecycle_active,1)==0); usleep(100); unregister_count++; p->flags|=1; assert(atomic_fetch_sub(&lifecycle_active,1)==1); }
struct kretprobe_instance { void *data; };
struct kretprobe {
    struct kprobe kp;
    int (*entry_handler)(struct kretprobe_instance *,struct pt_regs *);
    int (*handler)(struct kretprobe_instance *,struct pt_regs *);
    size_t data_size;
    int maxactive;
};
static int uname_register_error;
static int register_kretprobe(struct kretprobe *p) { return uname_register_error; }
static void unregister_kretprobe(struct kretprobe *p) { }
struct new_utsname { char sysname[65],nodename[65],release[65],version[65],machine[65],domainname[65]; };
static struct new_utsname native_uts={.release="native-release",.version="native-version"};
static struct new_utsname *utsname(void) { return &native_uts; }
static long strscpy(char *dst,const char *src,size_t n) {
    if(!n) return -E2BIG;
    size_t len=strnlen(src,n);
    size_t copied=len<n?len:n-1;
    memcpy(dst,src,copied); dst[copied]=0;
    return len<n?(long)len:-E2BIG;
}
struct inode { int unused; };
struct file { int unused; };
struct seq_file { char buffer[4096]; };
static void seq_printf(struct seq_file *m,const char *fmt,...) { va_list args; va_start(args,fmt); vsnprintf(m->buffer,sizeof(m->buffer),fmt,args); va_end(args); }
static int single_open(struct file *f,int (*show)(struct seq_file *,void *),void *v) { return 0; }
static ssize_t seq_read(struct file *f,char *b,size_t l,loff_t *o) { return 0; }
static loff_t seq_lseek(struct file *f,loff_t o,int whence) { return 0; }
static int single_release(struct inode *i,struct file *f) { return 0; }
struct proc_ops { int (*proc_open)(struct inode *,struct file *); ssize_t (*proc_read)(struct file *,char *,size_t,loff_t *); ssize_t (*proc_write)(struct file *,const char *,size_t,loff_t *); loff_t (*proc_lseek)(struct file *,loff_t,int); int (*proc_release)(struct inode *,struct file *); };
struct proc_dir_entry { int unused; };
static struct proc_dir_entry *proc_create(const char *n,int mode,void *parent,const struct proc_ops *ops) { static struct proc_dir_entry entry; return &entry; }
static void proc_remove(struct proc_dir_entry *e) { }
static bool susfs_expose_proc = true;
static bool sus_path_lsm_active(void) { return true; }
static bool susfs_control_node_allowed(void) { return true; }
static int security_secctx_to_secid(const char *s,size_t len,u32 *sid) { *sid=strstr(s,"ksu")?3173:4567; return 0; }
#endif
