#!/usr/bin/env python3
"""Run actual bootconfig and AVC production C with instrumented kernel API stubs."""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--sanitizers',action='store_true')
parser.add_argument('--leak-check',action='store_true',help='Enable LSan on hosts that support its process inspection')
parser.add_argument('--json',type=Path)
args=parser.parse_args()
if args.leak_check and not args.sanitizers:
    parser.error('--leak-check requires --sanitizers')
here=Path(__file__).resolve().parent
kernel=here.parents[1]/'kernel'
names=['boot-cycle','boot-null','boot-allocation','boot-foreign','boot-reset-input',
       'boot-abi-errors','boot-concurrency','boot-reclaim-bound','boot-reader-replace',
       'boot-reader-reset','boot-foreign-unload','boot-exit','uname-shorter','uname-default',
       'uname-initial-parameter','uname-snapshot','uname-writers','uname-registration-failure','uname-exit','uname-incomplete','variant-label','avc-register-selection','avc-repeat',
       'avc-sid-unavailable','avc-register-failure','avc-proc-input','avc-abi-input','avc-concurrency',
       'avc-unload','avc-unload-disabled']
results=[]
with tempfile.TemporaryDirectory(prefix='susfs-identity-host-') as d:
    d=Path(d)
    sources={k:re.sub(r'^#include[^\n]*\n','', (kernel/v).read_text(),flags=re.M)
             for k,v in {'ABI':'susfs_abi.h','BOOT':'spoof_cmdline.c','AVC':'susfs_avc_spoof.c','UNAME':'susfs_uname.c'}.items()}
    def build(label,changed=None):
        paths={}
        for k,v in (changed or sources).items():
            paths[k]=d/(label+k+'.h'); paths[k].write_text(v)
        exe=d/label
        flags=['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-no-pie'] if args.sanitizers else ['-O2']
        subprocess.run(['cc','-std=gnu11','-Wall','-Wextra','-Werror','-Wno-unused-function','-Wno-unused-parameter','-Wno-unused-variable',*flags,
                        '-pthread','-I',str(here),*[f'-D{k}="{v}"' for k,v in paths.items()],str(here/'controls_test.c'),'-o',str(exe)],check=True)
        return exe
    env=dict(os.environ,ASAN_OPTIONS=f'detect_leaks={int(args.leak_check)}:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
    exe=build('production')
    for name in names:
        case_env=dict(env)
        if name=='boot-foreign-unload':
            case_env['ASAN_OPTIONS']='detect_leaks=0:abort_on_error=1'
        run=subprocess.run([str(exe),name],text=True,capture_output=True,env=case_env,timeout=30)
        passed=run.returncode==0
        results.append(dict(case=name,passed=passed,exit_code=run.returncode,stdout=run.stdout,stderr=run.stderr))
        print(('PASS ' if passed else 'FAIL ')+name)
        if not passed:
            print(run.stderr[:2000])
    assert sources['UNAME'].count(', 0444)')==3
    controls=[('mixed-uname-pair','UNAME','version, SUSFS_UNAME_LEN))','fake_version, SUSFS_UNAME_LEN))','uname-snapshot'),('old-avc-register','AVC','? 2 : 1','? 2 : 2','avc-register-selection'),
              ('allow-avc-after-exit','AVC','avc_exiting = true;','/* exit admission omitted */','avc-unload'),
              ('retain-disabled-probe','AVC','kp_avc.flags = 0;','/* disabled flag deliberately retained */','avc-repeat'),
              ('free-published-bootconfig','BOOT','if (rc)\n\t\tkfree(value);','if (1)\n\t\tkfree(value);','boot-cycle'),
              ('omit-reader-grace','BOOT','synchronize_rcu_tasks();','/* grace period omitted */','boot-reader-replace'),
              ('omit-uname-padding','UNAME','memset(value + len, 0, size - len);','(void)value;','uname-initial-parameter'),
              ('overwrite-foreign-bootconfig','BOOT','if (cmpxchg(&saved_boot_config, expected, value->text) != expected)',
               'if ((saved_boot_config = value->text, false))','boot-foreign')]
    for label,key,old,new,name in controls:
        assert old in sources[key]
        changed=dict(sources); changed[key]=changed[key].replace(old,new,1)
        control=build(label,changed)
        run=subprocess.run([str(control),name],text=True,capture_output=True,env=env,timeout=30)
        passed=run.returncode!=0
        results.append(dict(case='negative/'+label,passed=passed,exit_code=run.returncode,
                            stdout=run.stdout,stderr=run.stderr[:6000]))
        print(('PASS ' if passed else 'FAIL ')+'negative/'+label)
if args.json:
    args.json.parent.mkdir(parents=True,exist_ok=True)
    args.json.write_text(json.dumps(dict(kind='production C with host kernel API stubs',sanitizers=args.sanitizers,
        leak_detection=args.sanitizers and args.leak_check,allocation_accounting=True,
        foreign_ownership_exception='boot-foreign-unload retains one value intentionally; leak detection disabled for that case only',
        reader_model='pthread reader gate, not an RCU implementation',hardware_validated=False,results=results),indent=2)+'\n')
raise SystemExit(any(not r['passed'] for r in results))
