# Bootconfig lifetime, uname buffers and AVC controls

`python3 tests/identity_controls/run.py --sanitizers --json evidence.json`
compiles the production C with instrumented allocation, atomic pointer, mutex,
probe and userspace-copy APIs. The 25 cases include native/NULL restoration,
allocation and ABI failures, foreign ownership, reader-held replacement/reset,
2000 successive updates with exactly one live value, concurrent writers,
post-exit admission, full-width uname copies, and the existing AVC controls.

Seven negative controls must fail: the old AVC argument, post-exit AVC arming,
a retained disabled probe flag, premature bootconfig freeing, a missing reader
grace period, missing uname padding, and overwriting a foreign pointer.

Allocation accounting verifies every normal case ends with no outstanding
allocation. The foreign-unload case deliberately retains exactly one live
value, because a foreign owner may still hold that pointer. A pthread reader
gate models a preempted native reader and verifies reclamation waits without
holding the writer mutex. It does not prove the kernel's RCU implementation.

ASan/UBSan run with LSan disabled by default for hosts that cannot inspect
other processes' `/proc/.../task` entries. `--leak-check` enables LSan where
supported, except for the deliberate foreign-ownership retention case.

Uname cases cover init parameters and control-ABI writes, including default
values and long-to-short replacements. The existing direct runtime sysfs
parameter setter is unchanged, matching the scope of the upstream patch.

These are host checks, not Samsung runtime validation. The real-header checker
and a full ARM64 module build remain separate validation steps.
