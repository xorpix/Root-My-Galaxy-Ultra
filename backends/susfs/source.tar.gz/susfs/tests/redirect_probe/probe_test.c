/* SPDX-License-Identifier: GPL-2.0 */
#include <assert.h>
#include <errno.h>
#include <limits.h>
#include <pthread.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define __nocfi
#define noinline __attribute__((noinline))
#define READ_ONCE(x) (x)
#define WRITE_ONCE(x,v) ((x)=(v))
#define smp_load_acquire(p) (*(p))
#define smp_store_release(p,v) (*(p)=(v))
#define ARRAY_SIZE(x) (sizeof(x)/sizeof((x)[0]))
#define IS_ENABLED(x) (x)
#define CONFIG_COMPAT 1
static bool bti_config;
#define CONFIG_ARM64_BTI_KERNEL bti_config
#define __NR_openat 56
#define __NR_openat2 437
#define SUSFS_OR_ENTRY_PASS LONG_MIN
enum { SUSFS_OR_ENTRY_OPENAT, SUSFS_OR_ENTRY_OPENAT2, SUSFS_OR_ENTRY_COMPAT_OPEN,
       SUSFS_OR_ENTRY_COMPAT_OPENAT, SUSFS_OR_ENTRY_COMPAT_OPENAT2, SUSFS_OR_ENTRY_KIND_COUNT };
typedef uint32_t u32;
typedef u32 kprobe_opcode_t;
struct pt_regs { unsigned long regs[31], pc; };
typedef long (*susfs_syscall_fn_t)(const struct pt_regs *);
struct kprobe { kprobe_opcode_t *addr; const char *symbol_name; unsigned int flags;
    int (*pre_handler)(struct kprobe *, struct pt_regs *);
    void (*post_handler)(struct kprobe *, struct pt_regs *, unsigned long); };
struct task_struct { int id; };
static struct task_struct task1={1}, task2={2}, *current=&task1;
struct hlist_node { struct hlist_node *next, **pprev; };
struct hlist_head { struct hlist_node *first; };
#define container_of(p,t,m) ((t *)((char *)(p)-offsetof(t,m)))
#define INIT_HLIST_HEAD(h) ((h)->first=NULL)
#define hlist_for_each_entry(v,h,m) for (struct hlist_node *n_=(h)->first; n_ && ((v)=container_of(n_,__typeof__(*(v)),m),1); n_=n_->next)
static void hlist_add_head(struct hlist_node *n,struct hlist_head *h) {n->next=h->first;if(n->next)n->next->pprev=&n->next;h->first=n;n->pprev=&h->first;}
static void hlist_del(struct hlist_node *n) {*n->pprev=n->next;if(n->next)n->next->pprev=n->pprev;}
typedef pthread_mutex_t raw_spinlock_t;
#define raw_spin_lock_init(p) assert(!pthread_mutex_init(p,NULL))
#define raw_spin_lock_irqsave(p,f) do{(f)=0;assert(!pthread_mutex_lock(p));}while(0)
#define raw_spin_unlock_irqrestore(p,f) do{(void)(f);assert(!pthread_mutex_unlock(p));}while(0)
static unsigned long hash_ptr(const void *p,int bits) {return ((uintptr_t)p>>3)&((1U<<bits)-1);}
struct susfs_fp_hook {
    int nr,nr_compat;const char *name,*sym;susfs_syscall_fn_t wrapper,*orig_slot,*orig_slot_compat;
    bool installed,compat_installed;int active_callbacks,callback_waitq;
};
#define atomic_set(p,v) (*(p)=(v))
#define init_waitqueue_head(p) (*(p)=0)
static bool or_entry_ready, rules=true, compat_task, in_probe, reject_identity, unreadable;
static bool missing_native,missing_compat,adjusted,table_changed;
static u32 first_instruction=0xd503233f;
static int fail_register=-1,registrations,unregistrations,live_count,redirects,originals,depth;
static long redirect_result=SUSFS_OR_ENTRY_PASS, original_result=17;
static struct kprobe *live[5];
static susfs_syscall_fn_t native[512],compat[512],pending;
static struct pt_regs real_regs;
static long invoke(int body,const struct pt_regs *regs);
static long core0(const struct pt_regs *r) {return invoke(0,r);}
static long core1(const struct pt_regs *r) {return invoke(1,r);}
static long core2(const struct pt_regs *r) {return invoke(2,r);}
static long core3(const struct pt_regs *r) {return invoke(3,r);}
static long foreign(const struct pt_regs *r) {return -ENOSYS;}
static susfs_syscall_fn_t cores[]={core0,core1,core2,core3};
static bool is_compat_task(void) {return compat_task;}
static bool susfs_open_redirect_active(void) {return rules;}
static unsigned long susfs_fp_syscall_table(void) {return missing_native?0:(unsigned long)native;}
static unsigned long susfs_fp_compat_syscall_table(void) {return missing_compat?0:(unsigned long)compat;}
static int ksu_symbol_is_start(unsigned long address,const char *name) {
    if(reject_identity)return 0;
    if(!strcmp(name,"__arm64_sys_openat"))return address==(unsigned long)core0;
    if(!strcmp(name,"__arm64_sys_openat2"))return address==(unsigned long)core1;
    if(!strcmp(name,"__arm64_compat_sys_open"))return address==(unsigned long)core2;
    if(!strcmp(name,"__arm64_compat_sys_openat"))return address==(unsigned long)core3||address==(unsigned long)core2;
    return 0;
}
static int copy_from_kernel_nofault(void *dst,const void *src,size_t n) {
    if(unreadable)return -EFAULT;
    for(unsigned int i=0;i<ARRAY_SIZE(cores);i++)if(src==(const void*)cores[i]) {assert(n==4);memcpy(dst,&first_instruction,4);return 0;}
    memcpy(dst,src,n);return 0;
}
static int register_kprobe(struct kprobe *p) {
    assert(!p->symbol_name && !p->flags && p->pre_handler && p->post_handler);
    assert(!or_entry_ready && live_count<5);
    if(registrations++==fail_register)return -EIO;
    live[live_count++]=p;
    if(adjusted)p->addr++;
    if(table_changed && live_count==4)native[56]=foreign;
    return 0;
}
static void unregister_kprobe(struct kprobe *p) {
    int i;for(i=0;i<live_count;i++)if(live[i]==p)break;assert(i<live_count);
    live[i]=live[--live_count];unregistrations++;
}
static void susfs_kp_forget_addr(struct kprobe *p) {p->addr=NULL;p->flags=0;}
static void susfs_fp_callback_enter(struct susfs_fp_hook *h) {assert(h->active_callbacks>=0);h->active_callbacks++;}
static long susfs_fp_callback_return(struct susfs_fp_hook *h,long result) {assert(h->active_callbacks>0);h->active_callbacks--;return result;}
static void susfs_fp_drain(struct susfs_fp_hook *h) {
    assert(!live_count);
    if(h->active_callbacks) {assert(pending && h->active_callbacks==1);susfs_syscall_fn_t f=pending;pending=NULL;assert(f(&real_regs)==original_result);}
    assert(!h->active_callbacks);
}
static long or_entry_redirect(const struct pt_regs *regs,int kind) {assert(!in_probe);redirects++;return redirect_result;}
#include PRODUCTION
static long invoke(int body,const struct pt_regs *regs) {
    assert(++depth<5);struct pt_regs frame={0};frame.regs[0]=(unsigned long)regs;frame.regs[30]=0xdeadbeef;
    for(int i=0;i<live_count;i++)if((void*)live[i]->addr==(void*)cores[body]) {
        in_probe=true;int redirected=live[i]->pre_handler(live[i],&frame);in_probe=false;
        if(redirected) {assert(redirected==1 && frame.regs[0]==(unsigned long)regs && frame.regs[30]==0xdeadbeef);long ret=((susfs_syscall_fn_t)frame.pc)(regs);depth--;return ret;}
    }
    originals++;depth--;return original_result;
}
static long inspect_original(const struct pt_regs *regs) {
    assert(or_probe_is_original(regs,0));
    assert(!or_probe_is_original(regs,1));
    assert(!or_probe_is_original(&real_regs+1,0));
    current=&task2;assert(!or_probe_is_original(regs,0));current=&task1;
    return -EINVAL;
}
static void counters_clear(void) {for(int i=0;i<5;i++)assert(!or_hooks[i].active_callbacks);}
int main(int argc,char **argv) {
    assert(argc==2);const char *c=argv[1];
    native[56]=core0;native[437]=core1;compat[5]=core2;compat[322]=core3;compat[437]=core1;
    if(!strcmp(c,"bti-config"))bti_config=true;
    if(!strcmp(c,"bti-entry"))first_instruction=0xd503245f;
    if(!strcmp(c,"existing-breakpoint"))first_instruction=0xd4200080;
    if(!strcmp(c,"foreign-target"))reject_identity=true;
    if(!strcmp(c,"unreadable"))unreadable=true;
    if(!strcmp(c,"missing-native"))missing_native=true;
    if(!strcmp(c,"missing-compat"))missing_compat=true;
    if(!strcmp(c,"ambiguous-alias"))compat[322]=core2;
    if(!strcmp(c,"adjusted-entry"))adjusted=true;
    if(!strcmp(c,"table-changed"))table_changed=true;
    if(!strncmp(c,"register-fail-",14))fail_register=atoi(c+14);
    bool failure=bti_config||first_instruction!=0xd503233f||reject_identity||unreadable||missing_native||missing_compat||compat[322]==core2||adjusted||table_changed||fail_register>=0;
    int rc=or_entry_probe_start();
    if(failure) {assert(rc<0&&!live_count&&!or_entry_probe_active);counters_clear();printf("PASS %s\n",c);return 0;}
    assert(!rc && live_count==4 && registrations==4 && or_entry_probe_active);
    or_entry_ready=true;
    if(!strcmp(c,"bypass-isolation")) {assert(or_entry_original(&real_regs,0,inspect_original)==-EINVAL);assert(!or_probe_is_original(&real_regs,0));}
    else if(!strcmp(c,"pending-entry")) {
        struct pt_regs frame={0};frame.regs[0]=(unsigned long)&real_regs;
        assert(or_entry_probes[0].kp.pre_handler(&or_entry_probes[0].kp,&frame)==1);
        assert(or_hooks[0].active_callbacks==1);pending=(susfs_syscall_fn_t)frame.pc;
    } else if(strcmp(c,"success")) {
        if(!strcmp(c,"redirect-all"))redirect_result=42;
        else if(!strcmp(c,"errors-all"))original_result=-ENOENT;
        else if(!strcmp(c,"no-rules"))rules=false;
        else if(!strcmp(c,"disabled"))or_entry_ready=false;
        else if(!strcmp(c,"missing-original"))or_orig_openat=NULL;
        else assert(!strcmp(c,"pass-all")||!strcmp(c,"wrong-abi"));
        if(!strcmp(c,"wrong-abi")) {assert(core2(&real_regs)==17 && !redirects);}
        else if(!strcmp(c,"missing-original")) {assert(core0(&real_regs)==-ENOSYS);}
        else for(int kind=0;kind<5;kind++) {
            compat_task=kind>=2;int body=kind<2?kind:(kind==4?1:kind);
            long result=cores[body](&real_regs);
            assert(result==(!or_entry_ready||!rules?original_result:(redirect_result==SUSFS_OR_ENTRY_PASS?original_result:redirect_result)));
            counters_clear();
        }
    }
    or_entry_ready=false;or_entry_probe_stop();
    assert(!pending&&!live_count&&!or_entry_probe_active&&unregistrations==4);counters_clear();
    printf("PASS %s\n",c);return 0;
}
