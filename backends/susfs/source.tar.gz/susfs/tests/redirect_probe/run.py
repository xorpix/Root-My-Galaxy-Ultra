#!/usr/bin/env python3
"""Exercise actual protected-table fallback, wrappers, recursion and teardown."""
import argparse
import importlib.util
import os
from pathlib import Path
import subprocess
import tempfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--sanitizers', action='store_true')
a = p.parse_args()
root = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('extract', root / 'tests/path_creds/run.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
s = (root / 'kernel/susfs_or_entry.c').read_text()
slots = ['openat', 'openat2', 'compat_open', 'compat_openat', 'compat_openat2']
production = 'static struct susfs_fp_hook or_hooks[5];\n'
production += '\n'.join('static susfs_syscall_fn_t or_orig_' + n + ';' for n in slots)
production += '\nstatic long or_entry_original(const struct pt_regs *, int, susfs_syscall_fn_t);\n'
production += '\n'.join(extract.function(s, 'or_wrap_' + n) for n in slots)
production += '\n#define SUSFS_COMPAT_NR_OPEN 5\n#define SUSFS_COMPAT_NR_OPENAT 322\n#define SUSFS_COMPAT_NR_OPENAT2 437\n'
b = s.index('static struct susfs_fp_hook or_hooks[] = {')
production += s[b:s.index('#include "susfs_or_probe.h"', b)]
production += (root / 'kernel/susfs_or_probe.h').read_text()
here = Path(__file__).resolve().parent
cases = ['success', 'redirect-all', 'pass-all', 'errors-all', 'no-rules', 'wrong-abi',
         'disabled', 'missing-original', 'bypass-isolation', 'pending-entry',
         'bti-config', 'bti-entry', 'existing-breakpoint', 'foreign-target',
         'unreadable', 'missing-native', 'missing-compat', 'ambiguous-alias',
         'adjusted-entry', 'table-changed'] + ['register-fail-' + str(i) for i in range(4)]
flags = ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-no-pie'] if a.sanitizers else ['-O2']
env = dict(os.environ, ASAN_OPTIONS='detect_leaks=0:abort_on_error=1', UBSAN_OPTIONS='halt_on_error=1')
with tempfile.TemporaryDirectory(prefix='susfs-or-probe-') as work:
    work = Path(work)
    def build(text, label):
        header = work / (label + '.h')
        header.write_text(text)
        exe = work / label
        subprocess.run([os.environ.get('CC', 'cc'), '-std=gnu11', '-Wall', '-Wextra', '-Werror',
                        '-Wno-unused-parameter', '-Wno-unused-function', *flags, '-pthread', '-DPRODUCTION="' + str(header) + '"',
                        str(here / 'probe_test.c'), '-o', str(exe)], check=True)
        return exe
    exe = build(production, 'probe')
    for case in cases:
        subprocess.run([str(exe), case], check=True, env=env, timeout=15)
    for label, old, new, case in [
        ('entry-gap', 'susfs_fp_callback_enter(&or_hooks[kind]);', '(void)kind;', 'pending-entry'),
        ('wrong-abi', 'is_compat_task() ? probe->compat_kind : probe->native_kind',
         'probe->native_kind', 'redirect-all'),
        ('recursion', 'if (or_probe_is_original((const void *)regs->regs[0], kind))',
         'if (false)', 'pass-all'),
        ('lost-adapter-reference', 'return susfs_fp_callback_return(&or_hooks[kind], wrapper(regs));',
         'return wrapper(regs);', 'redirect-all'),
    ]:
        assert old in production
        changed = build(production.replace(old, new, 1), label)
        r = subprocess.run([str(changed), case], env=env, capture_output=True, timeout=15)
        assert r.returncode != 0, 'mutation escaped: ' + label
        print('PASS mutation rejected: ' + label)
