#!/usr/bin/env python3
"""Run as ordinary Termux; requests root only for management and root controls.

Checkpoint 19, SM-S948B BZIG. Uses two app-created files and retains the same
app mappings through baseline, hiding and restoration. Never clears other rules.
"""
import ctypes as ct
import json
import mmap
import os
from pathlib import Path
import re
import shlex
import signal
import subprocess
import sys
import tempfile

KERNEL = '6.12.69-android16-6-pb4d3caf-abogkiS948BXXS4BZIG-4k'
RULES = '/sys/module/susfs_guard_lkm/parameters/map_rules'
STATS = '/sys/module/susfs_guard_lkm/parameters/map_stat'
TARGET_BYTES = 4 * 1024 * 1024
CONTROL_BYTES = 64 * 1024
ROOT_TIMEOUT = 30

class RootCommandTimeout(RuntimeError):
    """The command may still be blocked in the kernel; its outcome is unknown."""

# The root reader executes these same routines in its own process and mappings.
COMMON = r'''
import ctypes as ct
import json
import mmap
import os
from pathlib import Path
import re
import struct
import stat as statmod
import sys
import threading
import time

HEADER = re.compile(r'^([0-9a-f]+)-([0-9a-f]+)\s+(\S+)\s+([0-9a-f]+)\s+([0-9a-f]+):([0-9a-f]+)\s+(\d+)(?:\s+(.*))?$')
_cold_sequence = 0

class Iovec(ct.Structure):
    _fields_ = [('base', ct.c_void_p), ('length', ct.c_size_t)]

def mapping(path):
    stat = os.stat(path)
    with open(path, 'rb') as f:
        view = mmap.mmap(f.fileno(), stat.st_size, flags=mmap.MAP_PRIVATE,
                         prot=mmap.PROT_READ | mmap.PROT_WRITE)
    address = ct.addressof(ct.c_char.from_buffer(view))
    page = os.sysconf('SC_PAGE_SIZE')
    checksum = sum(view[i] for i in range(0, stat.st_size, page))
    return {'view':view, 'address':address, 'size':stat.st_size,
            'ino':stat.st_ino, 'major':os.major(stat.st_dev),
            'minor':os.minor(stat.st_dev), 'checksum':checksum, 'path':str(path)}

def matching_headers(text, item):
    result = []
    for line in text.splitlines():
        match = HEADER.match(line)
        if (match and int(match[5],16)==item['major'] and
                int(match[6],16)==item['minor'] and int(match[7])==item['ino']):
            result.append(line)
    return result

def rss(text):
    match = re.search(r'^Rss:\s+(\d+)\s+kB$',text,re.M)
    if not match:
        raise RuntimeError('Rss line missing from proc output')
    return int(match[1])

def proc_memory(item):
    try:
        fd = os.open('/proc/self/mem',os.O_RDONLY)
        try:
            data=os.pread(fd,16,item['address'])
        finally:
            os.close(fd)
        return {'bytes':len(data),'hex':data.hex(),'errno':0}
    except OSError as error:
        return {'bytes':-1,'hex':'','errno':error.errno}

def vm_memory(item):
    libc=ct.CDLL(None,use_errno=True)
    function=libc.process_vm_readv
    function.restype=ct.c_ssize_t
    function.argtypes=[ct.c_int,ct.POINTER(Iovec),ct.c_ulong,
                       ct.POINTER(Iovec),ct.c_ulong,ct.c_ulong]
    buf=ct.create_string_buffer(16)
    local=Iovec(ct.addressof(buf),16)
    remote=Iovec(item['address'],16)
    ct.set_errno(0)
    n=function(os.getpid(),ct.byref(local),1,ct.byref(remote),1,0)
    return {'bytes':n,'hex':buf.raw[:max(n,0)].hex(),
            'errno':ct.get_errno() if n<0 else 0}

def pagemap(item):
    fd=os.open('/proc/self/pagemap',os.O_RDONLY)
    try:
        data=os.pread(fd,8,(item['address']//os.sysconf('SC_PAGE_SIZE'))*8)
    finally:
        os.close(fd)
    if len(data) not in (0,8):
        raise RuntimeError('Unexpected pagemap byte count: %d'%len(data))
    value=int.from_bytes(data,'little')
    # PFNs are restricted; the present bit and read length are the assertions.
    return {'bytes':len(data),'present':bool(value & (1<<63)),
            'metadata':hex(value & (0x1ff<<55))}

def progress(label, operation):
    print('READ '+label+' '+operation, file=sys.stderr, flush=True)

def decode_dirents(data):
    names=[]
    cookies=[]
    offset=0
    while offset<len(data):
        if len(data)-offset<20:
            raise RuntimeError('Short getdents64 record')
        ino,cookie,length,kind=struct.unpack_from('<QqHB',data,offset)
        if length<24 or length%8 or offset+length>len(data):
            raise RuntimeError('Invalid getdents64 record length')
        raw=data[offset+19:offset+length]
        if b'\0' not in raw:
            raise RuntimeError('Unterminated getdents64 name')
        name=raw.split(b'\0',1)[0].decode('ascii')
        if name not in ('.','..'):
            names.append(name)
            cookies.append(cookie)
        offset+=length
    return names,cookies

def small_directory(path, deadline=None, max_batches=65536):
    # A small real getdents64 buffer exercises resumption across hidden entries.
    nr={'aarch64':61,'x86_64':217}.get(os.uname().machine)
    if nr is None:
        raise RuntimeError('Unknown getdents64 syscall architecture')
    libc=ct.CDLL(None,use_errno=True)
    libc.syscall.restype=ct.c_long
    buf=ct.create_string_buffer(128)
    names=[]
    cookies=[]
    batches=0
    fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY)
    try:
        while batches<max_batches:
            if deadline is not None and time.monotonic()>=deadline:
                raise RuntimeError('getdents64 observation deadline exceeded')
            ct.set_errno(0)
            n=libc.syscall(ct.c_long(nr),ct.c_int(fd),ct.byref(buf),ct.c_uint(len(buf)))
            if n<0:
                raise OSError(ct.get_errno(),'getdents64')
            if not n:
                return names,cookies,batches
            batch,positions=decode_dirents(buf.raw[:n])
            names.extend(batch)
            cookies.extend(positions)
            batches+=1
        raise RuntimeError('getdents64 did not reach EOF')
    finally:
        os.close(fd)

def link_access(item):
    link='/proc/self/map_files/%x-%x'%(item['address'],item['address']+item['size'])
    result={}
    for name,follow in (('lstat',False),('stat_follow',True)):
        try:
            value=os.stat(link,follow_symlinks=follow)
            result[name]={'errno':0,'ino':value.st_ino,'dev':value.st_dev,'mode':value.st_mode}
        except OSError as error:
            result[name]={'errno':error.errno}
    # Linux UAPI O_PATH=010000000 on the supported ARM64/x86_64 ABIs;
    # some Android Python builds omit the optional os constant.
    opath=getattr(os,'O_PATH',0o10000000)
    for name,flags in (('opath_nofollow',opath|os.O_NOFOLLOW),('open_follow',os.O_RDONLY)):
        try:
            fd=os.open(link,flags|os.O_CLOEXEC)
            try:
                value=os.fstat(fd)
                entry={'errno':0,'ino':value.st_ino,'dev':value.st_dev,'mode':value.st_mode}
                if name=='open_follow': entry['hex']=os.pread(fd,16,0).hex()
                result[name]=entry
            finally:
                os.close(fd)
        except OSError as error:
            result[name]={'errno':error.errno}
    return result

def cold_alias_access(item):
    # Create this alias after directory/maps observations. Its first procfs
    # access is lstat by the exact name, without warming it through readdir.
    # Different lengths make the names distinct across phases even if mmap
    # reuses an address. All aliases close before RSS/churn comparisons.
    global _cold_sequence
    _cold_sequence += 1
    length = os.sysconf('SC_PAGE_SIZE') * _cold_sequence
    if length > item['size']:
        raise RuntimeError('Fresh-range alias exceeds the owned fixture')
    with open(item['path'], 'rb') as source:
        with mmap.mmap(source.fileno(), length, flags=mmap.MAP_PRIVATE,
                       prot=mmap.PROT_READ | mmap.PROT_WRITE) as view:
            address = ct.addressof(ct.c_char.from_buffer(view))
            alias = {'address': address, 'size': length}
            return {'range': '%x-%x' % (address, address + length),
                    'access': link_access(alias)}

def changing_directory(items,label):
    # Only unrelated control aliases change. Target/control mappings stay live.
    # Native directory walks are not atomic snapshots: duplicates/omissions
    # during mutation are diagnostic, not stable-walk correctness assertions.
    stop=threading.Event(); ready=threading.Event(); changes=[0]; problems=[]
    def mutate():
        try:
            with open(items['control']['path'],'rb') as source:
                ready.set()
                for _ in range(256):
                    if stop.is_set(): break
                    with mmap.mmap(source.fileno(),os.sysconf('SC_PAGE_SIZE'),
                                   flags=mmap.MAP_PRIVATE,prot=mmap.PROT_READ):
                        changes[0]+=1
                        stop.wait(0.001)
                    changes[0]+=1
        except BaseException as error:
            problems.append(str(error)); ready.set()
    thread=threading.Thread(target=mutate,daemon=True)
    result={'passes':0,'changes_during_observation':0,'target_rows':0,
            'control_rows':0,'duplicate_names':0,'duplicate_cookies':0}
    target='%x-%x'%(items['target']['address'],items['target']['address']+items['target']['size'])
    control='%x-%x'%(items['control']['address'],items['control']['address']+items['control']['size'])
    thread.start()
    try:
        if not ready.wait(2): raise RuntimeError('Mapping-change worker did not start')
        before=changes[0]; deadline=time.monotonic()+8
        for index in range(12):
            progress(label,'map_files with changing control aliases pass '+str(index+1))
            names,cookies,_=small_directory('/proc/self/map_files',deadline,max_batches=4096)
            result['passes']+=1
            result['target_rows']+=names.count(target)
            result['control_rows']+=names.count(control)
            result['duplicate_names']+=len(names)-len(set(names))
            result['duplicate_cookies']+=len(cookies)-len(set(cookies))
            if changes[0]>before: result['changes_during_observation']=changes[0]-before
        if problems: raise RuntimeError('Mapping-change worker failed: '+problems[0])
        return result
    finally:
        stop.set(); thread.join(2)
        if thread.is_alive(): raise RuntimeError('Mapping-change worker did not stop')

def probe(items, label):
    progress(label, '/proc/self/maps')
    maps=Path('/proc/self/maps').read_text()
    progress(label, '/proc/self/smaps')
    smaps=Path('/proc/self/smaps').read_text()
    progress(label, '/proc/self/smaps_rollup')
    rollup=rss(Path('/proc/self/smaps_rollup').read_text())
    result={'uid':os.geteuid(),'pid':os.getpid(),'rollup_rss_kb':rollup}
    progress(label, '/proc/self/map_files listdir')
    names=[]
    listing_error=0
    try:
        names=os.listdir('/proc/self/map_files')
    except OSError as error:
        listing_error=error.errno
    progress(label, '/proc/self/map_files getdents64 (128-byte buffer)')
    short_names=[]
    short_cookies=[]
    short_batches=0
    short_error=0
    try:
        short_names,short_cookies,short_batches=small_directory('/proc/self/map_files')
    except OSError as error:
        short_error=error.errno
    result['map_files_access_errno']={'listdir':listing_error,'getdents64':short_error}
    result['map_files_small_batches']=short_batches
    result['map_files_small_duplicate_names']=len(short_names)-len(set(short_names))
    result['map_files_small_duplicate_cookies']=len(short_cookies)-len(set(short_cookies))
    for name,item in items.items():
        headers=matching_headers(maps,item)
        sheaders=matching_headers(smaps,item)
        own_rss=0
        for header in sheaders:
            block=smaps.split(header+'\n',1)[1]
            own_rss+=rss(block)
        link='/proc/self/map_files/%x-%x'%(item['address'],item['address']+item['size'])
        range_name=link.rsplit('/',1)[1]
        progress(label, name+' map_files readlink')
        try:
            link_value=os.readlink(link)
            link_error=0
        except OSError as error:
            link_value=''
            link_error=error.errno
        progress(label, name+' pagemap')
        page_data=pagemap(item)
        progress(label, name+' /proc/self/mem pread')
        mem_data=proc_memory(item)
        progress(label, name+' process_vm_readv')
        vm_data=vm_memory(item)
        progress(label, name+' known map_files metadata and follow/open')
        access=link_access(item)
        result[name]={'address':hex(item['address']),'size':item['size'],
                      'ino':item['ino'],'dev':'%x:%x'%(item['major'],item['minor']),
                      'maps_rows':len(headers),'smaps_rows':len(sheaders),
                      'smaps_rss_kb':own_rss,
                      'map_files_listing_rows':names.count(range_name) if not listing_error else None,
                      'map_files_small_rows':short_names.count(range_name) if not short_error else None,
                      'map_files_link':link_value,'map_files_errno':link_error,
                      'pagemap':page_data,'mem':mem_data,
                      'process_vm_readv':vm_data,
                      'map_files_direct':access,
                      'direct_hex':item['view'][:16].hex()}
    for name,item in items.items():
        progress(label, name+' fresh-range map_files metadata and follow/open (lstat first)')
        cold=cold_alias_access(item)
        result[name]['map_files_cold']=cold['access']
        result[name]['map_files_cold_range']=cold['range']
    result['map_files_changes']=changing_directory(items,label)
    return result
'''
exec(COMMON, globals())

def root(command, progress=False):
    # Root readers keep stdout as JSON and inherit stderr for live markers.
    # subprocess.run's context manager waits for its direct child on timeout.
    # A root child that cannot be killed/reaped can therefore wait indefinitely.
    # Bound both waits and use regular output files to avoid descendant pipe
    # ownership coupling. A timeout does not prove that a root write was stopped.
    with tempfile.TemporaryFile(mode='w+t') as output, tempfile.TemporaryFile(mode='w+t') as error:
        proc=subprocess.Popen(['su','-c',command],stdin=subprocess.DEVNULL,
                              stdout=output,stderr=None if progress else error,
                              text=True,start_new_session=True)
        try:
            proc.wait(timeout=ROOT_TIMEOUT)
        except subprocess.TimeoutExpired:
            try:
                proc.kill()
            except (ProcessLookupError,PermissionError):
                pass
            try:
                proc.wait(timeout=1)
            except subprocess.TimeoutExpired:
                pass
            raise RootCommandTimeout('Root command timed out after %s seconds; its outcome is unknown. '
                                     'Capture the blocked process, then fully reboot before changing rules.'%ROOT_TIMEOUT)
        output.seek(0)
        error.seek(0)
        if proc.returncode:
            raise RuntimeError('Root command failed (%d): %s'%(proc.returncode,error.read().strip()))
        return output.read()

def read_rules():
    text=root('cat '+RULES)
    lines=text.splitlines()
    match=re.fullmatch(r'rules=(\d+)/64',lines[0] if lines else '')
    if not match:
        raise RuntimeError('Checkpoint 19 map_rules control missing or invalid: '+text.strip())
    entries=[]
    for line in lines[1:]:
        row=re.fullmatch(r'ino=(\d+) dev=(\d+)',line)
        if not row:
            raise RuntimeError('Invalid rule identity: '+line)
        entries.append((int(row[1]),int(row[2])))
    if len(entries)!=int(match[1]):
        raise RuntimeError('Rule count does not agree with entries')
    return entries

def write_rule(operation,path):
    print('WRITE '+operation.upper()+' target rule',flush=True)
    try:
        root("printf '%s\\n' "+shlex.quote(operation+' '+str(path))+' > '+RULES)
    except RootCommandTimeout:
        raise
    except RuntimeError:
        # The writer exited, so the parameter lock was released. Preserve the
        # precise installation stage before cleanup; root() still bounds this
        # diagnostic read. A timed-out writer must never take this path.
        print('\nRULE-WRITE FAILURE DIAGNOSTICS:\n'+root('cat '+STATS),flush=True)
        raise
    print('WRITE '+operation.upper()+' returned',flush=True)

def errors(snapshot,visible,label):
    found=[]
    for method,number in snapshot['map_files_access_errno'].items():
        if number:
            found.append('%s map_files %s blocked by errno %s; enumeration unqualified'%(label,method,number))
    for field in ('map_files_small_duplicate_names','map_files_small_duplicate_cookies'):
        if snapshot[field]:
            found.append(label+' '+field+'='+str(snapshot[field]))
    for name in ('target','control'):
        item=snapshot[name]
        show=visible or name=='control'
        expected=1 if show else 0
        for field in ('maps_rows','smaps_rows','map_files_listing_rows','map_files_small_rows'):
            if item[field]!=expected:
                found.append('%s %s %s=%s, expected %s'%(label,name,field,item[field],expected))
        if show:
            for field in ('map_files_direct','map_files_cold'):
                direct=item[field]
                kind='cached' if field=='map_files_direct' else 'fresh-range'
                for method in ('lstat','opath_nofollow'):
                    if not direct[method]['errno'] and not statmod.S_ISLNK(direct[method].get('mode',0)):
                        found.append(label+' '+name+' '+kind+' '+method+' is not the expected symlink')
                for method in ('stat_follow','open_follow'):
                    value=direct[method]
                    major,minor=(int(part,16) for part in item['dev'].split(':'))
                    if not value['errno'] and (value.get('ino')!=item['ino'] or value.get('dev')!=os.makedev(major,minor)):
                        found.append(label+' '+name+' '+kind+' '+method+' does not describe the mapped file')
                if not direct['open_follow']['errno'] and direct['open_follow'].get('hex')!=item['direct_hex']:
                    found.append(label+' '+name+' '+kind+' open_follow reads different file content')
            if item['smaps_rss_kb'] < item['size']//1024-16:
                found.append(label+' '+name+' mapping not fully resident in smaps')
            if item['map_files_errno'] or not item['map_files_link']:
                found.append(label+' '+name+' map_files baseline/control link unavailable')
            if item['pagemap']['bytes']!=8 or not item['pagemap']['present']:
                found.append(label+' '+name+' pagemap does not show the touched page')
            for method in ('mem','process_vm_readv'):
                if item[method]['bytes']!=16 or item[method]['hex']!=item['direct_hex']:
                    found.append(label+' '+name+' '+method+' cannot read the known bytes')
        else:
            if item['map_files_errno']!=2:
                found.append(label+' target map_files readlink did not return ENOENT')
            if item['pagemap']['metadata']!='0x0':
                found.append(label+' target pagemap still exposes page metadata')
            for method in ('mem','process_vm_readv'):
                data=item[method]
                if not (data['bytes']==0 or (data['bytes']<0 and data['errno'] in (5,14))):
                    found.append(label+' target '+method+' still reads or returned an unexpected error')
    change=snapshot['map_files_changes']
    if change['passes']!=12 or change['changes_during_observation']<=0:
        found.append(label+' concurrent mapping changes were not observed; scope unqualified')
    if not visible and change['target_rows']:
        found.append(label+' changing-directory walk exposed the stable hidden target')
    return found

def direct_errors(baseline,current,visible,label):
    found=[]; blocked=[]
    for name in ('target','control'):
        show=visible or name=='control'
        for field in ('map_files_direct','map_files_cold'):
            kind='cached' if field=='map_files_direct' else 'fresh-range'
            for method in ('lstat','opath_nofollow','stat_follow','open_follow'):
                before=baseline[name][field][method]
                after=current[name][field][method]
                if before['errno']:
                    blocked.append('%s %s %s %s baseline errno=%d; scope unqualified'%(label,name,kind,method,before['errno']))
                    if show and after['errno']!=before['errno']:
                        found.append(label+' '+name+' '+kind+' '+method+' changed a blocked control/baseline')
                    continue
                if not show:
                    if after['errno']!=2:
                        found.append(label+' target '+kind+' '+method+' did not return ENOENT')
                elif method in ('lstat','opath_nofollow'):
                    # Proc symlink inode numbers are not a lifetime contract,
                    # and root readers/aliases differ between phases.
                    if after['errno'] or not statmod.S_ISLNK(after.get('mode',0)):
                        found.append(label+' '+name+' '+kind+' '+method+' lost the visible symlink')
                elif after!=before:
                    found.append(label+' '+name+' '+kind+' '+method+' changed visible identity/content')
    return found,blocked

def require_checkpoint(diagnostics,active=False):
    if ('pin_calls=' not in diagnostics or 'listing: maps_calls=' not in diagnostics or
            'map_files: ready=' not in diagnostics or 'route=kprobe' not in diagnostics or
            'divert_checked=1' not in diagnostics or
            not re.search(r'^map_metadata: checkpoint=19 ready=[01]\b',diagnostics,re.M)):
        raise RuntimeError('Checkpoint 19 metadata guards missing; no test rules changed.')
    if active and (not re.search(r'^map_files: ready=1\b',diagnostics,re.M) or
                   not re.search(r'^map_metadata: checkpoint=19 ready=1\b',diagnostics,re.M)):
        raise RuntimeError('Checkpoint 19 native map_files probes were not installed.')

def display(label,snapshot):
    print('\n'+label+':',flush=True)
    print(json.dumps(snapshot,indent=2),flush=True)

def main():
    if os.geteuid()<10000:
        raise RuntimeError('Run from ordinary Termux, outside a root shell.')
    if os.uname().machine!='aarch64' or os.uname().release!=KERNEL:
        raise RuntimeError('This runner targets the SM-S948B BZIG ARM64 kernel only.')
    if not re.fullmatch(r'[A-Za-z0-9_./-]+',os.getcwd()):
        raise RuntimeError('Use your ordinary Termux home directory.')
    print('Map runner revision: 8 (CP19 cached and fresh-range metadata guards)',flush=True)
    print('App reader:',subprocess.check_output(['id'],text=True).strip(),flush=True)
    if read_rules():
        raise RuntimeError('Existing map rules found; no rules were changed. Use a clean test boot.')
    diagnostics=root('cat '+STATS)
    require_checkpoint(diagnostics)

    fixture=Path(tempfile.mkdtemp(prefix='rmgu-susfs-map.',dir=os.getcwd()))
    target=fixture/'target.bin'
    control=fixture/'control.bin'
    helper=fixture/'root-reader.py'
    items={}
    attempted=False
    management_timed_out=False
    failures=[]
    blocked=[]
    cleaned=False
    try:
        target.write_bytes(b'RMGU-map-target\n'+b'T'*(TARGET_BYTES-16))
        control.write_bytes(b'RMGU-map-control\n'+b'C'*(CONTROL_BYTES-17))
        # Keep exact whole-page lengths; markers are the direct-read controls.
        with target.open('r+b') as f: f.truncate(TARGET_BYTES)
        with control.open('r+b') as f: f.truncate(CONTROL_BYTES)
        helper.write_text(COMMON+"\nitems={'target':mapping(sys.argv[1]),'control':mapping(sys.argv[2])}\n"
                          +"print(json.dumps(probe(items,sys.argv[3])),flush=True)\n")
        for path in (target,control,helper): path.chmod(0o600)
        items={'target':mapping(target),'control':mapping(control)}
        identity=(items['target']['ino'],(items['target']['major']<<20)|items['target']['minor'])
        root_command=('/system/bin/toybox nsenter -t %d -m '%os.getpid()
                      +shlex.quote(sys.executable)+' '+shlex.quote(str(helper))+' '
                      +shlex.quote(str(target))+' '+shlex.quote(str(control)))
        probe(items,'WARMUP APP')  # Warm proc readers and ctypes before RSS comparisons.
        baseline=probe(items,'BASELINE APP')
        root_baseline=json.loads(root(root_command+" 'BASELINE ROOT'",progress=True))
        display('BASELINE APP',baseline)
        display('BASELINE ROOT',root_baseline)
        failures=errors(baseline,True,'BASELINE APP')+errors(root_baseline,True,'BASELINE ROOT')
        if failures:
            raise RuntimeError('Baseline is unsuitable: '+'; '.join(failures))
        if root_baseline['uid']!=0:
            raise RuntimeError('Root control reader was not UID 0.')

        attempted=True
        print('\nENABLE: adding only the target inode/device rule.',flush=True)
        write_rule('add',target)
        print('VERIFY: reading the published target rule.',flush=True)
        if read_rules()!=[identity]:
            raise RuntimeError('Published rule does not match the target inode/device.')
        require_checkpoint(root('cat '+STATS),active=True)
        active=probe(items,'HIDDEN APP')
        root_active=json.loads(root(root_command+" 'HIDDEN ROOT'",progress=True))
        display('HIDDEN APP',active)
        display('HIDDEN ROOT',root_active)
        print('\nACTIVE MAP DIAGNOSTICS:\n'+root('cat '+STATS),flush=True)
        failures=errors(active,False,'HIDDEN APP')+errors(root_active,True,'HIDDEN ROOT')
        for prior,now,visible,label in ((baseline,active,False,'HIDDEN APP'),
                                       (root_baseline,root_active,True,'HIDDEN ROOT')):
            direct_failures,direct_blocked=direct_errors(prior,now,visible,label)
            failures+=direct_failures; blocked+=direct_blocked
        if root_active['uid']!=0:
            failures.append('Active root control reader was not UID 0')
        if active['target']['direct_hex']!=baseline['target']['direct_hex']:
            failures.append('HIDDEN APP direct mapping content changed')
        drop=baseline['rollup_rss_kb']-active['rollup_rss_kb']
        expected=baseline['target']['smaps_rss_kb']
        print('rollup RSS decrease: %d kB; target RSS %d kB; tolerance 512 kB'%(drop,expected),flush=True)
        if abs(drop-expected)>512:
            failures.append('HIDDEN APP smaps_rollup did not exclude the resident target')

        print('\nDISABLE: removing the test rule.',flush=True)
        write_rule('del',target)
        if read_rules():
            raise RuntimeError('Rules were not restored to the empty baseline.')
        attempted=False
        restored=probe(items,'RESTORED APP')
        display('RESTORED APP',restored)
        failures+=errors(restored,True,'RESTORED APP')
        direct_failures,direct_blocked=direct_errors(baseline,restored,True,'RESTORED APP')
        failures+=direct_failures; blocked+=direct_blocked
        if abs(restored['rollup_rss_kb']-baseline['rollup_rss_kb'])>512:
            failures.append('RESTORED APP smaps_rollup RSS did not return to baseline')
        print('\nRESTORED MAP DIAGNOSTICS:\n'+root('cat '+STATS),flush=True)
    except RootCommandTimeout:
        management_timed_out=True
        raise
    finally:
        safe=True
        if attempted and management_timed_out:
            safe=False
            print('Cleanup skipped further root commands because a management command timed out; '
                  'the rule outcome is unknown.',flush=True)
        elif attempted:
            try:
                current=read_rules()
                stat=os.stat(target)
                identity=(stat.st_ino,(os.major(stat.st_dev)<<20)|os.minor(stat.st_dev))
                if identity in current:
                    write_rule('del',target)
                if identity in read_rules():
                    raise RuntimeError('Test rule is still active')
            except Exception as error:
                safe=False
                print('Cleanup could not remove the test rule: '+str(error),flush=True)
        for item in items.values(): item['view'].close()
        if safe:
            for path in (target,control,helper): path.unlink(missing_ok=True)
            fixture.rmdir()
            cleaned=True
            print('Cleanup complete; test mappings closed, test rule and fixture removed.',flush=True)
        else:
            print('Fixture retained: '+str(fixture)+'. Fully reboot before removing it.',flush=True)
    for note in dict.fromkeys(blocked): print('BLOCKED: '+note,flush=True)
    if not cleaned or failures:
        raise RuntimeError('; '.join(failures) or 'Cleanup incomplete')
    print('\n'+('PARTIAL PASS' if blocked else 'PASS')+': maps/smaps, rollup, pagemap, cached and fresh-range map_files access, changing-directory walks, memory reads, root controls, restoration and cleanup within available scopes.',flush=True)
    print('Scope: other-process exec and remapping the hidden target were not tested.',flush=True)

if __name__=='__main__':
    def interrupted(signum, frame):
        raise KeyboardInterrupt('signal %d'%signum)
    for sig in (signal.SIGTERM, signal.SIGHUP):
        signal.signal(sig, interrupted)
    try:
        main()
    except (Exception,KeyboardInterrupt) as error:
        print('\nFAIL: '+str(error),flush=True)
        raise SystemExit(1)
