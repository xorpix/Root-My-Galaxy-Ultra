#!/usr/bin/env python3
"""Qualify module-name hiding on the phone-validated CP14 BZIG setup.

Run from ordinary Termux. The original module-name list is briefly cleared
for a baseline, then restored before active checks and on exit. Permission
blocks are reported per app interface; they never count as successful hiding.
The independent symbol-prefix filter remains enabled throughout. No map,
mount, boot-identity or AVC configuration is changed.
"""
import errno
import json
import os
from pathlib import Path
import re
import shlex
import signal
import subprocess
import sys

KERNEL = '6.12.69-android16-6-pb4d3caf-abogkiS948BXXS4BZIG-4k'
CONTROL = '/proc/susfs_hide_modules'
NAME = re.compile(r'[A-Za-z0-9_-]{1,63}')
CORE_NAMES = ('init_task', 'schedule', 'do_exit')

# Root and ordinary app readers execute the same parsing and observation code.
COMMON = r'''
import errno
import json
import os
from pathlib import Path
import stat
import sys

def module_names(lines):
    names = []
    for line in lines:
        fields = line.split()
        if len(fields) < 6 or not fields[1].isdigit():
            raise RuntimeError('Malformed /proc/modules row')
        names.append(fields[0])
    if len(names) != len(set(names)):
        raise RuntimeError('Duplicate /proc/modules name')
    return set(names)

def symbol_counts(lines, wanted):
    counts = dict.fromkeys(wanted, 0)
    core = dict.fromkeys(('init_task', 'schedule', 'do_exit'), 0)
    for line in lines:
        fields = line.split()
        if len(fields) not in (3, 4):
            raise RuntimeError('Malformed /proc/kallsyms row')
        if len(fields) == 4:
            tag = fields[3]
            if not (tag.startswith('[') and tag.endswith(']')):
                raise RuntimeError('Malformed kallsyms module tag')
            name = tag[1:-1]
            if name in counts:
                counts[name] += 1
        elif fields[2] in core:
            core[fields[2]] += 1
    return counts, core

def permission_read(reader):
    try:
        return reader(), 0
    except OSError as error:
        if error.errno not in (errno.EACCES, errno.EPERM):
            raise
        return None, error.errno

def read_modules():
    with open('/proc/modules') as f:
        return sorted(module_names(f))

def read_symbols(names):
    with open('/proc/kallsyms') as f:
        return symbol_counts(f, names)

def permission_diagnostics():
    result = {}
    getxattr = getattr(os, 'getxattr', None)
    for path in ('/proc/modules', '/proc/kallsyms', '/sys/module'):
        row = {}
        try:
            info = os.stat(path)
            row.update(mode=oct(stat.S_IMODE(info.st_mode)), uid=info.st_uid,
                       gid=info.st_gid)
        except OSError as error:
            row['stat_errno'] = error.errno
        if callable(getxattr):
            try:
                row['selinux_label'] = getxattr(path, 'security.selinux').decode(errors='replace').rstrip('\x00')
            except OSError as error:
                row['label_errno'] = error.errno
            except (AttributeError, NotImplementedError) as error:
                row['label_unavailable'] = type(error).__name__
        else:
            row['label_unavailable'] = 'os.getxattr is not provided by this Python build'
        result[path] = row
    for key, path in (('reader_context', '/proc/self/attr/current'),
                      ('selinux_enforce', '/sys/fs/selinux/enforce')):
        try:
            result[key] = Path(path).read_text(errors='replace').strip().rstrip('\x00')
        except OSError as error:
            result[key] = {'errno': error.errno}
    return result

def observe(names, label, diagnostics=False):
    print('READ ' + label + ' /proc/modules', file=sys.stderr, flush=True)
    modules, modules_errno = permission_read(read_modules)
    print('READ ' + label + ' /proc/kallsyms', file=sys.stderr, flush=True)
    symbol_data, symbols_errno = permission_read(lambda: read_symbols(names))
    symbols, core = symbol_data if symbol_data is not None else (None, None)
    print('READ ' + label + ' /sys/module', file=sys.stderr, flush=True)
    listed, sysfs_errno = permission_read(lambda: os.listdir('/sys/module'))
    sysfs = {}
    for name in names:
        try:
            info = os.stat('/sys/module/' + name)
            result = {'errno': 0, 'directory': stat.S_ISDIR(info.st_mode)}
        except OSError as e:
            result = {'errno': e.errno, 'directory': False}
        result['listed'] = name in listed if listed is not None else None
        sysfs[name] = result
    result = {'uid': os.geteuid(), 'pid': os.getpid(),
              'modules': modules, 'sysfs_list': sorted(listed) if listed is not None else None,
              'symbols': symbols, 'core': core, 'sysfs': sysfs,
              'access_errno': {'modules': modules_errno, 'symbols': symbols_errno,
                               'sysfs_list': sysfs_errno}}
    if diagnostics:
        print('READ ' + label + ' optional permission diagnostics', file=sys.stderr, flush=True)
        # These details explain access blocks; no visibility assertion depends
        # on them. Python builds may omit optional OS APIs, including Termux's
        # getxattr. A diagnostic failure must not discard the measured reads.
        try:
            result['permissions'] = permission_diagnostics()
        except Exception as error:
            result['permissions'] = {'unavailable': type(error).__name__, 'detail': str(error)}
    return result
'''
exec(COMMON, globals())

def root(command, live=False):
    proc = subprocess.run(['su', '-c', command], input='', text=True,
                          stdout=subprocess.PIPE,
                          stderr=None if live else subprocess.PIPE, timeout=45)
    if proc.returncode:
        raise RuntimeError('Root command failed (%d): %s' %
                           (proc.returncode, (proc.stderr or '').strip()))
    return proc.stdout

def parse_config(text):
    lines = text.splitlines()
    if not lines or not re.match(r'^hide_modules: \d+/16 name\(s\), ', lines[0]):
        raise RuntimeError('SusFS module control missing or invalid')
    rows = [line for line in lines if line.startswith('names:')]
    if len(rows) != 1:
        raise RuntimeError('Module control must have exactly one names line')
    names = tuple(rows[0][len('names:'):].split())
    count = int(re.match(r'^hide_modules: (\d+)', lines[0])[1])
    if len(names) != count or count > 16:
        raise RuntimeError('Module count disagrees with names')
    if not all(NAME.fullmatch(name) for name in names):
        raise RuntimeError('Unsupported configured module name; no change made')
    return names

def read_config():
    return parse_config(root('cat ' + CONTROL))

def write_config(names):
    command = 'set ' + ' '.join(names) if names else 'clear'
    root("printf '%s\\n' " + shlex.quote(command) + ' > ' + CONTROL)
    if read_config() != tuple(names):
        raise RuntimeError('Module-name readback does not match requested list')

def root_observe(names, label, diagnostics=False):
    code = COMMON + '\nprint(json.dumps(observe(%r, %r, %r)))\n' % (list(names), label, diagnostics)
    result = json.loads(root(shlex.quote(sys.executable) + ' -u -c ' +
                             shlex.quote(code), live=True))
    if result.get('uid') != 0:
        raise RuntimeError('Root comparison reader did not have UID 0')
    return result

INTERFACES = {'modules': '/proc/modules', 'symbols': '/proc/kallsyms',
              'sysfs_list': '/sys/module enumeration'}

def check_access(app, privileged):
    if app['uid'] < 10000 or privileged['uid'] != 0:
        raise RuntimeError('Reader privilege mismatch')
    blocked = []
    for key, path in INTERFACES.items():
        if privileged[key] is None or privileged['access_errno'][key]:
            raise RuntimeError('ROOT ' + path + ' is unreadable; no qualification possible')
        rc = app['access_errno'][key]
        if app[key] is None:
            if rc not in (errno.EACCES, errno.EPERM):
                raise RuntimeError('APP ' + path + ' has an unexpected access failure')
            blocked.append('APP ' + path + ': ' + errno.errorcode[rc] +
                           ' (%d); hiding unqualified' % rc)
        elif rc:
            raise RuntimeError('APP ' + path + ' data/access status disagrees')
    return blocked

def unchanged_access(before, after, label):
    for key, path in INTERFACES.items():
        if (before[key] is None) != (after[key] is None):
            raise RuntimeError(label + ' ' + path + ' access changed; no valid baseline')

def baseline_controls(app, privileged, targets):
    blocked = check_access(app, privileged)
    visible = set(privileged['modules'])
    if app['modules'] is not None:
        visible &= set(app['modules'])
        for name in targets:
            if (name in app['modules']) != (name in privileged['modules']):
                raise RuntimeError('Baseline app/root module visibility differs: ' + name)
    loaded = [name for name in targets if name in privileged['modules']]
    if not loaded:
        raise RuntimeError('No configured target is loaded in the root baseline table')
    present, app_sysfs = [], []
    for name in targets:
        a, r = app['sysfs'][name], privileged['sysfs'][name]
        if r['errno'] not in (0, errno.ENOENT):
            raise RuntimeError('Root baseline sysfs unavailable: ' + name)
        if r['errno'] == 0:
            if not r['directory'] or not r['listed']:
                raise RuntimeError('Root baseline sysfs directory/list mismatch: ' + name)
            present.append(name)
            if app['sysfs_list'] is None:
                continue
            if a['errno'] in (errno.EACCES, errno.EPERM):
                blocked.append('APP /sys/module/' + name + ': ' +
                               errno.errorcode[a['errno']] + '; stat hiding unqualified')
            elif a['errno'] != 0 or not a['directory'] or not a['listed']:
                raise RuntimeError('App baseline sysfs unreadable before hiding: ' + name)
            else:
                app_sysfs.append(name)
        elif r['listed']:
            raise RuntimeError('Root baseline missing sysfs path is still listed: ' + name)
    symbol_targets = [name for name in loaded if privileged['symbols'][name] > 0]
    if app['symbols'] is not None:
        symbol_targets = [name for name in symbol_targets if app['symbols'][name] > 0]
    if not symbol_targets:
        raise RuntimeError('No baseline target module symbols; cannot prove filtering')
    candidates = sorted(visible - set(targets))
    candidates = [name for name in candidates if NAME.fullmatch(name) and
                  name in privileged['sysfs_list'] and
                  (app['sysfs_list'] is None or name in app['sysfs_list'])]
    if not candidates:
        raise RuntimeError('No visible unrelated module control')
    core = next((name for name in CORE_NAMES if
                 privileged['core'][name] > 0 and
                 (app['core'] is None or app['core'][name] > 0)), None)
    if core is None:
        raise RuntimeError('No readable unrelated core symbol control')
    if not present:
        raise RuntimeError('No existing target sysfs directory; hiding is untested')
    return {'loaded': loaded, 'symbol_targets': symbol_targets,
            'module': candidates[0], 'core': core, 'present_sysfs': present,
            'app_sysfs': app_sysfs, 'blocked': blocked,
            'access': {'APP': {key: app[key] is not None for key in INTERFACES},
                       'ROOT': dict.fromkeys(INTERFACES, True)}}

def active_errors(app, privileged, targets, controls):
    errors = []
    if app['uid'] < 10000 or privileged['uid'] != 0:
        errors.append('active reader privilege mismatch')
    for label, snapshot in (('APP', app), ('ROOT', privileged)):
        usable = {}
        for key, path in INTERFACES.items():
            usable[key] = snapshot[key] is not None
            if usable[key] != controls['access'][label][key]:
                errors.append(label + ' ' + path + ' access changed; cannot qualify hiding')
            if not usable[key] and snapshot['access_errno'][key] not in (errno.EACCES, errno.EPERM):
                errors.append(label + ' ' + path + ' has an unexpected access failure')
            if usable[key] and snapshot['access_errno'][key]:
                errors.append(label + ' ' + path + ' data/access status disagrees')
        if usable['modules']:
            for name in targets:
                if name in snapshot['modules']:
                    errors.append(label + ' /proc/modules exposes ' + name)
            if controls['module'] not in snapshot['modules']:
                errors.append(label + ' unrelated module control disappeared')
        if usable['symbols']:
            for name in targets:
                if snapshot['symbols'][name] != 0:
                    errors.append(label + ' /proc/kallsyms exposes [' + name + ']')
            if snapshot['core'][controls['core']] <= 0:
                errors.append(label + ' unrelated core symbol disappeared')
        if usable['sysfs_list']:
            c = snapshot['sysfs'][controls['module']]
            if c['errno'] != 0 or not c['directory'] or not c['listed']:
                errors.append(label + ' unrelated sysfs control disappeared')
    for name in controls['present_sysfs']:
        a, r = app['sysfs'][name], privileged['sysfs'][name]
        if name in controls['app_sysfs'] and (a['errno'] != errno.ENOENT or a['listed']):
            errors.append('APP target sysfs must return ENOENT and be unlisted: ' + name)
        if r['errno'] != 0 or not r['directory'] or not r['listed']:
            errors.append('ROOT management sysfs was hidden: ' + name)
    return errors

def concise(snapshot, names, controls=None):
    # Do not print the phone's full unrelated module/symbol inventory.
    result = {'uid': snapshot['uid'], 'pid': snapshot['pid'],
              'access_errno': snapshot['access_errno'], 'targets': {}}
    for name in names:
        result['targets'][name] = {
            'proc_modules_rows': int(name in snapshot['modules']) if snapshot['modules'] is not None else None,
            'kallsyms_module_rows': snapshot['symbols'][name] if snapshot['symbols'] is not None else None,
            'sysfs': snapshot['sysfs'][name]}
    if controls:
        name = controls['module']
        result['control'] = {'module': name,
                             'proc_modules_rows': int(name in snapshot['modules']) if snapshot['modules'] is not None else None,
                             'sysfs': snapshot['sysfs'][name],
                             'core_symbol': controls['core'],
                             'core_symbol_rows': snapshot['core'][controls['core']] if snapshot['core'] is not None else None}
    return result

def final_status(controls):
    scopes = ['ROOT /proc/modules', 'ROOT /proc/kallsyms', 'ROOT sysfs management']
    for key in ('modules', 'symbols'):
        if controls['access']['APP'][key]:
            scopes.append('APP ' + INTERFACES[key])
    if controls['app_sysfs']:
        scopes.append('APP existing-target sysfs hiding')
    prefix = 'PARTIAL PASS' if controls['blocked'] else 'PASS'
    result = prefix + ': ' + ', '.join(scopes) + '; unrelated controls and exact list restoration.'
    if controls['blocked']:
        result += ' Blocked app scopes remain unqualified.'
    return result

class ModuleListLease:
    def __init__(self, names, reader=read_config, writer=write_config):
        self.names = tuple(names)
        self.reader = reader
        self.writer = writer
        self.dirty = False
        self.touched = False

    def __enter__(self):
        if self.reader() != self.names:
            raise RuntimeError('Module list changed before test; no change made')
        return self

    def clear(self):
        self.touched = True
        self.dirty = True  # Include a failed or partially applied write in cleanup.
        self.writer(())

    def restore(self):
        self.writer(self.names)
        if self.reader() != self.names:
            raise RuntimeError('Original module list was not restored')
        self.dirty = False

    def __exit__(self, exc_type, exc, tb):
        if not self.touched:
            return False
        previous = {sig: signal.getsignal(sig) for sig in
                    (signal.SIGINT, signal.SIGTERM, signal.SIGHUP)}
        try:
            for sig in previous:
                signal.signal(sig, signal.SIG_IGN)
            if self.dirty or self.reader() != self.names:
                self.restore()
        finally:
            for sig, handler in previous.items():
                signal.signal(sig, handler)
        return False

def interrupted(signum, frame):
    raise KeyboardInterrupt('Signal %d' % signum)

def main():
    if os.geteuid() < 10000:
        raise RuntimeError('Run from ordinary Termux, outside a root shell')
    if os.uname().machine != 'aarch64' or os.uname().release != KERNEL:
        raise RuntimeError('This runner targets the SM-S948B BZIG ARM64 kernel')
    print('Module runner revision: 3 (CP14 portable optional diagnostics)', flush=True)
    print('App reader:', subprocess.check_output(['id'], text=True).strip(), flush=True)
    names = read_config()
    if not names:
        raise RuntimeError('No module names configured; no configuration changed')
    print('Saved original names:', ' '.join(names), flush=True)
    print('Module tables are filtered for app and root; root retains sysfs management.',
          flush=True)
    print('\nPREFLIGHT: read-only access checks before changing any rules.', flush=True)
    app_preflight = observe(names, 'PREFLIGHT APP', diagnostics=True)
    root_preflight = root_observe(names, 'PREFLIGHT ROOT', diagnostics=True)
    print('APP ACCESS ERRNO:', json.dumps(app_preflight['access_errno']), flush=True)
    print('ROOT ACCESS ERRNO:', json.dumps(root_preflight['access_errno']), flush=True)
    blocked = check_access(app_preflight, root_preflight)
    if blocked:
        for message in blocked:
            print('BLOCKED: ' + message, flush=True)
        print('APP PERMISSION DIAGNOSTICS:', json.dumps(app_preflight['permissions'], indent=2), flush=True)
        print('ROOT PERMISSION DIAGNOSTICS:', json.dumps(root_preflight['permissions'], indent=2), flush=True)
        print('Permission causes are not inferred from errno alone. No policy or modes changed.', flush=True)
    for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
        signal.signal(sig, interrupted)
    cleanup_ok = False
    lease = ModuleListLease(names)
    try:
        with lease:
            print('\nBASELINE: briefly clearing only the module-name list.', flush=True)
            lease.clear()
            app = observe(names, 'BASELINE APP')
            privileged = root_observe(names, 'BASELINE ROOT')
            unchanged_access(app_preflight, app, 'APP')
            unchanged_access(root_preflight, privileged, 'ROOT')
            print('BASELINE APP:', json.dumps(concise(app, names), indent=2), flush=True)
            print('BASELINE ROOT:', json.dumps(concise(privileged, names), indent=2), flush=True)
            controls = baseline_controls(app, privileged, names)
            for message in controls['blocked']:
                print('BLOCKED BASELINE: ' + message, flush=True)
            for name in names:
                if name not in controls['symbol_targets']:
                    print('SYMBOL SKIP: no readable baseline symbols for [' + name +
                          ']; module-name symbol filtering is untested for this name.',
                          flush=True)
                if name not in controls['present_sysfs']:
                    print('SYSFS SKIP: /sys/module/' + name +
                          ' is absent to root; no hiding result claimed for it.', flush=True)
            print('\nRESTORE: reapplying the exact original module-name list.', flush=True)
            lease.restore()
            # Repeat metadata reads for the selected unrelated module control.
            observed_names = list(dict.fromkeys((*names, controls['module'])))
            app = observe(observed_names, 'ACTIVE APP')
            privileged = root_observe(observed_names, 'ACTIVE ROOT')
            print('ACTIVE APP:', json.dumps(concise(app, names, controls), indent=2), flush=True)
            print('ACTIVE ROOT:', json.dumps(concise(privileged, names, controls), indent=2), flush=True)
            errors = active_errors(app, privileged, names, controls)
            print('\nMODULE DIAGNOSTICS:\n' + root('cat ' + CONTROL), flush=True)
            print('Historical failed counter is diagnostic; absent root paths are not hook failures.',
                  flush=True)
            if errors:
                raise RuntimeError('; '.join(errors))
        cleanup_ok = True
    finally:
        if not lease.touched:
            print('\nNo module configuration change was made by this runner.', flush=True)
        else:
            try:
                verified = read_config() == names
            except Exception as error:
                print('\nCleanup readback failed: ' + str(error), flush=True)
                verified = False
            if verified:
                print('\nCleanup complete; exact original module-name list restored.', flush=True)
            else:
                print('\nCLEANUP FAILED: original names: ' + ' '.join(names), flush=True)
                command = "printf '%s\\n' " + shlex.quote('set ' + ' '.join(names)) + ' > ' + CONTROL
                print('Original-list restoration command: su -c ' + shlex.quote(command), flush=True)
                raise RuntimeError('Cannot verify original configuration restoration')
    if cleanup_ok:
        print('\n' + final_status(controls), flush=True)

if __name__ == '__main__':
    try:
        main()
    except (Exception, KeyboardInterrupt) as error:
        print('\nFAIL: ' + str(error), flush=True)
        raise SystemExit(1)
