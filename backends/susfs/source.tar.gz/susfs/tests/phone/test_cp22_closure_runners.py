import ctypes as ct
import importlib.util
import io
import json
import os
from pathlib import Path
import signal
import struct
import subprocess
import tempfile
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
def load(stem):
    spec=importlib.util.spec_from_file_location('cp22_'+stem,HERE/('rmgu-susfs-'+stem+'-test-cp22.py'))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
n=load('native-control');a=load('acceptance');m=load('module-assertions')

class FakeLibc:
    def __init__(self,writer,rc=0,error=0):
        def call(nr,magic1,magic2,command,pointer):
            self.args=(nr.value,magic1.value,magic2.value,command.value)
            writer(pointer.value);ct.set_errno(error);return rc
        self.syscall=call

class PayloadTests(unittest.TestCase):
    def test_production_layouts(self):n.layouts()
    def test_only_control_magics_and_error_field(self):
        p=n.KstatPayload();p.target_pathname=b'/owned';p.spoofed_ino=(1<<40)+99
        before=bytes(p)[:type(p).err.offset]
        lib=FakeLibc(lambda ptr:ct.memmove(ptr+type(p).err.offset,struct.pack('<i',-22),4))
        result=n.supercall(n.COMMANDS['static'],p,libc=lib)
        self.assertEqual((142,0xDEADBEEF,0xFAFAFAFA,0x55572),lib.args)
        self.assertEqual(-22,result['reply']);self.assertEqual(before,bytes(p)[:type(p).err.offset])
    def test_payload_corruption_is_failure(self):
        lib=FakeLibc(lambda ptr:ct.memmove(ptr,b'X',1))
        with self.assertRaisesRegex(RuntimeError,'Input payload'):n.supercall(n.COMMANDS['path'],n.PathPayload(),libc=lib)
    def test_guard_corruption_is_failure(self):
        lib=FakeLibc(lambda ptr:ct.memmove(ptr-1,b'X',1))
        with self.assertRaisesRegex(RuntimeError,'guards'):n.supercall(n.COMMANDS['path'],n.PathPayload(),libc=lib)
    def test_unhandled_payload_keeps_sentinel(self):
        lib=FakeLibc(lambda ptr:None,rc=-1,error=22)
        result=n.supercall(n.COMMANDS['unsupported1'],n.PathPayload(),libc=lib)
        self.assertEqual((-1,22,126),(result['syscall'],result['errno'],result['reply']))
    def test_query_changes_output_with_guards(self):
        def write(ptr):
            ct.memmove(ptr,b'v2.3.0\0',7);ct.memmove(ptr+16,struct.pack('<i',0),4)
        result=n.supercall(n.COMMANDS['version'],n.QueryPayload(),True,FakeLibc(write))
        self.assertEqual('v2.3.0',result['value'])
    def test_unknown_command_never_reaches_syscall(self):
        lib=FakeLibc(lambda ptr:None)
        with self.assertRaisesRegex(RuntimeError,'Unknown test command'):n.supercall(0x1234,n.PathPayload(),libc=lib)
        self.assertFalse(hasattr(lib,'args'))
    def test_wide_signed_profile_matches_native_representation(self):
        expected=n.static_expected(n.PROFILE)
        self.assertEqual(-4294967302765432110,expected['mtime_ns'])
        self.assertGreater(expected['ino'],1<<32);self.assertEqual(3740974081,expected['dev'])
        p=n.make_payload('static','/owned',profile=n.PROFILE)
        self.assertEqual(0xfff,p.flags);self.assertEqual(-4294967303,p.spoofed_mtime_tv_sec)
    def test_long_path_is_rejected(self):
        with self.assertRaisesRegex(RuntimeError,'exceeds payload'):n.make_payload('path','/'+'x'*256)

class StateTests(unittest.TestCase):
    def test_app_preflight_with_denied_sysctls_and_spoofed_uname(self):
        uname=os.uname_result(('Linux','phone','configured-spoof','configured-version','aarch64'))
        reads=[]
        def read(path,*args,**kwargs):
            reads.append(str(path))
            if str(path).startswith('/proc/sys/kernel/'):
                raise PermissionError(13,'Permission denied',str(path))
            self.assertEqual('/proc/self/attr/current',str(path))
            return 'u:r:untrusted_app_27:s0\0'
        for runner in (m,n,a):
            with self.subTest(runner=runner.__name__),patch.object(runner.os,'geteuid',return_value=10362),patch.object(runner.os,'uname',return_value=uname),patch.object(runner.Path,'read_text',read):
                runner.preflight()
        self.assertEqual(['/proc/self/attr/current']*3,reads)
    def test_boot_identity_requires_root_or_reuses_root_snapshot(self):
        for runner in (m,n,a):
            with self.subTest(runner=runner.__name__),patch.object(runner.os,'geteuid',return_value=10362),patch.object(runner.Path,'read_text',side_effect=PermissionError(13,'Permission denied')):
                self.assertEqual('root-collected-boot',runner.boot_id({'boot_id':'root-collected-boot'}))
                with self.assertRaisesRegex(RuntimeError,'root helper'):runner.boot_id()
            with patch.object(runner.os,'geteuid',return_value=0),patch.object(runner.Path,'read_text',return_value='native-boot\n'):
                self.assertEqual('native-boot',runner.boot_id())
    def test_avc_counters_do_not_change_config_but_enable_does(self):
        text='1 (su_sid=3204 priv_app_sid=7 enter=10 hits=2 registered=1 tsid_arg=1 abi_checked=1 checkpoint=18 last_error=0)'
        changed=text.replace('enter=10 hits=2','enter=900 hits=300')
        self.assertEqual(n.avc_config(text),n.avc_config(changed))
        disabled=text.replace('1 (','0 (',1).replace('registered=1','registered=0')
        self.assertNotEqual(n.avc_config(text),n.avc_config(disabled))
    def test_avc_registration_disagreement_is_failure(self):
        text='0 (su_sid=3204 priv_app_sid=7 enter=10 hits=2 registered=1 tsid_arg=1 abi_checked=1 checkpoint=18 last_error=0)'
        with self.assertRaisesRegex(RuntimeError,'registration disagree'):n.avc_config(text)
    def test_boot_counters_do_not_change_config_but_active_does(self):
        text='checkpoint=18 restore=1 active=1 captured=1 values=4 sets=1 resets=0 conflicts=0 last_error=0'
        changed=text.replace('sets=1 resets=0','sets=9 resets=8')
        self.assertEqual(n.boot_config(text),n.boot_config(changed))
        self.assertNotEqual(n.boot_config(text),n.boot_config(text.replace('active=1','active=0')))
    def test_redirect_proc_has_hooks_not_listing_marker(self):
        text='(empty)\nhooks: open=1 dpath=1 statfs=1 maps=1 fdinfo=1 | rev hits: dpath=0 statfs=0 maps=0/0/0 fdinfo=0/0 | su_sid=3204 | fdinfo_probes=4/4\n'
        self.assertEqual([],n.rules('redirect',text))
    def test_kstat_separates_statx_diagnostic(self):
        text='(empty)\nstatx: checkpoint=20 device_pair=1 dev_bits=32 time_bits=64\nmaps: armed=1 hits=0 rewrites=0\n'
        self.assertEqual([],n.rules('kstat',text))
    def test_kstat_rejects_unrecognized_pre_diagnostic_row(self):
        with self.assertRaisesRegex(RuntimeError,'Invalid kstat'):
            n.rules('kstat','unknown\nstatx: checkpoint=20 device_pair=1 dev_bits=32 time_bits=64\n')
    def test_truncated_path_table_cannot_be_restored(self):
        with self.assertRaisesRegex(RuntimeError,'truncated'):n.rules('path','hide_from_apps=1\n(truncated: the table holds more rules than one page; the rules are intact)\n')
    def test_duplicate_map_entries_rejected(self):
        with self.assertRaisesRegex(RuntimeError,'Duplicate'):n.rules('map','rules=2/32\nino=12 dev=3\nino=12 dev=3\n')
    def test_module_names_count(self):
        text='hide_modules: 2/16 name(s), /sys/module rules=1\nnames: kernelsu susfs_guard_lkm\n'
        self.assertEqual(['kernelsu','susfs_guard_lkm'],m.module_config(text))
    def test_foreign_rules_are_preserved(self):
        original={'rules':{'path':['path=/foreign  dev=1 ino=2 name=foreign'],'kstat':[],'map':[],'redirect':[]},'boot_id':'boot'}
        now=json.loads(json.dumps(original));now['rules']['path'].append('path=/owned  dev=1 ino=3 name=owned')
        self.assertTrue(n.owned(now,original,'path','/owned'))
        now['rules']['path']=now['rules']['path'][1:]
        with self.assertRaisesRegex(RuntimeError,'Foreign rules'):n.owned(now,original,'path','/owned')
    def test_actual_native_held_descriptor_after_unlink(self):
        native=n.NativeStat()
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory)/'old';p.write_bytes(b'old');fd=os.open(p,os.O_RDONLY)
            try:
                old=native.fstat(fd)['fields'];p.unlink();p.write_bytes(b'replacement')
                held=native.fstat(fd)['fields'];fresh=native.statx(p)['fields']
                self.assertEqual(0,held['nlink']);self.assertEqual(old['ino'],held['ino'])
                self.assertNotEqual(held['ino'],fresh['ino'])
            finally:os.close(fd)
    def test_blocked_module_inventory_does_not_write(self):
        state={'module_names':[]};view={'access_errno':{'modules':13,'symbols':0,'sysfs_list':0}}
        calls=[]
        def root(op,**args):calls.append(op);return state if op=='state' else view
        output=io.StringIO()
        with patch.object(m,'preflight'),patch.object(m,'root_call',root),patch.object(m,'module_observe',return_value=view),patch.object(m.sys,'stdout',output):
            with self.assertRaises(m.Blocked):m.run()
        self.assertNotIn('module_write',calls)
        line=next(x for x in output.getvalue().splitlines() if x.startswith('BASELINE ACCESS ERRNO:'))
        self.assertEqual({'app':view['access_errno'],'root':view['access_errno']},json.loads(line.split(':',1)[1]))
    def test_app_seccomp_is_a_blocked_baseline(self):
        with patch.object(n.subprocess,'run',return_value=subprocess.CompletedProcess([], -signal.SIGSYS,'','')):
            self.assertIn('SIGSYS',n.app_negative())
    def test_app_query_success_fails_negative_control(self):
        value=json.dumps({'syscall':0,'errno':0,'reply':0,'value':'v2.3.0'})
        with patch.object(n.subprocess,'run',return_value=subprocess.CompletedProcess([],0,value,'')):
            with self.assertRaisesRegex(RuntimeError,'acquired'):n.app_negative()

class SnapshotTests(unittest.TestCase):
    # Representative text follows CP22's production formatter contracts. It is
    # synthetic host evidence, not a claimed readback from the phone.
    def fixture(self,hide=0,prefixes=('/data/adb/',)):
        p=n.PARAMS
        files={
            p+'redirect_map_stat':'checkpoint=22 routes=2 ready=1 maps=16 smaps=16 missed=0/0\n',
            '/proc/susfs_path':'hide_from_apps=1  enoent: getattr=2 perm=2 nameop=0 meta=0\n'
                'dirent: pending=0 (counters: /proc/susfs_kstat)\n'
                'pend: passes=0 ticks=0 walks=0 lost=0 last-rc=0 caller-cred=0\n'
                'path=/sys/module/susfs_guard_lkm  dev=22 ino=232257 name=susfs_guard_lkm  [ours: clear/del refuse it]\n',
            '/proc/susfs_kstat':'(empty)\nstatx: checkpoint=20 device_pair=1 dev_bits=32 time_bits=64\n'
                'maps: armed=1 hits=24 rewrites=24\nmap_identity: checkpoint=21 routes=2 maps=12 smaps=12 missed=0/0\n',
            p+'map_rules':'rules=0/64\n',
            '/proc/susfs_open_redirect':'(empty)\nhooks: open=1 dpath=1 statfs=1 maps=1 fdinfo=1 | rev hits: dpath=42 statfs=0 maps=32/32/0 fdinfo=0/0 | su_sid=3204 | fdinfo_probes=4/4\n',
            p+'mount_stat':'idmap=3/3  ident=2/2  hide=%d su_domain=1\n'
                'show_probes=0/3 (show_vfsstat/show_mountinfo/show_vfsmnt)\n'
                'keep: prefixes=%d rescans=0\n'%(hide,len(prefixes)),
            p+'hide_mounts':'mount prefixes: %d/8, rescans=0, recorded=0, hidden_by_identity=16, learned_ids=1\n'
                'prefixes: %s\n'%(len(prefixes),' '.join(prefixes) if prefixes else '(none - only KSU-range ids are hidden)'),
            '/proc/sys/kernel/random/boot_id':'99c16129-08d5-47e9-b5b0-7f2761a4fc1c\n',
            '/proc/sys/kernel/osrelease':n.KERNEL+'\n',
            '/proc/susfs_hide_modules':'hide_modules: 2/16 name(s), /sys/module rules=1 (failed=3), /proc/modules lines removed=4, kallsyms lines removed=8008\n'
                'names: kernelsu susfs_guard_lkm\nsysfs: absent=3 errors=0 rescans=0\n',
            '/proc/susfs_enable_log':'0\n',
            '/proc/susfs_avc_spoof':'0 (su_sid=3204 priv_app_sid=3205 enter=10 hits=0 registered=0 tsid_arg=1 abi_checked=1 checkpoint=18 last_error=0)\n',
            p+'bootconfig_stat':'checkpoint=18 restore=1 active=0 captured=0 values=0 sets=0 resets=0 conflicts=0 last_error=0\n',
            '/sys/fs/selinux/enforce':'1\n',
            '/proc/cmdline':'androidboot.test=synthetic-host-fixture\n',
            '/proc/bootconfig':'androidboot.test = "synthetic-host-fixture"\n'}
        files.update({p+key:value+'\n' for key,value in {'bootconfig':'','avc_su_ctx':'u:r:ksu:s0',
            'avc_priv_app_ctx':'u:r:priv_app:s0:c512,c768','release':'','version':'',
            'uname_spoof_enabled':'N','enable_log':'N','or_su_ctx':'u:r:su:s0'}.items()})
        return files
    def collect(self,files,runner=n):
        def read(path,*args,**kwargs):return files[str(path)]
        def raw(path,*args,**kwargs):return files[str(path)].encode()
        with patch.object(runner.os,'geteuid',return_value=0),patch.object(runner.Path,'read_text',read),patch.object(runner.Path,'read_bytes',raw):
            return runner.snapshot()
    def test_complete_snapshot_uses_separate_production_interfaces(self):
        for runner in (m,n,a):
            with self.subTest(runner=runner.__name__):
                state=self.collect(self.fixture(),runner)
                self.assertEqual(0,state['mount_hide']);self.assertEqual('prefixes: /data/adb/',state['mount_prefixes'])
                self.assertEqual(n.KERNEL,state['kernel'])
                self.assertEqual(['kernelsu','susfs_guard_lkm'],state['module_names'])
                self.assertEqual([],state['rules']['kstat']);self.assertEqual([],state['rules']['map'])
    def test_empty_prefixes_and_enabled_mount_snapshot(self):
        state=self.collect(self.fixture(hide=1,prefixes=()))
        self.assertEqual(1,state['mount_hide'])
        self.assertEqual('prefixes: (none - only KSU-range ids are hidden)',state['mount_prefixes'])
    def test_full_prefix_parameter_preserves_more_than_proc_buffer(self):
        prefixes=tuple('/data/'+str(i)+'/'+'x'*105+'/' for i in range(8))
        files=self.fixture(prefixes=prefixes);self.assertGreater(len(files[n.PARAMS+'hide_mounts']),512)
        self.assertEqual('prefixes: '+' '.join(prefixes),self.collect(files)['mount_prefixes'])
    def test_changing_diagnostics_preserves_complete_snapshot(self):
        original=self.fixture();changed=dict(original)
        for key in (n.PARAMS+'mount_stat',n.PARAMS+'hide_mounts'):
            changed[key]=changed[key].replace('rescans=0','rescans=99').replace('hidden_by_identity=16','hidden_by_identity=999')
        changed['/proc/susfs_avc_spoof']=changed['/proc/susfs_avc_spoof'].replace('enter=10 hits=0','enter=500 hits=100')
        changed['/proc/susfs_hide_modules']=changed['/proc/susfs_hide_modules'].replace('lines removed=4','lines removed=400')
        self.assertEqual(self.collect(original),self.collect(changed))
    def test_real_mount_enable_change_changes_complete_snapshot(self):
        self.assertNotEqual(self.collect(self.fixture(hide=0)),self.collect(self.fixture(hide=1)))
    def test_truncated_prefix_list_is_rejected_before_controls(self):
        files=self.fixture();files[n.PARAMS+'hide_mounts']=files[n.PARAMS+'hide_mounts'].replace('1/8','2/8')
        with self.assertRaisesRegex(RuntimeError,'truncated or count differs'):self.collect(files)
    def test_root_kernel_pin_is_still_required(self):
        files=self.fixture();files['/proc/sys/kernel/osrelease']='different-native-kernel\n'
        with self.assertRaisesRegex(RuntimeError,'Root kernel mismatch'):self.collect(files)

class ReaderProcessTests(unittest.TestCase):
    def probe(self,code):
        with patch.object(n,'read_text',return_value='u:r:ksu:s0'),patch.object(n,'NON_SU_READER',code):
            return n.non_su_observe(Path('/owned'))
    def test_optional_child_signal_is_contained(self):
        parent=os.getpid()
        result=self.probe('import os,signal; os.kill(os.getpid(),signal.SIGTERM)')
        self.assertFalse(result['qualified']);self.assertIn('signal SIGTERM',result['reason'])
        self.assertEqual(parent,os.getpid())
    def test_optional_child_failure_preserves_exit_and_stderr(self):
        result=self.probe('import sys; sys.stderr.write("reader-denied"); sys.exit(7)')
        self.assertFalse(result['qualified']);self.assertIn('exit 7',result['reason'])
        self.assertIn('reader-denied',result['reason'])
    def test_optional_empty_reply_cannot_qualify_scope(self):
        result=self.probe('pass')
        self.assertFalse(result['qualified']);self.assertIn('no valid JSON',result['reason'])
    def test_optional_child_timeout_is_a_baseline_block(self):
        with patch.object(n,'read_text',return_value='u:r:ksu:s0'),patch.object(n.subprocess,'run',side_effect=subprocess.TimeoutExpired('reader',10)):
            result=n.non_su_observe(Path('/owned'))
        self.assertFalse(result['qualified']);self.assertIn('timed out',result['reason'])
    def test_success_requires_actual_non_su_identity_and_readable_controls(self):
        result={'qualified':True,'uid':0,'context':'u:r:su:s0',
                'files':{'redirect':'6161','destination':'6262','control':'6363'}}
        self.assertEqual(result,self.probe('print('+repr(json.dumps(result))+')'))
        result['context']='u:r:ksu:s0'
        self.assertFalse(self.probe('print('+repr(json.dumps(result))+')')['qualified'])
        result['context']='u:r:su:s0';result['uid']=10362
        self.assertFalse(self.probe('print('+repr(json.dumps(result))+')')['qualified'])
        result['uid']=0;del result['files']['control']
        self.assertFalse(self.probe('print('+repr(json.dumps(result))+')')['qualified'])
    def test_optional_block_continues_to_required_native_effect_and_verified_cleanup(self):
        class ReachedFeature(RuntimeError):pass
        original={'boot_id':'boot','settings':{'or_su_ctx':'u:r:ksu:s0'},
                  'rules':{key:[] for key in n.CONTROLS}}
        feature_names={'CONFIG_KSU_SUSFS_'+x for x in ('SUS_PATH','SUS_MOUNT','SUS_KSTAT','SPOOF_UNAME','ENABLE_LOG',
            'HIDE_KSU_SUSFS_SYMBOLS','SPOOF_CMDLINE_OR_BOOTCONFIG','OPEN_REDIRECT','SUS_MAP')}|{'SUSFS_GUARD_LKM_HIDE_MODULES'}
        calls=[]
        def root(op,**arguments):
            calls.append(op)
            if op=='state':return original
            if op=='queries':return {key:{'syscall':0,'reply':0,'value':value} for key,value in
                [('version','v2.3.0'),('variant','GKI'),('features','\n'.join(sorted(feature_names)))]}
            if op=='invalid':return [['unsupported1',{'syscall':-1,'errno':22,'reply':126},126]]
            if op=='setup':return {}
            if op=='reader':return {'uid':0,'context':'u:r:ksu:s0'}
            if op=='non_su':return {'qualified':False,'reason':'signal SIGTERM'}
            if op=='files':return n.read_contents(Path(arguments['cfg']['base']))
            if op=='control':raise ReachedFeature('Required native feature reached')
            if op=='cleanup':
                self.assertEqual(original,arguments['original'])
                base=Path(arguments['cfg']['base'])
                for file in base.iterdir():file.unlink()
                base.rmdir();return {'restored':True}
            raise AssertionError(op)
        output=io.StringIO()
        with tempfile.TemporaryDirectory() as home,patch.object(n.Path,'home',return_value=Path(home)),\
                patch.object(n.os,'geteuid',return_value=10362),patch.object(n,'preflight'),\
                patch.object(n,'app_negative',return_value=None),patch.object(n,'root_call',root),\
                patch.object(n,'identity',return_value={'pid':123,'starttime':1}),\
                patch.object(n,'UNKNOWN',False),patch.object(n.sys,'stdout',output),\
                patch.object(n,'require_cp22_phone_tests_enabled'):
            with self.assertRaises(ReachedFeature):n.run()
            self.assertEqual([],list(Path(home).iterdir()))
        self.assertIn('NON-SU BASELINE:',output.getvalue())
        self.assertIn('Cleanup complete;',output.getvalue())
        self.assertEqual(['state','queries','invalid','state','setup','reader','non_su','files','control','cleanup'],calls)

class RootReplyTests(unittest.TestCase):
    def setUp(self):
        self.old_unknown=n.UNKNOWN;n.UNKNOWN=False
        self.directory=tempfile.TemporaryDirectory();self.home=Path(self.directory.name)
    def tearDown(self):
        n.UNKNOWN=self.old_unknown;self.directory.cleanup()
    def invoke(self,op,rc,output,timeout=False):
        class FakeProcess:
            terminated=False
            def wait(self,timeout):
                if self_timed_out:raise subprocess.TimeoutExpired('su',timeout)
                return rc
            def terminate(self):self.terminated=True
        self_timed_out=timeout
        process=FakeProcess()
        def start(command,stdout,stderr):stdout.write(output.encode());stdout.flush();return process
        self.process=process
        with patch.object(n.Path,'home',return_value=self.home),patch.object(n.subprocess,'Popen',side_effect=start):
            return n.root_call(op)
    def retained(self,text):
        logs=list(self.home.iterdir());self.assertEqual(1,len(logs))
        self.assertEqual(text,logs[0].read_text());return str(logs[0])
    def test_read_failure_retains_exit_status_and_log(self):
        with self.assertRaises(RuntimeError) as caught:self.invoke('files',7,'read denied')
        self.assertIn('Root helper files failed (exit 7)',str(caught.exception))
        self.assertIn(self.retained('read denied'),str(caught.exception));self.assertFalse(n.UNKNOWN)
    def test_blank_signal_failure_is_diagnosable(self):
        with self.assertRaises(RuntimeError) as caught:self.invoke('non_su',-signal.SIGTERM,'')
        self.assertIn('signal SIGTERM',str(caught.exception));self.assertIn('no output',str(caught.exception))
        self.retained('');self.assertFalse(n.UNKNOWN)
    def test_missing_read_reply_is_retained(self):
        with self.assertRaisesRegex(RuntimeError,'empty reply'):self.invoke('state',0,'')
        self.retained('');self.assertFalse(n.UNKNOWN)
    def test_failed_mutation_blocks_every_later_root_call(self):
        with self.assertRaises(n.Unknown):self.invoke('control',1,'setter failed after possible change')
        self.assertTrue(n.UNKNOWN);self.retained('setter failed after possible change')
        with patch.object(n.subprocess,'Popen') as popen:
            with self.assertRaises(n.Unknown):n.root_call('cleanup')
            popen.assert_not_called()
    def test_invalid_mutation_reply_is_unknown_and_retained(self):
        with self.assertRaisesRegex(n.Unknown,'invalid JSON'):self.invoke('module_write',0,'not-json')
        self.assertTrue(n.UNKNOWN);self.retained('not-json')
    def test_timeout_stops_controls_and_retains_log(self):
        with self.assertRaises(n.Unknown):self.invoke('control',0,'partial output',timeout=True)
        self.assertTrue(n.UNKNOWN);self.assertTrue(self.process.terminated)
        self.retained('partial output')
    def test_completed_reply_removes_temporary_log(self):
        self.assertEqual({'restored':True},self.invoke('cleanup',0,'{"restored":true}\n'))
        self.assertEqual([],list(self.home.iterdir()));self.assertFalse(n.UNKNOWN)

class CrashSuspensionTests(unittest.TestCase):
    def test_native_entry_stops_before_even_preflight_or_root_calls(self):
        with patch.object(n,'preflight') as preflight,patch.object(n,'root_call') as root,\
                patch.object(n.sys,'stdout',io.StringIO()):
            with self.assertRaisesRegex(n.Blocked,'freeze/reboot'):n.run()
        preflight.assert_not_called();root.assert_not_called()
    def test_acceptance_entry_stops_before_root_or_regression(self):
        with patch.object(a,'preflight') as preflight,patch.object(a,'root_call') as root,\
                patch.object(a,'regression') as regression,patch.object(a.sys,'stdout',io.StringIO()):
            with self.assertRaisesRegex(a.Blocked,'freeze/reboot'):a.run()
        preflight.assert_not_called();root.assert_not_called();regression.assert_not_called()

class AcceptanceTests(unittest.TestCase):
    def test_pass_with_failed_exit_is_failure(self):
        with self.assertRaises(RuntimeError):a.assess_log(a.REGRESSION[0],1,'PASS: done\n')
    def test_pass_cannot_mask_fail(self):
        with self.assertRaises(RuntimeError):a.assess_log(a.REGRESSION[0],0,'FAIL: bad\nPASS: done\n')
    def test_known_mapping_follow_block_is_retained(self):
        value=a.assess_log('rmgu-susfs-map-test-cp19.py',0,'BLOCKED: RESTORED APP target cached open_follow baseline errno=1; scope unqualified\nPARTIAL PASS: done\n')
        self.assertEqual('PARTIAL PASS',value['status'])
    def test_new_mapping_block_is_failure(self):
        with self.assertRaises(RuntimeError):a.assess_log('rmgu-susfs-map-test-cp19.py',0,'BLOCKED: new read baseline errno=1; scope unqualified\nPARTIAL PASS: done\n')
    def test_other_fixture_partial_is_failure(self):
        with self.assertRaises(RuntimeError):a.assess_log(a.REGRESSION[0],0,'PARTIAL PASS: done\n')
    def test_missing_terminal_pass_is_failure(self):
        with self.assertRaises(RuntimeError):a.assess_log(a.REGRESSION[0],0,'Cleanup complete\n')
    def test_short_window_is_not_pass(self):
        with self.assertRaises(a.Blocked):a.assess_observation({'state':{'boot_id':'b'}},{'boot_id':'b'},1799,'clean')
    def test_elapsed_time_does_not_qualify_unobserved_outcome(self):
        self.assertEqual('UNQUALIFIED',a.assess_observation({'state':{'boot_id':'b'}},{'boot_id':'b'},1800,'unobserved'))
    def test_observed_issue_is_unqualified(self):
        self.assertEqual('UNQUALIFIED',a.assess_observation({'state':{'boot_id':'b'}},{'boot_id':'b'},1800,'issue'))
    def test_reboot_fails(self):
        with self.assertRaisesRegex(RuntimeError,'Boot changed'):a.assess_observation({'state':{'boot_id':'b'}},{'boot_id':'new'},2000,'clean')
    def test_changed_settings_do_not_pass(self):
        self.assertEqual('UNQUALIFIED',a.assess_observation({'state':{'boot_id':'b','rule':1}},{'boot_id':'b','rule':2},1800,'clean'))
    def test_observed_clean_unchanged_state_passes(self):
        self.assertEqual('PASS',a.assess_observation({'state':{'boot_id':'b'}},{'boot_id':'b'},1800,'clean'))
    def test_no_receipt_overwrite(self):
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory)/'receipt';a.save_receipt(p,{'first':1})
            with self.assertRaises(RuntimeError):a.save_receipt(p,{'second':2})
            self.assertEqual({'first':1},json.loads(p.read_text()))

if __name__=='__main__':unittest.main()
