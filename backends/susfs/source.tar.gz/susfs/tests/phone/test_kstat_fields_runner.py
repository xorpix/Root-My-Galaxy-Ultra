import copy
import importlib.util
import io
import json
import os
from pathlib import Path
import shlex
import struct
import tempfile
import unittest
from unittest.mock import patch


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).with_name(filename))
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


r = module('field_runner', 'rmgu-susfs-kstat-fields-test.py')
formatting = module('formatting', 'kstat_control_format.py')
FOREIGN = '/data/other ino=1 dev=22 flags=0x9 [ino=3 dev=22 nlink=1 size=4 atime=0.0 mtime=0.0 ctime=0.0 blocks=0 blksize=4096]'


def control(rules):
    return '\n'.join(rules or ['(empty)']) + '\n' + r.STATX_DIAGNOSTIC + '\nmaps: armed=1 hits=0 rewrites=0\n' + ''.join(
        'stat nr %s (%d): ok=0 rw=0 | err=0 nobuf=0 empty=0 gate=0 lookup=0 noflag=0 uacc=0\n' % pair
        for pair in [('newfstatat', 79), ('fstat', 80), ('statx', 291)])


def apply_profile(row, profile, architecture):
    """Independent UAPI buffer producer for modeled workflow/error-path tests."""
    payload = bytearray.fromhex(row['raw_hex'])
    if 'mask' in row['fields']:
        effective = row['requested_mask'] | row['fields']['mask']
        field_layout = [('ino', 32, '<Q', 0x100), ('nlink', 16, '<I', 4),
                        ('size', 40, '<Q', 0x200), ('blocks', 48, '<Q', 0x400),
                        ('blksize', 4, '<I', None), ('atime_sec', 64, '<q', 32),
                        ('atime_nsec', 72, '<I', 32), ('mtime_sec', 112, '<q', 64),
                        ('mtime_nsec', 120, '<I', 64), ('ctime_sec', 96, '<q', 128),
                        ('ctime_nsec', 104, '<I', 128)]
        for key, offset, fmt, bit in field_layout:
            if key in profile and (bit is None or effective & bit): struct.pack_into(fmt, payload, offset, profile[key])
        if 'dev' in profile and effective & 0x7ff:
            struct.pack_into('<II', payload, 136, os.major(profile['dev']), os.minor(profile['dev']))
        row['fields'] = r.decode_statx(payload)
    else:
        field_layout = [('dev', 0, '<Q'), ('ino', 8, '<Q'), ('size', 48, '<q'), ('blocks', 64, '<q'),
                        ('nlink', 20 if architecture == 'aarch64' else 16, '<I' if architecture == 'aarch64' else '<Q'),
                        ('blksize', 56, '<i' if architecture == 'aarch64' else '<q'),
                        ('atime_sec', 72, '<q'), ('atime_nsec', 80, '<Q'), ('mtime_sec', 88, '<q'),
                        ('mtime_nsec', 96, '<Q'), ('ctime_sec', 104, '<q'), ('ctime_nsec', 112, '<Q')]
        for key, offset, fmt in field_layout:
            if key in profile: struct.pack_into(fmt, payload, offset, profile[key])
        row['fields'] = r.decode_stat(payload, architecture)
    row['raw_hex'] = payload.hex()


class NativeFieldTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(); self.addCleanup(self.directory.cleanup)
        self.paths = {name: Path(self.directory.name) / name for name in ('target', 'control')}
        for path in self.paths.values(): path.write_bytes(b'owned fixture\n')
        self.held = {name: os.open(path, os.O_RDONLY) for name, path in self.paths.items()}
        self.addCleanup(lambda: [os.close(fd) for fd in self.held.values()])
        self.before = r.observe(self.paths, self.held)

    def active(self, profile):
        value = copy.deepcopy(self.before)
        for row in value['files']['target'].values(): apply_profile(row, profile, value['architecture'])
        return value

    def test_real_native_baseline_and_all_twelve_methods(self):
        self.assertEqual(12, len(self.before['files']['target']))
        app = dict(self.before, uid=10362); root = dict(self.before, uid=0)
        real = {name: r.os_fields(os.fstat(fd)) for name, fd in self.held.items()}
        r.require_baseline(app, root, real)
        self.assertEqual([], r.assess(self.before, self.before, None, 'BASELINE'))

    def test_both_full_profiles_and_partial_profile_are_accepted(self):
        for profile in r.profiles(self.before['files']['target']['fstat_held']['fields']):
            self.assertEqual([], r.assess(self.before, self.active(profile), profile, 'ACTIVE'))

    def test_every_statx_field_leak_is_detected(self):
        profile = r.profiles({'ino': 101})[0]
        for field in r.OVERRIDE_FIELDS:
            with self.subTest(field=field):
                value = self.active(profile)
                partial = dict(profile); del partial[field]
                value['files']['target']['statx_path'] = copy.deepcopy(self.before['files']['target']['statx_path'])
                apply_profile(value['files']['target']['statx_path'], partial, value['architecture'])
                self.assertTrue(r.assess(self.before, value, profile, 'ACTIVE'))

    def test_held_fstat_wide_value_leak_is_detected(self):
        profile = r.profiles({'ino': 101})[1]; value = self.active(profile)
        value['files']['target']['fstat_held'] = copy.deepcopy(self.before['files']['target']['fstat_held'])
        self.assertTrue(any('fstat_held' in message for message in r.assess(self.before, value, profile, 'ACTIVE')))

    def test_timestamp_reserved_byte_corruption_is_detected(self):
        profile = r.profiles({'ino': 101})[0]; value = self.active(profile)
        row = value['files']['target']['statx_path']; raw = bytearray.fromhex(row['raw_hex']); raw[76] ^= 1; row['raw_hex'] = raw.hex()
        self.assertTrue(any('reserved bytes' in message for message in r.assess(self.before, value, profile, 'ACTIVE')))

    def test_partial_timestamp_preserves_unselected_component(self):
        profile = {'atime_nsec': 123, 'mtime_sec': -((1 << 35) + 1)}
        value = self.active(profile)
        self.assertEqual([], r.assess(self.before, value, profile, 'ACTIVE'))
        row = value['files']['target']['statx_path']; raw = bytearray.fromhex(row['raw_hex'])
        struct.pack_into('<q', raw, 64, 999); row['raw_hex'] = raw.hex(); row['fields'] = r.decode_statx(raw)
        self.assertTrue(any('atime_ns' in message for message in r.assess(self.before, value, profile, 'ACTIVE')))

    def test_unrequested_unreturned_statx_fields_stay_native(self):
        row = copy.deepcopy(self.before['files']['target']['statx_path'])
        row['fields']['mask'] = 0x100; row['requested_mask'] = 0x100
        profile = r.profiles({'ino': 101})[0]
        wanted = r.wanted_fields(row, profile)
        self.assertEqual(profile['ino'], wanted['ino']); self.assertEqual(profile['dev'], wanted['dev'])
        self.assertEqual(profile['blksize'], wanted['blksize']); self.assertEqual(row['fields']['mtime_ns'], wanted['mtime_ns'])
        self.assertEqual(row['fields']['size'], wanted['size'])
        self.assertNotIn(40, r.allowed_bytes(row, 'aarch64', profile))

    def test_root_and_unrelated_control_spoof_are_detected(self):
        profile = r.profiles({'ino': 101})[0]
        self.assertTrue(r.assess(self.before, self.active(profile), None, 'ROOT'))
        value = self.active(profile)
        apply_profile(value['files']['control']['statx_path'], profile, value['architecture'])
        self.assertTrue(any('control' in message for message in r.assess(self.before, value, profile, 'ACTIVE')))

    def test_guard_mask_and_native_error_changes_are_detected(self):
        profile = r.profiles({'ino': 101})[0]
        for change in ('guard', 'mask', 'error'):
            value = self.active(profile)
            if change == 'guard': value['files']['target']['statx_path']['buffer_guards'] = False
            elif change == 'mask': value['files']['target']['statx_path']['fields']['mask'] ^= 0x200
            else: value['negative']['invalid_fstat']['errno'] = 14
            self.assertTrue(r.assess(self.before, value, profile, 'ACTIVE'))

    def test_missing_basic_fields_stop_before_writes(self):
        app = copy.deepcopy(self.before); app['uid'] = 10362
        app['files']['target']['statx_path']['fields']['mask'] &= ~64
        with self.assertRaisesRegex(RuntimeError, 'no rules changed'):
            r.require_baseline(app, dict(self.before, uid=0), {name:r.os_fields(os.fstat(fd)) for name,fd in self.held.items()})


class CommandTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.real = {'ino':101,'dev':22,'nlink':1,'size':19,'blocks':8,'blksize':4096,
                    'atime_ns':1000000002,'mtime_ns':3000000004,'ctime_ns':5000000006}
        cls.profiles = r.profiles(cls.real)
        cls.outputs = formatting.production_outputs(commands=[shlex.split(r.command('add','/data/test',profile)) for profile in cls.profiles])

    def test_all_profiles_roundtrip_actual_kernel_static_parser_and_proc_output(self):
        original, _ = r.parse_control(self.outputs['foreign'])
        for index, profile in enumerate(self.profiles):
            rules, _ = r.parse_control(self.outputs['command'+str(index)])
            r.verify_owned(rules, original, '/data/test', self.real, profile)
        self.assertEqual([0xfff,0xfff,0x666],[r.profile_flags(profile) for profile in self.profiles])

    def test_control_order_has_exactly_twelve_values(self):
        for profile in self.profiles:
            tokens = shlex.split(r.command('add','/data/test',profile))
            self.assertEqual(14,len(tokens))
            self.assertEqual([str(profile[field]) if field in profile else 'default' for field in r.OVERRIDE_FIELDS],tokens[2:])
        self.assertEqual('del /data/test',r.command('del','/data/test'))

    def test_signed_seconds_and_wide_devices_are_not_truncated(self):
        self.assertLess(self.profiles[1]['atime_sec'],-(1<<32))
        self.assertGreater(os.minor(self.profiles[0]['dev']),65535)
        self.assertEqual(4094,os.major(self.profiles[1]['dev']))
        self.assertGreater(self.profiles[1]['nlink'],(1<<31))
        self.assertIn(str(self.profiles[1]['atime_sec']),r.command('add','/data/test',self.profiles[1]))

    def test_bad_fields_ranges_and_paths_are_rejected(self):
        for profile in ({}, {'unknown':1}, {'atime_nsec':1000000000}, {'ctime_nsec':-1},
                        {'nlink':1<<32}, {'dev':1<<32}, {'mtime_sec':1<<63}, {'blksize':0}, {'size':-1}, {'ino':True}):
            with self.subTest(profile=profile),self.assertRaises(RuntimeError):r.command('add','/data/test',profile)
        for path in ('/data/a b','/data/a\nb','/data/'+'x'*256):
            with self.assertRaises(RuntimeError):r.command('add',path,{'ino':1})

    def test_changed_published_field_or_flag_or_foreign_rule_is_detected(self):
        original, _ = r.parse_control(self.outputs['foreign'])
        rules, _ = r.parse_control(self.outputs['command0'])
        for bad in ([rules[-1]], [rules[0],rules[1].replace('flags=0xfff','flags=0xffe')],
                    [rules[0],rules[1].replace('nlink=65537','nlink=1')]):
            with self.assertRaises(RuntimeError):r.verify_owned(bad,original,'/data/test',self.real,self.profiles[0])


class FakeControl:
    def __init__(self, failure=None, original=()):
        self.original=list(original);self.rules=list(original);self.profile=None;self.writes=[]
        self.failure=failure;self.unknown=False;self.native_observe=r.observe

    def root(self, command):
        if self.unknown:raise AssertionError('Command after unknown outcome')
        if command.startswith('cat '):return control(self.rules)
        tokens=shlex.split(command)
        if tokens[0]=='printf':
            argv=tokens[2].split();self.writes.append(argv[0]);target=argv[1]
            if argv[0]=='add_sus_kstat_statically':
                if self.failure=='unknown':self.unknown=True;raise r.RootCommandUnknown('modeled unknown ADD')
                if self.failure=='returned-error':raise RuntimeError('modeled returned ADD error')
                self.profile={field:int(value) for field,value in zip(r.OVERRIDE_FIELDS,argv[2:]) if value!='default'}
                real=r.os_fields(os.stat(target));fields=r.components(real);fields.update(self.profile)
                row=target+' ino=%d dev=%d flags=0x%x [ino=%d dev=%d nlink=%d size=%d atime=%d.%d mtime=%d.%d ctime=%d.%d blocks=%d blksize=%d]'%(
                    real['ino'],real['dev'],r.profile_flags(self.profile),*(fields[field] for field in r.OVERRIDE_FIELDS))
                self.rules=self.original+[row]
            else:
                if argv[0]!='del':raise AssertionError('Unexpected global mutation')
                self.profile=None;self.rules=list(self.original)
                if self.failure=='conflict':self.rules.append(FOREIGN)
            return ''
        with patch.object(r,'observe',self.native_observe):value=r.root_observe(json.loads(tokens[-1]))
        value['uid']=0
        if self.profile and self.failure=='root-spoof':
            for row in value['files']['target'].values():apply_profile(row,self.profile,value['architecture'])
        return json.dumps(value)

    def observe(self, paths, held):
        value=self.native_observe(paths,held);value['uid']=10362
        if self.profile:
            for name,row in value['files']['target'].items():
                if self.failure=='statx-leak' and name.startswith('statx'):continue
                apply_profile(row,self.profile,value['architecture'])
        return value


class WorkflowTests(unittest.TestCase):
    def workflow(self,failure=None,original=()):
        owner=FakeControl(failure,original)
        with tempfile.TemporaryDirectory() as directory:
            previous=os.getcwd();os.chdir(directory)
            try:
                with patch.object(r,'root',owner.root),patch.object(r,'observe',owner.observe),patch('sys.stdout',new=io.StringIO()) as output:
                    if failure:
                        with self.assertRaises(RuntimeError):r.run_fixture(list(original))
                    else:r.run_fixture(list(original))
                fixtures=list(Path(directory).glob('rmgu-susfs-kstat-fields.*'))
                if failure in ('unknown','conflict'):
                    self.assertEqual(1,len(fixtures));self.assertTrue((fixtures[0]/'original-rules.json').is_file())
                    self.assertTrue((fixtures[0]/'observations.json').is_file());self.assertNotIn('Cleanup complete',output.getvalue())
                else:self.assertEqual([],fixtures);self.assertIn('Cleanup complete',output.getvalue())
                return owner.writes,output.getvalue()
            finally:os.chdir(previous)

    def test_three_cycles_restore_empty_table_and_cleanup(self):
        writes,output=self.workflow();self.assertEqual(['add_sus_kstat_statically','del']*3,writes);self.assertIn('PASS:',output)

    def test_three_cycles_preserve_nonempty_original_rules(self):
        writes,output=self.workflow(original=[FOREIGN]);self.assertEqual(['add_sus_kstat_statically','del']*3,writes);self.assertIn(FOREIGN,output)

    def test_statx_leak_is_failed_after_cleanup(self):self.workflow('statx-leak')
    def test_root_spoof_is_failed_after_cleanup(self):self.workflow('root-spoof')
    def test_conflict_retains_evidence(self):self.workflow('conflict')

    def test_unknown_add_does_not_send_any_cleanup_commands(self):
        writes,_=self.workflow('unknown');self.assertEqual(['add_sus_kstat_statically'],writes)

    def test_returned_add_error_cleans_without_changing_other_rules(self):
        writes,_=self.workflow('returned-error',original=[FOREIGN]);self.assertEqual(['add_sus_kstat_statically'],writes)


if __name__=='__main__':unittest.main(verbosity=2)
