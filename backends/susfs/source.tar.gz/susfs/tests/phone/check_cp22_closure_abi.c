/* SPDX-License-Identifier: GPL-2.0 */
#include <stdbool.h>
#include <stddef.h>
#include "../../kernel/susfs_abi.h"
#define CHECK(type,size,off) _Static_assert(sizeof(struct type)==size,#type " size"); _Static_assert(offsetof(struct type,err)==off,#type " err")
CHECK(st_susfs_sus_path,260,256);
CHECK(st_susfs_sus_map,260,256);
CHECK(st_susfs_sus_kstat,376,372);
CHECK(st_susfs_open_redirect,520,516);
CHECK(st_susfs_version,20,16);
CHECK(st_susfs_variant,20,16);
CHECK(st_susfs_enabled_features,8196,8192);
_Static_assert(offsetof(struct st_susfs_sus_kstat,target_ino)==8,"target ino");
_Static_assert(offsetof(struct st_susfs_sus_kstat,target_pathname)==16,"target path");
_Static_assert(offsetof(struct st_susfs_sus_kstat,spoofed_ino)==272,"spoof ino");
_Static_assert(offsetof(struct st_susfs_sus_kstat,flags)==368,"flags");
_Static_assert(CMD_SUSFS_ADD_SUS_PATH==0x55550 && CMD_SUSFS_ADD_SUS_PATH_LOOP==0x55553 && CMD_SUSFS_ADD_SUS_MAP==0x60020,"path/map commands");
_Static_assert(CMD_SUSFS_ADD_SUS_KSTAT==0x55570 && CMD_SUSFS_UPDATE_SUS_KSTAT==0x55571 && CMD_SUSFS_ADD_SUS_KSTAT_STATICALLY==0x55572,"kstat commands");
_Static_assert(CMD_SUSFS_ADD_OPEN_REDIRECT==0x555c0 && CMD_SUSFS_SHOW_VERSION==0x555e1 && CMD_SUSFS_SHOW_ENABLED_FEATURES==0x555e2 && CMD_SUSFS_SHOW_VARIANT==0x555e3,"redirect/query commands");
_Static_assert(KSU_INSTALL_MAGIC1==0xDEADBEEF && SUSFS_MAGIC==0xFAFAFAFA,"control magics");
