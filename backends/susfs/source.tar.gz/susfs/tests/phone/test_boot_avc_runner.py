#!/usr/bin/env python3
"""Check CP18 runner assertions, exact bytes, restore ordering and bounded failures."""
import base64
import copy
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
from contextlib import redirect_stdout

spec=importlib.util.spec_from_file_location('runner',Path(__file__).with_name('rmgu-susfs-boot-avc-test-cp18.py'))
r=importlib.util.module_from_spec(spec); spec.loader.exec_module(r)

def raw(data): return {'errno':0,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'base64':base64.b64encode(data).decode()}
def snapshot():
 return {'uid':0,'kernel':r.KERNEL,'boot':{'active':0},'avc':{'enabled':False,'registered':0},
  'bootconfig':raw(b'original = "value"\n'),'cmdline':raw(b'original cmdline\n'),'enforce':raw(b'1\n'),'boot_id':raw(b'owned-boot-id\n'),
  'settings':dict(bootconfig='',avc_su_ctx='u:r:ksu:s0',avc_priv_app_ctx='u:r:priv_app:s0:c512,c768',release='',version='',uname_spoof_enabled='N',enable_log='Y')}

def audit_receipt():
 return {'baseline_errno':13,'active_errno':13,'worker_checks':[True]*4,'reader_pid':42,'tags':['RM18abcB','RM18abcA'],
  'baseline_audit':{'lines':['avc: denied { signull } pid=42 comm="RM18abcB" tcontext=u:r:ksu:s0 tclass=process']},
  'active_audit':{'lines':['avc: denied { signull } pid=42 comm="RM18abcA" tcontext=u:r:priv_app:s0:c512,c768 tclass=process']},
  'hits_before':3,'hits_after':4}

def verified_worker(identity,reader=None):
 if reader is None:
  reader=dict(identity,pid=r.os.getpid(),uids=[r.os.geteuid()]*4)
 return {'worker':{'errno':0,'identity':identity},'reader':{'errno':0,'identity':reader}}

class RunnerTests(unittest.TestCase):
 def test_layout_and_raw_boolean(self):
  r.APP['layout'](); self.assertEqual(2,r.APP['Flag'](2,126).enabled)
 def test_private_getter_newline_is_preserved(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'version'; p.write_bytes(b'\n\n')
   with mock.patch.dict(r.APP,PARAMS=d+'/'): self.assertEqual('\n',r.APP['param']('version'))
 def test_diagnostics_reject_inconsistent_registration(self):
  with self.assertRaisesRegex(RuntimeError,'disagree'):
   r.APP['parse_avc']('1 (su_sid=1 priv_app_sid=2 enter=0 hits=0 registered=0 tsid_arg=1 abi_checked=1 checkpoint=18 last_error=0)\n')
 def test_diagnostics_require_cp18_fields(self):
  with self.assertRaisesRegex(RuntimeError,'Missing'): r.APP['parse_boot']('active=0')
 def test_original_requires_native_baseline(self):
  saved=snapshot(); r.APP['original_ok'](saved)
  saved['boot']['active']=1
  with self.assertRaisesRegex(RuntimeError,'Invalid original'): r.APP['original_ok'](saved)
 def test_corrupt_saved_bytes_rejected(self):
  saved=snapshot(); saved['bootconfig']['base64']=base64.b64encode(b'corrupt').decode()
  with self.assertRaisesRegex(RuntimeError,'fingerprint'): r.APP['original_ok'](saved)
 def test_exact_restore_rejects_newline_and_flag(self):
  saved=snapshot(); r.APP['restoration_ok'](saved,copy.deepcopy(saved))
  for key,value in [('bootconfig',raw(b'original = "value"\n\n')),('settings',dict(saved['settings'],version='\n'))]:
   broken=copy.deepcopy(saved); broken[key]=value
   with self.assertRaises(RuntimeError): r.APP['restoration_ok'](saved,broken)
  broken=copy.deepcopy(saved); broken['avc']['enabled']=True
  with self.assertRaises(RuntimeError): r.APP['restoration_ok'](saved,broken)
 def test_rejected_bool_and_proc_inputs(self):
  writes=[]; controls=[]
  def write(path,data):
   writes.append(data); raise OSError(22,'invalid')
  with mock.patch.dict(r.APP,state=lambda:snapshot(),write=write,control=lambda *args:controls.append(args),layout=lambda:None),mock.patch.object(r.APP['os'],'geteuid',return_value=0):
   r.APP['action']('avc_invalid',{})
  self.assertEqual([b'x',b'1x',b'0junk'],writes)
  self.assertEqual(2,controls[0][1].enabled); self.assertEqual(-22,controls[0][2])
 def test_restore_attempts_both_controls_then_readback(self):
  saved=snapshot(); calls=[]
  def write(path,data): calls.append(('write',path,data))
  def state(): calls.append(('state',)); return copy.deepcopy(saved)
  with mock.patch.dict(r.APP,write=write,state=state),mock.patch.object(r.APP['os'],'geteuid',return_value=0):
   self.assertEqual(saved,r.APP['action']('restore',{'original':saved}))
  self.assertEqual([r.PARAMS+'bootconfig_reset','/proc/susfs_avc_spoof'],[item[1] for item in calls if item[0]=='write'])
  self.assertEqual(('state',),calls[-1])
 def test_restore_failure_does_not_skip_other_feature(self):
  calls=[]
  def write(path,data):
   calls.append(path)
   if 'bootconfig_reset' in path: raise OSError(16,'foreign pointer')
  with mock.patch.dict(r.APP,write=write,state=snapshot),mock.patch.object(r.APP['os'],'geteuid',return_value=0):
   with self.assertRaisesRegex(RuntimeError,'Restoration write errors'): r.APP['action']('restore',{'original':snapshot()})
  self.assertEqual(2,len(calls))
 def test_reboot_fence_rejects_restore_before_writes(self):
  saved=snapshot(); current=copy.deepcopy(saved); current['boot_id']=raw(b'another-boot\n')
  writes=[]
  with mock.patch.dict(r.APP,write=lambda *args:writes.append(args),state=lambda:current),mock.patch.object(r.APP['os'],'geteuid',return_value=0):
   with self.assertRaisesRegex(RuntimeError,'different boot'): r.APP['action']('restore',{'original':saved})
  self.assertEqual([],writes)
 def test_permission_block_cannot_qualify_app(self):
  saved=snapshot(); saved['boot']['active']=0; saved['avc'].update(su_sid=1,priv_app_sid=2)
  app={'bootconfig':{'errno':13},'cmdline':saved['cmdline']}
  with mock.patch.object(r,'app_views',return_value=app),redirect_stdout(io.StringIO()):
   r.check_views(saved,saved,app,base64.b64decode(saved['bootconfig']['base64']),'BLOCKED')
  changed=copy.deepcopy(app); changed['bootconfig']={'errno':2}
  with mock.patch.object(r,'app_views',return_value=changed),self.assertRaises(RuntimeError):
   r.check_views(saved,saved,app,base64.b64decode(saved['bootconfig']['base64']),'BAD')
 def test_unknown_completion_does_not_send_restore(self):
  saved=snapshot(); saved['avc'].update(su_sid=1,priv_app_sid=2); calls=[]
  def call(helper,name,args=None): calls.append(name); return copy.deepcopy(saved)
  app={key:saved[key] for key in ('bootconfig','cmdline')}
  with tempfile.TemporaryDirectory() as d:
   f=Path(d); helper=f/'root-helper.py'; helper.write_text('')
   with mock.patch.object(r,'preflight'),mock.patch.object(r,'fixture_new',return_value=(f,helper)),mock.patch.object(r,'call',side_effect=call),mock.patch.object(r,'app_views',return_value=app),mock.patch.object(r,'exercise',side_effect=r.ManagementUnknown('test timeout')),redirect_stdout(io.StringIO()):
    with self.assertRaises(r.ManagementUnknown): r.run()
   self.assertEqual(['preflight'],calls); self.assertTrue((f/'original-state.json').exists())
 def test_failure_still_restores_and_verifies(self):
  saved=snapshot(); saved['avc'].update(su_sid=1,priv_app_sid=2); calls=[]
  def call(helper,name,args=None): calls.append(name); return copy.deepcopy(saved)
  app={key:saved[key] for key in ('bootconfig','cmdline')}
  with tempfile.TemporaryDirectory() as d:
   f=Path(d)/'fixture'; f.mkdir(); helper=f/'root-helper.py'; helper.write_text('')
   with mock.patch.object(r,'preflight'),mock.patch.object(r,'fixture_new',return_value=(f,helper)),mock.patch.object(r,'call',side_effect=call),mock.patch.object(r,'app_views',return_value=app),mock.patch.object(r,'exercise',side_effect=RuntimeError('assertion failed')),redirect_stdout(io.StringIO()):
    with self.assertRaisesRegex(RuntimeError,'assertion failed'): r.run()
   self.assertEqual(['preflight','restore'],calls); self.assertFalse(f.exists())
 def test_failed_readback_retains_snapshot(self):
  saved=snapshot(); saved['avc'].update(su_sid=1,priv_app_sid=2)
  def call(helper,name,args=None):
   value=copy.deepcopy(saved)
   if name=='restore': value['bootconfig']=raw(b'wrong')
   return value
  app={key:saved[key] for key in ('bootconfig','cmdline')}
  with tempfile.TemporaryDirectory() as d:
   f=Path(d); helper=f/'root-helper.py'; helper.write_text('')
   with mock.patch.object(r,'preflight'),mock.patch.object(r,'fixture_new',return_value=(f,helper)),mock.patch.object(r,'call',side_effect=call),mock.patch.object(r,'app_views',return_value=app),mock.patch.object(r,'exercise',return_value=False),redirect_stdout(io.StringIO()):
    with self.assertRaisesRegex(RuntimeError,'Restoration'): r.run()
   self.assertTrue((f/'original-state.json').exists())
 def test_bounded_root_timeout(self):
  process=mock.Mock()
  process.wait.side_effect=[subprocess.TimeoutExpired('su',0.01),None]
  with mock.patch.object(r.subprocess,'Popen',return_value=process):
   with self.assertRaises(r.ManagementUnknown): r.root('owned timeout fixture')
  process.kill.assert_called_once(); self.assertEqual(2,process.wait.call_count)

 def test_audit_only_restore_never_writes_bootconfig(self):
  saved=snapshot(); saved['runner_scope']='audit_only'; writes=[]
  with mock.patch.dict(r.APP,write=lambda *args:writes.append(args),state=lambda:copy.deepcopy(saved)),mock.patch.object(r.APP['os'],'geteuid',return_value=0):
   self.assertEqual(saved,r.APP['action']('restore',{'original':saved}))
  self.assertEqual([(r.APP['AVC'],b'0')],writes)
 def test_unknown_saved_scope_rejects_before_writes(self):
  saved=snapshot(); saved['runner_scope']='unknown'; writes=[]
  with mock.patch.dict(r.APP,write=lambda *args:writes.append(args),state=snapshot),mock.patch.object(r.APP['os'],'geteuid',return_value=0):
   with self.assertRaisesRegex(RuntimeError,'scope'): r.APP['action']('restore',{'original':saved})
  self.assertEqual([],writes)
 def test_worker_wait_survives_stdin_eof_and_exits_on_release(self):
  with tempfile.TemporaryDirectory() as d:
   release=Path(d)/'audit.release'; token='0'*32
   code=r.HELPER.split("if __name__=='__main__':",1)[0]+"\nprint('READY',flush=True)\nworker_wait(Path("+repr(str(release))+"),"+repr(token)+")\n"
   process=subprocess.Popen([sys.executable,'-u','-c',code],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
   try:
    ready,_,_=r.select.select([process.stdout],[],[],3)
    self.assertTrue(ready); self.assertEqual('READY\n',process.stdout.readline())
    self.assertIsNone(process.poll())
    release.write_text(token)
    out,err=process.communicate(timeout=3)
    self.assertEqual(0,process.returncode,err)
   finally:
    if process.poll() is None: process.kill(); process.wait(timeout=3)
    process.stdout.close(); process.stderr.close()
 def test_worker_wait_has_deadline(self):
  with tempfile.TemporaryDirectory() as d,mock.patch.object(r.APP['time'],'monotonic',side_effect=[0,181]):
   with self.assertRaisesRegex(RuntimeError,'deadline'): r.APP['worker_wait'](Path(d)/'release','0'*32)
 def test_worker_wait_rejects_foreign_release(self):
  with tempfile.TemporaryDirectory() as d:
   release=Path(d)/'release'; release.write_text('wrong token')
   with self.assertRaisesRegex(RuntimeError,'token'): r.APP['worker_wait'](release,'0'*32)
 def test_worker_identity_reuse_is_not_accepted(self):
  identity={'pid':123,'uids':[10000]*4,'starttime':1234,'context':'u:r:ksu:s0','pid_namespace':'pid:[1]','pid_namespace_disabled':False,'mount_namespace':'mnt:[2]'}
  for key,value in [('starttime',1235),('context','another domain'),('uids',[0]*4),('pid_namespace','pid:[3]')]:
   changed=dict(identity); changed[key]=value
   with mock.patch.object(r,'call',return_value=verified_worker(changed)),redirect_stdout(io.StringIO()):
    self.assertFalse(r.worker_verified(Path('/private/helper'),identity,'CHECK'))
  with mock.patch.object(r,'call',return_value=verified_worker(identity)),redirect_stdout(io.StringIO()):
   self.assertTrue(r.worker_verified(Path('/private/helper'),identity,'CHECK'))
 def test_worker_exit_unknown_is_not_silently_ignored(self):
  process=mock.Mock(); process.wait.side_effect=subprocess.TimeoutExpired('owned-worker',5)
  with tempfile.TemporaryDirectory() as d:
   release=Path(d)/'release'
   with self.assertRaises(r.ManagementUnknown): r.worker_stop(process,release,'0'*32)
   self.assertEqual('0'*32,release.read_text())
  process.stdout.close.assert_called_once(); process.stderr.close.assert_called_once()
 def test_release_failure_is_unknown_and_stops_controls(self):
  process=mock.Mock()
  with mock.patch.object(Path,'write_text',side_effect=OSError(13,'cannot release')):
   with self.assertRaises(r.ManagementUnknown): r.worker_stop(process,Path('/private/release'),'0'*32)
  process.wait.assert_not_called()
 def test_dead_worker_is_not_probed_or_activated(self):
  process=mock.Mock(); info={'context':'u:r:ksu:s0','pid_namespace':r.os.readlink('/proc/self/ns/pid')}
  with tempfile.TemporaryDirectory() as d,mock.patch.object(r,'worker_start',return_value=(process,info)),mock.patch.object(r,'worker_verified',return_value=False),mock.patch.object(r,'worker_stop') as stop,mock.patch.object(r,'audit_probe') as probe,mock.patch.object(r,'call') as call,redirect_stdout(io.StringIO()):
   self.assertFalse(r.audit_exercise(Path(d)/'helper',snapshot(),Path(d)))
  call.assert_not_called(); probe.assert_not_called(); stop.assert_called_once()
 def test_complete_audit_pair_qualifies(self):
  self.assertTrue(r.audit_qualified(audit_receipt(),'u:r:ksu:s0','u:r:priv_app:s0:c512,c768'))
 def test_hit_alone_enoent_dead_worker_or_wrong_pid_cannot_qualify(self):
  cases=[]
  value=audit_receipt(); value['baseline_errno']=value['active_errno']=2; cases.append(value)
  value=audit_receipt(); value['worker_checks'][2]=False; cases.append(value)
  value=audit_receipt(); value['active_audit']['lines']=[]; cases.append(value)
  value=audit_receipt(); value['baseline_audit']['lines'][0]=value['baseline_audit']['lines'][0].replace('pid=42','pid=420'); cases.append(value)
  value=audit_receipt(); value['active_audit']['lines'][0]=value['active_audit']['lines'][0].replace('RM18abcA','other'); cases.append(value)
  value=audit_receipt(); value['hits_after']=value['hits_before']; cases.append(value)
  value=audit_receipt(); value['baseline_audit']['lines'][0]=value['baseline_audit']['lines'][0].replace('u:r:ksu:s0','u:r:ksu:s0:c1'); cases.append(value)
  for value in cases: self.assertFalse(r.audit_qualified(value,'u:r:ksu:s0','u:r:priv_app:s0:c512,c768'))
 def test_changed_denial_or_wrong_correlated_context_fails(self):
  for key,value in [('active_errno',0),('active_audit',{'lines':['avc: denied { signull } pid=42 comm="RM18abcA" tcontext=u:r:ksu:s0 tclass=process']})]:
   receipt=audit_receipt(); receipt[key]=value
   with self.assertRaises(RuntimeError): r.audit_qualified(receipt,'u:r:ksu:s0','u:r:priv_app:s0:c512,c768')
 def test_audit_only_does_not_call_full_exercise(self):
  saved=snapshot(); saved['avc'].update(su_sid=1,priv_app_sid=2); calls=[]
  def call(helper,name,args=None): calls.append((name,args)); return copy.deepcopy(saved)
  app={key:saved[key] for key in ('bootconfig','cmdline')}
  with tempfile.TemporaryDirectory() as d:
   f=Path(d)/'fixture'; f.mkdir(); helper=f/'root-helper.py'; helper.write_text('')
   with mock.patch.object(r,'preflight'),mock.patch.object(r,'fixture_new',return_value=(f,helper)),mock.patch.object(r,'call',side_effect=call),mock.patch.object(r,'app_views',return_value=app),mock.patch.object(r,'exercise') as full,mock.patch.object(r,'audit_exercise',return_value=True),redirect_stdout(io.StringIO()) as out:
    r.run(audit_only=True)
   full.assert_not_called(); self.assertEqual('audit_only',calls[1][1]['original']['runner_scope'])
   self.assertIn('no bootconfig writes',out.getvalue()); self.assertFalse(f.exists())

 def test_startup_exit_preserves_stderr_returncode_and_stage(self):
  real_popen=subprocess.Popen
  code="import sys; sys.stderr.write('worker stage=pid_namespace\\nPermissionError: denied\\n'); sys.stderr.flush(); sys.exit(7)"
  with tempfile.TemporaryDirectory() as d:
   release=Path(d)/'audit.release'; processes=[]
   def launch(args,**kwargs):
    process=real_popen([sys.executable,'-u','-c',code],**kwargs); processes.append(process); return process
   with mock.patch.object(r.subprocess,'Popen',side_effect=launch):
    with self.assertRaises(r.WorkerStartupError) as caught: r.worker_start(Path(d)/'helper',release,'0'*32)
   self.assertEqual(7,caught.exception.diagnostics['returncode'])
   self.assertIn('worker stage=pid_namespace',caught.exception.diagnostics['stderr'])
   self.assertIn('PermissionError: denied',caught.exception.diagnostics['stderr'])
   self.assertEqual('',caught.exception.diagnostics['startup_stdout'])
   self.assertFalse(caught.exception.diagnostics['stderr_limit_reached'])
   self.assertTrue(processes[0].stdout.closed); self.assertTrue(processes[0]._worker_stderr.closed)

 def test_large_stderr_does_not_block_worker_exit_and_is_capped(self):
  real_popen=subprocess.Popen
  code="import sys; sys.stderr.write('x'*65536); sys.stderr.flush(); sys.exit(8)"
  with tempfile.TemporaryDirectory() as d:
   def launch(args,**kwargs): return real_popen([sys.executable,'-u','-c',code],**kwargs)
   with mock.patch.object(r.subprocess,'Popen',side_effect=launch):
    with self.assertRaises(r.WorkerStartupError) as caught: r.worker_start(Path(d)/'helper',Path(d)/'release','0'*32)
   self.assertEqual(8,caught.exception.diagnostics['returncode'])
   self.assertEqual('x'*16384,caught.exception.diagnostics['stderr'])
   self.assertTrue(caught.exception.diagnostics['stderr_limit_reached'])

 def test_invalid_startup_json_retains_original_stdout(self):
  real_popen=subprocess.Popen
  code="import sys; print('not json',flush=True); sys.stderr.write('worker startup failed\\n')"
  with tempfile.TemporaryDirectory() as d:
   def launch(args,**kwargs): return real_popen([sys.executable,'-u','-c',code],**kwargs)
   with mock.patch.object(r.subprocess,'Popen',side_effect=launch):
    with self.assertRaises(r.WorkerStartupError) as caught: r.worker_start(Path(d)/'helper',Path(d)/'release','0'*32)
   self.assertEqual('not json\n',caught.exception.diagnostics['startup_stdout'])
   self.assertIn('worker startup failed',caught.exception.diagnostics['stderr'])

 def test_worker_helper_error_handler_prints_traceback(self):
  with tempfile.TemporaryDirectory() as d:
   helper=Path(d)/'helper.py'; helper.write_text(r.HELPER)
   args=base64.b64encode(json.dumps({'uid':'invalid','token':'0'*32}).encode()).decode()
   result=subprocess.run([sys.executable,'-u',str(helper),'worker',args],capture_output=True,text=True,timeout=3)
  self.assertEqual(1,result.returncode); self.assertEqual('',result.stdout)
  self.assertIn('Traceback (most recent call last)',result.stderr)
  self.assertNotIn('NameError',result.stderr)
  if r.os.geteuid()==0: self.assertIn('worker stage=arguments',result.stderr)

 def test_startup_collection_failure_sends_no_feature_controls(self):
  saved=snapshot(); calls=[]
  def call(helper,name,args=None): calls.append(name); return copy.deepcopy(saved)
  error=r.WorkerStartupError('startup failed',{'stderr':'worker stage=proc_context\nPermissionError','returncode':1})
  with tempfile.TemporaryDirectory() as d:
   f=Path(d); helper=f/'helper'; helper.write_text('')
   with mock.patch.object(r,'preflight'),mock.patch.object(r,'fixture_new',return_value=(f,helper)),mock.patch.object(r,'call',side_effect=call),mock.patch.object(r,'worker_start',side_effect=error),mock.patch.dict(r.APP,write=mock.Mock(side_effect=AssertionError('feature write')),control=mock.Mock(side_effect=AssertionError('feature control'))),redirect_stdout(io.StringIO()) as out:
    r.startup_collect()
   evidence=json.loads((f/'startup-evidence.json').read_text())
   self.assertEqual(['preflight','state'],calls); self.assertEqual(1,evidence['returncode'])
   self.assertFalse(evidence['feature_controls_sent']); self.assertTrue(evidence['states_unchanged'])
   self.assertTrue((f/'before.json').exists()); self.assertTrue((f/'after.json').exists())
   self.assertIn('STARTUP COLLECTION COMPLETE',out.getvalue()); self.assertNotIn('AUDIT PASS',out.getvalue())

 def test_successful_startup_collection_checks_identity_and_exit(self):
  saved=snapshot(); calls=[]; process=mock.Mock(); info={'pid':123}
  def call(helper,name,args=None): calls.append(name); return copy.deepcopy(saved)
  with tempfile.TemporaryDirectory() as d:
   f=Path(d); helper=f/'helper'; helper.write_text('')
   with mock.patch.object(r,'preflight'),mock.patch.object(r,'fixture_new',return_value=(f,helper)),mock.patch.object(r,'call',side_effect=call),mock.patch.object(r,'worker_start',return_value=(process,info)),mock.patch.object(r,'worker_verified',return_value=True) as check,mock.patch.object(r,'worker_stop',return_value={'returncode':0,'stderr':'worker stage=ready'}) as stop,redirect_stdout(io.StringIO()):
    r.startup_collect()
   evidence=json.loads((f/'startup-evidence.json').read_text())
   check.assert_called_once_with(helper,info,'STARTUP'); self.assertTrue(evidence['verified'])
   self.assertEqual(0,evidence['exit']['returncode']); self.assertEqual(['preflight','state'],calls)
   self.assertFalse(evidence['feature_controls_sent']); self.assertTrue(stop.call_args.kwargs['capture'])

 def test_unknown_startup_stops_before_state_readback(self):
  calls=[]
  def call(helper,name,args=None): calls.append(name); return snapshot()
  with tempfile.TemporaryDirectory() as d:
   f=Path(d); helper=f/'helper'; helper.write_text('')
   with mock.patch.object(r,'preflight'),mock.patch.object(r,'fixture_new',return_value=(f,helper)),mock.patch.object(r,'call',side_effect=call),mock.patch.object(r,'worker_start',side_effect=r.ManagementUnknown('unknown startup')),redirect_stdout(io.StringIO()):
    with self.assertRaises(r.ManagementUnknown): r.startup_collect()
   self.assertEqual(['preflight'],calls)
   self.assertFalse(json.loads((f/'startup-evidence.json').read_text())['feature_controls_sent'])

 def test_startup_collector_rejects_changed_native_data_without_restore(self):
  saved=snapshot(); changed=copy.deepcopy(saved); changed['bootconfig']=raw(b'changed')
  with tempfile.TemporaryDirectory() as d:
   f=Path(d); helper=f/'helper'; helper.write_text('')
   error=r.WorkerStartupError('startup failed',{'returncode':1,'stderr':'error'})
   with mock.patch.object(r,'preflight'),mock.patch.object(r,'fixture_new',return_value=(f,helper)),mock.patch.object(r,'call',side_effect=[saved,changed]) as call,mock.patch.object(r,'worker_start',side_effect=error),redirect_stdout(io.StringIO()):
    with self.assertRaisesRegex(RuntimeError,'Restoration mismatch'): r.startup_collect()
   self.assertEqual(['preflight','state'],[item.args[1] for item in call.call_args_list])
   self.assertIn('Restoration mismatch',json.loads((f/'startup-evidence.json').read_text())['error'])

 def test_unavailable_audit_collects_error_without_probe_or_control(self):
  error=r.WorkerStartupError('startup failed',{'returncode':1,'stderr':'worker stage=dumpable'})
  with tempfile.TemporaryDirectory() as d,mock.patch.object(r,'worker_start',side_effect=error),mock.patch.object(r,'audit_probe') as probe,mock.patch.object(r,'call') as call,redirect_stdout(io.StringIO()) as out:
   self.assertFalse(r.audit_exercise(Path(d)/'helper',snapshot(),Path(d)))
   self.assertEqual(error.diagnostics,json.loads((Path(d)/'worker-startup-error.json').read_text()))
  probe.assert_not_called(); call.assert_not_called(); self.assertIn('WORKER STARTUP ERROR',out.getvalue())

 def test_audit_only_partial_result_does_not_claim_audit_pair_passed(self):
  saved=snapshot(); saved['avc'].update(su_sid=1,priv_app_sid=2); app={key:saved[key] for key in ('bootconfig','cmdline')}
  with tempfile.TemporaryDirectory() as d:
   f=Path(d)/'fixture'; f.mkdir(); helper=f/'helper'; helper.write_text('')
   with mock.patch.object(r,'preflight'),mock.patch.object(r,'fixture_new',return_value=(f,helper)),mock.patch.object(r,'call',return_value=copy.deepcopy(saved)),mock.patch.object(r,'app_views',return_value=app),mock.patch.object(r,'audit_exercise',return_value=False),redirect_stdout(io.StringIO()) as out:
    r.run(audit_only=True)
   self.assertIn('AVC audit pair unqualified',out.getvalue())

 def test_post_drop_identity_does_not_read_namespace_links(self):
  stat='123 (worker) S '+' '.join(['0']*18+['4242']+['0']*3)
  def text(path,*args,**kwargs): return stat if path.name=='stat' else 'Uid:\t10362 10362 10362 10362\n'
  with mock.patch.object(Path,'read_text',text),mock.patch.object(Path,'read_bytes',return_value=b'u:r:ksu:s0\n'),mock.patch.dict(r.APP,worker_namespaces=mock.Mock(side_effect=FileNotFoundError(2,'phone namespace link'))):
   identity=r.APP['worker_identity'](123,include_namespaces=False)
   r.APP['worker_namespaces'].assert_not_called()
  self.assertEqual({'pid':123,'uids':[10362]*4,'starttime':4242,'context':'u:r:ksu:s0'},identity)

 def test_worker_captures_namespaces_before_dropping_credentials(self):
  current_uid=0; events=[]
  namespaces={'pid_namespace':'pid:[1]','pid_namespace_disabled':False,'mount_namespace':'mnt:[2]'}
  def capture(pid,trace=False):
   self.assertEqual(0,current_uid); events.append('namespaces'); return namespaces
  def setuid(uid):
   nonlocal current_uid
   events.append('setuid'); current_uid=uid
  def identity(pid,trace=False,include_namespaces=True):
   self.assertEqual(10362,current_uid); self.assertFalse(include_namespaces); events.append('identity')
   return {'pid':pid,'uids':[10362]*4,'starttime':4242,'context':'u:r:ksu:s0'}
  libc=mock.Mock(); libc.prctl.side_effect=[0,1]
  with tempfile.TemporaryDirectory() as d,mock.patch.dict(r.APP,__file__=str(Path(d)/'helper.py'),worker_namespaces=capture,worker_identity=identity,worker_wait=mock.Mock()),mock.patch.object(r.APP['os'],'geteuid',side_effect=lambda:current_uid),mock.patch.object(r.APP['os'],'setgroups'),mock.patch.object(r.APP['os'],'setgid'),mock.patch.object(r.APP['os'],'setuid',side_effect=setuid),mock.patch.object(r.APP['ct'],'CDLL',return_value=libc),redirect_stdout(io.StringIO()) as out:
   r.APP['action']('worker',{'uid':10362,'token':'0'*32})
  self.assertEqual(['namespaces','setuid','identity'],events)
  observed=json.loads(out.getvalue()); self.assertEqual(10362,observed['uid']); self.assertEqual(1,observed['dumpable'])
  self.assertEqual('pid:[1]',observed['pid_namespace'])

 def test_missing_pid_namespace_requires_running_kernel_config_proof(self):
  def link(path):
   if path.name=='pid': raise FileNotFoundError(2,'namespace missing')
   return 'mnt:[2]'
  with mock.patch.object(r.APP['os'],'geteuid',return_value=0),mock.patch.object(r.APP['os'],'readlink',side_effect=link),mock.patch.object(Path,'read_bytes',return_value=gzip.compress(b'# CONFIG_PID_NS is not set\n')):
   identity=r.APP['worker_namespaces'](123)
  self.assertEqual({'pid_namespace':None,'pid_namespace_disabled':True,'mount_namespace':'mnt:[2]'},identity)
  with mock.patch.object(r.APP['os'],'geteuid',return_value=0),mock.patch.object(r.APP['os'],'readlink',side_effect=link),mock.patch.object(Path,'read_bytes',return_value=gzip.compress(b'CONFIG_PID_NS=y\n')):
   with self.assertRaisesRegex(RuntimeError,'does not establish'): r.APP['worker_namespaces'](123)

 def test_unreadable_config_does_not_qualify_missing_namespace(self):
  with mock.patch.object(r.APP['os'],'geteuid',return_value=0),mock.patch.object(r.APP['os'],'readlink',side_effect=FileNotFoundError(2,'missing')),mock.patch.object(Path,'read_bytes',side_effect=PermissionError(13,'config denied')):
   with self.assertRaises(PermissionError): r.APP['worker_namespaces'](123)
  with mock.patch.object(r.APP['os'],'geteuid',return_value=10362),mock.patch.object(r.APP['os'],'readlink',side_effect=FileNotFoundError(2,'missing')),mock.patch.object(Path,'read_bytes') as read:
   with self.assertRaises(FileNotFoundError): r.APP['worker_namespaces'](123)
   read.assert_not_called()

 def test_reader_identity_and_namespaces_are_root_verified(self):
  identity={'pid':123,'uids':[10000]*4,'starttime':4242,'context':'u:r:ksu:s0','pid_namespace':'pid:[1]','pid_namespace_disabled':False,'mount_namespace':'mnt:[2]'}
  current=verified_worker(identity)
  with mock.patch.object(r,'call',return_value=current) as call,mock.patch.object(r.os,'readlink',side_effect=AssertionError('unprivileged namespace read')),redirect_stdout(io.StringIO()):
   self.assertTrue(r.worker_verified(Path('/helper'),identity,'STARTUP'))
  call.assert_called_once_with(Path('/helper'),'worker_check',{'pid':123,'reader_pid':r.os.getpid()})
  for field,value in [('pid',r.os.getpid()+1),('uids',[9999]*4),('pid_namespace','pid:[9]'),('mount_namespace','mnt:[9]'),('pid_namespace_disabled',True)]:
   changed=copy.deepcopy(current); changed['reader']['identity'][field]=value
   with mock.patch.object(r,'call',return_value=changed),redirect_stdout(io.StringIO()):
    self.assertFalse(r.worker_verified(Path('/helper'),identity,'CHECK'))

 def test_root_namespace_failure_does_not_qualify_worker(self):
  identity={'pid':123,'uids':[10000]*4,'starttime':4242,'context':'u:r:ksu:s0','pid_namespace':'pid:[1]','pid_namespace_disabled':False,'mount_namespace':'mnt:[2]'}
  current=verified_worker(identity); current['reader']={'errno':2,'error':'namespace link missing'}
  with mock.patch.object(r,'call',return_value=current),redirect_stdout(io.StringIO()):
   self.assertFalse(r.worker_verified(Path('/helper'),identity,'CHECK'))

 def test_disabled_pid_namespace_is_verified_for_worker_and_reader(self):
  identity={'pid':123,'uids':[10000]*4,'starttime':4242,'context':'u:r:ksu:s0','pid_namespace':None,'pid_namespace_disabled':True,'mount_namespace':'mnt:[2]'}
  with mock.patch.object(r,'call',return_value=verified_worker(identity)),redirect_stdout(io.StringIO()):
   self.assertTrue(r.worker_verified(Path('/helper'),identity,'CHECK'))

 def test_audit_pair_runs_after_root_namespace_checks(self):
  info={'pid':123,'context':'u:r:ksu:s0'}; process=mock.Mock(); events=[]
  def check(helper,worker,label): events.append(label); return True
  def call(helper,name,args=None):
   events.append((name,args)); value=snapshot(); value['avc']['hits']=1
   if name=='audit_log': value['audit']={'returncode':0,'lines':[]}
   return value
  with tempfile.TemporaryDirectory() as d,mock.patch.object(r,'worker_start',return_value=(process,info)),mock.patch.object(r,'worker_verified',side_effect=check),mock.patch.object(r,'worker_stop') as stop,mock.patch.object(r,'audit_probe',return_value=13) as probe,mock.patch.object(r,'call',side_effect=call),mock.patch.object(r.os,'readlink',side_effect=AssertionError('unprivileged namespace read')),redirect_stdout(io.StringIO()):
   self.assertFalse(r.audit_exercise(Path(d)/'helper',snapshot(),Path(d)))
   receipt=json.loads((Path(d)/'audit-evidence.json').read_text())
  self.assertEqual('STARTUP',events[0]); self.assertEqual(('avc_abi',{'enabled':False}),events[1])
  self.assertEqual([True]*4,receipt['worker_checks']); self.assertEqual(2,probe.call_count); stop.assert_called_once()

 def test_signal_zero_probe_keeps_owned_process_alive_without_proc_maps(self):
  process=subprocess.Popen([sys.executable,'-c','import time; time.sleep(10)'])
  try:
   original=Path('/proc/self/comm').read_text()
   with mock.patch('builtins.open',side_effect=AssertionError('proc maps dependency')):
    self.assertEqual(0,r.audit_probe(process.pid,'RM18abcB'))
   self.assertIsNone(process.poll()); self.assertEqual(original,Path('/proc/self/comm').read_text())
  finally:
   process.terminate(); process.wait(timeout=3)

 def test_signal_zero_probe_rejects_non_owned_pid_shapes(self):
  with mock.patch.object(r.os,'kill') as kill:
   for pid in (0,1,-1,True,'123'):
    with self.assertRaisesRegex(RuntimeError,'owned audit PID'): r.audit_probe(pid,'RM18abcB')
   kill.assert_not_called()

 def test_denied_signal_zero_restores_comm(self):
  original=Path('/proc/self/comm').read_text()
  with mock.patch.object(r.os,'kill',side_effect=PermissionError(1,'denied')) as kill:
   self.assertEqual(1,r.audit_probe(123,'RM18abcB'))
  kill.assert_called_once_with(123,0); self.assertEqual(original,Path('/proc/self/comm').read_text())

 def test_unrelated_permission_or_class_does_not_qualify_audit(self):
  for old,new in [('signull','ptrace'),('tclass=process','tclass=file'),('avc: denied','avc: granted')]:
   receipt=audit_receipt(); receipt['baseline_audit']['lines'][0]=receipt['baseline_audit']['lines'][0].replace(old,new)
   self.assertFalse(r.audit_qualified(receipt,'u:r:ksu:s0','u:r:priv_app:s0:c512,c768'))
  receipt=audit_receipt(); receipt['active_audit']['lines'].append(receipt['active_audit']['lines'][0].replace('u:r:priv_app:s0:c512,c768','u:r:ksu:s0'))
  with self.assertRaises(RuntimeError): r.audit_qualified(receipt,'u:r:ksu:s0','u:r:priv_app:s0:c512,c768')

 def test_logcat_supplies_correlated_audit_when_dmesg_is_empty(self):
  def run(command,stdout,stderr,timeout):
   self.assertEqual(5,timeout)
   if command[0].endswith('logcat'):
    stdout.write(b'avc: denied { signull } pid=42 comm="RM18abcB" tcontext=u:r:ksu:s0 tclass=process\n')
    stdout.write(b'avc: denied { signull } pid=999 comm="unrelated" tcontext=u:r:other:s0\n')
   return subprocess.CompletedProcess(command,0)
  with mock.patch.object(r.APP['subprocess'],'run',side_effect=run): logs=r.APP['audit_logs']('RM18abcB')
  self.assertEqual(1,len(logs['lines'])); self.assertEqual(0,logs['sources']['dmesg']['matched_lines'])
  self.assertEqual(1,logs['sources']['logcat']['matched_lines']); self.assertNotIn('unrelated',''.join(logs['lines']))

 def test_audit_log_sources_fail_independently_and_capture_is_bounded(self):
  def run(command,stdout,stderr,timeout):
   if command[0].endswith('toybox'): raise subprocess.TimeoutExpired(command,timeout)
   stdout.write(b'x'*(1024*1024+100)+b'\navc: denied { signull } pid=42 comm="RM18abcB" tcontext=u:r:ksu:s0 tclass=process\n')
   stderr.write(b'e'*4000)
   return subprocess.CompletedProcess(command,0)
  with mock.patch.object(r.APP['subprocess'],'run',side_effect=run): logs=r.APP['audit_logs']('RM18abcB')
  self.assertIn('unavailable',logs['sources']['dmesg']); self.assertTrue(logs['sources']['logcat']['tail_limited'])
  self.assertEqual(2048,len(logs['sources']['logcat']['stderr'])); self.assertEqual(1,len(logs['lines']))

 def test_random_audit_tags_fit_comm_and_differ_between_runs(self):
  tags=[]
  def probe(pid,tag): tags.append(tag); return 1
  def call(helper,name,args=None):
   value=snapshot(); value['avc']['hits']=1
   if name=='audit_log': value['audit']={'lines':[]}
   return value
  with tempfile.TemporaryDirectory() as d,mock.patch.object(r,'worker_start',return_value=(mock.Mock(),{'pid':123,'context':'u:r:ksu:s0'})),mock.patch.object(r,'worker_verified',return_value=True),mock.patch.object(r,'worker_stop'),mock.patch.object(r,'audit_probe',side_effect=probe),mock.patch.object(r,'call',side_effect=call),mock.patch.object(r.os,'getpid',return_value=4194304),mock.patch.object(r.secrets,'token_hex',side_effect=['0'*32,'aabb','1'*32,'ccdd']),redirect_stdout(io.StringIO()):
   for _ in range(2): self.assertFalse(r.audit_exercise(Path(d)/'helper',snapshot(),Path(d)))
  self.assertEqual(4,len(set(tags))); self.assertTrue(all(len(tag)<=15 for tag in tags))

if __name__=='__main__': unittest.main()
