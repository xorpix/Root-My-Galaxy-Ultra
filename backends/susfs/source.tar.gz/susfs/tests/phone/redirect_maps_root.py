
"""Additional root actions; the verified r2 fixture and owned controls are retained."""


def root_action(action, config):
    if action == 'map_observe':
        if os.geteuid() != 0: raise RuntimeError('Root helper did not obtain uid 0')
        return mapping_snapshot(config)
    result = base_root_action(action, config)
    if action == 'state':
        routes = bounded_text('/sys/module/susfs_guard_lkm/parameters/redirect_map_stat').strip()
        if not re.fullmatch(r'checkpoint=22 routes=2 ready=[01] maps=\d+ smaps=\d+ missed=\d+/\d+', routes):
            raise RuntimeError('CP22 redirect listing route marker missing')
        result['mapping_routes'] = routes
    if action == 'setup' and result['available']:
        try:
            size = config['mapping_size']
            if size != 16 * os.sysconf('SC_PAGE_SIZE'): raise RuntimeError('Invalid owned mapping fixture size')
            for name in ('destination', 'destination_control'):
                verify_file(config['paths'][name], result['owned'][name])
                fd = os.open(config['paths'][name], os.O_RDWR | os.O_NOFOLLOW | os.O_CLOEXEC)
                try:
                    if descriptor_identity(fd) != result['owned'][name]: raise RuntimeError('Owned destination changed before resize')
                    os.ftruncate(fd, size)
                finally: os.close(fd)
        except Exception as error:
            result['available'] = False; result['error'] = '%s: %s' % (type(error).__name__, error)
    return result
