#!/usr/bin/env python3
"""Host parser, nonvacuous assertions, and failure-cleanup tests; no phone claim."""
import copy
import builtins
from contextlib import ExitStack, contextmanager, redirect_stdout
import errno
import importlib.util
import io
import json
from pathlib import Path
from types import SimpleNamespace
import shlex
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location(
    'module_runner', Path(__file__).with_name('rmgu-susfs-module-test.py'))
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
NAMES = ('kernelsu', 'susfs_guard_lkm')

def snapshot(uid, active=False):
    show = {'errno': 0, 'directory': True, 'listed': True}
    missing = {'errno': 2, 'directory': False, 'listed': False}
    result = {'uid': uid, 'pid': 42,
              'modules': ['unrelated'] if active else ['kernelsu', 'susfs_guard_lkm', 'unrelated'],
              'sysfs_list': ['susfs_guard_lkm', 'unrelated'],
              'symbols': {'kernelsu': 0, 'susfs_guard_lkm': 0 if active else 15, 'unrelated': 3},
              'core': {'init_task': 1, 'schedule': 1, 'do_exit': 1},
              'access_errno': {'modules': 0, 'symbols': 0, 'sysfs_list': 0},
              'sysfs': {'kernelsu': copy.deepcopy(missing),
                        'susfs_guard_lkm': copy.deepcopy(missing if active and uid else show),
                        'unrelated': copy.deepcopy(show)}}
    return result

def deny(result, *keys, rc=errno.EACCES):
    for key in keys:
        result[key] = None
        result['access_errno'][key] = rc
        if key == 'symbols':
            result['core'] = None
        elif key == 'sysfs_list':
            for row in result['sysfs'].values():
                row['listed'] = None
    return result

@contextmanager
def main_fakes(app_phases, root_phases):
    state, writes, output = [NAMES], [], io.StringIO()
    original_lease = runner.ModuleListLease
    def writer(names):
        state[0] = tuple(names)
        writes.append(tuple(names))
    for row in (*app_phases, *root_phases):
        row['permissions'] = {'fixture': True}
    with ExitStack() as stack:
        for target, name, kwargs in (
            (runner.os, 'geteuid', {'return_value': 10362}),
            (runner.os, 'uname', {'return_value': SimpleNamespace(machine='aarch64', release=runner.KERNEL)}),
            (runner.subprocess, 'check_output', {'return_value': 'uid=10362 fixture'}),
            (runner.signal, 'signal', {}),
            (runner, 'read_config', {'side_effect': lambda: state[0]}),
            (runner, 'root', {'return_value': 'fixture diagnostics'}),
            (runner, 'observe', {'side_effect': app_phases}),
            (runner, 'root_observe', {'side_effect': root_phases}),
            (runner, 'ModuleListLease', {'side_effect': lambda names: original_lease(names, lambda: state[0], writer)}),
        ):
            stack.enter_context(patch.object(target, name, **kwargs))
        stack.enter_context(patch.object(runner.sys, 'stdout', output))
        yield state, writes, output

class RunnerTests(unittest.TestCase):
    def controls(self):
        return runner.baseline_controls(snapshot(10362), snapshot(0), NAMES)

    def test_exact_module_symbols(self):
        counts, core = runner.symbol_counts([
            '0000 t target_function [susfs_guard_lkm]\n',
            '0000 t same_prefix [susfs_guard_lkm_extra]\n',
            '0000 T init_task\n',
            '0000 t init_task [unrelated]\n'], NAMES)
        self.assertEqual(counts, {'kernelsu': 0, 'susfs_guard_lkm': 1})
        self.assertEqual(core['init_task'], 1)

    def test_module_table_parser(self):
        rows = ['target 4096 1 - Live 0x0\n', 'control 8192 0 - Live 0x0\n']
        self.assertEqual(runner.module_names(rows), {'target', 'control'})
        with self.assertRaises(RuntimeError):
            runner.module_names(rows + rows[:1])
        with self.assertRaises(RuntimeError):
            runner.module_names(['broken\n'])

    def test_config_readback(self):
        self.assertEqual(runner.parse_config(
            'hide_modules: 2/16 name(s), /sys/module rules=1 (failed=3)\n'
            'names: kernelsu susfs_guard_lkm\n'), NAMES)
        self.assertEqual(runner.parse_config(
            'hide_modules: 0/16 name(s), /sys/module rules=0 (failed=3)\nnames:\n'), ())

    def test_unsafe_or_truncated_config_rejected(self):
        for text in (
            'hide_modules: 2/16 name(s), x\nnames: one\n',
            'hide_modules: 1/16 name(s), x\nnames: ../../escape\n',
            'hide_modules: 1/16 name(s), x\nnames: ' + 'x' * 64 + '\n',
            'hide_modules: 1/16 name(s), x\nnames: one\nnames: two\n'):
            with self.subTest(text=text), self.assertRaises(RuntimeError):
                runner.parse_config(text)

    def test_missing_root_directory_is_unmeasured(self):
        controls = self.controls()
        self.assertEqual(controls['present_sysfs'], ['susfs_guard_lkm'])
        self.assertEqual(controls['symbol_targets'], ['susfs_guard_lkm'])

    def test_nonvacuous_baseline_required(self):
        app, root = snapshot(10362), snapshot(0)
        app['symbols']['susfs_guard_lkm'] = 0
        root['symbols']['susfs_guard_lkm'] = 0
        with self.assertRaisesRegex(RuntimeError, 'No baseline target'):
            runner.baseline_controls(app, root, NAMES)

    def test_unreadable_baseline_rejected(self):
        app = snapshot(10362)
        app['sysfs']['susfs_guard_lkm']['errno'] = 2
        with self.assertRaisesRegex(RuntimeError, 'App baseline sysfs unreadable'):
            runner.baseline_controls(app, snapshot(0), NAMES)

    def test_no_loaded_target_rejected(self):
        app, root = snapshot(10362), snapshot(0)
        app['modules'] = root['modules'] = ['unrelated']
        with self.assertRaisesRegex(RuntimeError, 'No configured target'):
            runner.baseline_controls(app, root, NAMES)

    def test_active_readers_and_management(self):
        self.assertEqual(runner.active_errors(
            snapshot(10362, True), snapshot(0, True), NAMES, self.controls()), [])

    def test_table_leaks_rejected_for_each_reader(self):
        for which in ('app', 'root'):
            app, root = snapshot(10362, True), snapshot(0, True)
            victim = app if which == 'app' else root
            victim['modules'].append('susfs_guard_lkm')
            victim['symbols']['susfs_guard_lkm'] = 1
            errors = runner.active_errors(app, root, NAMES, self.controls())
            self.assertTrue(any('/proc/modules' in e for e in errors))
            self.assertTrue(any('/proc/kallsyms' in e for e in errors))

    def test_wrong_sysfs_errno_or_root_hiding_rejected(self):
        app, root = snapshot(10362, True), snapshot(0, True)
        app['sysfs']['susfs_guard_lkm']['errno'] = 13
        root['sysfs']['susfs_guard_lkm']['errno'] = 2
        errors = runner.active_errors(app, root, NAMES, self.controls())
        self.assertTrue(any('APP target sysfs' in e for e in errors))
        self.assertTrue(any('ROOT management' in e for e in errors))

    def test_unrelated_controls_must_survive(self):
        app, root = snapshot(10362, True), snapshot(0, True)
        app['modules'] = []
        app['core']['init_task'] = 0
        root['sysfs']['unrelated']['listed'] = False
        errors = runner.active_errors(app, root, NAMES, self.controls())
        self.assertTrue(any('module control' in e for e in errors))
        self.assertTrue(any('core symbol' in e for e in errors))
        self.assertTrue(any('sysfs control' in e for e in errors))

    def test_app_table_permissions_produce_only_scoped_partial_pass(self):
        for keys in (('modules',), ('symbols',), ('modules', 'symbols')):
            with self.subTest(keys=keys):
                app = deny(snapshot(10362), *keys)
                controls = runner.baseline_controls(app, snapshot(0), NAMES)
                active = deny(snapshot(10362, True), *keys)
                self.assertEqual(runner.active_errors(active, snapshot(0, True), NAMES, controls), [])
                self.assertEqual(len(controls['blocked']), len(keys))
                report = runner.final_status(controls)
                self.assertTrue(report.startswith('PARTIAL PASS:'))
                self.assertIn('ROOT /proc/modules', report)
                self.assertIn('APP existing-target sysfs hiding', report)
                self.assertIn('remain unqualified', report)
                for key in keys:
                    self.assertNotIn('APP ' + runner.INTERFACES[key], report)
                    self.assertFalse(controls['access']['APP'][key])

    def test_blocked_app_never_masks_root_leaks(self):
        controls = runner.baseline_controls(
            deny(snapshot(10362), 'modules', 'symbols'), snapshot(0), NAMES)
        root = snapshot(0, True)
        root['modules'].append('susfs_guard_lkm')
        root['symbols']['susfs_guard_lkm'] = 1
        errors = runner.active_errors(
            deny(snapshot(10362, True), 'modules', 'symbols'), root, NAMES, controls)
        self.assertTrue(any('ROOT /proc/modules exposes' in e for e in errors))
        self.assertTrue(any('ROOT /proc/kallsyms exposes' in e for e in errors))

    def test_blocked_root_preflight_is_rejected(self):
        for key in runner.INTERFACES:
            with self.subTest(key=key), self.assertRaisesRegex(RuntimeError, 'ROOT .* unreadable'):
                runner.check_access(snapshot(10362), deny(snapshot(0), key))

    def test_readable_app_interfaces_remain_strict(self):
        for denied_key, leak_key in (('modules', 'symbols'), ('symbols', 'modules')):
            with self.subTest(denied_key=denied_key):
                controls = runner.baseline_controls(
                    deny(snapshot(10362), denied_key), snapshot(0), NAMES)
                active = deny(snapshot(10362, True), denied_key)
                if leak_key == 'modules':
                    active['modules'].append('susfs_guard_lkm')
                else:
                    active['symbols']['susfs_guard_lkm'] = 1
                errors = runner.active_errors(active, snapshot(0, True), NAMES, controls)
                self.assertTrue(any('APP ' + runner.INTERFACES[leak_key] + ' exposes' in e for e in errors))

    def test_access_changes_cannot_prove_hiding(self):
        for key in runner.INTERFACES:
            with self.subTest(key=key):
                before = snapshot(10362)
                after = deny(snapshot(10362), key)
                with self.assertRaisesRegex(RuntimeError, 'access changed'):
                    runner.unchanged_access(before, after, 'APP')
                with self.assertRaisesRegex(RuntimeError, 'access changed'):
                    runner.unchanged_access(after, before, 'APP')
                controls = self.controls()
                errors = runner.active_errors(
                    deny(snapshot(10362, True), key), snapshot(0, True), NAMES, controls)
                self.assertTrue(any('access changed' in e for e in errors))
                controls = runner.baseline_controls(after, snapshot(0), NAMES)
                errors = runner.active_errors(snapshot(10362, True), snapshot(0, True), NAMES, controls)
                self.assertTrue(any('access changed' in e for e in errors))

    def test_sysfs_stat_denial_is_unqualified(self):
        app = snapshot(10362)
        app['sysfs']['susfs_guard_lkm']['errno'] = errno.EACCES
        controls = runner.baseline_controls(app, snapshot(0), NAMES)
        self.assertEqual(controls['app_sysfs'], [])
        self.assertIn('stat hiding unqualified', controls['blocked'][0])
        self.assertNotIn('APP existing-target sysfs hiding', runner.final_status(controls))
        active = snapshot(10362, True)
        active['sysfs']['susfs_guard_lkm']['errno'] = errno.EACCES
        self.assertEqual(runner.active_errors(active, snapshot(0, True), NAMES, controls), [])

    def test_sysfs_enumeration_denial_is_unqualified(self):
        controls = runner.baseline_controls(deny(snapshot(10362), 'sysfs_list'), snapshot(0), NAMES)
        self.assertEqual(controls['app_sysfs'], [])
        self.assertEqual(runner.active_errors(
            deny(snapshot(10362, True), 'sysfs_list'), snapshot(0, True), NAMES, controls), [])
        self.assertNotIn('APP existing-target sysfs hiding', runner.final_status(controls))

    def test_missing_root_baselines_cannot_pass_with_blocked_app(self):
        for what in ('modules', 'symbols', 'sysfs'):
            app = deny(snapshot(10362), 'modules', 'symbols', 'sysfs_list')
            root = snapshot(0)
            if what == 'modules':
                root['modules'] = ['unrelated']
            elif what == 'symbols':
                root['symbols']['susfs_guard_lkm'] = 0
            else:
                root['sysfs']['susfs_guard_lkm'] = {'errno': 2, 'directory': False, 'listed': False}
            with self.subTest(what=what), self.assertRaises(RuntimeError):
                runner.baseline_controls(app, root, NAMES)

    def test_blocked_data_is_null_in_report_not_zero_hidden_rows(self):
        result = runner.concise(deny(snapshot(10362), 'modules', 'symbols'), NAMES)
        for target in result['targets'].values():
            self.assertIsNone(target['proc_modules_rows'])
            self.assertIsNone(target['kallsyms_module_rows'])
        self.assertEqual(result['access_errno']['modules'], 13)

    def test_observer_checks_other_interfaces_after_permission_denial(self):
        with (patch.object(runner, 'read_modules', side_effect=PermissionError(13, 'denied')),
              patch.object(runner, 'read_symbols', return_value=({'susfs_guard_lkm': 9}, {'init_task': 1})),
              patch.object(runner.os, 'listdir', return_value=['susfs_guard_lkm']),
              patch.object(runner.os, 'stat', return_value=type('Info', (), {'st_mode': 0o40755})()),
              patch.object(runner.sys, 'stderr', io.StringIO())):
            result = runner.observe(['susfs_guard_lkm'], 'BASELINE APP')
        self.assertIsNone(result['modules'])
        self.assertEqual(result['access_errno']['modules'], 13)
        self.assertEqual(result['symbols']['susfs_guard_lkm'], 9)
        self.assertEqual(result['sysfs']['susfs_guard_lkm']['errno'], 0)

    def test_unexpected_io_and_parser_errors_are_not_skipped(self):
        for problem in (OSError(errno.EIO, 'bad read'), FileNotFoundError(2, 'missing'),
                        RuntimeError('Malformed /proc/modules row')):
            with self.subTest(problem=problem), self.assertRaises(type(problem)):
                runner.permission_read(lambda: (_ for _ in ()).throw(problem))
        for rc in (errno.EACCES, errno.EPERM):
            with self.subTest(rc=rc):
                result = runner.permission_read(lambda: (_ for _ in ()).throw(PermissionError(rc, 'denied')))
                self.assertEqual(result, (None, rc))

    def test_main_root_preflight_failure_never_writes(self):
        with main_fakes([snapshot(10362)], [deny(snapshot(0), 'modules')]) as (state, writes, output):
            with self.assertRaisesRegex(RuntimeError, 'ROOT .* unreadable'):
                runner.main()
            self.assertEqual(writes, [])
            self.assertEqual(state[0], NAMES)
            self.assertNotIn('PASS:', output.getvalue())

    def test_main_app_table_denial_preserves_config_and_reports_partial_pass(self):
        app_phases = [deny(snapshot(10362, active), 'modules', 'symbols')
                      for active in (True, False, True)]
        root_phases = [snapshot(0, active) for active in (True, False, True)]
        with main_fakes(app_phases, root_phases) as (state, writes, output):
            runner.main()
            self.assertEqual(writes, [(), NAMES])
            self.assertEqual(state[0], NAMES)
            self.assertIn('PARTIAL PASS:', output.getvalue())
            self.assertIn('exact original module-name list restored', output.getvalue())
            self.assertIn('"proc_modules_rows": null', output.getvalue())

    def test_main_baseline_permission_change_restores_original_config(self):
        with main_fakes([snapshot(10362, True), deny(snapshot(10362), 'modules')],
                        [snapshot(0, True), snapshot(0)]) as (state, writes, output):
            with self.assertRaisesRegex(RuntimeError, 'access changed'):
                runner.main()
            self.assertEqual(writes, [(), NAMES])
            self.assertEqual(state[0], NAMES)
            self.assertIn('exact original module-name list restored', output.getvalue())
            self.assertNotIn('PASS:', output.getvalue())

    def test_complete_runner_and_generated_root_reader_without_getxattr(self):
        # Exercise the real observers and generated root Python, including
        # diagnostics. The previous main fixtures stubbed those paths out.
        state, writes, root_reads = [NAMES], [], []
        def file_stat(path, uid):
            if path == '/sys/module/kernelsu' or (
                path == '/sys/module/susfs_guard_lkm' and uid and state[0]
            ):
                raise FileNotFoundError(2, 'absent', path)
            return SimpleNamespace(st_mode=0o40755 if path.startswith('/sys/') else 0o100444,
                                   st_uid=0, st_gid=0)
        def module_dirs(uid):
            return ['unrelated'] if uid and state[0] else ['susfs_guard_lkm', 'unrelated']
        def portable_os(uid):
            return SimpleNamespace(geteuid=lambda: uid, getpid=lambda: 42 + uid,
                                   uname=lambda: SimpleNamespace(machine='aarch64', release=runner.KERNEL),
                                   stat=lambda path: file_stat(path, uid),
                                   listdir=lambda path: module_dirs(uid))
        def open_table(path, uid):
            if uid:
                raise PermissionError(13, 'denied', path)
            if path == '/proc/modules':
                names = ['unrelated'] if state[0] else [*NAMES, 'unrelated']
                return io.StringIO(''.join(name + ' 4096 0 - Live 0x0\n' for name in names))
            if path == '/proc/kallsyms':
                text = '0000 T init_task\n0000 t control [unrelated]\n'
                if not state[0]:
                    text += '0000 t fixture_entry [susfs_guard_lkm]\n'
                return io.StringIO(text)
            raise AssertionError('Unexpected table: ' + path)
        def diagnostic_path(path):
            return SimpleNamespace(read_text=lambda **kwargs: '1' if path.endswith('/enforce') else 'fixture_context')
        def root_command(command, live=False):
            parts = shlex.split(command)
            if parts == ['cat', runner.CONTROL]:
                return 'hide_modules: %d/16 name(s), fixture\nnames: %s\n' % (len(state[0]), ' '.join(state[0]))
            if parts[:2] == ['printf', '%s\\n'] and parts[-2:] == ['>', runner.CONTROL]:
                state[0] = () if parts[2] == 'clear' else tuple(parts[2].split()[1:])
                writes.append(state[0])
                return ''
            self.assertEqual(parts[:3], [runner.sys.executable, '-u', '-c'])
            def portable_import(name, *args, **kwargs):
                if name == 'os': return portable_os(0)
                if name == 'pathlib': return SimpleNamespace(Path=diagnostic_path)
                return builtins.__import__(name, *args, **kwargs)
            namespace = {'__builtins__': dict(vars(builtins), __import__=portable_import,
                                               open=lambda path: open_table(path, 0))}
            out = io.StringIO()
            with redirect_stdout(out):
                exec(compile(parts[3], '<actual generated root reader>', 'exec'), namespace)
            result = out.getvalue()
            root_reads.append(json.loads(result))
            return result
        stdout, stderr = io.StringIO(), io.StringIO()
        with (patch.object(runner, 'os', portable_os(10362)),
              patch.object(runner, 'Path', diagnostic_path),
              patch.object(runner, 'open', lambda path: open_table(path, 10362), create=True),
              patch.object(runner, 'root', root_command),
              patch.object(runner.subprocess, 'check_output', return_value='uid=10362 fixture'),
              patch.object(runner.signal, 'signal'),
              patch.object(runner.sys, 'stdout', stdout),
              patch.object(runner.sys, 'stderr', stderr)):
            runner.main()
        self.assertEqual(writes, [(), NAMES])
        self.assertEqual(state[0], NAMES)
        self.assertEqual(len(root_reads), 3)
        for path in ('/proc/modules', '/proc/kallsyms', '/sys/module'):
            self.assertIn('not provided', root_reads[0]['permissions'][path]['label_unavailable'])
        self.assertIn('Module runner revision: 3', stdout.getvalue())
        self.assertIn('PARTIAL PASS:', stdout.getvalue())
        self.assertIn('exact original module-name list restored', stdout.getvalue())
        self.assertIn('READ PREFLIGHT APP optional permission diagnostics', stderr.getvalue())
        self.assertIn('READ PREFLIGHT ROOT optional permission diagnostics', stderr.getvalue())

    def test_optional_diagnostic_errors_preserve_reads_but_core_errors_fail(self):
        with (patch.object(runner, 'read_modules', return_value=['susfs_guard_lkm']),
              patch.object(runner, 'read_symbols', return_value=({'susfs_guard_lkm': 1}, {'init_task': 1})),
              patch.object(runner.os, 'listdir', return_value=['susfs_guard_lkm']),
              patch.object(runner.os, 'stat', return_value=SimpleNamespace(st_mode=0o40755)),
              patch.object(runner.sys, 'stderr', io.StringIO())):
            for problem in (AttributeError('optional API absent'), NotImplementedError('unsupported'),
                            PermissionError(13, 'diagnostic denied'), RuntimeError('diagnostic failed')):
                with self.subTest(problem=problem), patch.object(runner, 'permission_diagnostics', side_effect=problem):
                    result = runner.observe(['susfs_guard_lkm'], 'APP', diagnostics=True)
                    self.assertEqual(result['modules'], ['susfs_guard_lkm'])
                    self.assertEqual(result['symbols']['susfs_guard_lkm'], 1)
                    self.assertEqual(result['permissions']['unavailable'], type(problem).__name__)
            with patch.object(runner, 'read_modules', side_effect=RuntimeError('Malformed table')):
                with self.assertRaisesRegex(RuntimeError, 'Malformed table'):
                    runner.observe(['susfs_guard_lkm'], 'APP', diagnostics=True)

    def test_failure_or_interrupt_restores_original_list(self):
        for problem in (RuntimeError('baseline failure'), KeyboardInterrupt()):
            state, writes = [NAMES], []
            def writer(names):
                writes.append(tuple(names))
                state[0] = tuple(names)
            with self.subTest(problem=type(problem).__name__):
                with self.assertRaises(type(problem)):
                    with runner.ModuleListLease(NAMES, lambda: state[0], writer) as lease:
                        lease.clear()
                        raise problem
                self.assertEqual(state[0], NAMES)
                self.assertEqual(writes, [(), NAMES])

    def test_partial_clear_failure_restores_original_list(self):
        state, writes = [NAMES], []
        def writer(names):
            state[0] = tuple(names)
            writes.append(tuple(names))
            if not names:
                raise RuntimeError('write failed after applying')
        with self.assertRaisesRegex(RuntimeError, 'write failed'):
            with runner.ModuleListLease(NAMES, lambda: state[0], writer) as lease:
                lease.clear()
        self.assertEqual(state[0], NAMES)
        self.assertEqual(writes, [(), NAMES])

    def test_changed_configuration_before_clear_is_preserved(self):
        writes = []
        with self.assertRaisesRegex(RuntimeError, 'changed before test'):
            with runner.ModuleListLease(NAMES, lambda: ('someone_else',), writes.append):
                self.fail('Should not enter')
        self.assertEqual(writes, [])

    def test_failed_restoration_never_reports_success(self):
        state = [NAMES]
        def writer(names):
            if names:
                raise RuntimeError('root restoration unavailable')
            state[0] = ()
        with self.assertRaisesRegex(RuntimeError, 'restoration unavailable'):
            with runner.ModuleListLease(NAMES, lambda: state[0], writer) as lease:
                lease.clear()
        self.assertEqual(state[0], ())

    def test_untouched_lease_does_not_replace_external_change(self):
        state, writes = [NAMES], []
        with runner.ModuleListLease(NAMES, lambda: state[0], writes.append):
            state[0] = ('external_change',)
        self.assertEqual(writes, [])
        self.assertEqual(state[0], ('external_change',))

if __name__ == '__main__':
    unittest.main(verbosity=2)
