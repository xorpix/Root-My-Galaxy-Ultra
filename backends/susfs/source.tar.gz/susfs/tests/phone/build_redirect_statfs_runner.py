#!/usr/bin/env python3
"""Build a standalone runner with retained bounded root calls and process identity."""
import ast
from pathlib import Path


def definitions(path):
    source = path.read_text()
    return {node.name: ast.get_source_segment(source, node) for node in ast.parse(source).body
            if isinstance(node, (ast.FunctionDef, ast.ClassDef))}


def build():
    directory = Path(__file__).resolve().parent
    root_support = definitions(directory / 'rmgu-susfs-kstat-native-test.py')
    identity = definitions(directory / 'kstat_maps_observer.py')['process_identity']
    shared = (directory / 'redirect_statfs_shared.py').read_text() + '\n\n' + identity + '\n'
    helper = shared + '\n' + (directory / 'redirect_statfs_root.py').read_text()
    head = '''#!/usr/bin/env python3
"""CP21 native redirect statfs qualification; run from ordinary Termux.

Creates owned source files and two labelled files in a private /dev directory.
Uses scheme 3 for two owned rules; preserves existing rules. No mount, policy,
kernel-module, global-clear, or feature-flag changes. Root commands bounded.
"""
import base64
import ctypes as ct
import errno
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import tempfile

KERNEL = '6.12.69-android16-6-pb4d3caf-abogkiS948BXXS4BZIG-4k'
ROOT_TIMEOUT = 30

'''
    result = head + '\n\n'.join(root_support[name] for name in ('RootCommandUnknown', 'root'))
    result += '\n\nSHARED = ' + repr(shared) + '\nexec(SHARED, globals())\n'
    result += '\nROOT_HELPER = ' + repr(helper) + '\n\n'
    result += (directory / 'redirect_statfs_workflow.py').read_text()
    return result


if __name__ == '__main__':
    Path(__file__).with_name('rmgu-susfs-redirect-statfs-test.py').write_text(build())
