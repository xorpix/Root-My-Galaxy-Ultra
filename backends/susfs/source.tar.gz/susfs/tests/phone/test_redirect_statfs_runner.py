"""Real native host filesystems plus explicitly modeled phone credentials/controls."""
import copy
import importlib.util
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).with_name(filename))
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


builder = module('redirect_statfs_builder', 'build_redirect_statfs_runner.py')
r = module('redirect_statfs_runner', 'rmgu-susfs-redirect-statfs-test.py')
root_definitions = module('redirect_statfs_root_definitions', 'redirect_statfs_root.py')
exec(r.SHARED, root_definitions.__dict__)
HOOKS = 'hooks: open=1 dpath=1 statfs=1 maps=1 fdinfo=1 | rev hits: dpath=0 statfs=0 maps=0/0/0 fdinfo=0/0 | su_sid=3203 | fdinfo_probes=4/4'
FOREIGN = '/data/adb/foreign -> /data/adb/replacement uid=4 (ino=71 dev=266338385 mnt=8 | rev: ino=99 dev=22)'
REAL_OPEN = os.open


class NativeTests(unittest.TestCase):
    def setUp(self):
        self.native = r.NativeStatFS()
        self.source = tempfile.TemporaryDirectory(); self.addCleanup(self.source.cleanup)
        self.destination = tempfile.TemporaryDirectory(dir='/dev/shm'); self.addCleanup(self.destination.cleanup)
        self.paths = [Path(value.name) / 'probe.txt' for value in (self.source, self.destination)]
        for path in self.paths: path.write_bytes(b'owned host statfs\n')

    def test_native_path_descriptor_guards_and_statvfs_crosscheck(self):
        for path in self.paths:
            value = self.native.call('statfs', path)
            fd = REAL_OPEN(path, os.O_RDONLY)
            try: held = self.native.call('fstatfs', fd)
            finally: os.close(fd)
            self.assertEqual(r.stable_statfs(value), r.stable_statfs(held))
            reference = os.statvfs(path)
            self.assertEqual(reference.f_bsize, value['fields']['bsize'])
            self.assertEqual(reference.f_frsize, value['fields']['frsize'])
            self.assertEqual(reference.f_namemax, value['fields']['namelen'])
            self.assertEqual(120, len(bytes.fromhex(value['raw'])))
            self.assertTrue(value['buffer_guards'])

    def test_real_distinct_filesystems(self):
        values = [self.native.call('statfs', path) for path in self.paths]
        self.assertNotEqual(r.filesystem_identity(values[0]), r.filesystem_identity(values[1]))
        self.assertNotEqual(os.stat(self.paths[0]).st_dev, os.stat(self.paths[1]).st_dev)

    def test_native_errors_and_no_descriptor_content_change(self):
        self.assertEqual(2, self.native.call('statfs', str(self.paths[0]) + '.absent')['errno'])
        self.assertEqual(9, self.native.call('fstatfs', -1)['errno'])
        fd = REAL_OPEN(self.paths[0], os.O_RDONLY)
        try:
            os.lseek(fd, 4, os.SEEK_SET); self.native.call('fstatfs', fd)
            self.assertEqual(4, os.lseek(fd, 0, os.SEEK_CUR))
            self.assertEqual(b'owned host statfs\n', os.pread(fd, 64, 0))
        finally: os.close(fd)

    def test_dynamic_counts_accepted_stable_bytes_guard_and_errors_rejected(self):
        value = self.native.call('statfs', self.paths[0]); changed = copy.deepcopy(value)
        raw = bytearray.fromhex(changed['raw']); raw[16:56] = b'\x83' * 40; changed['raw'] = raw.hex()
        self.assertEqual(r.stable_statfs(value), r.stable_statfs(changed))
        for offset in (0, 8, 56, 64, 72, 80, 88, 119):
            raw = bytearray.fromhex(value['raw']); raw[offset] ^= 1
            self.assertNotEqual(r.stable_statfs(value), r.stable_statfs(dict(value, raw=raw.hex())))
        with self.assertRaises(RuntimeError): r.stable_statfs(dict(value, buffer_guards=False))
        with self.assertRaises(RuntimeError): r.stable_statfs(dict(value, errno=13))


class FormatTests(unittest.TestCase):
    def test_builder_matches_standalone(self):
        self.assertEqual(Path(r.__file__).read_text(), builder.build())
        compile(r.ROOT_HELPER, 'embedded-root-helper', 'exec')

    def test_initial_empty_deleted_empty_and_foreign_scheme_four(self):
        for text in ('(empty)\n' + HOOKS, HOOKS): self.assertEqual([], r.parse_redirect(text)['rules'])
        self.assertEqual([FOREIGN], r.parse_redirect(FOREIGN + '\n' + HOOKS)['rules'])

    def test_malformed_unknown_duplicate_rows_rejected(self):
        for text in ('', '(empty)', FOREIGN, HOOKS + '\nunknown', HOOKS + '\n' + HOOKS,
                     '(empty)\n' + FOREIGN + '\n' + HOOKS, FOREIGN + '\n' + FOREIGN + '\n' + HOOKS):
            with self.assertRaises(RuntimeError): r.parse_redirect(text)

    def test_kernel_raw_device_encoding_not_userspace_encoding(self):
        self.assertEqual(266338385, r.raw_device(os.makedev(254, 81)))
        self.assertEqual(22, r.raw_device(os.makedev(0, 22)))

    def test_unknown_root_command_blocks_every_followup(self):
        client = r.RootClient('/owned/helper.py', {'pid': os.getpid()})
        with patch.object(r, 'root', side_effect=r.RootCommandUnknown('modeled timeout')) as command, \
             patch('sys.stdout', io.StringIO()):
            with self.assertRaises(r.RootCommandUnknown): client.call('add', {})
            with self.assertRaises(r.RootCommandUnknown): client.call('state', {})
            self.assertEqual(1, command.call_count)


class PhoneModel:
    """Native syscalls/files remain real. Only controls, namespace and UID are modeled.

    Destination files live in a temporary /dev/shm directory; no root-level /dev
    objects, SELinux changes, mount operations or real proc controls are used.
    """
    def __init__(self, test, home, failure=None):
        self.test = test; self.home = home; self.failure = failure
        self.destination = tempfile.TemporaryDirectory(dir='/dev/shm'); test.addCleanup(self.destination.cleanup)
        self.native = r.NativeStatFS(); self.original = [FOREIGN]; self.rules = list(self.original)
        self.events = []; self.active = False; self.unknown = False; self.config = None

    def factory(self, helper, subject): self.helper = helper; self.subject = subject; return self

    def identity(self, pid):
        if pid != os.getpid(): raise AssertionError('Unexpected modeled PID')
        return {'pid': pid, 'starttime': 1234, 'uids': [10362] * 4,
                'context': 'explicit-host-credential-stub', 'mount_namespace': 'explicit-host-namespace-stub'}

    def namespace(self, path):
        if str(path) not in ('/proc/self/ns/mnt', '/proc/%d/ns/mnt' % os.getpid()):
            raise AssertionError('Unexpected namespace request')
        return 'explicit-host-namespace-stub'

    def text(self, path):
        if str(path) == r.REDIRECT_CONTROL: return '\n'.join(self.rules + [HOOKS])
        if str(path) == '/proc/susfs_kstat': return r.CP21_MARKER + ' maps=0 smaps=0 missed=0/0\n'
        return r.bounded_text_original(path)

    def open(self, path, flags, *arguments, **keywords):
        if (self.active and self.config and os.geteuid() == 10362
                and str(path) == self.config['paths']['target']): path = self.config['paths']['destination']
        return REAL_OPEN(path, flags, *arguments, **keywords)

    def native_call(self, operation, argument):
        value = self.native.call(operation, argument)
        if value['errno'] or not self.active or os.geteuid() != 10362: return value
        identity = os.fstat(argument) if operation == 'fstatfs' else os.stat(argument)
        dest = self.config['identities']['destination']
        if (identity.st_ino, identity.st_dev) == (dest['ino'], dest['dev']) and self.failure != 'leak':
            value = self.native.call('statfs', self.config['paths']['source_control'])
        return value

    def observe(self, config):
        result = r.observe_files(config, config['held'])
        if self.failure == 'root_spoof' and self.active:
            result['paths']['destination'] = self.native.call('statfs', config['paths']['source_control'])
        return result

    def call(self, action, config):
        if self.unknown: raise AssertionError('Root action after unknown outcome: ' + action)
        self.events.append(action); self.config = config
        if action == 'state':
            if self.failure == 'malformed': return r.parse_redirect(HOOKS + '\nnew unknown diagnostic')
            return {'rules': list(self.rules), 'diagnostics': HOOKS}
        if action == 'setup':
            if self.failure == 'setup_no_receipt': raise RuntimeError('modeled helper exit without setup receipt')
            config['device_directory'] = self.destination.name
            for name in ('destination', 'destination_control'):
                config['paths'][name] = str(Path(self.destination.name) / (name + '.txt'))
            if self.failure == 'blocked': return {'available': False, 'error': 'modeled label denial', 'owned': {}}
            for name in ('destination', 'destination_control'):
                Path(config['paths'][name]).write_bytes(bytes.fromhex(config['contents'][name]))
            labels = {name: {'verified': True, 'bytes': 32, 'method': 'explicit host SELinux label stub'}
                      for name in ('directory', 'destination', 'destination_control')}
            if self.failure == 'missing_label_receipt': del labels['destination_control']
            if self.failure == 'unverified_label': labels['destination']['verified'] = False
            if self.failure == 'empty_label': labels['directory']['bytes'] = 0
            return {'available': True, 'error': None, 'labels': labels,
                    'owned': {'directory': r.file_identity(self.destination.name),
                              **{name: r.file_identity(config['paths'][name]) for name in ('destination', 'destination_control')}}}
        if action == 'metadata':
            value = {'identities': {name: r.file_identity(path) for name, path in config['paths'].items()}, 'source_mount_id': 8123}
            if self.failure == 'same_fs': value['identities']['destination']['dev'] = value['identities']['target']['dev']
            return value
        if action == 'observe':
            if self.failure == 'unknown_observe' and self.active:
                self.unknown = True; raise r.RootCommandUnknown('modeled blocked root observation')
            with patch.object(r.os, 'geteuid', return_value=0): return self.observe(config)
        if action == 'add':
            self.test.assertEqual(self.original, self.rules)
            if self.failure == 'unknown_add':
                self.unknown = True; raise r.RootCommandUnknown('modeled unknown ADD')
            self.rules.append(r.expected_rule(config)); self.active = True
            if self.failure == 'publication': raise RuntimeError('modeled known failure after publication')
            if self.failure == 'foreign_change':
                self.rules.append('/different -> /replacement uid=3 (ino=1 dev=2 mnt=3 | rev: ino=4 dev=5)')
                raise RuntimeError('modeled foreign writer changed list')
            return {'rules': list(self.rules), 'diagnostics': HOOKS}
        if action == 'del':
            self.test.assertEqual(self.original + [r.expected_rule(config)], self.rules)
            if self.failure == 'unknown_del':
                self.unknown = True; raise r.RootCommandUnknown('modeled unknown DEL')
            self.rules = list(self.original); self.active = False
            return {'rules': list(self.rules), 'diagnostics': HOOKS}
        if action == 'cleanup':
            self.test.assertEqual(self.original, self.rules)
            if self.failure == 'cleanup': raise RuntimeError('modeled changed fixture inode')
            for name in ('destination', 'destination_control'):
                path = Path(config['paths'][name])
                if path.exists(): path.unlink()
            return {'removed': True}
        raise AssertionError(action)


class WorkflowTests(unittest.TestCase):
    def run_model(self, failure=None):
        home = tempfile.TemporaryDirectory(); self.addCleanup(home.cleanup)
        model = PhoneModel(self, home.name, failure)
        uname = type('PhoneUname', (), {'machine': 'aarch64', 'release': r.KERNEL})()
        output = io.StringIO(); gateway = type('NativeGateway', (), {'call': staticmethod(model.native_call)})
        with patch.object(r, 'RootClient', side_effect=model.factory), \
             patch.object(r, 'process_identity', side_effect=model.identity), \
             patch.object(r.os, 'readlink', side_effect=model.namespace), \
             patch.object(r.os, 'uname', return_value=uname), patch.object(r.os, 'geteuid', return_value=10362), \
             patch.object(r.Path, 'home', return_value=Path(home.name)), \
             patch.object(r.os, 'open', side_effect=model.open), \
             patch.object(r, 'NativeStatFS', return_value=gateway), \
             patch.object(r.sys, 'argv', ['owned-runner']), patch('sys.stdout', output):
            code = r.main()
        receipts = list(Path(home.name).glob('*/receipt.json'))
        return code, model, output.getvalue(), json.loads(receipts[0].read_text()) if receipts else None

    def test_two_cycles_content_provenance_held_post_delete_and_foreign_rules_preserved(self):
        code, model, output, receipt = self.run_model()
        self.assertEqual(0, code, output); self.assertIsNone(receipt)
        self.assertEqual(2, model.events.count('add')); self.assertEqual(2, model.events.count('del'))
        self.assertEqual(model.original, model.rules)
        self.assertIn('PASS: native statfs/fstatfs', output)
        self.assertIn('active descriptor held', output)

    def test_real_destination_filesystem_leak_and_root_spoof_detected_and_restored(self):
        for failure in ('leak', 'root_spoof'):
            with self.subTest(failure=failure):
                code, model, output, receipt = self.run_model(failure)
                self.assertEqual(1, code, output); self.assertEqual(model.original, model.rules)
                self.assertTrue(receipt['cleanup_complete']); self.assertNotIn('PASS:', output)

    def test_fixture_blocked_or_same_filesystem_sends_no_feature_controls(self):
        for failure in ('blocked', 'same_fs', 'missing_label_receipt', 'unverified_label', 'empty_label'):
            code, model, output, receipt = self.run_model(failure)
            self.assertEqual(2, code, output); self.assertNotIn('add', model.events)
            self.assertFalse(receipt['feature_controls_attempted']); self.assertIn('BLOCKED:', output)

    def test_preflight_parse_failure_and_missing_setup_receipt_retain_without_controls(self):
        for failure in ('malformed', 'setup_no_receipt'):
            code, model, output, receipt = self.run_model(failure)
            self.assertEqual(1, code, output); self.assertNotIn('add', model.events)
            if failure == 'setup_no_receipt': self.assertNotIn('cleanup', model.events)
            self.assertFalse(receipt['feature_controls_attempted'])

    def test_known_add_publication_failure_removes_only_own_confirmed_row(self):
        code, model, output, receipt = self.run_model('publication')
        self.assertEqual(1, code, output); self.assertEqual(model.original, model.rules)
        self.assertEqual(1, model.events.count('del')); self.assertTrue(receipt['cleanup_complete'])

    def test_foreign_table_change_refuses_deletion_and_fixture_cleanup(self):
        code, model, output, receipt = self.run_model('foreign_change')
        self.assertEqual(1, code, output); self.assertNotIn('del', model.events)
        self.assertNotIn('cleanup', model.events); self.assertFalse(receipt['cleanup_complete'])

    def test_unknown_add_del_observe_stop_all_further_root_actions(self):
        for failure, last in (('unknown_add', 'add'), ('unknown_del', 'del'), ('unknown_observe', 'observe')):
            code, model, output, receipt = self.run_model(failure)
            self.assertEqual(1, code, output); self.assertEqual(last, model.events[-1])
            self.assertTrue(receipt['root_outcome_unknown']); self.assertFalse(receipt['cleanup_complete'])

    def test_cleanup_identity_failure_is_failure_and_retains_receipt(self):
        code, model, output, receipt = self.run_model('cleanup')
        self.assertEqual(1, code, output); self.assertEqual(model.original, model.rules)
        self.assertFalse(receipt['cleanup_complete']); self.assertIn('CLEANUP UNQUALIFIED:', output)
        self.assertEqual('FAIL', receipt['result'])

    def test_omitted_reader_or_descriptor_cannot_be_reported_as_pass(self):
        _, _, _, receipt = self.run_model('leak')
        config = receipt['config']; baseline = receipt['observations']['baseline']
        references = r.baseline_references(config, baseline)
        for mutation in ('reader', 'descriptor', 'proc_fd'):
            value = copy.deepcopy(baseline)
            if mutation == 'reader': value.pop('root')
            elif mutation == 'descriptor': value['app']['descriptors'].pop('destination_fresh')
            else: value['app']['descriptors']['target_before'].pop('proc_fd_statfs')
            errors = []; r.check_phase(config, value, references, False, errors, 'INCOMPLETE')
            self.assertTrue(errors)

    def test_pre_add_descriptor_and_post_delete_destination_backing_are_not_interchangeable(self):
        _, _, _, receipt = self.run_model('leak')
        config = receipt['config']; references = r.baseline_references(config, receipt['observations']['baseline'])
        restored = receipt['observations']['restored_1']
        errors = []; r.check_phase(config, restored, references, False, errors, 'RESTORED', active_descriptor=True)
        self.assertEqual([], errors)
        for key in ('statfs', 'proc_fd_statfs'):
            value = copy.deepcopy(restored)
            value['app']['descriptors']['target_active'][key] = value['app']['descriptors']['target_before'][key]
            errors = []; r.check_phase(config, value, references, False, errors, 'RESTORED', active_descriptor=True)
            self.assertTrue(errors)


class OwnershipTests(unittest.TestCase):
    def control_config(self, directory):
        paths = {'target': str(Path(directory) / 'source.txt'), 'destination': str(Path(directory) / 'destination.txt')}
        for path in paths.values(): Path(path).write_bytes(b'owned')
        return {'paths': paths, 'identities': {name: r.file_identity(path) for name, path in paths.items()},
                'source_mount_id': 8123, 'original_rules': [FOREIGN], 'subject': {}}

    def test_real_root_helper_add_del_verify_exact_table_and_proc_command(self):
        with tempfile.TemporaryDirectory() as directory:
            config = self.control_config(directory); rows = [FOREIGN]; commands = []
            class Sink(io.BytesIO):
                def write(inner, data):
                    commands.append(data.decode())
                    if data.startswith(b'add_open_redirect '): rows.append(r.expected_rule(config))
                    elif data.startswith(b'del '): rows.pop()
                    else: raise AssertionError('Unexpected mutation')
                    return len(data)
            with patch.object(root_definitions, 'assert_subject'), patch.object(root_definitions.os, 'geteuid', return_value=0), \
                 patch.object(root_definitions, 'bounded_text', side_effect=lambda path: '\n'.join(rows + [HOOKS])), \
                 patch.object(root_definitions, 'open', side_effect=lambda *args, **kwargs: Sink(), create=True):
                root_definitions.root_action('add', config)
                self.assertEqual([FOREIGN, r.expected_rule(config)], rows)
                root_definitions.root_action('del', config)
                self.assertEqual([FOREIGN], rows)
            self.assertEqual(['add_open_redirect %s %s 3\n' % (config['paths']['target'], config['paths']['destination']),
                              'del %s\n' % config['paths']['target']], commands)

    def test_real_root_helper_refuses_changed_list_or_inode_without_control_write(self):
        with tempfile.TemporaryDirectory() as directory:
            config = self.control_config(directory)
            with patch.object(root_definitions, 'assert_subject'), patch.object(root_definitions.os, 'geteuid', return_value=0), \
                 patch.object(root_definitions, 'bounded_text', return_value=HOOKS), \
                 patch.object(root_definitions, 'open', create=True) as control:
                with self.assertRaisesRegex(RuntimeError, 'rule list changed'): root_definitions.root_action('add', config)
                control.assert_not_called()
            config['identities']['target']['ino'] += 1
            with patch.object(root_definitions, 'assert_subject'), patch.object(root_definitions.os, 'geteuid', return_value=0), \
                 patch.object(root_definitions, 'bounded_text', return_value=FOREIGN + '\n' + HOOKS), \
                 patch.object(root_definitions, 'open', create=True) as control:
                with self.assertRaisesRegex(RuntimeError, 'identity changed'): root_definitions.root_action('add', config)
                control.assert_not_called()

    def test_real_cleanup_refuses_extra_entries_or_changed_identity_before_unlink(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory); target = path / 'destination.txt'; target.write_bytes(b'owned')
            config = {'device_directory': directory, 'original_rules': [], 'paths': {'destination': str(target)},
                      'device_owned': {'directory': r.file_identity(path), 'destination': r.file_identity(target)},
                      'subject': {}}
            with patch.object(root_definitions, 'assert_subject'), patch.object(root_definitions.os, 'geteuid', return_value=0), \
                 patch.object(root_definitions, 'bounded_text', return_value=HOOKS):
                extra = path / 'extra.txt'; extra.write_bytes(b'foreign')
                with self.assertRaisesRegex(RuntimeError, 'extra entries'): root_definitions.root_action('cleanup', config)
                self.assertTrue(target.exists()); extra.unlink()
                config['device_owned']['destination']['ino'] += 1
                with self.assertRaisesRegex(RuntimeError, 'identity changed'): root_definitions.root_action('cleanup', config)
                self.assertTrue(target.exists())
                config['device_owned']['destination']['ino'] -= 1
                root_definitions.root_action('cleanup', config)
                self.assertFalse(path.exists())


r.bounded_text_original = r.bounded_text

if __name__ == '__main__': unittest.main(verbosity=2)
