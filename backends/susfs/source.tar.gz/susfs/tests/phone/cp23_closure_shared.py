"""CP23-only final acceptance additions to the retained closure readers."""

# FIXED_MANIFEST is embedded by build_cp23_closure_runners.py. The eleven
# previously accepted fixture files are unchanged from the frozen CP22 list.
EXPECTED_BOOT_ID = None
_retained_snapshot = snapshot
_retained_root_dispatch = root_dispatch
_retained_root_call = root_call
PATH_TRUNCATION_LINE = '(truncated: the table holds more rules than one page; the rules are intact)'


def cp23_guard():
    text = read_text(CONTROLS['path'])
    markers = re.findall(r'^creds: checkpoint=23 native_copy=1 per_rule=1 live=(\d+)$', text, re.M)
    require(len(markers) == 1, 'Repaired CP23 credential marker missing; no fixture controls sent')
    pending = re.findall(r'^dirent: pending=(\d+)\b', text, re.M)
    gate = re.findall(r'^hide_from_apps=([01])\b', text, re.M)
    active = re.findall(r'^pend: .*\bcaller-cred=(\d+)\b', text, re.M)
    require(len(pending) == len(gate) == len(active) == 1, 'Invalid CP23 path diagnostics')
    require(int(markers[0]) == int(pending[0]) == int(active[0]) == 0,
            'Pending work or caller credentials remain; controls untouched')
    require(gate[0] == '1', 'App-only path gate is not enabled; controls untouched')
    require(read_text('/proc/sys/kernel/osrelease') == KERNEL, 'Root kernel mismatch')
    return {'checkpoint': 23, 'native_copy': 1, 'per_rule': 1,
            'path_hide_from_apps': 1, 'pending': 0, 'live': 0, 'caller_cred_active': 0}


def path_snapshot_blocker(guard):
    # Both CP23 front ends call sus_path_format_list(..., PAGE_SIZE). A larger
    # Python read or switching to hide_list cannot recover the omitted tail.
    raw = Path(CONTROLS['path']).read_bytes()
    text = raw.decode()
    if 'truncated:' not in text:
        return None
    require(text.splitlines().count(PATH_TRUNCATION_LINE) == 1,
            'Unrecognized path truncation diagnostic; controls untouched')
    interfaces = {}
    for name, path in (('proc', CONTROLS['path']), ('sysfs', PARAMS + 'hide_list')):
        try:
            content = raw if name == 'proc' else Path(path).read_bytes()
            value = content.decode()
            interfaces[name] = {'path': path, 'errno': 0, 'bytes': len(content),
                                'sha256': hashlib.sha256(content).hexdigest(), 'text': value,
                                'visible_rows': sum(line.startswith('path=') for line in value.splitlines()),
                                'truncation_reported': 'truncated:' in value}
        except OSError as error:
            interfaces[name] = {'path': path, 'errno': error.errno}
    return {'kind': 'cp23-preflight-blocked', 'reason_code': 'path_listing_truncated',
            'boot_id': boot_id(), 'kernel': KERNEL, 'candidate': guard,
            'controls_attempted': False, 'snapshot_complete': False,
            'path_interfaces': interfaces,
            'limit': 'CP23 exposes one page of path rules through both proc and sysfs. '
                     'The omitted rules remain intact but cannot be inventoried through these interfaces.'}


def snapshot():
    guard = cp23_guard()
    blocked = path_snapshot_blocker(guard)
    if blocked is not None:
        return blocked
    result = _retained_snapshot()
    result['candidate'] = guard
    return result


def read_fixed_batch(directory):
    directory = Path(directory)
    require(str(directory).startswith('/sdcard/Download/'), 'Use the extracted Download test directory')
    manifest = json.loads((directory / 'phone-tests-manifest.json').read_text())
    require(manifest == FIXED_MANIFEST, 'Fixed CP23 test manifest differs; no fixture controls sent')
    result = {}
    for name in REGRESSION:
        path = directory / 'phone-tests' / name
        info = path.lstat()
        require(stat.S_ISREG(info.st_mode) and info.st_size <= 1024 * 1024, 'Invalid test artifact: ' + name)
        content = path.read_bytes()
        expected = FIXED_MANIFEST['files'][name]
        require(len(content) == expected['bytes'] and hashlib.sha256(content).hexdigest() == expected['sha256'],
                'Retained test artifact checksum differs: ' + name)
        result[name] = base64.b64encode(content).decode()
    return {'manifest': manifest, 'sources': result}


def root_dispatch(request):
    require(os.geteuid() == 0, 'Root command requires UID 0')
    op = request['op']
    require(op in ('state', 'read_batch', 'module_observe', 'module_write'),
            'Final acceptance root operation is not allowed')
    cp23_guard()
    expected = request.get('expected_boot_id')
    if expected is not None:
        require(boot_id() == expected, 'Boot changed; no further fixture controls sent')
    if op == 'module_write':
        require(expected is not None, 'Module assertion requires a saved boot identity')
    if op == 'read_batch':
        return read_fixed_batch(request['directory'])
    return _retained_root_dispatch(request)


def root_call(op, **arguments):
    global EXPECTED_BOOT_ID
    if EXPECTED_BOOT_ID is not None:
        arguments['expected_boot_id'] = EXPECTED_BOOT_ID
    result = _retained_root_call(op, **arguments)
    if op == 'state':
        if result.get('kind') == 'cp23-preflight-blocked':
            require(result.get('reason_code') == 'path_listing_truncated' and
                    result.get('controls_attempted') is False and result.get('snapshot_complete') is False,
                    'Invalid blocked preflight reply')
            with tempfile.NamedTemporaryFile(mode='w', prefix='rmgu-cp23-preflight-', suffix='.json',
                                             dir=Path.home(), delete=False) as stream:
                json.dump(dict(result, reader_uid=os.geteuid(), app_uname_release=os.uname().release),
                          stream, indent=2)
                stream.write('\n')
                evidence = stream.name
            print('READ-ONLY PREFLIGHT EVIDENCE:', evidence, flush=True)
            raise Blocked('CP23 path listing exceeds one page; a complete original-rule snapshot is unavailable. '
                          'No fixture controls sent. A5 remains unqualified; retain the preflight evidence. '
                          'Do not clear existing rules or rerun merely to reproduce this blocker.')
        if EXPECTED_BOOT_ID is None:
            EXPECTED_BOOT_ID = result['boot_id']
        require(result['boot_id'] == EXPECTED_BOOT_ID, 'Boot changed; final acceptance stopped')
    return result
