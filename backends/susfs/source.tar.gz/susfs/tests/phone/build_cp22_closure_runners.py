"""Build self-contained stdin runners from reviewed source and retained ABI readers."""
import ast
from pathlib import Path

ROOT=Path(__file__).resolve().parent
def common(path):
    tree=ast.parse(path.read_text())
    return next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and
                any(isinstance(t,ast.Name) and t.id=='COMMON' for t in n.targets))
def build(destination=ROOT):
    native=common(ROOT/'rmgu-susfs-kstat-native-test.py').split('\ndef observe(')[0]
    modules=common(ROOT/'rmgu-susfs-module-test.py').replace('def observe(', 'def module_observe(')
    runtime=native+'\n'+modules+'\n'+(ROOT/'cp22_closure_shared.py').read_text()
    destination.mkdir(parents=True,exist_ok=True)
    for stem,workflow in [('module-assertions','cp22_module_assertions_workflow.py'),
                          ('native-control','cp22_native_control_workflow.py'),
                          ('acceptance','cp22_acceptance_workflow.py')]:
        if not (ROOT/workflow).exists():continue
        text='#!/usr/bin/env python3\n# SPDX-License-Identifier: GPL-2.0\nRUNTIME = '+repr(runtime)+'\nexec(RUNTIME, globals())\n'+(ROOT/workflow).read_text()
        compile(text,stem,'exec')
        (destination/('rmgu-susfs-'+stem+'-test-cp22.py')).write_text(text)
if __name__=='__main__':build()
