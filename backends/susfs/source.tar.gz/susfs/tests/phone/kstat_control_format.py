"""Emit control fixtures using the actual production kstat_proc_show function.

Only kernel output/locking APIs and input state are stubbed. The emitted rule,
diagnostic, maps and syscall-counter formats and ordering come from kernel C.
"""
import os
from pathlib import Path
import re
import subprocess
import tempfile


def production_outputs(source_dir=None, commands=()):
    source_dir = Path(source_dir) if source_dir else Path(__file__).resolve().parents[2]
    source = (source_dir / 'kernel/susfs_kstat.c').read_text()
    def extract(pattern):
        match = re.search(pattern, source, re.M | re.S)
        if not match: raise RuntimeError('Production control fragment unavailable')
        return match.group()
    structures = ''.join(extract(r'^struct ' + name + r' \{.*?^\};\n') for name in
                         ('sus_kstat_entry', 'kstat_call_counters', 'kstat_nr_entry'))
    table = extract(r'^static struct kstat_nr_entry kstat_nr_table\[\] = \{.*?^\};\n')
    show = extract(r'^static int kstat_proc_show\([^;{]*\)\n\{\n.*?^\}\n')
    overrides = extract(r'^static int parse_override\([^;{]*\)\n\{\n.*?^\}\n')
    overrides += extract(r'^static int susfs_kstat_add_statically\([^;{]*\)\n\{\n.*?^\}\n')
    abi = (source_dir / 'kernel/susfs_abi.h').read_text()
    flags = '\n'.join(re.findall(r'^#define KSTAT_SPOOF_\w+[^\n]+', abi, re.M)) + '\n'
    stubs = r'''
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <stdbool.h>
#include <errno.h>
#define SUS_KSTAT_MAX 32
#define KSTAT_PATH_MAX 256
#define __NR_newfstatat 79
#define __NR_fstat 80
#define __NR_statx 291
#define COMPAT_FSTATAT64_NR 327
#define COMPAT_STAT64_NR 195
#define COMPAT_LSTAT64_NR 196
#define COMPAT_FSTAT64_NR 197
#define COMPAT_STATX_NR 397
#define KSTAT_UNLISTED_SEEN 8
#define ARRAY_SIZE(x) (sizeof(x) / sizeof((x)[0]))
#define READ_ONCE(x) (x)
#define min_t(t, x, y) ((t)(x) < (t)(y) ? (t)(x) : (t)(y))
typedef int atomic_t;
static int atomic_read(const atomic_t *x) { return *x; }
struct seq_file { FILE *out; };
static void seq_puts(struct seq_file *m, const char *s) { fputs(s, m->out); }
static void seq_printf(struct seq_file *m, const char *f, ...) {
    va_list args; va_start(args, f); vfprintf(m->out, f, args); va_end(args);
}
static void seq_write(struct seq_file *m, const char *s, int n) { fwrite(s, 1, n, m->out); }
static void mutex_lock(int *lock) { (void)lock; }
static void mutex_unlock(int *lock) { (void)lock; }
static int sus_path_dirent_stat_line(char *line, size_t size) {
    (void)line; (void)size; return 0;
}
static int kstat_lock, nkstat, kstat_maps_registered = 1;
static atomic_t n_kstat_map_hits, n_kstat_map_rewrites, n_kstat_unlisted;
static atomic_t n_kstat_map_routes[2];
static struct { int nmissed; } krp_kstat_maps, krp_kstat_smaps;
static long kstat_unlisted_seen[KSTAT_UNLISTED_SEEN];
'''
    state = 'static struct sus_kstat_entry kstat_entries[SUS_KSTAT_MAX];\n'
    state += ''.join('static struct kstat_call_counters cnt_' + name + ';\n' for name in
                     ('nfstatat', 'nfstat', 'statx', 'fstatat64', 'stat64', 'lstat64',
                      'fstat64', 'compat_statx'))
    rule_stubs = r'''
static int kstrtoll(const char *s, unsigned int base, long long *value) {
    char *end; errno = 0; *value = strtoll(s, &end, base);
    return errno || end == s || *end ? -EINVAL : 0;
}
static void strscpy(char *to, const char *from, size_t size) { snprintf(to, size, "%s", from); }
static struct sus_kstat_entry *susfs_kstat_find_by_path(const char *path) {
    for (int i = 0; i < nkstat; ++i)
        if (!strcmp(kstat_entries[i].target_pathname, path)) return &kstat_entries[i];
    return NULL;
}
static int susfs_kstat_fill_from_path(struct sus_kstat_entry *e, const char *path) {
    (void)path;
    e->target_ino = 101; e->target_dev = 22; e->spoofed_ino = 101; e->spoofed_dev = 22;
    e->spoofed_nlink = 1; e->spoofed_size = 19; e->spoofed_blocks = 8; e->spoofed_blksize = 4096;
    e->spoofed_atime_tv_sec = 1; e->spoofed_atime_tv_nsec = 2;
    e->spoofed_mtime_tv_sec = 3; e->spoofed_mtime_tv_nsec = 4;
    e->spoofed_ctime_tv_sec = 5; e->spoofed_ctime_tv_nsec = 6;
    return 0;
}
static void kstat_table_put(int index, const struct sus_kstat_entry *entry) { kstat_entries[index] = *entry; }
static int kstat_table_append(const struct sus_kstat_entry *entry) {
    if (nkstat == SUS_KSTAT_MAX) return -ENOSPC;
    kstat_entries[nkstat] = *entry; return nkstat++;
}
'''
    driver = r'''
static void add(const char *path, unsigned long ino, unsigned long spoof, long long size) {
    struct sus_kstat_entry *e = &kstat_entries[nkstat++];
    snprintf(e->target_pathname, sizeof(e->target_pathname), "%s", path);
    e->target_ino = ino; e->target_dev = 22; e->spoofed_ino = spoof;
    e->spoofed_dev = 22; e->spoofed_nlink = 1; e->spoofed_size = size;
    e->spoofed_blksize = 4096; e->flags = 0x9;
}
int main(int argc, char **argv) {
    int mode = argc >= 2 ? atoi(argv[1]) : -1;
    if (mode < 0 || mode > 3) return 2;
    if (mode & 1) add("/data/other", 1, 3, 4);
    if (mode & 2) add("/data/test", 101, 999, 8192);
    if (argc > 2 && susfs_kstat_add_statically(argv + 2, argc - 2)) return 3;
    struct seq_file output = {stdout};
    return kstat_proc_show(&output, NULL);
}
'''
    with tempfile.TemporaryDirectory(prefix='susfs-control-format-') as directory:
        directory = Path(directory)
        program = directory / 'control.c'; program.write_text(stubs + flags + structures + state + table + rule_stubs + overrides + show + driver)
        executable = directory / 'control'
        subprocess.run([os.environ.get('CC', 'cc'), '-std=gnu11', '-Wall', '-Wextra',
                        '-Werror', '-Wno-unused-parameter', str(program), '-o', str(executable)],
                       check=True, capture_output=True, text=True, timeout=30)
        outputs = {name: subprocess.check_output([str(executable), str(mode)], text=True, timeout=10)
                   for mode, name in enumerate(('empty', 'foreign', 'owned', 'combined'))}
        outputs.update({'command' + str(index): subprocess.check_output([str(executable), '1', *command], text=True, timeout=10)
                        for index, command in enumerate(commands)})
        return outputs
