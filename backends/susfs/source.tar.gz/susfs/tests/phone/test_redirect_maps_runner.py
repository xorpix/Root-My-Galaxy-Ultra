"""Actual host mappings and production callback; explicit phone API/control stubs."""
import copy
import importlib.util
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).with_name(filename))
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


r = module('redirect_mapping_runner', 'rmgu-susfs-redirect-maps-test.py')
builder = module('redirect_mapping_builder', 'build_redirect_maps_runner.py')
retained = module('redirect_mapping_retained', 'test_redirect_statfs_runner.py')
production = module('redirect_mapping_production', 'redirect_maps_production.py')
REAL_SNAPSHOT = r.mapping_snapshot
FOREIGN = retained.FOREIGN


class MappingPhoneModel(retained.PhoneModel):
    """Actual mappings/syscalls; roots, labels, controls and route delivery modeled."""
    def __init__(self, test, home, hook, failure=None):
        super().__init__(test, home, failure); self.hook = hook

    def effect(self, value, forced=False):
        for view, rows in value['views'].items():
            for name, row in list(rows.items()):
                deliver = not ((self.failure == 'maps_leak' and view.startswith('maps_')) or
                               (self.failure == 'smaps_leak' and view.startswith('smaps_')))
                text, _ = self.hook.rewrite(row['raw'] + '\n', self.config,
                                            self.config['slots'][name]['file'], uid=10362, deliver=deliver)
                rows[name] = r.parse_header(text.rstrip('\n'))
        return value

    def snapshot(self, config):
        value = REAL_SNAPSHOT(config)
        if self.active and os.geteuid() == 10362: self.effect(value)
        if self.failure == 'baseline_wrong' and not self.active:
            value['views']['maps_full']['destination_before_main']['raw'] += ' '
        if self.failure == 'missing_view' and self.active: value['views'].pop('maps_small')
        if self.failure == 'control_spoof' and self.active:
            value['views']['smaps_small']['source_control_main']['raw'] += ' '
        return value

    def open(self, path, flags, *args, **kwargs):
        if self.failure == 'forward_leak': return retained.REAL_OPEN(path,flags,*args,**kwargs)
        return super().open(path,flags,*args,**kwargs)

    def call(self, action, config):
        if action == 'map_observe':
            if self.unknown: raise AssertionError('Root followup after unknown outcome')
            self.events.append(action); self.config = config
            if self.failure == 'unknown_observe' and self.active:
                self.unknown = True; raise r.RootCommandUnknown('explicit host unknown mapping observation')
            with patch.object(r.os, 'geteuid', return_value=0): value = REAL_SNAPSHOT(config)
            if self.failure == 'root_spoof' and self.active: self.effect(value,forced=True)
            return value
        result = super().call(action, config)
        if action == 'state': result['mapping_routes'] = 'checkpoint=22 routes=2 ready=%d maps=4 smaps=4 missed=0/0' % self.active
        if action == 'setup' and result['available']:
            for name in ('destination','destination_control'):
                fd = retained.REAL_OPEN(config['paths'][name],os.O_RDWR)
                try: os.ftruncate(fd,config['mapping_size'])
                finally: os.close(fd)
        return result


class MappingWorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.hook = production.ProductionCallback()
    @classmethod
    def tearDownClass(cls): cls.hook.close()

    def run_model(self, failure=None):
        home = tempfile.TemporaryDirectory(); self.addCleanup(home.cleanup)
        model = MappingPhoneModel(self,home.name,self.hook,failure)
        uname = type('PhoneUname',(),{'machine':'aarch64','release':r.KERNEL})(); output = io.StringIO()
        # The control model and runner deliberately use the same exception type.
        with patch.object(retained.r,'RootCommandUnknown',r.RootCommandUnknown), \
             patch.object(r,'RootClient',side_effect=model.factory), patch.object(r,'process_identity',side_effect=model.identity), \
             patch.object(r.os,'readlink',side_effect=model.namespace), patch.object(r.os,'uname',return_value=uname), \
             patch.object(r.os,'geteuid',return_value=10362), patch.object(r.Path,'home',return_value=Path(home.name)), \
             patch.object(r.os,'open',side_effect=model.open), patch.object(r,'mapping_snapshot',side_effect=model.snapshot), \
             patch.object(r.sys,'argv',['owned-redirect-mapping-runner']), patch('sys.stdout',output):
            code = r.main()
        receipts = list(Path(home.name).glob('*/receipt.json'))
        receipt = json.loads(receipts[0].read_text()) if receipts else None
        return code,model,output.getvalue(),receipt

    def test_builder_standalone_and_helper_compile(self):
        self.assertEqual(Path(r.__file__).read_text(),builder.build())
        compile(r.ROOT_HELPER,'embedded-root-helper','exec')

    def test_two_cycles_real_preexisting_fresh_held_mappings_and_original_rules(self):
        code,model,output,receipt = self.run_model()
        self.assertEqual(0,code,output); self.assertIsNone(receipt)
        self.assertEqual(2,model.events.count('add')); self.assertEqual(2,model.events.count('del'))
        self.assertEqual(model.original,model.rules); self.assertIn('PASS: redirect inode/device/path',output)
        self.assertIn('active mappings held',output)

    def test_each_listing_route_leak_is_detected_and_restored(self):
        for failure in ('maps_leak','smaps_leak'):
            code,model,output,receipt = self.run_model(failure)
            self.assertEqual(1,code,output); self.assertEqual(model.original,model.rules)
            self.assertTrue(receipt['cleanup_complete']); self.assertNotIn('PASS:',output)
            self.assertIn('header identity/path/padding differ',output)

    def test_root_and_unrelated_control_spoof_are_detected(self):
        for failure in ('root_spoof','control_spoof'):
            code,model,output,receipt = self.run_model(failure)
            self.assertEqual(1,code,output); self.assertEqual(model.original,model.rules)
            self.assertTrue(receipt['cleanup_complete']); self.assertNotIn('PASS:',output)

    def test_missing_view_cannot_pass(self):
        code,model,output,receipt = self.run_model('missing_view')
        self.assertEqual(1,code,output); self.assertTrue(receipt['cleanup_complete'])
        self.assertIn('view coverage incomplete',output); self.assertEqual(model.original,model.rules)

    def test_forward_content_leak_restores_without_false_header_pass(self):
        code,model,output,receipt = self.run_model('forward_leak')
        self.assertEqual(1,code,output); self.assertTrue(receipt['cleanup_complete'])
        self.assertIn('mapped content provenance differs',output); self.assertEqual(model.original,model.rules)

    def test_unavailable_fixture_or_baseline_blocks_before_controls(self):
        for failure in ('blocked','same_fs','baseline_wrong','missing_label_receipt','unverified_label','empty_label'):
            code,model,output,receipt = self.run_model(failure)
            self.assertEqual(2,code,output); self.assertNotIn('add',model.events)
            self.assertFalse(receipt['feature_controls_attempted']); self.assertIn('BLOCKED:',output)

    def test_known_publication_failure_removes_only_owned_confirmed_rule(self):
        code,model,output,receipt = self.run_model('publication')
        self.assertEqual(1,code,output); self.assertEqual(model.original,model.rules)
        self.assertEqual(1,model.events.count('del')); self.assertTrue(receipt['cleanup_complete'])

    def test_foreign_change_refuses_del_or_cleanup(self):
        code,model,output,receipt = self.run_model('foreign_change')
        self.assertEqual(1,code,output); self.assertNotIn('del',model.events); self.assertNotIn('cleanup',model.events)
        self.assertFalse(receipt['cleanup_complete'])

    def test_unknown_add_del_or_observe_sends_no_further_root_calls(self):
        for failure in ('unknown_add','unknown_del','unknown_observe'):
            code,model,output,receipt = self.run_model(failure)
            self.assertEqual(1,code,output); self.assertTrue(receipt['root_outcome_unknown'])
            self.assertFalse(receipt['cleanup_complete']); self.assertNotIn('cleanup',model.events)
            terminal={'unknown_add':'add','unknown_del':'del','unknown_observe':'map_observe'}[failure]
            self.assertEqual(terminal,model.events[-1]); self.assertNotIn('PASS:',output)

    def test_setup_receipt_or_cleanup_failure_retains_evidence(self):
        for failure in ('setup_no_receipt','cleanup'):
            code,model,output,receipt = self.run_model(failure)
            self.assertEqual(1,code,output); self.assertFalse(receipt['cleanup_complete'])
            self.assertIn('RETAINED EVIDENCE:',output)
            if failure=='setup_no_receipt': self.assertNotIn('cleanup',model.events)


class ObserverAndProductionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.hook=production.ProductionCallback(sanitizers=True)
    @classmethod
    def tearDownClass(cls): cls.hook.close()

    def setUp(self):
        self.config={'paths':{'target':'/data/owned/original-long-name','destination':'/dev/owned/dest','source_control':'/data/owned/control'},
                     'identities':{'target':{'ino':7,'dev':os.makedev(254,81)},'destination':{'ino':123456789,'dev':os.makedev(0,5)},'source_control':{'ino':8,'dev':os.makedev(254,81)}}}
        self.line='1000-2000 rw-p 00000000 00:05 123456789     /dev/owned/dest\n'

    def test_actual_callback_shrinks_identity_grows_path_and_preserves_metrics(self):
        text,counts=self.hook.rewrite(self.line+'Rss: 4 kB\n',self.config,'destination')
        self.assertEqual((1,1,1),counts); self.assertIn('fe:51 7',text)
        self.assertIn(self.config['paths']['target'],text); self.assertTrue(text.endswith('Rss: 4 kB\n'))

    def test_actual_callback_root_control_and_no_delivery_preserve_text(self):
        for backing,uid,deliver in [('destination',0,True),('source_control',10362,True),('destination',10362,False)]:
            value,counts=self.hook.rewrite(self.line,self.config,backing,uid=uid,deliver=deliver)
            self.assertEqual(self.line,value); self.assertEqual((0,0,0),counts)

    def test_actual_callback_capacity_guard_does_not_overwrite_storage(self):
        value,counts=self.hook.rewrite(self.line,self.config,'destination',capacity=len(self.line)+1)
        self.assertEqual((1,1,0),counts); self.assertIn('/dev/owned/dest',value)

    def test_selected_rows_reject_duplicate_missing_and_malformed_headers(self):
        config={'paths':{'target':'/dev/owned/dest'},'slots':{'one':{'start':0x1000,'end':0x2000}}}
        for text in ('',self.line+self.line,self.line+'broken\n'):
            with self.assertRaises(RuntimeError): r.selected_rows(text,config,'maps')
        self.assertEqual(1,len(r.selected_rows(self.line+'Rss: 4 kB\n',config,'smaps')))

    def test_bounded_read_and_changed_subject_refuse_observation(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'table'; path.write_bytes(b'X'*128)
            with patch.object(r,'TABLE_LIMIT',64), self.assertRaises(RuntimeError): r.read_table(path,16)
        with patch.object(r,'assert_subject',side_effect=RuntimeError('owned identity changed')), self.assertRaises(RuntimeError):
            r.mapping_snapshot({'subject':{}})


class RootResizeTests(unittest.TestCase):
    def test_actual_owned_destination_resize_and_refused_size(self):
        scope={'__name__':'explicit_host_root_helper'}; exec(r.ROOT_HELPER,scope)
        for valid in (True,False):
            with tempfile.TemporaryDirectory() as folder:
                directory=Path(folder); config={'mapping_size':16*os.sysconf('SC_PAGE_SIZE') if valid else 17,
                    'paths':{name:str(directory/(name+'.txt')) for name in ('destination','destination_control')}}
                for path in config['paths'].values(): Path(path).write_bytes(b'owned-prefix\n')
                owned={name:r.file_identity(path) for name,path in config['paths'].items()}
                before={'available':True,'error':None,'owned':owned,'labels':{}}
                with patch.dict(scope,{'base_root_action':lambda action,payload:copy.deepcopy(before)}):
                    result=scope['root_action']('setup',config)
                self.assertEqual(valid,result['available']); self.assertEqual(owned,result['owned'])
                for path in config['paths'].values():
                    self.assertTrue(Path(path).read_bytes().startswith(b'owned-prefix\n'))
                    self.assertEqual(config['mapping_size'] if valid else len(b'owned-prefix\n'),Path(path).stat().st_size)

    def test_changed_owned_destination_is_not_resized(self):
        scope={'__name__':'explicit_host_root_helper'}; exec(r.ROOT_HELPER,scope)
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'owned'; path.write_bytes(b'preserve\n'); identity=r.file_identity(path); identity['ino']+=1
            config={'mapping_size':16*os.sysconf('SC_PAGE_SIZE'),'paths':{'destination':str(path)}}
            with patch.dict(scope,{'base_root_action':lambda action,payload:{'available':True,'owned':{'destination':identity}}}):
                result=scope['root_action']('setup',config)
            self.assertFalse(result['available']); self.assertEqual(b'preserve\n',path.read_bytes())


if __name__=='__main__': unittest.main(verbosity=2)
