"""CP22 test-only runtime. Native stat and module readers are embedded by the builder."""
import base64
import errno
import hashlib
import mmap
import re
import shlex
import signal
import stat
import subprocess
import tempfile
import time
from pathlib import Path

KERNEL = '6.12.69-android16-6-pb4d3caf-abogkiS948BXXS4BZIG-4k'
PARAMS = '/sys/module/susfs_guard_lkm/parameters/'
CONTROLS = {'path':'/proc/susfs_path', 'kstat':'/proc/susfs_kstat',
            'map':PARAMS+'map_rules', 'redirect':'/proc/susfs_open_redirect'}
FILES = ('plain','loop','spare','static','dynamic','replacement','map_target',
         'map_control','redirect','destination','control')
NAME = re.compile(r'[A-Za-z0-9_-]{1,63}')
UNKNOWN = False
REGRESSION = ('rmgu-susfs-path-test.sh','rmgu-susfs-mount-test.sh','rmgu-susfs-feature-test.sh',
 'rmgu-susfs-identity-test-cp17-r2.py','rmgu-susfs-map-test-cp19.py',
 'rmgu-susfs-map-lifetime-test-cp19.py','rmgu-susfs-kstat-native-test-cp20-r3.py',
 'rmgu-susfs-kstat-fields-test-cp20.py','rmgu-susfs-kstat-maps-test-cp21.py',
 'rmgu-susfs-redirect-statfs-test-cp21-r2.py','rmgu-susfs-redirect-maps-test-cp22.py')

class Blocked(RuntimeError): pass
class Unknown(RuntimeError): pass

def require(value, message):
    if not value: raise RuntimeError(message)

def boot_id(state=None):
    if state is not None: return state['boot_id']
    require(os.geteuid()==0,'Boot identity must be collected by the root helper')
    return Path('/proc/sys/kernel/random/boot_id').read_text().strip()

def identity(pid):
    value = Path('/proc/%d/stat'%pid).read_text()
    return {'pid':pid,'starttime':int(value[value.rfind(')')+2:].split()[19])}

def preflight():
    require(os.geteuid() >= 10000, 'Run with ordinary Termux Python, outside su')
    uname=os.uname()
    require(uname.machine=='aarch64' and sys.byteorder=='little' and
            ct.sizeof(ct.c_void_p)==8, 'Native AArch64 is required')
    print('App reader:',os.geteuid(),Path('/proc/self/attr/current').read_text().rstrip('\0\n'),flush=True)
    print('App uname release:',uname.release,'(native kernel pin checked by root helper)',flush=True)

def read_text(path): return Path(path).read_text().removesuffix('\n')

def boolean(value):
    require(value in ('0','1','Y','N'),'Invalid boolean control')
    return value in ('1','Y')

def avc_config(text):
    match=re.fullmatch(r'([01]) \((.*)\)',text.removesuffix('\n'))
    require(match,'Invalid AVC state')
    values={key:int(value) for key,value in re.findall(r'(\w+)=(-?\d+)',match[2])}
    fields=('su_sid','priv_app_sid','enter','hits','registered','tsid_arg',
            'abi_checked','checkpoint','last_error')
    require(set(values)==set(fields),'Invalid AVC diagnostics')
    enabled=match[1]=='1'
    require(values['registered']==int(enabled),'AVC flag and registration disagree')
    require(values['checkpoint']==18 and values['abi_checked']==1,'AVC ABI marker missing')
    # enter/hits advance during unrelated activity; last_error is diagnostic.
    return dict(enabled=enabled,**{key:values[key] for key in
                ('registered','su_sid','priv_app_sid','tsid_arg','abi_checked','checkpoint')})

def boot_config(text):
    values={key:int(value) for key,value in re.findall(r'(\w+)=(-?\d+)',text)}
    fields=('checkpoint','restore','active','captured','values','sets','resets','conflicts','last_error')
    require(set(values)==set(fields),'Invalid bootconfig diagnostics')
    require(values['checkpoint']==18 and values['restore']==1 and
            values['active'] in (0,1) and values['captured'] in (0,1),'Bootconfig restoration marker missing')
    return {key:values[key] for key in ('checkpoint','restore','active','captured')}

def mount_config(diagnostics,prefix_dump):
    lines=diagnostics.splitlines()
    flag=re.fullmatch(r'idmap=\d+/\d+  ident=\d+/\d+  hide=([01]) su_domain=[01]',
                      lines[0] if lines else '')
    require(flag,'Invalid mount_stat header')
    rows=prefix_dump.splitlines()
    count=re.fullmatch(r'mount prefixes: (\d+)/8, rescans=-?\d+, recorded=-?\d+, hidden_by_identity=-?\d+, learned_ids=-?\d+',
                       rows[0] if rows else '')
    require(count and int(count[1])<=8 and len(rows)==2 and rows[1].startswith('prefixes:'),
            'Invalid mount prefix list')
    value=rows[1][9:]
    if int(count[1])==0:
        require(value==' (none - only KSU-range ids are hidden)','Invalid empty mount prefixes')
    else:
        prefixes=value.split()
        require(len(prefixes)==int(count[1]) and all(len(os.fsencode(x))<128 for x in prefixes),
                'Mount prefixes truncated or count differs')
    return {'hide':int(flag[1]),'prefixes':rows[1]}

def module_config(text):
    first = re.match(r'^hide_modules: (\d+)/16 name\(s\), ',text)
    rows = [x for x in text.splitlines() if x.startswith('names:')]
    require(first and len(rows)==1,'Invalid module-name list')
    names = rows[0][6:].split()
    require(len(names)==int(first[1]) and len(set(names))==len(names) and
            all(NAME.fullmatch(x) for x in names),'Invalid module names/count')
    return names

def rules(kind,text):
    lines=text.splitlines()
    if kind=='path':
        require(lines and lines[0].startswith('hide_from_apps='),'Invalid path list')
        require(not any('truncated:' in x for x in lines),'Path list is truncated')
        result=[x for x in lines if x.startswith('path=')]
        require(all(re.fullmatch(r'path=/\S+  dev=\d+ ino=\d+ name=\S*.*',x) for x in result),'Invalid path row')
    elif kind=='kstat':
        marker='statx: checkpoint=20 device_pair=1 dev_bits=32 time_bits=64'
        require(lines.count(marker)==1,'CP20 statx marker missing')
        result=lines[:lines.index(marker)]
        if result==['(empty)']: result=[]
        else: require(result and all(re.fullmatch(r'/\S+ ino=\d+ dev=\d+ flags=0x[0-9a-f]+ \[.+\]',x) for x in result),'Invalid kstat rules')
    elif kind=='map':
        match=re.fullmatch(r'rules=(\d+)/\d+',lines[0] if lines else '')
        require(match and len(lines)==int(match[1])+1,'Invalid map-rule count')
        result=lines[1:]
        require(all(re.fullmatch(r'ino=\d+ dev=\d+',x) for x in result),'Invalid map row')
    elif kind=='redirect':
        require(len([x for x in lines if x.startswith('hooks: open=')])==1,'Redirect diagnostics missing')
        result=[x for x in lines if x.startswith('/')]
        require(all(re.fullmatch(r'/\S+ -> /\S+ uid=[0-4] \(.+\)',x) for x in result),'Invalid redirect rule')
    else: raise RuntimeError('Unknown rule kind')
    require(len(result)==len(set(result)),'Duplicate rules')
    return result

def snapshot():
    require(os.geteuid()==0,'Root collector requires UID 0')
    marker=read_text(PARAMS+'redirect_map_stat')
    require(re.fullmatch(r'checkpoint=22 routes=2 ready=[01] maps=\d+ smaps=\d+ missed=\d+/\d+',marker),'CP22 redirect marker missing')
    tables={kind:rules(kind,read_text(path)) for kind,path in CONTROLS.items()}
    # mount_stat owns the enabled flag. The root-only prefix parameter has
    # PAGE_SIZE output; the proc prefix formatter has only a 512-byte buffer.
    mount=mount_config(read_text(PARAMS+'mount_stat'),read_text(PARAMS+'hide_mounts'))
    state={'boot_id':boot_id(),'kernel':read_text('/proc/sys/kernel/osrelease'),
           'rules':tables,'module_names':module_config(read_text('/proc/susfs_hide_modules')),
           'mount_hide':mount['hide'],'mount_prefixes':mount['prefixes'],
           'settings':{name:read_text(PARAMS+name) for name in
              ('bootconfig','avc_su_ctx','avc_priv_app_ctx','release','version',
               'uname_spoof_enabled','enable_log','or_su_ctx')},
           'proc_log':read_text('/proc/susfs_enable_log'),
           'avc':avc_config(read_text('/proc/susfs_avc_spoof')),
           'boot_control':boot_config(read_text(PARAMS+'bootconfig_stat')),
           'selinux':read_text('/sys/fs/selinux/enforce')}
    require(boolean(state['proc_log'])==boolean(state['settings']['enable_log']),'Log controls disagree')
    for name in ('cmdline','bootconfig'):
        try:
            data=Path('/proc/'+name).read_bytes()
            state[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
        except OSError as e: state[name]={'errno':e.errno}
    require(state['kernel']==KERNEL,'Root kernel mismatch')
    return state

def write_control(path,command):
    data=(command+'\n').encode(); fd=os.open(path,os.O_WRONLY|os.O_CLOEXEC)
    try: require(os.write(fd,data)==len(data),'Short control write')
    finally: os.close(fd)

class PathPayload(ct.Structure):
    _fields_=[('target_pathname',ct.c_char*256),('err',ct.c_int)]
class KstatPayload(ct.Structure):
    _fields_=[('is_statically',ct.c_int),('target_ino',ct.c_ulong),
      ('target_pathname',ct.c_char*256),('spoofed_ino',ct.c_ulong),
      ('spoofed_dev',ct.c_ulong),('spoofed_nlink',ct.c_uint),('spoofed_size',ct.c_longlong),
      ('spoofed_atime_tv_sec',ct.c_long),('spoofed_atime_tv_nsec',ct.c_ulong),
      ('spoofed_mtime_tv_sec',ct.c_long),('spoofed_mtime_tv_nsec',ct.c_ulong),
      ('spoofed_ctime_tv_sec',ct.c_long),('spoofed_ctime_tv_nsec',ct.c_ulong),
      ('spoofed_blocks',ct.c_longlong),('spoofed_blksize',ct.c_long),('flags',ct.c_int),('err',ct.c_int)]
class RedirectPayload(ct.Structure):
    _fields_=[('target_pathname',ct.c_char*256),('redirected_pathname',ct.c_char*256),('uid_scheme',ct.c_int),('err',ct.c_int)]
class QueryPayload(ct.Structure):
    _fields_=[('value',ct.c_char*16),('err',ct.c_int)]
class FeaturesPayload(ct.Structure):
    _fields_=[('value',ct.c_char*8192),('err',ct.c_int)]

COMMANDS={'path':0x55550,'loop':0x55553,'map':0x60020,'kstat':0x55570,
          'update':0x55571,'static':0x55572,'redirect':0x555c0,
          'version':0x555e1,'features':0x555e2,'variant':0x555e3,
          'unsupported1':0x55551,'unsupported2':0x55560,'unsupported3':0x60000}

def layouts():
    expected=((PathPayload,260,256),(KstatPayload,376,372),(RedirectPayload,520,516),
              (QueryPayload,20,16),(FeaturesPayload,8196,8192))
    for cls,size,offset in expected:
        require(ct.sizeof(cls)==size and cls.err.offset==offset,'Native payload layout mismatch')
    require(KstatPayload.target_ino.offset==8 and KstatPayload.target_pathname.offset==16 and
            KstatPayload.spoofed_ino.offset==272 and KstatPayload.flags.offset==368,'Kstat field layout mismatch')

def supercall(command,payload,query=False,libc=None):
    require(command in COMMANDS.values(),'Unknown test command')
    layouts(); payload.err=126
    size=ct.sizeof(payload); original=bytes(payload)
    buffer=ct.create_string_buffer(b'G'*16+original+b'G'*16,size+32)
    libc=libc or ct.CDLL(None,use_errno=True);libc.syscall.restype=ct.c_long
    ct.set_errno(0)
    rc=libc.syscall(ct.c_long(142),ct.c_uint(0xDEADBEEF),ct.c_uint(0xFAFAFAFA),
                    ct.c_uint(command),ct.c_void_p(ct.addressof(buffer)+16))
    require(buffer.raw[:16]==b'G'*16 and buffer.raw[-16:]==b'G'*16,'Payload guards changed')
    after=buffer.raw[16:16+size]; offset=type(payload).err.offset
    if not query: require(after[:offset]==original[:offset] and after[offset+4:]==original[offset+4:], 'Input payload bytes changed')
    ct.memmove(ct.addressof(payload),after,size)
    result={'syscall':int(rc),'errno':ct.get_errno() if rc<0 else 0,'reply':payload.err,'guards':True,'input_preserved':not query}
    if query: result['value']=bytes(payload.value).decode()
    return result

def make_payload(kind,path='',destination='',profile=None,scheme=3):
    cls=KstatPayload if kind in ('kstat','update','static') else RedirectPayload if kind=='redirect' else PathPayload
    value=cls(); encoded=os.fsencode(path)
    require(len(encoded)<256 and b'\0' not in encoded,'Fixture path exceeds payload')
    value.target_pathname=encoded
    if kind=='static':
        value.is_statically=1;value.flags=0xfff
        for name,number in profile.items():setattr(value,name,number)
    if kind=='redirect':
        encoded=os.fsencode(destination);require(len(encoded)<256,'Destination path exceeds payload')
        value.redirected_pathname=encoded;value.uid_scheme=scheme
    return value

def validate_fixture(cfg,recovery=False):
    require(os.geteuid()==0 and cfg['uid']>=10000,'Invalid fixture reader identity')
    require(boot_id()==cfg['boot_id'],'Fixture belongs to a different boot')
    base=Path(cfg['base']); info=base.lstat()
    require(base.name.startswith('rmgu-susfs-native-control.') and base.parent==Path(cfg['home']) and
            str(base)==str(base.resolve()) and stat.S_ISDIR(info.st_mode) and
            info.st_uid==cfg['uid'] and [info.st_dev,info.st_ino]==cfg['directory'], 'Fixture directory identity changed')
    journal=json.loads((base/'fixture.json').read_text())
    require(journal==cfg,'Fixture journal/config mismatch')
    if not recovery: require(identity(cfg['subject']['pid'])==cfg['subject'],'Owned subject changed')
    for name in FILES:
        path=base/name
        try: info=path.lstat()
        except FileNotFoundError: continue
        require(stat.S_ISREG(info.st_mode) and info.st_nlink==1,'Unsafe owned fixture entry')
    return base

def stat_observe(path,fd=None):
    native=NativeStat();fresh=os.open(path,os.O_RDONLY|os.O_CLOEXEC)
    try:
        held=fresh if fd is None else fd
        return {'fstat_held':native.fstat(held),'fstat_fresh':native.fstat(fresh),
                'newfstatat_path':native.at(path),'newfstatat_empty':native.at('',held,0x1000),
                'statx_path':native.statx(path),'statx_empty':native.statx('',held,0x1000)}
    finally:os.close(fresh)

def map_rows(pid,ranges):
    result={}
    for kind in ('maps','smaps'):
        text=Path('/proc/%d/%s'%(pid,kind)).read_text()
        result[kind]={name:[x for x in text.splitlines() if x.startswith(value+' ')] for name,value in ranges.items()}
    return result

def read_contents(base):
    return {name:(base/name).read_bytes().hex() for name in ('redirect','destination','control')}

NON_SU_READER = r'''
import ctypes as ct
import json
import os
import sys
from pathlib import Path
request=json.loads(sys.stdin.read())
try:
    if os.geteuid()!=0:raise RuntimeError('Optional reader requires UID 0')
    lib=ct.CDLL('libselinux.so',use_errno=True)
    lib.setcon.argtypes=[ct.c_char_p];lib.setcon.restype=ct.c_int
    if lib.setcon(request['desired'].encode()):raise OSError(ct.get_errno(),'setcon')
    actual=Path('/proc/self/attr/current').read_text().rstrip('\0\n')
    if actual!=request['desired'] or actual==request['configured'] or os.geteuid()!=0:
        raise RuntimeError('Non-su reader identity not qualified')
    base=Path(request['base'])
    result={'qualified':True,'uid':os.geteuid(),'context':actual,
            'files':{name:(base/name).read_bytes().hex() for name in ('redirect','destination','control')}}
except Exception as error:
    result={'qualified':False,'reason':type(error).__name__+': '+str(error)}
print(json.dumps(result,separators=(',',':')),flush=True)
'''

def process_status(rc):
    if rc<0:
        try:return 'signal '+signal.Signals(-rc).name+' ('+str(-rc)+')'
        except ValueError:return 'signal '+str(-rc)
    return 'exit '+str(rc)

def non_su_observe(base):
    configured=read_text(PARAMS+'or_su_ctx')
    desired='u:r:su:s0' if configured!='u:r:su:s0' else 'u:r:ksu:s0'
    request={'base':str(base),'configured':configured,'desired':desired}
    # Only this child changes its domain. The root collector retains its
    # original identity and output channel even if the optional reader dies.
    try:
        child=subprocess.run([sys.executable,'-u','-c',NON_SU_READER],
            input=json.dumps(request),capture_output=True,text=True,timeout=10)
    except subprocess.TimeoutExpired:
        return {'qualified':False,'reason':'Optional non-su child timed out after 10 seconds'}
    except OSError as error:
        return {'qualified':False,'reason':'Optional non-su child could not start: '+str(error)}
    if child.returncode:
        return {'qualified':False,'reason':'Optional non-su child ended with '+process_status(child.returncode)
                +('; stderr: '+child.stderr[-1000:] if child.stderr else '; no stderr')}
    if len(child.stdout)>256*1024:
        return {'qualified':False,'reason':'Optional non-su child reply exceeded its limit'}
    try:result=json.loads(child.stdout)
    except ValueError:
        return {'qualified':False,'reason':'Optional non-su child returned no valid JSON reply'
                +('; stderr: '+child.stderr[-1000:] if child.stderr else '')}
    if not isinstance(result,dict) or type(result.get('qualified')) is not bool:
        return {'qualified':False,'reason':'Optional non-su child reply has an invalid status'}
    if not result['qualified']:
        if not isinstance(result.get('reason'),str) or not result['reason']:
            return {'qualified':False,'reason':'Optional non-su child failed without a reason'}
        return result
    files=result.get('files')
    if result.get('uid')!=0 or result.get('context')!=desired or desired==configured or \
            not isinstance(files,dict) or set(files)!= {'redirect','destination','control'} or \
            not all(isinstance(value,str) and re.fullmatch(r'(?:[0-9a-f]{2})*',value) for value in files.values()):
        return {'qualified':False,'reason':'Optional non-su child identity/content reply was not qualified'}
    return result

def root_dispatch(request):
    op=request['op']; cfg=request.get('cfg')
    require(os.geteuid()==0,'Root command requires UID 0')
    if op=='state': return snapshot()
    if op=='read_batch':
        directory=Path(request['directory'])
        require(str(directory)=='/sdcard/Download' or str(directory).startswith('/sdcard/Download/'),'Use an extracted Download test directory')
        manifest=json.loads((directory/'phone-tests-manifest.json').read_text())
        require(manifest['kind']=='cp22-fixed-phone-tests' and manifest['regression_order']==list(REGRESSION),'Fixed test manifest differs')
        result={}
        for name in REGRESSION:
            p=directory/'phone-tests'/name
            info=p.lstat();require(stat.S_ISREG(info.st_mode) and info.st_size<=1024*1024,'Invalid test artifact')
            content=p.read_bytes();item=manifest['files'][name]
            require(len(content)==item['bytes'] and hashlib.sha256(content).hexdigest()==item['sha256'],'Test artifact checksum differs: '+name)
            result[name]=base64.b64encode(content).decode()
        return {'manifest':manifest,'sources':result}
    if op=='module_observe':return module_observe(request['names'],'ROOT')
    if op=='module_write':
        require(NAME.fullmatch(request['name']) and request['action'] in ('add','del'),'Invalid owned module change')
        write_control('/proc/susfs_hide_modules',request['action']+' '+request['name']);return snapshot()
    if op=='queries':
        result={}
        for key,cls in (('version',QueryPayload),('variant',QueryPayload),('features',FeaturesPayload)):
            result[key]=supercall(COMMANDS[key],cls(),True)
        return result
    if op=='negative':
        payload=QueryPayload();return supercall(COMMANDS['version'],payload,True)
    if op=='invalid':
        result=[]
        for kind in ('path','loop','map','kstat','update','static'):
            p=KstatPayload() if kind in ('kstat','update','static') else PathPayload();p.target_pathname=b'x'*256
            result.append([kind,supercall(COMMANDS[kind],p),-errno.ENAMETOOLONG])
        for field in ('target_pathname','redirected_pathname'):
            p=RedirectPayload();setattr(p,field,b'x'*256)
            result.append(['redirect_'+field,supercall(COMMANDS['redirect'],p),-errno.ENAMETOOLONG])
        for kind in ('path','map','kstat','update','static'):
            p=make_payload(kind,request['missing'],profile={} if kind=='static' else None)
            result.append(['missing_'+kind,supercall(COMMANDS[kind],p),-errno.ENOENT])
        p=make_payload('redirect',request['missing'],request['missing'],scheme=5)
        result.append(['bad_scheme',supercall(COMMANDS['redirect'],p),-errno.EINVAL])
        for key in ('unsupported1','unsupported2','unsupported3'):
            result.append([key,supercall(COMMANDS[key],PathPayload()),126])
        return result
    base=validate_fixture(cfg,op=='cleanup')
    if op=='reader':return {'uid':os.geteuid(),'context':Path('/proc/self/attr/current').read_text().rstrip('\0\n')}
    if op=='setup':
        for name in ('plain','spare'):
            fd=os.open(base/name,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
            try:os.fchown(fd,0,0);os.fchmod(fd,0o644)
            finally:os.close(fd)
        return {name:os_fields(os.stat(base/name)) for name in FILES if (base/name).exists()}
    if op=='control':
        kind=request['kind'];require(kind in ('path','loop','map','kstat','update','static','redirect'),'Invalid fixture command')
        name=request['name'];require(name in FILES,'Invalid fixture name')
        payload=make_payload(kind,str(base/name),str(base/'destination'),request.get('profile'),request.get('scheme',3))
        reply=supercall(COMMANDS[kind],payload)
        require(reply['syscall']==0 and reply['reply']==0,'Native command failed: '+repr(reply))
        return {'reply':reply,'state':snapshot()}
    if op=='del':
        kind=request['kind'];name=request['name'];require(kind in CONTROLS and name in FILES,'Invalid owned DEL')
        write_control(CONTROLS[kind],'del '+str(base/name));return snapshot()
    if op=='stat':return stat_observe(str(base/request['name']))
    if op=='held':
        fd=request['fd'];require(isinstance(fd,int) and fd>=0,'Invalid held FD')
        return stat_observe('/proc/%d/fd/%d'%(cfg['subject']['pid'],fd))
    if op=='files':return read_contents(base)
    if op=='maps':return map_rows(cfg['subject']['pid'],request['ranges'])
    if op=='path_read':return (base/request['name']).read_bytes().hex()
    if op=='non_su':return non_su_observe(base)
    if op=='cleanup':
        current=snapshot()
        for kind in ('path','kstat','redirect'):
            for name in FILES:
                path=str(base/name)
                if any((x.startswith('path='+path+' ') if kind=='path' else x.startswith(path+' ')) for x in current['rules'][kind]):
                    write_control(CONTROLS[kind],'del '+path)
        st=os.stat(base/'map_target'); key='ino=%d dev=%d'%(st.st_ino,(os.major(st.st_dev)<<20)|os.minor(st.st_dev))
        if key in current['rules']['map']:write_control(CONTROLS['map'],'del '+str(base/'map_target'))
        require(snapshot()==request['original'],'Exact original rules/settings did not restore')
        entries=set(os.listdir(base));require(entries<=set(FILES)|{'fixture.json'},'Unrecognized fixture files; retained')
        for name in entries:os.unlink(base/name)
        base.rmdir();return {'restored':True}
    raise RuntimeError('Unknown root operation')

def root_cli():
    try:print(json.dumps(root_dispatch(json.loads(sys.argv[1])),separators=(',',':')),flush=True)
    except Exception as error:print(type(error).__name__+': '+str(error),file=sys.stderr,flush=True);sys.exit(1)

def root_call(op,**arguments):
    global UNKNOWN
    if UNKNOWN:raise Unknown('Previous root outcome is unknown; no further controls sent')
    request=dict(op=op,**arguments)
    print('ROOT',op,flush=True)
    code=RUNTIME+'\nroot_cli()\n'
    command=shlex.quote(sys.executable)+' -u -c '+shlex.quote(code)+' '+shlex.quote(json.dumps(request,separators=(',',':')))
    handle=tempfile.NamedTemporaryFile(prefix='rmgu-cp22-root-',dir=Path.home(),delete=False)
    path=Path(handle.name)
    try:
        process=subprocess.Popen(['su','-c',command],stdout=handle,stderr=subprocess.STDOUT)
        try:rc=process.wait(timeout=45)
        except subprocess.TimeoutExpired:
            UNKNOWN=True;process.terminate();raise Unknown('Root operation timed out; retained log '+str(path))
        except BaseException:
            UNKNOWN=True;process.terminate();raise
    finally:handle.close()
    def failed(reason):
        global UNKNOWN
        # A failed setter can have changed state before losing its reply.
        # Keep read failures distinguishable so owned cleanup remains possible.
        if op not in ('state','read_batch','module_observe','queries','negative',
                      'reader','stat','held','files','maps','path_read','non_su'):
            UNKNOWN=True
        message='Root helper '+op+' failed ('+process_status(rc)+'): '+reason+'; retained log '+str(path)
        if UNKNOWN:raise Unknown(message+'; outcome unknown, no further controls sent')
        raise RuntimeError(message)
    if path.stat().st_size>2*1024*1024:failed('output exceeded limit')
    text=path.read_text()
    if rc:failed(text[-4000:] if text else 'no output')
    lines=text.splitlines()
    if not lines:failed('empty reply')
    try:result=json.loads(lines[-1])
    except ValueError:failed('invalid JSON reply: '+text[-4000:])
    path.unlink()
    return result

def require_cp22_phone_tests_enabled():
    raise Blocked('CP22 phone tests suspended: first pending LOOP control was followed by a full freeze/reboot on 9 October 2026. Do not rerun or reactivate SusFS; collect existing crash evidence. No controls attempted.')

def terminal_main(run):
    try:run()
    except KeyboardInterrupt:print('Interrupted; inspect the printed owned fixture/retained log before rerunning.',flush=True);return 130
    except Blocked as error:print('BLOCKED:',error,flush=True);return 2
    except Exception as error:print('FAIL:',type(error).__name__+':',error,flush=True);return 1
    return 0
