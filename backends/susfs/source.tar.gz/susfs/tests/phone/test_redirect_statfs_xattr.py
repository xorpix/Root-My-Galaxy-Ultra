"""Real libc descriptor xattrs; owned user.* labels stand in for phone SELinux.

No host security.selinux attributes, /dev objects or feature controls are changed.
The fixture tests run the actual setup/cleanup functions with explicit host paths.
"""
from contextlib import contextmanager
import ctypes as ct
import errno
import importlib.util
import os
from pathlib import Path
import subprocess
import tempfile
import types
import unittest
from unittest.mock import patch


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).with_name(filename))
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


r = module('redirect_xattr_runner', 'rmgu-susfs-redirect-statfs-test.py')
root = module('redirect_xattr_root', 'redirect_statfs_root.py')
exec(r.SHARED, root.__dict__)
ATTRIBUTE = b'user.rmgu-cp21-label-test'
LABEL = b'owned-host-label\0opaque\xff\0'
HOOKS = 'hooks: open=1 dpath=1 statfs=1 maps=1 fdinfo=1 | rev hits: dpath=0 statfs=0 maps=0/0/0 fdinfo=0/0 | su_sid=3203 | fdinfo_probes=4/4'
REAL_OPEN = os.open


@contextmanager
def missing_python_xattrs():
    names = ('getxattr', 'setxattr', 'listxattr', 'removexattr')
    saved = {name: os.__dict__.pop(name) for name in names if name in os.__dict__}
    try:
        yield
    finally:
        os.__dict__.update(saved)


class XattrTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(); self.addCleanup(self.directory.cleanup)
        self.paths = [Path(self.directory.name) / name for name in ('source', 'destination')]
        self.fds = []
        for path in self.paths:
            path.write_bytes(b'owned-content\n')
            self.fds.append(REAL_OPEN(path, os.O_RDWR | os.O_CLOEXEC))
        self.addCleanup(lambda: [os.close(fd) for fd in self.fds])
        self.native = r.NativeXattr(ATTRIBUTE)

    def test_opaque_bytes_copy_without_any_python_xattr_api(self):
        with missing_python_xattrs():
            self.assertFalse(hasattr(os, 'getxattr'))
            self.native.set(self.fds[0], LABEL)
            receipt = self.native.copy(*self.fds)
            self.assertEqual(LABEL, self.native.get(self.fds[0]))
            self.assertEqual(LABEL, self.native.get(self.fds[1]))
            self.assertEqual({'bytes': len(LABEL), 'hex': LABEL.hex(), 'verified': True,
                              'method': 'libc fgetxattr/fsetxattr'}, receipt)
        for path in self.paths: self.assertEqual(b'owned-content\n', path.read_bytes())

    def test_native_descriptor_and_missing_attribute_errors(self):
        for fd, expected in ((-1, errno.EBADF), (self.fds[0], errno.ENODATA)):
            with self.subTest(fd=fd):
                with self.assertRaises(OSError) as problem: self.native.get(fd)
                self.assertEqual(expected, problem.exception.errno)

    def test_native_erange_and_rejected_oversize_write_preserve_existing_label(self):
        narrow = r.NativeXattr(ATTRIBUTE, limit=16); label = b'L' * 17
        self.native.set(self.fds[0], label)
        with self.assertRaises(OSError) as problem: narrow.get(self.fds[0])
        self.assertEqual(errno.ERANGE, problem.exception.errno)
        with self.assertRaises(ValueError): narrow.set(self.fds[0], label)
        self.assertEqual(label, self.native.get(self.fds[0]))

    def test_native_empty_source_and_invalid_name_limits_refuse_copy(self):
        raw = ct.create_string_buffer(1)
        self.assertEqual(0, self.native.write(self.fds[0], ATTRIBUTE, raw, 0, 0))
        with self.assertRaisesRegex(RuntimeError, 'empty'): self.native.copy(*self.fds)
        for attribute, limit in ((b'', 4096), (b'a\0b', 4096), (ATTRIBUTE, 0), (ATTRIBUTE, 65537)):
            with self.assertRaises(ValueError): r.NativeXattr(attribute, limit)

    def test_read_boundary_guard_and_oversize_return_are_rejected(self):
        def guard_corruption(fd, attribute, pointer, limit):
            ct.memmove(pointer.value + limit, b'X', 1)
            return 1
        with patch.object(self.native, 'read', side_effect=guard_corruption):
            with self.assertRaisesRegex(RuntimeError, 'guard'): self.native.get(self.fds[0])
        with patch.object(self.native, 'read', return_value=self.native.limit + 1):
            with self.assertRaisesRegex(RuntimeError, 'exceeded'): self.native.get(self.fds[0])

    def test_readback_and_source_change_are_rejected(self):
        for reads, message in (([LABEL, b'wrong'], 'readback'), ([LABEL, LABEL, b'changed'], 'Source label changed')):
            with patch.object(self.native, 'get', side_effect=reads):
                with self.assertRaisesRegex(RuntimeError, message): self.native.copy(*self.fds)


class FixtureTests(unittest.TestCase):
    def setUp(self):
        self.parent = tempfile.TemporaryDirectory(); self.addCleanup(self.parent.cleanup)
        self.source = Path(self.parent.name) / 'source'; self.source.mkdir()
        self.target = self.source / 'target.txt'; self.target.write_bytes(b'owned-source\n')
        self.destination = Path(self.parent.name) / 'device-standin'
        self.native = r.NativeXattr(ATTRIBUTE)
        for path in (self.source, self.target):
            fd = REAL_OPEN(path, os.O_RDONLY | os.O_CLOEXEC)
            try: self.native.set(fd, LABEL)
            finally: os.close(fd)
        self.config = {'subject': {'explicit_host_identity_stub': True},
                       'fixture': str(self.source), 'device_directory': str(self.destination),
                       'uid': os.geteuid(), 'gid': os.getegid(), 'original_rules': [],
                       'paths': {'target': str(self.target),
                                 'destination': str(self.destination / 'replacement.txt'),
                                 'destination_control': str(self.destination / 'control.txt')},
                       'contents': {'destination': b'owned-replacement\n'.hex(),
                                    'destination_control': b'owned-control\n'.hex()}}

    def create(self, native=None):
        opened = []
        def observe_open(*args, **kwargs):
            fd = REAL_OPEN(*args, **kwargs); opened.append(fd); return fd
        with missing_python_xattrs(), patch.object(root, 'NativeXattr', return_value=native or self.native), \
             patch.object(root.os, 'open', side_effect=observe_open):
            receipt = root.create_device_fixture(self.config, self.destination)
        for fd in opened:
            with self.assertRaises(OSError) as problem: os.fstat(fd)
            self.assertEqual(errno.EBADF, problem.exception.errno)
        return receipt

    def cleanup_fixture(self, receipt):
        config = dict(self.config, device_owned=receipt['owned'])
        with patch.object(root, 'assert_subject'), patch.object(root.os, 'geteuid', return_value=0), \
             patch.object(root, 'bounded_text', return_value=HOOKS):
            result = root.root_action('cleanup', config)
        self.assertTrue(result['removed'])
        self.assertFalse(self.destination.exists())
        self.assertEqual(b'owned-source\n', self.target.read_bytes())

    def test_actual_setup_without_python_xattrs_copies_three_labels_and_contents(self):
        receipt = self.create()
        self.assertTrue(receipt['available'], receipt)
        self.assertEqual({'directory', 'destination', 'destination_control'}, set(receipt['owned']))
        self.assertEqual(set(receipt['owned']), set(receipt['labels']))
        for label in receipt['labels'].values():
            self.assertTrue(label['verified']); self.assertEqual(LABEL.hex(), label['hex'])
        for name in ('destination', 'destination_control'):
            self.assertEqual(bytes.fromhex(self.config['contents'][name]), Path(self.config['paths'][name]).read_bytes())
        self.cleanup_fixture(receipt)

    def test_actual_partial_native_denial_retains_owned_receipt_and_cleans_only_fixture(self):
        count = 0; real_copy = self.native.copy
        def deny_second_copy(source, destination):
            nonlocal count
            count += 1
            if count == 2: raise PermissionError(errno.EACCES, 'explicit host label-denial stub')
            return real_copy(source, destination)
        with patch.object(self.native, 'copy', side_effect=deny_second_copy): receipt = self.create()
        self.assertFalse(receipt['available']); self.assertIn('PermissionError', receipt['error'])
        self.assertEqual({'directory', 'destination'}, set(receipt['owned']))
        self.assertEqual({'directory'}, set(receipt['labels']))
        self.cleanup_fixture(receipt)

    def test_source_label_failure_occurs_before_any_destination_creation(self):
        absent = r.NativeXattr(b'user.rmgu-cp21-absent-label-test')
        receipt = self.create(absent)
        self.assertFalse(receipt['available']); self.assertEqual({}, receipt['owned'])
        self.assertIn('OSError', receipt['error']); self.assertFalse(self.destination.exists())

    def test_source_owner_mismatch_occurs_before_destination_creation(self):
        self.config['uid'] += 1
        receipt = self.create()
        self.assertFalse(receipt['available']); self.assertEqual({}, receipt['owned'])
        self.assertIn('owner differs', receipt['error']); self.assertFalse(self.destination.exists())

    def test_existing_destination_preserved_and_unclaimed(self):
        self.destination.mkdir(); marker = self.destination / 'unowned'; marker.write_bytes(b'preserve\n')
        receipt = self.create()
        self.assertFalse(receipt['available']); self.assertEqual({}, receipt['owned'])
        self.assertIn('FileExistsError', receipt['error']); self.assertEqual(b'preserve\n', marker.read_bytes())

    def test_r1_missing_getxattr_failure_reproduced_without_dev_mutation(self):
        # Read the committed r1 code. All filesystem mutation calls in it are stubs.
        previous = subprocess.run(['git', 'show', '5c10a5614ddd7ddc1e974cd94946c90362d2d8c7:tests/phone/redirect_statfs_root.py'],
                                  cwd=Path(__file__).resolve().parents[2], check=True,
                                  capture_output=True, text=True).stdout
        old = types.ModuleType('explicit_r1_reproduction'); exec(r.SHARED, old.__dict__); exec(previous, old.__dict__)
        config = dict(self.config, fixture='/owned/rmgu-susfs-redirect-statfs.host-test',
                      device_directory='/dev/rmgu-susfs-redirect-statfs.host-test')
        with missing_python_xattrs(), patch.object(old, 'assert_subject'), \
             patch.object(old.os, 'geteuid', return_value=0), patch.object(old.os, 'mkdir') as mkdir, \
             patch.object(old.os, 'chown'), patch.object(old, 'file_identity', return_value={'explicit': 'host stub'}):
            receipt = old.root_action('setup', config)
        self.assertFalse(receipt['available']); self.assertIn("has no attribute 'getxattr'", receipt['error'])
        self.assertEqual({'directory'}, set(receipt['owned'])); mkdir.assert_called_once()


if __name__ == '__main__': unittest.main(verbosity=2)
