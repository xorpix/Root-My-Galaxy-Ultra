"""Production caller-route regression, including the CP20 helper-only baseline."""
import importlib.util
import os
from pathlib import Path
import subprocess
import unittest

spec=importlib.util.spec_from_file_location('route_production',Path(__file__).with_name('kstat_maps_production.py'))
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
LINE='1000-2000 rw-p 00000000 fe:51 101    /data/target\n'

class ListingRoutes(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.hook=p.ProductionCallback()
    @classmethod
    def tearDownClass(cls): cls.hook.close()

    def test_helper_bypass_reproduces_cp20_failure_and_top_level_fix(self):
        baseline=Path(os.environ['CP20_SOURCE'])
        old=p.ProductionCallback(baseline)
        try:
            for route,spoofed in [('show_map',False),('show_smap',True)]:
                text,counters=old.rewrite(LINE,101,65105,{'ino':7},route=route)
                self.assertEqual(spoofed,'fe:51 7 ' in text)
                fixed,counters=self.hook.rewrite(LINE,101,65105,{'ino':7},route=route)
                self.assertIn('fe:51 7 ',fixed);self.assertEqual(1,counters['rewrites'])
        finally:old.close()

    def test_failed_second_registration_rolls_back_and_pair_can_retry(self):
        subprocess.run([str(self.hook.executable),'registration'],check=True,timeout=10)

    def test_both_routes_wide_values_keep_metrics_and_prior_identical_header(self):
        prior=LINE+'Rss: 4 kB\n'
        for route in ('show_map','show_smap'):
            value,counters=self.hook.rewrite(prior+LINE+'Rss: 8 kB\n',101,65105,
                 {'ino':2**40+101,'dev':os.makedev(0xabc,0xdef01)},start=len(prior),route=route)
            self.assertTrue(value.startswith(prior));self.assertTrue(value.endswith('Rss: 8 kB\n'))
            self.assertEqual(1,value.count('abc:def01'));self.assertEqual(1,counters['rewrites'])

    def test_inode_prefix_or_path_text_cannot_match(self):
        for line in (LINE.replace('fe:51 101 ','fe:51 1019 '),
                     LINE.replace('fe:51 101 ','fe:51 202 ').replace('/data/target','/data/fe:51 101')):
            value,counters=self.hook.rewrite(line,101,65105,{'ino':7})
            self.assertEqual(line,value);self.assertEqual(0,counters['rewrites'])

    def test_empty_new_record_cannot_rewrite_an_earlier_header(self):
        value,counters=self.hook.rewrite(LINE,101,65105,{'ino':7},start=len(LINE))
        self.assertEqual(LINE,value);self.assertEqual(0,counters['rewrites'])

    def test_overflow_marks_retry_and_larger_buffer_rewrites(self):
        chosen={'ino':2**60+1,'dev':os.makedev(4094,0xabcde)}
        value,counters=self.hook.rewrite(LINE,101,65105,chosen,capacity=len(LINE)+1)
        self.assertEqual(1,counters['overflow']);self.assertEqual(0,counters['rewrites'])
        value,counters=self.hook.rewrite(LINE,101,65105,chosen,capacity=8192)
        self.assertIn('ffe:abcde %d'%chosen['ino'],value);self.assertEqual(0,counters['overflow'])
        self.assertEqual(1,counters['rewrites'])

if __name__=='__main__':unittest.main(verbosity=2)
