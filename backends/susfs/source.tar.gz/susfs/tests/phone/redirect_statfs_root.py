"""Embedded root helper; only mutations to the named owned fixture and its rule."""


def create_device_fixture(config, directory):
    """Called only after root_action validates the private /dev destination."""
    owned = {}; labels = {}; available = False; problem = None; descriptors = []
    try:
        native = NativeXattr()
        source_directory = os.open(config['fixture'], os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
        descriptors.append(source_directory)
        source_file = os.open(config['paths']['target'], os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
        descriptors.append(source_file)
        for fd, directory_expected in ((source_directory, True), (source_file, False)):
            identity = descriptor_identity(fd)
            if (identity['uid'], identity['gid']) != (config['uid'], config['gid']):
                raise RuntimeError('Source label fixture owner differs')
            if not (stat.S_ISDIR(identity['mode']) if directory_expected else stat.S_ISREG(identity['mode'])):
                raise RuntimeError('Source label fixture type differs')
            if not native.get(fd): raise RuntimeError('Source SELinux label is empty')
        os.mkdir(directory, 0o700)
        # Keep a receipt even if the first open or ownership operation fails.
        owned['directory'] = file_identity(directory)
        directory_fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
        descriptors.append(directory_fd)
        os.fchown(directory_fd, config['uid'], config['gid'])
        owned['directory'] = descriptor_identity(directory_fd)
        labels['directory'] = native.copy(source_directory, directory_fd)
        for name in ('destination', 'destination_control'):
            path = config['paths'][name]
            if Path(path).parent != directory: raise RuntimeError('Invalid device fixture child')
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
            descriptors.append(fd)
            owned[name] = descriptor_identity(fd)
            os.fchown(fd, config['uid'], config['gid'])
            owned[name] = descriptor_identity(fd)
            labels[name] = native.copy(source_file, fd)
            data = bytes.fromhex(config['contents'][name])
            if os.write(fd, data) != len(data): raise RuntimeError('Short fixture content write')
        for name, expected in owned.items():
            verify_file(directory if name == 'directory' else config['paths'][name], expected,
                        directory=(name == 'directory'))
        available = True
    except Exception as error:
        problem = '%s: %s' % (type(error).__name__, error)
    finally:
        for fd in reversed(descriptors): os.close(fd)
    return {'available': available, 'error': problem, 'owned': owned, 'labels': labels}


def root_action(action, config):
    if os.geteuid() != 0: raise RuntimeError('Root helper did not obtain uid 0')
    assert_subject(config['subject'])
    if action == 'state':
        marker = bounded_text('/proc/susfs_kstat')
        if CP21_MARKER not in marker: raise RuntimeError('CP21 maps identity marker missing')
        return parse_redirect(bounded_text(REDIRECT_CONTROL))
    if action == 'setup':
        directory = Path(config['device_directory'])
        if directory.parent != Path('/dev') or directory.name != Path(config['fixture']).name:
            raise RuntimeError('Invalid owned device fixture path')
        if not directory.name.startswith('rmgu-susfs-redirect-statfs.'):
            raise RuntimeError('Invalid fixture prefix')
        return create_device_fixture(config, directory)
    if action == 'metadata':
        identities = {name: file_identity(path) for name, path in config['paths'].items()}
        opened = os.open(config['paths']['target'], os.O_RDONLY | os.O_CLOEXEC)
        try:
            mount_id = fd_mount_id(opened)
        finally:
            os.close(opened)
        return {'identities': identities, 'source_mount_id': mount_id}
    if action == 'observe':
        return observe_files(config, config['held'])
    if action in ('add', 'del'):
        original = config['original_rules']; own = expected_rule(config)
        before = original if action == 'add' else original + [own]
        after = original + [own] if action == 'add' else original
        current = parse_redirect(bounded_text(REDIRECT_CONTROL))
        if current['rules'] != before: raise RuntimeError('Redirect rule list changed before ' + action)
        for name, path in config['paths'].items(): verify_file(path, config['identities'][name])
        if any(len(os.fsencode(path)) >= 256 or any(char.isspace() for char in path)
               for path in config['paths'].values()): raise RuntimeError('Unsupported fixture path width/spacing')
        text = ('add_open_redirect %s %s 3\n' % (config['paths']['target'], config['paths']['destination'])
                if action == 'add' else 'del %s\n' % config['paths']['target'])
        with open(REDIRECT_CONTROL, 'wb', buffering=0) as stream:
            if stream.write(text.encode()) != len(text.encode()): raise RuntimeError('Short redirect control write')
        current = parse_redirect(bounded_text(REDIRECT_CONTROL))
        if current['rules'] != after: raise RuntimeError('Redirect rule publication/restoration mismatch')
        return current
    if action == 'cleanup':
        if parse_redirect(bounded_text(REDIRECT_CONTROL))['rules'] != config['original_rules']:
            raise RuntimeError('Rules must be restored before fixture cleanup')
        directory = Path(config['device_directory']); owned = config['device_owned']
        if 'directory' not in owned: return {'removed': True, 'created': False}
        verify_file(directory, owned['directory'], directory=True)
        children = {Path(config['paths'][name]).name for name in owned if name != 'directory'}
        if set(os.listdir(directory)) != children:
            raise RuntimeError('Owned device directory contains changed or extra entries')
        for name in owned:
            if name != 'directory': verify_file(config['paths'][name], owned[name])
        for name in owned:
            if name != 'directory': os.unlink(config['paths'][name])
        os.rmdir(directory)
        return {'removed': True, 'created': True}
    raise RuntimeError('Unknown helper action')


if __name__ == '__main__':
    import base64
    import traceback
    try:
        payload = json.loads(base64.b64decode(sys.argv[2], validate=True))
        result = root_action(sys.argv[1], payload)
        assert_subject(payload['subject'])
        print(json.dumps({'ok': True, 'value': result}, separators=(',', ':')))
    except Exception as problem:
        print(json.dumps({'ok': False, 'error': '%s: %s' % (type(problem).__name__, problem)}, separators=(',', ':')))
