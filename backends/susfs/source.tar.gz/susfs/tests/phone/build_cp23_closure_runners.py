"""Build only the final CP23 runner; CP22 suspended entry points stay intact."""
import ast
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def common(path):
    tree = ast.parse(path.read_text())
    return next(ast.literal_eval(node.value) for node in tree.body if isinstance(node, ast.Assign) and
                any(isinstance(target, ast.Name) and target.id == 'COMMON' for target in node.targets))


def build(destination=ROOT):
    native = common(ROOT / 'rmgu-susfs-kstat-native-test.py').split('\ndef observe(')[0]
    modules = common(ROOT / 'rmgu-susfs-module-test.py').replace('def observe(', 'def module_observe(')
    manifest = json.loads((ROOT / 'cp23-fixed-phone-tests.json').read_text())
    runtime = native + '\n' + modules + '\n' + (ROOT / 'cp22_closure_shared.py').read_text()
    runtime += '\nFIXED_MANIFEST = ' + repr(manifest) + '\n' + (ROOT / 'cp23_closure_shared.py').read_text()
    workflow = (ROOT / 'cp22_module_assertions_workflow.py').read_text().split("\nif __name__=='__main__':")[0]
    assert workflow.count('def run():') == 1
    workflow = workflow.replace('def run():', 'def run_module_assertions():', 1)
    workflow = workflow.replace('Module assertions runner revision: 4 (CP22 baseline diagnostics and retained helper failures)',
                                'Module assertions (CP23 final run; baseline diagnostics and exact restoration)')
    destination.mkdir(parents=True, exist_ok=True)
    text = '#!/usr/bin/env python3\n# SPDX-License-Identifier: GPL-2.0\nRUNTIME = ' + repr(runtime)
    text += '\nexec(RUNTIME, globals())\n' + workflow + '\n' + (ROOT / 'cp23_acceptance_workflow.py').read_text()
    compile(text, 'cp23-acceptance', 'exec')
    path = destination / 'rmgu-susfs-acceptance-test-cp23.py'
    path.write_text(text)
    return path


if __name__ == '__main__':
    build()
