# CP18 phone runner revision 5

The CP18 kernel and APK are unchanged. The first phone run qualified root
bootconfig set/reset/reapply, AVC controls, invalid-input rejection, exact
restoration and cleanup. Its app bootconfig/cmdline reads were blocked with
EACCES. The owned-worker audit probes returned ENOENT and no correlated audit
lines; a global hit increment cannot establish the displayed target context.

Revision 1 relied on stdin keeping its su-launched worker alive and did not
verify that worker before opening its proc maps file. Early stdin EOF is a
possible explanation for an absent proc path, not an established phone cause.

Revision 2 uses a private release file with a random token. The worker survives
stdin EOF, waits at most 180 seconds, and exits after its owner sends the token.
The parent verifies PID, all four UIDs, start time, SELinux context and PID/mount
namespaces before and after each app access attempt. A reused PID, dead worker
or unverifiable identity cannot qualify the audit. A probe is not sent to a
worker whose identity failed validation. The worker's PID namespace must match
the reader's. Startup, root commands and exit waits remain bounded. Unknown
completion or a failed release prevents subsequent feature restoration writes.

An audit PASS requires the same EPERM/EACCES outcome in both phases, four worker
identity checks, the reader's exact PID and unique comm in the baseline and
active records, the exact configured source and replacement tcontexts, and an
increased rewrite counter. Missing logs or ENOENT remain unqualified. A changed
denial result or a correlated active record with an incorrect context fails.
No policy, SELinux enforcement, modes of existing files or module state changes.

The revision 2 phone run exits during worker startup, before an identity line,
either app probe or an AVC activation. Its native fingerprints and exact AVC
flag were restored; enter=76 and hits=1 are unchanged. Revision 2 discarded the
worker's stderr, so that output cannot establish why startup failed. Its
"PARTIAL PASS: AVC audit pair" phrase does not qualify a pair that never ran.

Revision 3 records the worker's last startup stage, stderr/traceback, return
code and startup stdout. Stages cover argument checking, the release path,
credential changes, dumpability and each proc identity read. Stderr goes to a
private temporary file rather than a pipe; even a long traceback cannot block
the worker while the parent awaits stdout. Evidence displays at most 16 KiB
and explicitly marks truncation. Startup and exit waits retain their bounds.
The audit-only partial result now explicitly calls the audit pair unqualified.

The revision 3 startup-only phone result identifies a specific runner failure:
after the UID drop, stat/status/context reads completed, but reading
`/proc/30964/ns/pid` returned ENOENT. The worker exited with status 1 before
readiness. The collector sent no feature controls, verified unchanged state,
retained the fixture and returned to the shell. This does not establish the
underlying reason for the unavailable namespace link or qualify AVC rewriting.

Revision 4 captures namespace information while the owned worker is still root,
before changing credentials. After the UID drop, its readiness message still
includes live PID, all four UIDs, start time, context and dumpability. A separate
root verifier reads the worker and the ordinary reader's identities and
namespaces. It checks the captured worker identity and the shared PID/mount
namespaces before any audit test control, then repeats the checks around both
access attempts. The ordinary reader no longer needs to read namespace links.

If a PID namespace link is absent even to root, it is accepted only when the
running kernel's `/proc/config.gz` explicitly contains
`# CONFIG_PID_NS is not set`. The mount namespace still must be available and
match. Missing/unreadable configuration or an enabled PID namespace without a
link cannot qualify the worker. The phone's CONFIG_PID_NS value is not yet known.
Linux documents that PID namespaces require CONFIG_PID_NS:
https://man7.org/linux/man-pages/man7/pid_namespaces.7.html

The revision 4 phone run now verifies worker readiness, the initial identity
gate and all four checks around the audit accesses. Both reader and worker
report disabled PID namespaces, established by the running kernel configuration,
and share `mnt:[4026536367]`. Both app maps accesses still return ENOENT despite
the live worker. No tagged dmesg audit record is found. Hits increase from 1 to
2, but that cannot attribute or qualify a displayed context rewrite. Exact flag
restoration, unchanged native data and cleanup complete without bootconfig writes.

Revision 5 uses `kill(owned_worker_pid, 0)` for the audit pair. Signal zero sends
no signal and checks process existence and permission; it does not open a proc
path or read memory. This avoids the maps lookup dependency without changing
proc mounts, policy or process permissions. A policy that permits or does not
audit this operation still leaves target-context rewriting unqualified.
The permission semantics are documented by Linux:
https://man7.org/linux/man-pages/man2/kill.2.html

Audit collection now reads both dmesg and Android logcat. Each source has a
five-second command deadline, a 1 MiB output-tail read bound and a 2 KiB stderr
bound. Only AVC lines matching the test's tag are returned, up to 32 per source;
unrelated log text is discarded. A failed source does not prevent reading the
other, and per-source availability, bytes, truncation and match counts are
reported. The existing outer root-command deadline remains in place. Android
documents both log routes:
https://source.android.com/docs/security/features/selinux/validate

The probe tags now include a random per-run suffix and fit the 15-byte comm
limit. Qualification additionally requires a denied `signull` permission in
the process class. A correlated active record with a conflicting target context
fails, including when another record has the intended replacement. Four live
identity checks, unchanged denial, PID/tag correlation and the hit increment
remain mandatory. ENOENT, success, missing logs or unrelated permission records
cannot qualify rewriting. The R4 proc-visibility cause remains unqualified.

Use the audit-only mode with the currently loaded CP18 module:

```sh
su -c 'cat /sdcard/Download/rmgu-susfs-boot-avc-test-cp18-r5.py' | python -u - --audit-only
```

The read-only --startup-only collector remains available. It reads the native
state, starts and verifies the owned worker if
possible, releases it, then checks the feature flags, boot diagnostics and
native data again. It sends no bootconfig or AVC feature controls and no
restoration writes. It retains before.json, after.json, startup-evidence.json
and the private helper in the printed fixture path, including on failure.
Unknown completion stops further root calls. COLLECTION COMPLETE verifies the
collector's unchanged-state scope; it never claims that AVC rewriting passed.
Revision 5 phone validation is recorded below. Revision 4 establishes disabled
PID namespace configuration and a live worker, but does not establish why app
access to that worker's maps path returns ENOENT.

The audit-only path saves a native-baseline snapshot, toggles only AVC controls,
restores the exact saved AVC flag and checks bootconfig/cmdline/settings remain
unchanged. It does not send bootconfig set/reset writes. Its saved scope also
limits recovery to AVC restoration. Older snapshots without a scope retain the
full runner's restoration behavior. All recovery is fenced to the saved boot ID.
Snapshots remain if restoration or completion cannot be verified.

Run without a mode flag for the complete bootconfig/AVC exercise. The canonical
source filename remains rmgu-susfs-boot-avc-test-cp18.py; the supplied r5 filename
is an identical copy. The APK remains pinned to its original CP18 source revision;
this later source commit changes only the phone runner, tests and this document.

Validation: tests/phone/test_boot_avc_runner.py includes the existing restoration,
timeout and boot-ID fence cases plus a real subprocess that remains alive with
stdin set to DEVNULL and exits on its release file. It also checks audit-only
restoration, dead/reused worker rejection, bounded release failures and the
complete correlated-audit qualification conditions. Revision 3 adds real
subprocess checks for failure stderr, stages, return codes, invalid stdout and
large output without a pipe deadlock, plus helper traceback and collector
no-control/retained-evidence checks. It does not simulate a Samsung audit
output as a hardware result. All 47 focused tests pass. Revision 4 adds checks
for pre-drop namespace capture, post-drop identity reads without namespace
access, explicit disabled-PID-namespace configuration proof, root verification
of both processes, mismatch/unavailable-reader rejection and reaching the audit
probes only after the initial identity gate. Credential changes are mocked in
those tests; no host process is actually switched to the Android UID.
All 54 focused tests pass for revision 5. New cases include a real owned host
process remaining alive after signal zero, comm restoration on success/denial,
PID-shape rejection, wrong permission/class and conflicting-context rejection,
logcat-only records, independent source failure, bounded large log output and
tag uniqueness/length at the Linux PID limit. Host test fixtures are assertion
inputs; they do not qualify Samsung audit output.

## Revision 5 phone result

The reported R5 audit-only run verifies startup and all four live worker checks.
Both signal-zero probes return EACCES=13. Dmesg and logcat succeed in both
phases, none reaches the capture byte limit, and all have zero tagged matches.
Hits rise from 2 to 3; final enter=174, hits=3, registered=0, enabled=false,
last_error=0. Native bootconfig, exact saved AVC flag, unrelated state and
cleanup are reported verified; the shell prompt returns. No bootconfig writes
or freeze/reboot are reported.

This is a scoped PARTIAL PASS. The global pre-handler hit cannot attribute an
event to the probe or prove a formatted replacement target context. Android
documents post-boot AVC log rate limiting; it is a possible explanation, not
the established cause on this phone. The SusFS ENABLE_LOG implementation only
gates its debug output. Repeating the same audit-only test is paused, with
actual emitted-context rewriting still unqualified. The full normalized
receipt is tests/phone/evidence/cp18-r5-audit-20261008.json.

The next runner is documented in CP18_MAP_EDGES_RUNNER.md. No APK/kernel or
audit-runner code was changed for this result.
