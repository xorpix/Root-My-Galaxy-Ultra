#!/usr/bin/env python3
"""Exercise the CP19 observer, metadata assertions and bounded root timeout."""
import copy
import importlib.util
import io
import json
import os
from pathlib import Path
import struct
import signal
import subprocess
import sys
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest import mock
from contextlib import redirect_stdout


spec=importlib.util.spec_from_file_location('map_runner',Path(__file__).with_name('rmgu-susfs-map-test.py'))
runner=importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)


class MapRunnerTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fixture=tempfile.TemporaryDirectory(prefix='susfs-map-runner-host-')
        target=Path(cls.fixture.name)/'target.bin'
        control=Path(cls.fixture.name)/'control.bin'
        target.write_bytes(b'T'*(64*1024))
        control.write_bytes(b'C'*(64*1024))
        cls.items={'target':runner.mapping(target),'control':runner.mapping(control)}
        cls.observed=runner.probe(cls.items,'HOST OBSERVER')
        cls.visible=copy.deepcopy(cls.observed)
        # This executor can deny process_vm_readv through seccomp. Preserve the
        # real observation separately; only the assertion fixture models the
        # known successful phone baseline for this unchanged CP14 observation.
        for item in cls.visible['target'],cls.visible['control']:
            if item['process_vm_readv']['bytes']<0:
                assert item['process_vm_readv']['errno'] in (1,13,38)
                item['process_vm_readv']={'bytes':16,'hex':item['direct_hex'],'errno':0}
        if os.environ.get('SUSFS_MAP_RUNNER_EVIDENCE'):
            Path(os.environ['SUSFS_MAP_RUNNER_EVIDENCE']).write_text(json.dumps(
                {'kind':'actual Linux observer; assertion fixtures modeled for host-blocked process_vm_readv',
                 'hardware_validated':False,'observation':cls.observed},indent=2)+'\n')

    @classmethod
    def tearDownClass(cls):
        for item in cls.items.values():
            item['view'].close()
        cls.fixture.cleanup()

    def hidden(self):
        state=copy.deepcopy(self.visible)
        item=state['target']
        for field in ('maps_rows','smaps_rows','map_files_listing_rows','map_files_small_rows','smaps_rss_kb'):
            item[field]=0
        item.update(map_files_link='',map_files_errno=2)
        item['pagemap']={'bytes':0,'present':False,'metadata':'0x0'}
        item['mem']={'bytes':-1,'hex':'','errno':5}
        item['process_vm_readv']={'bytes':-1,'hex':'','errno':14}
        for field in ('map_files_direct','map_files_cold'):
            for method in item[field]:
                item[field][method]={'errno':2}
        state['map_files_changes']['target_rows']=0
        return state

    def test_direct_metadata_leak_fails_after_accessible_baseline(self):
        hidden=self.hidden()
        hidden['target']['map_files_direct']['lstat']=self.visible['target']['map_files_direct']['lstat']
        issues,_=runner.direct_errors(self.visible,hidden,False,'HIDDEN')
        self.assertTrue(any('lstat' in issue for issue in issues))

    def test_fresh_range_metadata_leak_is_independently_detected(self):
        hidden=self.hidden()
        hidden['target']['map_files_cold']['opath_nofollow']=self.visible['target']['map_files_cold']['opath_nofollow']
        issues,_=runner.direct_errors(self.visible,hidden,False,'HIDDEN')
        self.assertTrue(any('fresh-range opath_nofollow' in issue for issue in issues))

    def test_fresh_range_is_unique_and_metadata_is_its_first_proc_access(self):
        records=[]
        def access(item):
            records.append((item['address'],item['size']))
            return {}
        with mock.patch.object(runner,'link_access',side_effect=access), \
             mock.patch.object(runner.os,'listdir',side_effect=AssertionError('cache warmed')), \
             mock.patch.object(runner,'_cold_sequence',0):
            first=runner.cold_alias_access(self.items['target'])
            second=runner.cold_alias_access(self.items['target'])
        self.assertNotEqual(first['range'],second['range'])
        self.assertEqual([os.sysconf('SC_PAGE_SIZE'),2*os.sysconf('SC_PAGE_SIZE')],
                         [length for address,length in records])

    def test_wrong_followed_file_cannot_qualify_a_visible_control(self):
        state=copy.deepcopy(self.visible)
        state['control']['map_files_direct']['stat_follow']={'errno':0,'ino':1,'dev':1,'mode':0o100600}
        self.assertTrue(any('mapped file' in issue for issue in runner.errors(state,True,'ROOT')))

    def test_metadata_failure_is_reported_after_rule_removal_and_fixture_cleanup(self):
        with tempfile.TemporaryDirectory() as temporary:
            fixture=Path(temporary)/'fixture'; fixture.mkdir()
            active=[False]; operations=[]
            hidden=self.hidden()
            hidden['rollup_rss_kb']=self.visible['rollup_rss_kb']-self.visible['target']['smaps_rss_kb']
            hidden['target']['map_files_direct']['lstat']=self.visible['target']['map_files_direct']['lstat']
            root_view=copy.deepcopy(self.visible); root_view['uid']=0
            diagnostics='vm: pin_calls=0\nlisting: maps_calls=0\nmap_files: ready=1 route=kprobe divert_checked=1\nmap_metadata: checkpoint=19 ready=1\n'
            def read_rules():
                value=os.stat(fixture/'target.bin') if active[0] else None
                return [(value.st_ino,(os.major(value.st_dev)<<20)|os.minor(value.st_dev))] if value else []
            def write(operation,path):
                operations.append(operation); active[0]=operation=='add'
            def root_response(command,progress=False):
                return diagnostics if command=='cat '+runner.STATS else json.dumps(root_view)
            with mock.patch.object(runner.os,'geteuid',return_value=10362), \
                 mock.patch.object(runner.os,'uname',return_value=SimpleNamespace(machine='aarch64',release=runner.KERNEL)), \
                 mock.patch.object(runner.tempfile,'mkdtemp',return_value=str(fixture)), \
                 mock.patch.object(runner,'root',side_effect=root_response), \
                 mock.patch.object(runner,'probe',side_effect=[self.visible,self.visible,hidden,self.visible]), \
                 mock.patch.object(runner,'read_rules',side_effect=read_rules), \
                 mock.patch.object(runner,'write_rule',side_effect=write), \
                 redirect_stdout(io.StringIO()) as out:
                with self.assertRaisesRegex(RuntimeError,'target cached lstat'):
                    runner.main()
            self.assertEqual(['add','del'],operations)
            self.assertFalse(active[0]); self.assertFalse(fixture.exists())
            self.assertIn('Cleanup complete',out.getvalue())

    def test_visible_proc_inode_may_change_between_root_readers(self):
        current=copy.deepcopy(self.visible)
        for name in ('target','control'):
            for method in ('lstat','opath_nofollow'):
                current[name]['map_files_direct'][method]['ino']+=100
        issues,_=runner.direct_errors(self.visible,current,True,'ROOT')
        self.assertEqual([],issues)

    def test_blocked_link_follow_is_unqualified_and_must_stay_blocked_for_control(self):
        baseline=copy.deepcopy(self.visible)
        hidden=self.hidden()
        for state in (baseline,hidden):
            state['control']['map_files_direct']['open_follow']={'errno':1}
        issues,blocked=runner.direct_errors(baseline,hidden,False,'HIDDEN')
        self.assertEqual([],issues)
        self.assertTrue(any('control cached open_follow' in note for note in blocked))
        hidden['control']['map_files_direct']['open_follow']={'errno':13}
        issues,_=runner.direct_errors(baseline,hidden,False,'HIDDEN')
        self.assertTrue(any('blocked' in issue for issue in issues))

    def test_changed_directory_requires_mutation_and_hidden_target_absence(self):
        hidden=self.hidden()
        hidden['map_files_changes']['changes_during_observation']=0
        self.assertTrue(any('unqualified' in issue for issue in runner.errors(hidden,False,'HIDDEN')))
        hidden=self.hidden()
        hidden['map_files_changes']['target_rows']=1
        self.assertTrue(any('stable hidden target' in issue for issue in runner.errors(hidden,False,'HIDDEN')))

    def test_real_changing_directory_worker_stops_and_exercises_mapping_changes(self):
        observed=runner.changing_directory(self.items,'HOST CHANGE')
        self.assertEqual(12,observed['passes'])
        self.assertGreater(observed['changes_during_observation'],0)

    def test_getdents_deadline_is_checked_before_syscall(self):
        with mock.patch.object(runner.time,'monotonic',return_value=100),mock.patch.object(runner.ct,'CDLL') as libc:
            libc.return_value.syscall.restype=runner.ct.c_long
            with self.assertRaisesRegex(RuntimeError,'deadline'):
                runner.small_directory('/proc/self/map_files',deadline=99)
            libc.return_value.syscall.assert_not_called()

    def test_actual_observer_and_small_buffer(self):
        actual_errors=runner.errors(self.observed,True,'HOST')
        self.assertEqual([], [e for e in actual_errors if 'process_vm_readv' not in e])
        self.assertGreater(self.observed['map_files_small_batches'],1)

    def test_hidden_and_control_assertions(self):
        self.assertEqual([],runner.errors(self.hidden(),False,'HIDDEN'))
        leaked=self.hidden()
        leaked['target']['map_files_listing_rows']=1
        self.assertTrue(any('map_files_listing_rows' in e for e in runner.errors(leaked,False,'HIDDEN')))

    def test_small_buffer_leak_and_duplicate_detection(self):
        leaked=self.hidden()
        leaked['target']['map_files_small_rows']=1
        leaked['map_files_small_duplicate_cookies']=1
        problems=runner.errors(leaked,False,'HIDDEN')
        self.assertTrue(any('map_files_small_rows' in e for e in problems))
        self.assertTrue(any('duplicate_cookies' in e for e in problems))

    def test_blocked_enumeration_cannot_pass(self):
        blocked=self.hidden()
        blocked['map_files_access_errno']['listdir']=13
        blocked['target']['map_files_listing_rows']=None
        self.assertTrue(any('unqualified' in e for e in runner.errors(blocked,False,'HIDDEN')))

    def test_control_omission_cannot_pass(self):
        broken=self.hidden()
        broken['control']['map_files_small_rows']=0
        self.assertTrue(any('control map_files_small_rows' in e for e in runner.errors(broken,False,'HIDDEN')))

    def test_older_module_rejected_before_fixture_or_rule(self):
        with self.assertRaisesRegex(RuntimeError,'Checkpoint 19'):
            runner.require_checkpoint('vm: pin_calls=2\nlisting: maps_calls=1\n')
        old='vm: pin_calls=0\nlisting: maps_calls=0\nmap_files: ready=0 iterate_calls=0\n'
        with self.assertRaisesRegex(RuntimeError,'Checkpoint 19'):
            runner.require_checkpoint(old)
        cp16=old.replace('iterate_calls=0','rollback_checked=1 iterate_calls=0')
        with self.assertRaisesRegex(RuntimeError,'Checkpoint 19'):
            runner.require_checkpoint(cp16)
        ready=old.replace('iterate_calls=0','route=kprobe divert_checked=1 iterate_calls=0')
        with self.assertRaisesRegex(RuntimeError,'Checkpoint 19'):
            runner.require_checkpoint(ready)  # CP17/18 lacks metadata guards.
        ready+='map_metadata: checkpoint=19 ready=0\n'
        runner.require_checkpoint(ready)
        with self.assertRaisesRegex(RuntimeError,'not installed'):
            runner.require_checkpoint(ready,active=True)
        runner.require_checkpoint(ready.replace('ready=0','ready=1'),active=True)

    def test_dirent_decoder_rejects_malformed_records(self):
        with self.assertRaises(RuntimeError):
            runner.decode_dirents(b'bad')
        with self.assertRaises(RuntimeError):
            runner.decode_dirents(struct.pack('<QqHB',1,3,32,10)+b'ABCDE')
        with self.assertRaises(RuntimeError):
            runner.decode_dirents(struct.pack('<QqHB',1,3,24,10)+b'ABCDE')
        names,cookies=runner.decode_dirents(struct.pack('<QqHB',1,3,32,10)+b'1000-2000\0\0\0\0')
        self.assertEqual(['1000-2000'],names)
        self.assertEqual([3],cookies)

    def check_root_timeout(self,cannot_kill=False):
        with tempfile.TemporaryDirectory(prefix='susfs-fake-su-') as temporary:
            directory=Path(temporary)
            record=directory/'child.pid'
            fake=directory/'su'
            fake.write_text('#!'+sys.executable+'\n'
                            'import os, subprocess, sys, time\n'
                            'from pathlib import Path\n'
                            'child=subprocess.Popen([sys.executable,"-c","import time; time.sleep(15)"],start_new_session=True)\n'
                            'Path(os.environ["SUSFS_FAKE_ROOT_CHILD"]).write_text(str(child.pid))\n'
                            'Path(os.environ["SUSFS_FAKE_ROOT_CHILD"]+".parent").write_text(str(os.getpid()))\n'
                            'time.sleep(15)\n')
            fake.chmod(0o700)
            try:
                with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH'],
                                                 'SUSFS_FAKE_ROOT_CHILD':str(record)}), \
                     mock.patch.object(runner,'ROOT_TIMEOUT',0.2):
                    start=time.monotonic()
                    if cannot_kill:
                        with mock.patch.object(runner.subprocess.Popen,'kill',side_effect=PermissionError('modeled root credentials')), \
                             self.assertRaises(runner.RootCommandTimeout):
                            runner.root('fake blocked command')
                    else:
                        with self.assertRaises(runner.RootCommandTimeout):
                            runner.root('fake blocked command')
                    self.assertLess(time.monotonic()-start,2.5)
                    child=int(record.read_text())
                    os.kill(child,0)  # It is still alive and retains inherited stdout.
            finally:
                parent=Path(str(record)+'.parent')
                if parent.exists():
                    try: os.kill(int(parent.read_text()),signal.SIGKILL)
                    except ProcessLookupError: pass
                if record.exists():
                    try: os.kill(int(record.read_text()),signal.SIGKILL)
                    except ProcessLookupError: pass

    def test_root_timeout_with_stdout_retaining_grandchild(self):
        self.check_root_timeout()

    def test_root_timeout_when_child_cannot_be_killed_or_reaped(self):
        self.check_root_timeout(cannot_kill=True)

    def test_failed_writer_captures_exact_installation_stage(self):
        output=io.StringIO()
        diagnostics='map_files: ready=0 route=kprobe divert_checked=1 probe_slot=1 probe_error=-22\n'
        with mock.patch.object(runner,'root',side_effect=[RuntimeError('printf: write: Bad address'),diagnostics]) as calls, \
             redirect_stdout(output):
            with self.assertRaisesRegex(RuntimeError,'Bad address'):
                runner.write_rule('add',Path('/fixture/target.bin'))
        self.assertEqual(2,calls.call_count)
        self.assertEqual(mock.call('cat '+runner.STATS),calls.call_args)
        self.assertIn('probe_error=-22',output.getvalue())

    def test_timed_out_writer_skips_diagnostic_read(self):
        with mock.patch.object(runner,'root',side_effect=runner.RootCommandTimeout('blocked')) as calls, \
             redirect_stdout(io.StringIO()):
            with self.assertRaises(runner.RootCommandTimeout):
                runner.write_rule('add',Path('/fixture/target.bin'))
        self.assertEqual(1,calls.call_count)

    def test_management_timeout_skips_rule_reads_and_retains_fixture(self):
        with tempfile.TemporaryDirectory(prefix='susfs-timeout-fixture-') as temporary:
            fixture=Path(temporary)/'fixture'
            fixture.mkdir()
            root_view=copy.deepcopy(self.visible)
            root_view['uid']=0
            diagnostics='vm: pin_calls=0\nlisting: maps_calls=0\nmap_files: ready=0 route=kprobe divert_checked=1\nmap_metadata: checkpoint=19 ready=0\n'
            output=io.StringIO()
            def root_response(command,progress=False):
                return diagnostics if command=='cat '+runner.STATS else json.dumps(root_view)
            with mock.patch.object(runner.os,'geteuid',return_value=10362), \
                 mock.patch.object(runner.os,'uname',return_value=SimpleNamespace(machine='aarch64',release=runner.KERNEL)), \
                 mock.patch.object(runner.tempfile,'mkdtemp',return_value=str(fixture)), \
                 mock.patch.object(runner,'root',side_effect=root_response), \
                 mock.patch.object(runner,'probe',return_value=self.visible), \
                 mock.patch.object(runner,'read_rules',return_value=[]) as reads, \
                 mock.patch.object(runner,'write_rule',side_effect=runner.RootCommandTimeout('blocked')) as writes, \
                 redirect_stdout(output):
                with self.assertRaises(runner.RootCommandTimeout):
                    runner.main()
            self.assertEqual(1,reads.call_count)
            self.assertEqual(1,writes.call_count)
            self.assertTrue((fixture/'target.bin').exists())
            self.assertIn('outcome is unknown',output.getvalue())
            self.assertIn('Fixture retained:',output.getvalue())


if __name__=='__main__':
    unittest.main()
