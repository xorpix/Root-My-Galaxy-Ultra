
"""Owned mapping observer; uses the existing bounded parser and native identities."""


def mapping_snapshot(config):
    assert_subject(config['subject'])
    pid = config['subject']['pid']
    directory = Path('/proc/self') if pid == os.getpid() else Path('/proc') / str(pid)
    views = {}
    for table in ('maps', 'smaps'):
        for style, chunk in (('full', 65536), ('small', 127)):
            views[table + '_' + style] = selected_rows(read_table(directory / table, chunk), config, table)
    descriptors = {}; opened = []
    try:
        for name, value in config['descriptors'].items():
            if pid == os.getpid(): fd = value['fd']
            else:
                fd = os.open('/proc/%d/fd/%d' % (pid, value['fd']), os.O_RDONLY | os.O_CLOEXEC)
                opened.append(fd)
            length = len(bytes.fromhex(config['contents'][value['file']]))
            descriptors[name] = {'identity': descriptor_identity(fd), 'content': os.pread(fd, length, 0).hex()}
    finally:
        for fd in opened: os.close(fd)
    assert_subject(config['subject'])
    return {'reader_uid': os.geteuid(), 'subject': config['subject'], 'views': views, 'descriptors': descriptors}


def mapping_expected_header(config, baseline, name, view, active, app):
    slot = config['slots'][name]; file = slot['file']
    references = baseline['root']['views'][view]
    native = references.get(name)
    if native is None:
        native = next(row for prior, row in references.items() if config['baseline_slots'][prior]['file'] == file)
    prefix = '%08x-%08x rw-p %08x ' % (slot['start'], slot['end'], slot['offset'])
    chosen = 'target' if app and active and file == 'destination' else file
    identity = config['identities'][chosen]
    before = '%02x:%02x %d' % (os.major(config['identities'][file]['dev']), os.minor(config['identities'][file]['dev']), config['identities'][file]['ino'])
    after = '%02x:%02x %d' % (os.major(identity['dev']), os.minor(identity['dev']), identity['ino'])
    # The existing callback pads a shrinking identity run and leaves other bytes.
    gap = ' ' * max(0, len(before) - len(after)) + native['gap']
    return prefix + after + gap + config['paths'][chosen]


def assess_mapping_phase(config, pair, baseline, active, label):
    failures = []
    if set(pair) != {'app', 'root'}: return [label + ': missing app/root view']
    for reader in ('app', 'root'):
        value = pair[reader]; app = reader == 'app'
        if value['reader_uid'] != (config['uid'] if app else 0) or value['subject'] != config['subject']:
            failures.append(label + ' ' + reader + ': reader/subject identity changed')
        if set(value['views']) != {'maps_full', 'maps_small', 'smaps_full', 'smaps_small'}:
            failures.append(label + ' ' + reader + ': view coverage incomplete'); continue
        for view, rows in value['views'].items():
            if set(rows) != set(config['slots']):
                failures.append(label + ' ' + reader + ' ' + view + ': range coverage incomplete'); continue
            for name, row in rows.items():
                wanted = mapping_expected_header(config, baseline, name, view, active, app)
                if row['raw'] != wanted:
                    failures.append(label + ' ' + reader + ' ' + view + ' ' + name + ': header identity/path/padding differ')
        for table in ('maps', 'smaps'):
            if value['views'][table + '_full'] != value['views'][table + '_small']:
                failures.append(label + ' ' + reader + ' ' + table + ': full/small reads differ')
        if set(value['descriptors']) != set(config['descriptors']):
            failures.append(label + ' ' + reader + ': descriptor coverage incomplete'); continue
        for name, observed in value['descriptors'].items():
            file = config['descriptors'][name]['file']
            if observed['content'] != config['contents'][file]:
                failures.append(label + ' ' + reader + ' ' + name + ': backing content differs')
            # Root checks the app descriptor's real backing object independently.
            if not app and observed['identity'] != config['identities'][file]:
                failures.append(label + ' ROOT ' + name + ': actual descriptor backing differs')
    return failures


def require_mapping_baseline(config, pair):
    if config['identities']['target']['dev'] == config['identities']['destination']['dev']:
        raise FixtureBlocked('Source/destination devices are equal; distinct mapping challenge unavailable')
    for reader in ('app', 'root'):
        value = pair[reader]
        for view, rows in value['views'].items():
            for name, row in rows.items():
                slot = config['slots'][name]; identity = config['identities'][slot['file']]
                if (row['start'], row['end'], row['offset'], row['perms'], row['ino'], row['dev'], row['path']) != (
                        slot['start'], slot['end'], slot['offset'], 'rw-p', identity['ino'], identity['dev'], config['paths'][slot['file']]):
                    raise FixtureBlocked(reader + ' ' + view + ' ' + name + ': non-native baseline')
    if pair['app']['views'] != pair['root']['views']: raise FixtureBlocked('App/root baseline headers disagree')
    failures = assess_mapping_phase(config, pair, pair, False, 'BASELINE')
    if failures: raise FixtureBlocked('; '.join(failures))


class OwnedMappingGroups:
    def __init__(self, config): self.config = config; self.groups = {}

    def add(self, name, opened_path, backing, aliases):
        if name in self.groups: raise RuntimeError('Owned mapping group already exists')
        fd = os.open(self.config['paths'][opened_path], os.O_RDONLY | os.O_CLOEXEC)
        group = {'fd': fd, 'mappings': [], 'slots': []}; self.groups[name] = group
        self.config['descriptors'][name] = {'fd': fd, 'file': backing}
        page = os.sysconf('SC_PAGE_SIZE')
        for suffix, length, offset in aliases:
            mapping = mmap.mmap(fd, length * page, access=mmap.ACCESS_COPY, offset=offset * page)
            group['mappings'].append(mapping)
            for index in range(0, length * page, page): _ = mapping[index]
            start = ct.addressof(ct.c_char.from_buffer(mapping)); slot_name = name + '_' + suffix
            self.config['slots'][slot_name] = {'file': backing, 'start': start, 'end': start + length * page, 'offset': offset * page}
            group['slots'].append(slot_name)
            if offset == 0:
                content = bytes.fromhex(self.config['contents'][backing])
                if mapping[:len(content)] != content: raise RuntimeError(name + ': mapped content provenance differs')

    def remove(self, name):
        group = self.groups[name]
        for mapping in group['mappings']: mapping.close()
        os.close(group['fd'])
        for slot in group['slots']: self.config['slots'].pop(slot)
        self.config['descriptors'].pop(name); self.groups.pop(name)

    def close(self):
        problems = []
        for name in list(self.groups):
            try: self.remove(name)
            except Exception as error: problems.append(name + ': ' + str(error))
        if problems: raise RuntimeError('Owned mapping release failed: ' + '; '.join(problems))
