#!/usr/bin/env python3
"""CP19 owned mapping lifetime test. Run in ordinary Termux; no APK rebuild.

Only the newly created target rule is changed. Other feature controls are not
written. Native permission-blocked baselines are reported as unqualified.
"""
import ctypes as ct

import json

import mmap

import os

from pathlib import Path

import re

import shlex

import signal

import subprocess

import sys

import tempfile

KERNEL = '6.12.69-android16-6-pb4d3caf-abogkiS948BXXS4BZIG-4k'

RULES = '/sys/module/susfs_guard_lkm/parameters/map_rules'

STATS = '/sys/module/susfs_guard_lkm/parameters/map_stat'

ROOT_TIMEOUT = 30

class RootCommandTimeout(RuntimeError):
    """The command may still be blocked in the kernel; its outcome is unknown."""

def root(command, progress=False):
    # Root readers keep stdout as JSON and inherit stderr for live markers.
    # subprocess.run's context manager waits for its direct child on timeout.
    # A root child that cannot be killed/reaped can therefore wait indefinitely.
    # Bound both waits and use regular output files to avoid descendant pipe
    # ownership coupling. A timeout does not prove that a root write was stopped.
    with tempfile.TemporaryFile(mode='w+t') as output, tempfile.TemporaryFile(mode='w+t') as error:
        proc=subprocess.Popen(['su','-c',command],stdin=subprocess.DEVNULL,
                              stdout=output,stderr=None if progress else error,
                              text=True,start_new_session=True)
        try:
            proc.wait(timeout=ROOT_TIMEOUT)
        except (subprocess.TimeoutExpired,KeyboardInterrupt) as interrupted:
            try:
                proc.kill()
            except (ProcessLookupError,PermissionError):
                pass
            try:
                proc.wait(timeout=1)
            except subprocess.TimeoutExpired:
                pass
            reason='was interrupted' if isinstance(interrupted,KeyboardInterrupt) else 'timed out after %s seconds'%ROOT_TIMEOUT
            raise RootCommandTimeout('Root command '+reason+'; its outcome is unknown. '
                                     'Capture the blocked process, then fully reboot before changing rules.')
        output.seek(0)
        error.seek(0)
        if proc.returncode:
            raise RuntimeError('Root command failed (%d): %s'%(proc.returncode,error.read().strip()))
        return output.read()

def read_rules():
    text=root('cat '+RULES)
    lines=text.splitlines()
    match=re.fullmatch(r'rules=(\d+)/64',lines[0] if lines else '')
    if not match:
        raise RuntimeError('Checkpoint 19 map_rules control missing or invalid: '+text.strip())
    entries=[]
    for line in lines[1:]:
        row=re.fullmatch(r'ino=(\d+) dev=(\d+)',line)
        if not row:
            raise RuntimeError('Invalid rule identity: '+line)
        entries.append((int(row[1]),int(row[2])))
    if len(entries)!=int(match[1]):
        raise RuntimeError('Rule count does not agree with entries')
    return entries

def write_rule(operation,path):
    print('WRITE '+operation.upper()+' target rule',flush=True)
    try:
        root("printf '%s\\n' "+shlex.quote(operation+' '+str(path))+' > '+RULES)
    except RootCommandTimeout:
        raise
    except RuntimeError:
        # The writer exited, so the parameter lock was released. Preserve the
        # precise installation stage before cleanup; root() still bounds this
        # diagnostic read. A timed-out writer must never take this path.
        print('\nRULE-WRITE FAILURE DIAGNOSTICS:\n'+root('cat '+STATS),flush=True)
        raise
    print('WRITE '+operation.upper()+' returned',flush=True)

def require_checkpoint(diagnostics,active=False):
    if ('pin_calls=' not in diagnostics or 'listing: maps_calls=' not in diagnostics or
            'map_files: ready=' not in diagnostics or 'route=kprobe' not in diagnostics or
            'divert_checked=1' not in diagnostics or
            not re.search(r'^map_metadata: checkpoint=19 ready=[01]\b',diagnostics,re.M)):
        raise RuntimeError('Checkpoint 19 metadata guards missing; no test rules changed.')
    if active and (not re.search(r'^map_files: ready=1\b',diagnostics,re.M) or
                   not re.search(r'^map_metadata: checkpoint=19 ready=1\b',diagnostics,re.M)):
        raise RuntimeError('Checkpoint 19 native map_files probes were not installed.')


COMMON = r'''
import ctypes as ct

import json

import mmap

import os

from pathlib import Path

import re

import struct

import stat as statmod

import sys

import threading

import time

HEADER = re.compile(r'^([0-9a-f]+)-([0-9a-f]+)\s+(\S+)\s+([0-9a-f]+)\s+([0-9a-f]+):([0-9a-f]+)\s+(\d+)(?:\s+(.*))?$')

class Iovec(ct.Structure):
    _fields_ = [('base', ct.c_void_p), ('length', ct.c_size_t)]

def decode_dirents(data):
    names=[]
    cookies=[]
    offset=0
    while offset<len(data):
        if len(data)-offset<20:
            raise RuntimeError('Short getdents64 record')
        ino,cookie,length,kind=struct.unpack_from('<QqHB',data,offset)
        if length<24 or length%8 or offset+length>len(data):
            raise RuntimeError('Invalid getdents64 record length')
        raw=data[offset+19:offset+length]
        if b'\0' not in raw:
            raise RuntimeError('Unterminated getdents64 name')
        name=raw.split(b'\0',1)[0].decode('ascii')
        if name not in ('.','..'):
            names.append(name)
            cookies.append(cookie)
        offset+=length
    return names,cookies

def small_directory(path, deadline=None, max_batches=65536):
    # A small real getdents64 buffer exercises resumption across hidden entries.
    nr={'aarch64':61,'x86_64':217}.get(os.uname().machine)
    if nr is None:
        raise RuntimeError('Unknown getdents64 syscall architecture')
    libc=ct.CDLL(None,use_errno=True)
    libc.syscall.restype=ct.c_long
    buf=ct.create_string_buffer(128)
    names=[]
    cookies=[]
    batches=0
    fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY)
    try:
        while batches<max_batches:
            if deadline is not None and time.monotonic()>=deadline:
                raise RuntimeError('getdents64 observation deadline exceeded')
            ct.set_errno(0)
            n=libc.syscall(ct.c_long(nr),ct.c_int(fd),ct.byref(buf),ct.c_uint(len(buf)))
            if n<0:
                raise OSError(ct.get_errno(),'getdents64')
            if not n:
                return names,cookies,batches
            batch,positions=decode_dirents(buf.raw[:n])
            names.extend(batch)
            cookies.extend(positions)
            batches+=1
        raise RuntimeError('getdents64 did not reach EOF')
    finally:
        os.close(fd)

class OwnedSlot:
    # MAP_FIXED replaces only a reservation owned by this worker. No address
    # supplied by another process is accepted, and no pointer survives exec.
    def __init__(self, pages=4):
        self.page=os.sysconf('SC_PAGE_SIZE'); self.capacity=self.page*pages
        self.libc=ct.CDLL(None,use_errno=True)
        self.libc.mmap.restype=ct.c_void_p
        self.libc.mmap.argtypes=[ct.c_void_p,ct.c_size_t,ct.c_int,ct.c_int,ct.c_int,ct.c_long]
        self.libc.munmap.restype=ct.c_int
        self.libc.munmap.argtypes=[ct.c_void_p,ct.c_size_t]
        self.address=self._map(0,self.capacity,0,mmap.MAP_PRIVATE|mmap.MAP_ANONYMOUS,-1)
        self.closed=False; self.item=None

    def _map(self,address,length,prot,flags,fd):
        ct.set_errno(0)
        value=self.libc.mmap(address,length,prot,flags,fd,0)
        if value==ct.c_void_p(-1).value:
            raise OSError(ct.get_errno(),'mmap owned slot')
        if value is None: raise RuntimeError('Unexpected zero-address reservation')
        if address and value!=address: raise RuntimeError('Owned-slot mmap changed address')
        return value

    def replace(self,path=None,pages=1,kind='vacant'):
        if self.closed: raise RuntimeError('Owned slot already closed')
        if not isinstance(pages,int) or not 1<=pages<=self.capacity//self.page:
            raise RuntimeError('Mapping length is outside the owned reservation')
        length=pages*self.page
        self._map(self.address,self.capacity,0,mmap.MAP_PRIVATE|mmap.MAP_ANONYMOUS|0x10,-1)
        self.item={'address':self.address,'size':length,'kind':kind,
                   'ino':0,'major':0,'minor':0,'path':'','direct_hex':''}
        if path is not None:
            value=os.stat(path)
            if value.st_size<length: raise RuntimeError('Owned fixture is too short')
            fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC)
            try:
                self._map(self.address,length,mmap.PROT_READ|mmap.PROT_WRITE,mmap.MAP_PRIVATE|0x10,fd)
            finally: os.close(fd)
            for offset in range(0,length,self.page): ct.c_ubyte.from_address(self.address+offset).value
            self.item.update(ino=value.st_ino,major=os.major(value.st_dev),minor=os.minor(value.st_dev),
                             path=str(path),direct_hex=ct.string_at(self.address,16).hex())
        return dict(self.item)

    def close(self):
        if not self.closed:
            if self.libc.munmap(self.address,self.capacity):
                raise OSError(ct.get_errno(),'munmap owned reservation')
            self.closed=True

def process_identity(pid,proc_pid=None):
    directory=Path('/proc/self') if pid==os.getpid() and proc_pid is None else Path('/proc')/str(proc_pid if proc_pid is not None else pid)
    text=(directory/'stat').read_text()
    actual_proc_pid=int(text.split(' ',1)[0])
    if proc_pid is not None and actual_proc_pid!=proc_pid: raise RuntimeError('Procfs identity PID changed')
    # The comm field may contain spaces or ')'; fields after its last ')' begin
    # at stat field 3, so starttime (field 22) is index 19 of that suffix.
    suffix=text[text.rfind(')')+2:].split()
    status=(directory/'status').read_text()
    match=re.search(r'^Uid:\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s*$',status,re.M)
    if not match or len(suffix)<20: raise RuntimeError('Incomplete process identity')
    result={'pid':pid,'proc_pid':actual_proc_pid,'starttime':int(suffix[19]),'uids':[int(x) for x in match.groups()]}
    for key,path,reader in (('context',directory/'attr/current',lambda p:p.read_text().strip('\0\n')),
                            ('mount_namespace',directory/'ns/mnt',os.readlink)):
        try: result[key]={'errno':0,'value':reader(path)}
        except OSError as error: result[key]={'errno':error.errno,'value':None}
    return result

def same_worker(expected,observed):
    for field in ('pid','starttime','uids'):
        if observed.get(field)!=expected.get(field):
            raise RuntimeError('Worker identity changed: '+field)
    if 'proc_pid' in expected and observed.get('proc_pid')!=expected['proc_pid']:
        raise RuntimeError('Worker identity changed: proc_pid')
    for field in ('context','mount_namespace'):
        if (expected.get(field,{}).get('errno')==0 and observed.get(field,{}).get('errno')==0
                and observed[field].get('value')!=expected[field].get('value')):
            raise RuntimeError('Worker identity changed: '+field)

def exact_rows(text,item):
    count=0
    for line in text.splitlines():
        m=HEADER.match(line)
        if (m and item['kind']=='vacant' and int(m[7]) and
                int(m[1],16)<item['address']+item['size'] and int(m[2],16)>item['address']):
            count+=1; continue
        if (m and int(m[1],16)==item['address'] and int(m[2],16)==item['address']+item['size']
                and int(m[5],16)==item['major'] and int(m[6],16)==item['minor'] and int(m[7])==item['ino']):
            count+=1
    return count

def metadata_access(link):
    result={}
    for name,follow in (('lstat',False),('stat_follow',True)):
        try:
            v=os.stat(link,follow_symlinks=follow)
            result[name]={'errno':0,'ino':v.st_ino,'dev':v.st_dev,'mode':v.st_mode}
        except OSError as error: result[name]={'errno':error.errno}
    opath=getattr(os,'O_PATH',0o10000000)
    for name,flags in (('opath_nofollow',opath|os.O_NOFOLLOW),('open_follow',os.O_RDONLY)):
        try:
            fd=os.open(link,flags|os.O_CLOEXEC)
            try:
                v=os.fstat(fd); entry={'errno':0,'ino':v.st_ino,'dev':v.st_dev,'mode':v.st_mode}
                if name=='open_follow': entry['hex']=os.pread(fd,16,0).hex()
                result[name]=entry
            finally: os.close(fd)
        except OSError as error: result[name]={'errno':error.errno}
    return result

def pread_observation(path,count,offset,pagemap=False):
    try:
        fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC)
        try: data=os.pread(fd,count,offset)
        finally: os.close(fd)
        result={'errno':0,'bytes':len(data),'hex':data.hex()}
        if pagemap:
            if len(data) not in (0,8): raise RuntimeError('Invalid pagemap read length')
            value=int.from_bytes(data,'little')
            result.update(present=bool(value&(1<<63)),metadata=hex(value&(0x1ff<<55)))
        return result
    except OSError as error: return {'errno':error.errno,'bytes':-1,'hex':''}

def remote_memory(pid,item):
    libc=ct.CDLL(None,use_errno=True)
    try: fn=libc.process_vm_readv
    except AttributeError: return {'errno':38,'bytes':-1,'hex':''}
    fn.restype=ct.c_ssize_t
    fn.argtypes=[ct.c_int,ct.POINTER(Iovec),ct.c_ulong,ct.POINTER(Iovec),ct.c_ulong,ct.c_ulong]
    data=ct.create_string_buffer(16); local=Iovec(ct.addressof(data),16); remote=Iovec(item['address'],16)
    ct.set_errno(0); n=fn(pid,ct.byref(local),1,ct.byref(remote),1,0)
    return {'errno':ct.get_errno() if n<0 else 0,'bytes':n,'hex':data.raw[:max(0,n)].hex()}

def observe(pid,items,label,proc_pid=None):
    print('READ '+label+' pid='+str(pid),file=sys.stderr,flush=True)
    directory='/proc/self' if pid==os.getpid() and proc_pid is None else '/proc/'+str(proc_pid if proc_pid is not None else pid)
    before=process_identity(pid,proc_pid)
    text={}; access={}
    for key in ('maps','smaps'):
        try: text[key]=Path(directory+'/'+key).read_text(); access[key]=0
        except OSError as error: text[key]=''; access[key]=error.errno
    try: names=os.listdir(directory+'/map_files'); access['listdir']=0
    except OSError as error: names=[]; access['listdir']=error.errno
    try:
        small,cookies,batches=small_directory(directory+'/map_files',time.monotonic()+8,4096)
        access['getdents64']=0
    except OSError as error: small=[]; cookies=[]; batches=0; access['getdents64']=error.errno
    result={'reader_uid':os.geteuid(),'identity':before,'access_errno':access,
            'small_batches':batches,'duplicate_names':len(small)-len(set(small)),
            'duplicate_cookies':len(cookies)-len(set(cookies)),'items':{}}
    for name,item in items.items():
        key='%x-%x'%(item['address'],item['address']+item['size'])
        link=directory+'/map_files/'+key
        row={'range':key,'kind':item['kind'],'ino':item['ino'],'dev':os.makedev(item['major'],item['minor']),
             'expected_hex':item['direct_hex'],'metadata':metadata_access(link)}
        for kind in ('maps','smaps'):
            row[kind+'_rows']=exact_rows(text[kind],item) if not access[kind] else None
        row['listing_rows']=names.count(key) if not access['listdir'] else None
        row['small_rows']=small.count(key) if not access['getdents64'] else None
        try:
            destination=os.readlink(link)
            entry={'errno':0,'value':destination}
            try:
                value=os.stat(destination)
                entry.update(identity_errno=0,ino=value.st_ino,dev=value.st_dev)
            except OSError as error: entry['identity_errno']=error.errno
            row['readlink']=entry
        except OSError as error: row['readlink']={'errno':error.errno,'value':''}
        if item['kind']!='vacant':
            row['pagemap']=pread_observation(directory+'/pagemap',8,
                                            (item['address']//os.sysconf('SC_PAGE_SIZE'))*8,True)
            row['mem']=pread_observation(directory+'/mem',16,item['address'])
            row['process_vm_readv']=remote_memory(pid,item)
        else:
            # This address now belongs to a PROT_NONE anonymous reservation.
            # Do not dereference it or claim file-memory revocation from it.
            row['memory_skipped']='vacant anonymous reservation'
        result['items'][name]=row
    same_worker(before,process_identity(pid,proc_pid))
    return result

def atomic_json(path,value):
    path=Path(path); pending=path.with_suffix(path.suffix+'.pending')
    with pending.open('w') as f:
        json.dump(value,f); f.write('\n')
    pending.chmod(0o600); os.replace(pending,path)

def read_json(path):
    path=Path(path)
    if path.stat().st_size>131072: raise RuntimeError('IPC record exceeds 128 KiB')
    return json.loads(path.read_text())

def worker(fixture,epoch,sequence,nonce):
    fixture=Path(fixture)
    if nonce!=read_json(fixture/'owner.json')['nonce']: raise RuntimeError('Worker nonce mismatch')
    target=fixture/'target.bin'; control=fixture/'control.bin'
    slot=OwnedSlot(); stable=OwnedSlot(pages=1)
    stopped=False
    try:
        slot.replace(target,pages=epoch+1,kind='target')
        stable.replace(control,kind='control')
        def reply(seq):
            items={'alias':dict(slot.item),'control':dict(stable.item)}
            value={'nonce':nonce,'sequence':seq,'epoch':epoch,'identity':process_identity(os.getpid()),
                   'items':items,'self':observe(os.getpid(),items,'WORKER SELF')}
            atomic_json(fixture/('reply-%d.json'%seq),value)
        reply(sequence)
        idle_deadline=time.monotonic()+120
        while time.monotonic()<idle_deadline:
            try: request=read_json(fixture/'request.json')
            except FileNotFoundError: time.sleep(0.02); continue
            if request.get('nonce')!=nonce: raise RuntimeError('Request nonce mismatch')
            seq=request.get('sequence')
            if not isinstance(seq,int): raise RuntimeError('Invalid request sequence')
            if seq<=sequence: time.sleep(0.02); continue
            if seq!=sequence+1: raise RuntimeError('Request sequence jumped')
            sequence=seq; idle_deadline=time.monotonic()+120
            op=request.get('operation')
            if op=='exec':
                if epoch>=1: raise RuntimeError('Only one owned exec is allowed')
                os.execv(sys.executable,[sys.executable,__file__,'worker',str(fixture),str(epoch+1),str(seq),nonce])
            if op=='stop':
                slot.close(); stable.close(); stopped=True
                atomic_json(fixture/('reply-%d.json'%seq),{'nonce':nonce,'sequence':seq,'stopped':True})
                return
            if op=='target': slot.replace(target,int(request['pages']),'target')
            elif op=='control': slot.replace(control,int(request['pages']),'control')
            elif op=='vacant': slot.replace(pages=int(request['pages']))
            elif op!='observe': raise RuntimeError('Unknown worker operation')
            reply(seq)
        raise RuntimeError('Worker idle deadline exceeded')
    finally:
        if not stopped: slot.close(); stable.close()

def helper_main():
    if sys.argv[1]=='worker': worker(sys.argv[2],int(sys.argv[3]),int(sys.argv[4]),sys.argv[5])
    elif sys.argv[1]=='root-observe':
        import base64
        value=json.loads(base64.b64decode(sys.argv[2]))
        print(json.dumps(observe(value['pid'],value['items'],value['label'],value.get('proc_pid'))),flush=True)
    else: raise RuntimeError('Unknown helper mode')

'''
exec(COMMON,globals())

import argparse
import base64
import secrets
import shutil

def assessment(before,now,hide,label):
    failures=[]; blocked=[]
    if now['duplicate_names'] or now['duplicate_cookies']:
        failures.append(label+' stable directory walk returned duplicate names/cookies')
    fields={'maps':'maps_rows','smaps':'smaps_rows','listdir':'listing_rows','getdents64':'small_rows'}
    for method,field in fields.items():
        if before['access_errno'][method]:
            blocked.append(label+' '+method+' baseline errno='+str(before['access_errno'][method]))
            if now['access_errno'][method]!=before['access_errno'][method]:
                failures.append(label+' '+method+' changed a permission-blocked baseline')
            continue
        if now['access_errno'][method]:
            failures.append(label+' '+method+' became unreadable'); continue
        for name,item in now['items'].items():
            expected=0 if item['kind']=='vacant' or (hide and name=='alias' and item['kind']=='target') else 1
            if item[field]!=expected: failures.append(label+' '+name+' '+field+' did not equal '+str(expected))
    for name,item in now['items'].items():
        prior=before['items'][name]
        hidden=hide and name=='alias' and item['kind']=='target'
        absent=hidden or item['kind']=='vacant'
        for method in ('lstat','opath_nofollow','stat_follow','open_follow'):
            b=prior['metadata'][method]; a=item['metadata'][method]
            if b['errno']:
                blocked.append(label+' '+name+' '+method+' baseline errno='+str(b['errno']))
                if not absent and a['errno']!=b['errno']:
                    failures.append(label+' '+name+' '+method+' changed a blocked visible baseline')
            elif absent:
                if a['errno']!=2: failures.append(label+' '+name+' '+method+' did not return ENOENT')
            elif a['errno']:
                failures.append(label+' '+name+' '+method+' lost visible access')
            elif method in ('lstat','opath_nofollow'):
                if not statmod.S_ISLNK(a['mode']): failures.append(label+' '+name+' '+method+' is not a proc symlink')
            else:
                if a['ino']!=item['ino'] or a['dev']!=item['dev']:
                    failures.append(label+' '+name+' '+method+' describes the wrong backing file')
                if method=='open_follow' and a.get('hex')!=item['expected_hex']:
                    failures.append(label+' '+name+' open_follow returned the wrong bytes')
        b=prior['readlink']; a=item['readlink']
        if b['errno']:
            blocked.append(label+' '+name+' readlink baseline errno='+str(b['errno']))
            if not absent and a['errno']!=b['errno']: failures.append(label+' changed a blocked readlink baseline')
        elif absent:
            if a['errno']!=2: failures.append(label+' '+name+' readlink did not return ENOENT')
        elif a['errno'] or not a['value']:
            failures.append(label+' '+name+' visible readlink unavailable')
        elif a.get('identity_errno') or a.get('ino')!=item['ino'] or a.get('dev')!=item['dev']:
            failures.append(label+' '+name+' readlink describes the wrong backing file')
        if item['kind']=='vacant': continue
        for method in ('mem','process_vm_readv','pagemap'):
            b=prior[method]; a=item[method]
            if b['errno']:
                blocked.append(label+' '+name+' '+method+' baseline errno='+str(b['errno']))
                if not hidden and a['errno']!=b['errno']:
                    failures.append(label+' '+name+' '+method+' changed a blocked visible baseline')
                continue
            if method=='pagemap':
                if hidden:
                    if a['errno'] or a['bytes']!=0 or a.get('metadata')!='0x0':
                        failures.append(label+' target pagemap was not suppressed')
                elif a['errno'] or a['bytes']!=8 or not a.get('present'):
                    failures.append(label+' '+name+' pagemap lost the touched page')
            elif hidden:
                if not (a['bytes']==0 or (a['bytes']<0 and a['errno'] in (5,14))):
                    failures.append(label+' target '+method+' remained readable or returned an unexpected errno')
            elif a['errno'] or a['bytes']!=16 or a['hex']!=item['expected_hex']:
                failures.append(label+' '+name+' '+method+' lost the known bytes')
    return failures,blocked

def require_self_baseline(value):
    for method,number in value['access_errno'].items():
        if number: raise RuntimeError('Worker self '+method+' baseline blocked; no rules changed')
    for name,item in value['items'].items():
        for method in ('lstat','opath_nofollow'):
            if item['metadata'][method]['errno']:
                raise RuntimeError('Worker self '+name+' '+method+' baseline blocked; no rules changed')
        if item['readlink']['errno']: raise RuntimeError('Worker self readlink baseline unavailable')

def wait_reply(proc,fixture,sequence,nonce,error,timeout=10):
    deadline=time.monotonic()+timeout
    path=fixture/('reply-%d.json'%sequence)
    while time.monotonic()<deadline:
        if path.exists():
            value=read_json(path)
            if value.get('sequence')!=sequence or value.get('nonce')!=nonce:
                raise RuntimeError('Reply ownership or sequence mismatch')
            return value
        if proc.poll() is not None:
            error.flush(); error.seek(0,os.SEEK_END); size=error.tell(); error.seek(max(0,size-8192))
            raise RuntimeError('Owned worker exited (%s): %s'%(proc.returncode,error.read()))
        time.sleep(0.02)
    raise RuntimeError('Owned worker reply timed out after '+str(timeout)+' seconds')

def stop_worker(proc,fixture,sequence,nonce,error):
    if proc is None: return True
    if proc.poll() is not None: return True
    try:
        atomic_json(fixture/'request.json',{'operation':'stop','sequence':sequence,'nonce':nonce})
        wait_reply(proc,fixture,sequence,nonce,error,timeout=2)
        proc.wait(timeout=2); return True
    except (RuntimeError,OSError,subprocess.TimeoutExpired):
        # Only this Popen-owned child receives a signal; no name/PID search.
        for action in (proc.terminate,proc.kill):
            try: action()
            except (ProcessLookupError,PermissionError): pass
            try: proc.wait(timeout=2); return True
            except subprocess.TimeoutExpired: pass
        return proc.poll() is not None

def validate_reply(reply,proc,original,markers,expected_kind=None,epoch=None):
    if reply['identity']['pid']!=proc.pid: raise RuntimeError('Reply PID is not the owned child')
    same_worker(original,reply['identity']); same_worker(original,reply['self']['identity'])
    if reply['self']['reader_uid']!=original['uids'][1]: raise RuntimeError('Worker self reader UID changed')
    if epoch is not None and reply['epoch']!=epoch: raise RuntimeError('Owned exec epoch did not advance')
    if expected_kind and reply['items']['alias']['kind']!=expected_kind:
        raise RuntimeError('Worker did not perform the requested mapping change')
    for name,item in reply['items'].items():
        if item['kind']!='vacant' and item['direct_hex']!=markers[item['kind']]:
            raise RuntimeError('Direct mapped '+name+' bytes changed')

def summary(label,views):
    result={}
    for reader,value in views.items():
        brief={'reader_uid':value['reader_uid'],'pid':value['identity']['pid'],
               'starttime':value['identity']['starttime'],'access_errno':value['access_errno'],
               'duplicates':[value['duplicate_names'],value['duplicate_cookies']]}
        for name,item in value['items'].items():
            v={'kind':item['kind'],'range':item['range'],'backing_inode':item['ino'],
               'rows':[item[k] for k in ('maps_rows','smaps_rows','listing_rows','small_rows')],
               'metadata_errno':{k:v['errno'] for k,v in item['metadata'].items()},
               'readlink_errno':item['readlink']['errno']}
            if item['kind']!='vacant':
                v['reads']={k:[item[k]['bytes'],item[k]['errno']] for k in ('pagemap','mem','process_vm_readv')}
            brief[name]=v
        result[reader]=brief
    print(label+': '+json.dumps(result,separators=(',',':')),flush=True)

def main():
    parser=argparse.ArgumentParser(description='CP19 owned mapping lifetime and cross-process access test')
    parser.add_argument('--cycles',type=int,choices=range(1,4),default=2)
    args=parser.parse_args()
    if os.geteuid()<10000: raise RuntimeError('Run in ordinary Termux, outside a root shell')
    if os.uname().machine!='aarch64' or os.uname().release!=KERNEL:
        raise RuntimeError('This runner targets SM-S948B BZIG ARM64 only')
    print('Map lifetime runner revision: 1 (CP19 owned remap, address reuse and exec)',flush=True)
    print('App reader:',subprocess.check_output(['id'],text=True).strip(),flush=True)
    original_rules=read_rules()
    if original_rules: raise RuntimeError('Existing map rules found; no rules were changed')
    require_checkpoint(root('cat '+STATS))
    fixture=Path(tempfile.mkdtemp(prefix='rmgu-susfs-map-life.',dir=os.getcwd()))
    fixture.chmod(0o700)
    nonce=secrets.token_hex(16); proc=None; sequence=0; attempted=False; timed_out=False
    cleaned=False; failures=[]; blocked=[]; records=[]
    target=fixture/'target.bin'; control=fixture/'control.bin'; helper=fixture/'worker.py'
    output=tempfile.TemporaryFile(mode='w+t'); error=tempfile.TemporaryFile(mode='w+t')
    markers={'target':b'RMGU-target-new\n','control':b'RMGU-control-v2\n'}
    try:
        for kind,path in (('target',target),('control',control)):
            path.write_bytes(markers[kind]+kind[0].upper().encode()*(65536-len(markers[kind])))
            path.chmod(0o600)
        markers={kind:data[:16].hex() for kind,data in markers.items()}
        atomic_json(fixture/'owner.json',{'nonce':nonce,'uid':os.geteuid(),'original_rules':original_rules})
        helper.write_text(COMMON+'\nif __name__=="__main__": helper_main()\n'); helper.chmod(0o600)
        proc=subprocess.Popen([sys.executable,str(helper),'worker',str(fixture),'0','0',nonce],
                              stdin=subprocess.DEVNULL,stdout=output,stderr=error,start_new_session=True,text=True)
        reply=wait_reply(proc,fixture,0,nonce,error)
        original=reply['identity']
        if original['uids']!=[os.geteuid()]*4: raise RuntimeError('Worker was not created under the ordinary app UID')
        validate_reply(reply,proc,original,markers,'target',0)
        print('OWNED WORKER: '+json.dumps(original),flush=True)
        slot_address=reply['items']['alias']['address']
        stable_address=reply['items']['control']['address']
        stat=os.stat(target); identity=(stat.st_ino,(os.major(stat.st_dev)<<20)|os.minor(stat.st_dev))
        command=('/system/bin/toybox nsenter -t %d -m '%os.getpid()+shlex.quote(sys.executable)+' '+shlex.quote(str(helper)))
        def views(value,label):
            same_worker(original,process_identity(proc.pid,original['proc_pid']))
            parent=observe(proc.pid,value['items'],label+' PARENT APP',original['proc_pid'])
            payload=base64.b64encode(json.dumps({'pid':proc.pid,'proc_pid':original['proc_pid'],'items':value['items'],'label':label+' ROOT'}).encode()).decode()
            privileged=json.loads(root(command+' root-observe '+shlex.quote(payload),progress=True))
            if privileged['reader_uid']!=0: raise RuntimeError('Root reader was not UID 0')
            same_worker(original,parent['identity']); same_worker(original,privileged['identity'])
            return {'self':value['self'],'parent_app':parent,'root':privileged}
        baseline=views(reply,'BASELINE')
        require_self_baseline(baseline['self'])
        for reader,value in baseline.items():
            issues,notes=assessment(value,value,False,'BASELINE '+reader)
            failures.extend(issues); blocked.extend(notes)
        summary('BASELINE',baseline)
        if failures: raise RuntimeError('Unsuitable baseline: '+'; '.join(failures))
        records.append({'phase':'BASELINE','views':baseline})
        print('ENABLE: adding only the owned target inode/device rule',flush=True)
        attempted=True; write_rule('add',target)
        if read_rules()!=[identity]: raise RuntimeError('Published rule differs from the owned target')
        require_checkpoint(root('cat '+STATS),active=True)
        def step(op,label,pages=1,active=True,expected_epoch=0):
            nonlocal sequence
            sequence+=1
            atomic_json(fixture/'request.json',{'nonce':nonce,'sequence':sequence,'operation':op,'pages':pages})
            value=wait_reply(proc,fixture,sequence,nonce,error)
            kind={'vacant':'vacant','control':'control','target':'target','exec':'target'}.get(op)
            validate_reply(value,proc,original,markers,kind,expected_epoch)
            if op!='exec' and expected_epoch==0:
                if value['items']['alias']['address']!=slot_address or value['items']['control']['address']!=stable_address:
                    raise RuntimeError('Serialized remap did not reuse the owned reservations')
            now=views(value,label)
            for reader,snapshot in now.items():
                issues,notes=assessment(baseline[reader],snapshot,active and reader!='root',label+' '+reader)
                failures.extend(issues); blocked.extend(notes)
            records.append({'phase':label,'epoch':value['epoch'],'views':now})
            summary(label,now)
            return value
        step('observe','HIDDEN INITIAL')
        for cycle in range(1,args.cycles+1):
            step('vacant','VACANT '+str(cycle),pages=cycle)
            step('control','CONTROL REUSE '+str(cycle),pages=cycle)
            step('target','HIDDEN REMAP '+str(cycle),pages=cycle)
        step('exec','HIDDEN AFTER EXEC',expected_epoch=1)
        print('ACTIVE MAP DIAGNOSTICS:\n'+root('cat '+STATS),flush=True)
        print('DISABLE: removing only the owned target rule',flush=True)
        write_rule('del',target)
        if read_rules()!=original_rules: raise RuntimeError('Map rule list did not return to the exact baseline')
        attempted=False
        step('observe','RESTORED AFTER EXEC',active=False,expected_epoch=1)
        print('RESTORED MAP DIAGNOSTICS:\n'+root('cat '+STATS),flush=True)
    except RootCommandTimeout:
        timed_out=True; raise
    finally:
        safe=True
        if attempted:
            if timed_out:
                safe=False; print('Root command outcome unknown; further rule commands skipped.',flush=True)
            else:
                try:
                    s=os.stat(target); owned=(s.st_ino,(os.major(s.st_dev)<<20)|os.minor(s.st_dev))
                    if owned in read_rules(): write_rule('del',target)
                    if read_rules()!=original_rules: raise RuntimeError('Exact original map rule list not verified')
                except Exception as problem:
                    safe=False; print('Rule cleanup unverified: '+str(problem),flush=True)
        if not stop_worker(proc,fixture,sequence+1,nonce,error):
            safe=False; print('Owned worker could not be reaped within the bounded cleanup.',flush=True)
        output.close(); error.close()
        if safe:
            shutil.rmtree(fixture); cleaned=True
            print('Cleanup complete; owned worker reaped, mappings released, test rule and fixture removed.',flush=True)
        else:
            atomic_json(fixture/'observations.json',{'records':records,'failures':failures,'blocked':blocked})
            print('Fixture retained: '+str(fixture)+'; capture blocked tasks and fully reboot before retrying.',flush=True)
    notes=sorted(set(re.sub(r'^(BASELINE|HIDDEN INITIAL|VACANT \d+|CONTROL REUSE \d+|HIDDEN REMAP \d+|HIDDEN AFTER EXEC|RESTORED AFTER EXEC) ', '',x) for x in blocked))
    for note in notes: print('BLOCKED: '+note+'; scope unqualified',flush=True)
    if not cleaned or failures: raise RuntimeError('; '.join(dict.fromkeys(failures)) or 'Cleanup incomplete')
    print(('PARTIAL PASS' if notes else 'PASS')+': serialized target unmap/remap, same-address control reuse, one owned exec, accessible self/parent/root views, exact rule restoration and cleanup.',flush=True)
    print('Scope: permission-blocked reads, concurrent exec/read races, previously opened proc descriptors, unloading and long-run stability remain unqualified.',flush=True)

if __name__=='__main__':
    def interrupted(signum,frame): raise KeyboardInterrupt('signal '+str(signum))
    for sig in (signal.SIGTERM,signal.SIGHUP): signal.signal(sig,interrupted)
    try: main()
    except (Exception,KeyboardInterrupt) as problem:
        print('FAIL: '+str(problem),flush=True); raise SystemExit(1)
