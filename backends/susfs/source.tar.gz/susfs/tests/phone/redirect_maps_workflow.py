"""Two serialized owned redirect mapping cycles with exact restoration."""


def observe_mapping_pair(client, config, label):
    print('READ ' + label + ' APP', flush=True)
    pair = {'app': mapping_snapshot(config), 'root': client.call('map_observe', config)}
    brief = {}
    for reader, value in pair.items():
        views = value.get('views', {})
        brief[reader] = {'reader_uid': value['reader_uid'],
                         'headers': {table: {name: row['raw'] for name, row in views.get(table + '_full', {}).items()}
                                     for table in ('maps', 'smaps')},
                         'full_small_equal': {table: table + '_full' in views and table + '_small' in views
                                                    and views[table + '_full'] == views[table + '_small']
                                              for table in ('maps', 'smaps')},
                         'backing': value['descriptors']}
    print(label + ': ' + json.dumps(brief, separators=(',', ':')), flush=True)
    return pair


def run_mapping_cycles(client, config, groups, baseline, receipt):
    failures = []
    for cycle in (1, 2):
        print('ENABLE %d: only the owned source path, UID scheme 3' % cycle, flush=True)
        client.call('add', config)
        groups.add('target_active', 'target', 'destination', [('main', 3, 0), ('alias', 2, 11)])
        now = observe_mapping_pair(client, config, 'ACTIVE ' + str(cycle))
        receipt['observations']['active_' + str(cycle)] = now
        failures.extend(assess_mapping_phase(config, now, baseline, True, 'ACTIVE ' + str(cycle)))
        receipt['diagnostics']['active_' + str(cycle)] = client.call('state', config)
        print('ACTIVE REDIRECT DIAGNOSTICS: ' + receipt['diagnostics']['active_' + str(cycle)]['diagnostics'], flush=True)
        print('ACTIVE LISTING ROUTES: ' + receipt['diagnostics']['active_' + str(cycle)]['mapping_routes'], flush=True)
        print('DISABLE ' + str(cycle), flush=True)
        client.call('del', config)
        now = observe_mapping_pair(client, config, 'RESTORED %d (active mappings held)' % cycle)
        receipt['observations']['restored_' + str(cycle)] = now
        failures.extend(assess_mapping_phase(config, now, baseline, False, 'RESTORED ' + str(cycle)))
        groups.remove('target_active')
        if failures: break
    return failures


def main():
    print('Redirect maps runner revision: 2 (CP22 direct maps/smaps routes, held aliases and exact restoration)', flush=True)
    if sys.argv[1:]: raise RuntimeError('This runner has no command-line options')
    if os.geteuid() < 10000 or os.uname().machine != 'aarch64' or os.uname().release != KERNEL:
        raise RuntimeError('Run from ordinary native AArch64 Termux on the qualified BZIG kernel')
    print('App reader: ' + subprocess.check_output(['id'], text=True).strip(), flush=True)
    subject = process_identity(os.getpid())
    if subject['uids'] != [os.geteuid()] * 4: raise RuntimeError('Ordinary reader UIDs differ')
    fixture = Path(tempfile.mkdtemp(prefix='rmgu-susfs-redirect-maps.', dir=str(Path.home())))
    helper = fixture / 'root-helper.py'; helper.write_text(ROOT_HELPER); helper.chmod(0o600)
    device_directory = '/dev/' + fixture.name
    contents = {'target': b'RMGU-map-original\n', 'source_control': b'RMGU-map-source-control\n',
                'destination': b'RMGU-map-redirected\n', 'destination_control': b'RMGU-map-destination-control\n'}
    size = 16 * os.sysconf('SC_PAGE_SIZE')
    config = {'fixture': str(fixture), 'device_directory': device_directory, 'mapping_size': size,
              'uid': os.geteuid(), 'gid': os.getegid(), 'subject': subject,
              'paths': {'target': str(fixture / 'target.txt'), 'source_control': str(fixture / 'control.txt'),
                        'destination': device_directory + '/redirected.txt', 'destination_control': device_directory + '/control.txt'},
              'contents': {name: value.hex() for name, value in contents.items()}, 'slots': {}, 'descriptors': {}}
    for name in ('target', 'source_control'):
        path = Path(config['paths'][name]); path.write_bytes(contents[name].ljust(size, b'\0')); path.chmod(0o600)
    client = RootClient(helper, subject); groups = OwnedMappingGroups(config)
    setup_attempted = False; controls_attempted = False; problem = None; cleanup_problem = None; status = 'FAIL'
    receipt = {'runner_revision': 2, 'checkpoint': 22, 'config': config, 'observations': {}, 'diagnostics': {},
               'feature_controls_attempted': False, 'cleanup_complete': False}
    try:
        state = client.call('state', config); config['original_rules'] = state['rules']; receipt['original_state'] = state
        print('REDIRECT LISTING ROUTES: ' + state['mapping_routes'], flush=True)
        print('Saved original redirect rules: ' + str(len(state['rules'])), flush=True)
        print('OWNED SUBJECT: ' + json.dumps(subject), flush=True)
        setup_attempted = True
        setup = client.call('setup', config); config['device_owned'] = setup['owned']; receipt['setup'] = setup
        if not setup['available']: raise FixtureBlocked('Owned /dev fixture unavailable: ' + str(setup['error']))
        labels = setup.get('labels', {})
        if set(labels) != {'directory', 'destination', 'destination_control'} or not all(
                value.get('verified') is True and value.get('bytes', 0) > 0 for value in labels.values()):
            raise FixtureBlocked('Owned fixture label verification receipt incomplete')
        print('FIXTURE LABELS: ' + json.dumps(labels, separators=(',', ':')), flush=True)
        try:
            config.update(client.call('metadata', config))
            groups.add('source_before', 'target', 'target', [('main', 3, 0), ('alias', 2, 8)])
            groups.add('destination_before', 'destination', 'destination', [('main', 4, 0), ('alias', 3, 5)])
            groups.add('source_control', 'source_control', 'source_control', [('main', 2, 0)])
            groups.add('destination_control', 'destination_control', 'destination_control', [('main', 2, 0)])
            config['baseline_slots'] = {name: dict(value) for name, value in config['slots'].items()}
            baseline = observe_mapping_pair(client, config, 'BASELINE'); receipt['observations']['baseline'] = baseline
            require_mapping_baseline(config, baseline)
        except RootCommandUnknown: raise
        except (OSError, RuntimeError) as error: raise FixtureBlocked(str(error)) from error
        controls_attempted = True; receipt['feature_controls_attempted'] = True
        failures = run_mapping_cycles(client, config, groups, baseline, receipt)
        if failures: raise RuntimeError('; '.join(failures))
        final = client.call('state', config)
        if final['rules'] != config['original_rules']: raise RuntimeError('Final redirect list not restored')
        receipt['final_state'] = final
        print('FINAL REDIRECT DIAGNOSTICS: ' + final['diagnostics'], flush=True)
        status = 'PASS'
    except FixtureBlocked as error:
        status = 'BLOCKED'; problem = str(error)
    except (Exception, KeyboardInterrupt) as error:
        status = 'FAIL'; problem = '%s: %s' % (type(error).__name__, error)
    finally:
        try: groups.close()
        except (Exception, KeyboardInterrupt) as error: cleanup_problem = str(error)
        if not client.unknown and cleanup_problem is None:
            try:
                if controls_attempted: receipt['restored_state'] = restore_rules(client, config)
                if setup_attempted and 'device_owned' not in config: raise RuntimeError('Setup ownership receipt unavailable; fixture retained')
                if setup_attempted: receipt['device_cleanup'] = client.call('cleanup', config)
                receipt['cleanup_complete'] = True
            except (Exception, KeyboardInterrupt) as error: cleanup_problem = '%s: %s' % (type(error).__name__, error)
        elif client.unknown:
            cleanup_problem = 'Root outcome unknown; no further root/control commands sent. Fixtures retained.'
        if cleanup_problem: status = 'FAIL'
        receipt.update(result=status, error=problem, cleanup_error=cleanup_problem, root_outcome_unknown=client.unknown)
        (fixture / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    if cleanup_problem: print('CLEANUP UNQUALIFIED: ' + cleanup_problem, flush=True)
    if status == 'PASS':
        try:
            source_cleanup(config, helper)
            print('Cleanup complete; mappings/descriptors released, exact original rule list restored, owned fixture names removed.', flush=True)
        except Exception as error:
            status = 'FAIL'; problem = str(error)
            receipt.update(result=status, error=problem, cleanup_complete=False)
            if fixture.is_dir(): (fixture / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    if status != 'PASS':
        print('RETAINED EVIDENCE: ' + str(fixture), flush=True)
        print('Device fixture path: ' + device_directory, flush=True)
        print(status + ': ' + (problem or cleanup_problem or 'Mapping qualification incomplete'), flush=True)
        print('Feature controls attempted: ' + str(controls_attempted), flush=True)
        return 2 if status == 'BLOCKED' else 1
    print('PASS: redirect inode/device/path in maps/smaps, pre-existing and fresh target/destination aliases, full/small reads, '
          'mapped content provenance, root/control preservation, held mappings after DEL, two cycles, exact restoration and cleanup.', flush=True)
    print('Scope: native AArch64 proc scheme 3 with owned stable mappings. Compat, supercalls, other UID schemes, '
          'map_files reverse identity, concurrent races, retired path-reference release, unloading and long-run stability remain unqualified.', flush=True)
    return 0


if __name__ == '__main__':
    try: raise SystemExit(main())
    except (Exception, KeyboardInterrupt) as error:
        print('FAIL: %s: %s' % (type(error).__name__, error), flush=True)
        raise SystemExit(1)
