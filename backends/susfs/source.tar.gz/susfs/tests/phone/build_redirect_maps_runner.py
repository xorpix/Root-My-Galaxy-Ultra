#!/usr/bin/env python3
"""Build owned redirect maps qualification using the completed r2 fixture support."""
import ast
from pathlib import Path


def definitions(path):
    source = path.read_text()
    return {node.name: ast.get_source_segment(source, node) for node in ast.parse(source).body
            if isinstance(node, (ast.FunctionDef, ast.ClassDef))}


def build():
    directory = Path(__file__).resolve().parent
    support = definitions(directory / 'rmgu-susfs-kstat-native-test.py')
    observer = definitions(directory / 'kstat_maps_observer.py')
    redirect = definitions(directory / 'redirect_statfs_workflow.py')
    common = (directory / 'redirect_statfs_shared.py').read_text() + '\n'
    common += '\n\n'.join(observer[name] for name in ('process_identity', 'read_table', 'parse_header', 'selected_rows'))
    common = "import mmap\nTABLE_LIMIT = 8 * 1024 * 1024\n" + common
    # Shared imports must precede the same qualified maps-header expression.
    common += "\nHEADER = re.compile(r'^([0-9a-f]+)-([0-9a-f]+) ([r-][w-][x-][ps]) ([0-9a-f]+) ([0-9a-f]+):([0-9a-f]+) ([0-9]+)([ \\t]*)(.*)$')\n"
    common += (directory / 'redirect_maps_shared.py').read_text()
    root_source = (directory / 'redirect_statfs_root.py').read_text()
    assert root_source.count("if __name__ == '__main__':") == 1
    root_functions, root_main = root_source.split("if __name__ == '__main__':", 1)
    assert root_functions.count('rmgu-susfs-redirect-statfs.') == 1
    root_functions = root_functions.replace('rmgu-susfs-redirect-statfs.', 'rmgu-susfs-redirect-maps.')
    helper = common + '\n' + root_functions + '\nbase_root_action = root_action\n'
    helper += (directory / 'redirect_maps_root.py').read_text()
    helper += "\nif __name__ == '__main__':" + root_main
    head = '''#!/usr/bin/env python3
"""CP22 owned redirect maps/smaps qualification; run from ordinary Termux.

Uses the completed native-label fixture and only an owned scheme-3 rule.
Two serialized cycles, original rules preserved, no mount or module changes.
"""
import base64
import ctypes as ct
import json
import mmap
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tempfile

KERNEL = '6.12.69-android16-6-pb4d3caf-abogkiS948BXXS4BZIG-4k'
ROOT_TIMEOUT = 30

'''
    result = head + '\n\n'.join(support[name] for name in ('RootCommandUnknown', 'root'))
    result += '\n\n' + '\n\n'.join(redirect[name] for name in ('FixtureBlocked', 'RootClient', 'restore_rules', 'source_cleanup'))
    result += '\n\nSHARED = ' + repr(common) + '\nexec(SHARED, globals())\n'
    result += '\nROOT_HELPER = ' + repr(helper) + '\n\n'
    result += (directory / 'redirect_maps_workflow.py').read_text()
    return result


if __name__ == '__main__':
    Path(__file__).with_name('rmgu-susfs-redirect-maps-test.py').write_text(build())
