"""Run unchanged redirect header callbacks with explicit host kernel API stubs.

Checks formatting and gates, not Samsung probe registration or live reachability.
"""
import hashlib
import os
from pathlib import Path
import re
import subprocess
import tempfile


def compile_callback(directory, sanitizers=False):
    source = (Path(__file__).resolve().parents[2] / 'kernel/susfs_open_redirect.c').read_text()
    names = ('or_reverse_visible', 'or_find_by_redirected_inode', 'or_maps_show_entry', 'or_maps_entry', 'or_smaps_entry', 'or_maps_replace', 'or_maps_ret')
    fragments = []
    for name in names:
        match = re.search(r'^static [^\n]*\b' + name + r'\([^;{]*\)\n\{\n.*?^\}\n', source, re.M | re.S)
        if not match: raise RuntimeError('Production function missing: ' + name)
        fragments.append(match[0])
    production = '\n'.join(fragments)
    stubs = r'''
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#define OR_APP_UID_MIN 10000
#define READ_ONCE(x) (x)
#define smp_rmb() ((void)0)
#define MAJOR(x) ((uint32_t)(x) >> 20)
#define MINOR(x) ((uint32_t)(x) & 0xfffffu)
typedef int atomic_t;
static void atomic_inc(atomic_t *x) { ++*x; }
static atomic_t or_rev_maps_hits, or_rev_maps_rewrites, or_rev_maps_names;
static atomic_t or_maps_routes[2];
struct host_uid { unsigned int val; };
static struct host_uid reader;
static struct host_uid current_uid(void) { return reader; }
struct seq_file { char *buf; size_t count, size; };
struct super_block { uint32_t s_dev; };
struct inode { unsigned long i_ino; struct super_block *i_sb; };
struct file { struct inode *inode; };
struct vm_area_struct { struct file *vm_file; };
struct kretprobe_instance { void *data; };
struct pt_regs { unsigned long regs[31]; };
struct or_maps_args { struct seq_file *m; struct vm_area_struct *vma; char *buf; size_t start; unsigned int route; };
struct sus_or_entry {
  unsigned long target_ino, redirected_ino;
  uint32_t target_dev, redirected_dev;
  char target_pathname[256], redirected_pathname[256];
  bool dead;
};
static struct sus_or_entry or_entries[64];
static int nor;
static bool susfs_ptr_plausible(const void *p) { return (uintptr_t)p > 4096; }
static struct inode *file_inode(struct file *f) { return f->inode; }
static int scnprintf(char *p, size_t n, const char *format, ...) {
  va_list args; va_start(args,format); int result=vsnprintf(p,n,format,args); va_end(args);
  return result<0 ? 0 : (result<(int)n ? result : (int)n-1);
}
'''
    main = r'''
int main(int argc, char **argv) {
  if (argc!=12) return 2;
  or_entries[0].target_ino=strtoul(argv[1],NULL,10); or_entries[0].target_dev=strtoul(argv[2],NULL,10);
  or_entries[0].redirected_ino=strtoul(argv[3],NULL,10); or_entries[0].redirected_dev=strtoul(argv[4],NULL,10);
  reader.val=strtoul(argv[7],NULL,10); size_t capacity=strtoul(argv[8],NULL,10);
  if (strlen(argv[9])>=256 || strlen(argv[10])>=256 || capacity>2097152) return 3;
  strcpy(or_entries[0].target_pathname,argv[9]); strcpy(or_entries[0].redirected_pathname,argv[10]); nor=1;
  char input[1048576]; size_t count=fread(input,1,sizeof(input),stdin);
  if (count>=sizeof(input) || capacity<=count) return 4;
  unsigned char *storage=malloc(capacity+32); assert(storage);
  memset(storage,0x71,capacity+32); memcpy(storage+16,input,count);
  struct seq_file seq={(char *)storage+16,0,capacity};
  struct super_block sb={(uint32_t)strtoul(argv[6],NULL,10)};
  struct inode ino={strtoul(argv[5],NULL,10),&sb}; struct file file={&ino};
  struct vm_area_struct vma={&file}; struct or_maps_args data;
  struct kretprobe_instance ri={&data}; struct pt_regs regs={{(unsigned long)&seq,(unsigned long)&vma}};
  if (atoi(argv[11])) { int skip=or_maps_entry(&ri,&regs); seq.count=count; regs.regs[0]=0; if (!skip) or_maps_ret(&ri,&regs); }
  else seq.count=count;
  assert(seq.count<=capacity);
  for (size_t i=0;i<16;i++) assert(storage[i]==0x71 && storage[16+capacity+i]==0x71);
  fwrite(seq.buf,1,seq.count,stdout);
  fprintf(stderr,"%d/%d/%d\n",or_rev_maps_hits,or_rev_maps_rewrites,or_rev_maps_names);
  free(storage); return 0;
}
'''
    directory = Path(directory); file = directory / 'redirect-maps.c'; executable = directory / 'redirect-maps'
    file.write_text(stubs + production + main)
    flags = ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-no-pie'] if sanitizers else ['-O2']
    subprocess.run([os.environ.get('CC', 'cc'), '-std=gnu11', '-Wall', '-Wextra', '-Werror',
                    '-Wno-unused-parameter', '-Wno-unused-function', *flags, str(file), '-o', str(executable)], check=True)
    return executable, {'functions': list(names), 'production_fragment_sha256': hashlib.sha256(production.encode()).hexdigest(),
                        'sanitizers': sanitizers, 'leak_sanitizer': False, 'hardware_validated': False}


class ProductionCallback:
    def __init__(self, sanitizers=False):
        self.directory = tempfile.TemporaryDirectory(prefix='rmgu-redirect-maps-host-')
        self.executable, self.receipt = compile_callback(self.directory.name, sanitizers)

    def close(self): self.directory.cleanup()

    def rewrite(self, text, config, backing, uid=10362, deliver=True, capacity=None):
        def dev(value): return (os.major(value) << 20) | os.minor(value)
        source = config['identities']['target']; destination = config['identities']['destination']
        actual = config['identities'][backing]
        data = text.encode('utf-8', errors='surrogateescape')
        args = [source['ino'], dev(source['dev']), destination['ino'], dev(destination['dev']),
                actual['ino'], dev(actual['dev']), uid, capacity or len(data) + 1024,
                config['paths']['target'], config['paths']['destination'], int(deliver)]
        environment = dict(os.environ)
        if self.receipt['sanitizers']:
            environment.update(ASAN_OPTIONS='detect_leaks=0:abort_on_error=1', UBSAN_OPTIONS='halt_on_error=1')
        value = subprocess.run([str(self.executable)] + list(map(str,args)), input=data,
                               capture_output=True, timeout=20, env=environment)
        if value.returncode: raise RuntimeError('Production callback failed: ' + value.stderr.decode())
        counts = tuple(map(int,value.stderr.strip().split(b'/')))
        return value.stdout.decode('utf-8', errors='surrogateescape'), counts
