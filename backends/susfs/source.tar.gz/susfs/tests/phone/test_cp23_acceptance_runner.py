import base64
import contextlib
import copy
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


a = load('cp23_acceptance', HERE / 'rmgu-susfs-acceptance-test-cp23.py')
old = load('retained_closure_tests', HERE / 'test_cp22_closure_runners.py')


class CandidateTests(unittest.TestCase):
    def fixture(self):
        files = old.SnapshotTests().fixture()
        files['/proc/susfs_path'] += 'creds: checkpoint=23 native_copy=1 per_rule=1 live=0\n'
        return files

    def collect(self, files):
        def read(path, *args, **kwargs):
            return files[str(path)]
        def raw(path, *args, **kwargs):
            return files[str(path)].encode()
        with patch.object(a.os, 'geteuid', return_value=0), patch.object(a.Path, 'read_text', read), \
                patch.object(a.Path, 'read_bytes', raw):
            return a.snapshot()

    def test_cp23_state_keeps_all_original_configuration(self):
        state = self.collect(self.fixture())
        self.assertEqual(23, state['candidate']['checkpoint'])
        self.assertEqual(0, state['candidate']['live'])
        self.assertEqual(['kernelsu', 'susfs_guard_lkm'], state['module_names'])
        self.assertEqual('prefixes: /data/adb/', state['mount_prefixes'])

    def test_legacy_cp22_marker_stops_before_retained_snapshot(self):
        with patch.object(a.Path, 'read_text', return_value='hide_from_apps=1\n'), \
                patch.object(a, '_retained_snapshot') as retained:
            with self.assertRaisesRegex(RuntimeError, 'CP23 credential marker missing'):
                a.snapshot()
        retained.assert_not_called()

    def test_pending_or_borrowed_credentials_cannot_start_acceptance(self):
        for before, after in (('live=0', 'live=1'), ('pending=0', 'pending=1'),
                              ('caller-cred=0', 'caller-cred=1')):
            with self.subTest(field=before):
                files = self.fixture()
                files['/proc/susfs_path'] = files['/proc/susfs_path'].replace(before, after)
                with self.assertRaisesRegex(RuntimeError, 'Pending work or caller credentials'):
                    self.collect(files)

    def test_disabled_app_gate_and_wrong_kernel_rejected(self):
        files = self.fixture()
        files['/proc/susfs_path'] = files['/proc/susfs_path'].replace('hide_from_apps=1', 'hide_from_apps=0')
        with self.assertRaisesRegex(RuntimeError, 'App-only path gate'):
            self.collect(files)
        files = self.fixture()
        files['/proc/sys/kernel/osrelease'] = 'different-kernel\n'
        with self.assertRaisesRegex(RuntimeError, 'Root kernel mismatch'):
            self.collect(files)

    def test_duplicate_marker_is_not_a_qualified_candidate(self):
        files = self.fixture()
        files['/proc/susfs_path'] += 'creds: checkpoint=23 native_copy=1 per_rule=1 live=0\n'
        with self.assertRaisesRegex(RuntimeError, 'CP23 credential marker missing'):
            self.collect(files)

    def test_no_native_or_loop_root_operation_is_allowed(self):
        with patch.object(a.os, 'geteuid', return_value=0), patch.object(a, 'cp23_guard') as guard, \
                patch.object(a, '_retained_root_dispatch') as dispatch:
            for op in ('control', 'invalid', 'queries', 'cleanup'):
                with self.assertRaisesRegex(RuntimeError, 'not allowed'):
                    a.root_dispatch({'op': op})
        guard.assert_not_called()
        dispatch.assert_not_called()

    def test_reboot_stops_module_setter_before_dispatch(self):
        with patch.object(a.os, 'geteuid', return_value=0), patch.object(a, 'cp23_guard'), \
                patch.object(a, 'boot_id', return_value='new-boot'), patch.object(a, '_retained_root_dispatch') as dispatch:
            with self.assertRaisesRegex(RuntimeError, 'Boot changed'):
                a.root_dispatch({'op': 'module_write', 'expected_boot_id': 'old-boot'})
        dispatch.assert_not_called()


class FixtureManifestTests(unittest.TestCase):
    def test_exact_source_bytes_required_even_with_modified_side_manifest(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'phone-tests').mkdir()
            content = b'owned host fixture\n'
            manifest = copy.deepcopy(a.FIXED_MANIFEST)
            for name in a.REGRESSION:
                (root / 'phone-tests' / name).write_bytes(content)
                manifest['files'][name] = {'bytes': len(content), 'sha256': a.hashlib.sha256(content).hexdigest()}
            (root / 'phone-tests-manifest.json').write_text(json.dumps(manifest))
            real_path = a.Path
            def translated(value):
                return root if str(value) == '/sdcard/Download/host-pack' else real_path(value)
            # The production location guard uses the requested path; map only
            # the actual manifest and byte reads to the host-owned directory.
            class DownloadPath:
                def __str__(self):
                    return '/sdcard/Download/host-pack'
                def __truediv__(self, child):
                    return root / child
            with patch.object(a, 'Path', return_value=DownloadPath()):
                with self.assertRaisesRegex(RuntimeError, 'Fixed CP23 test manifest differs'):
                    a.read_fixed_batch('/sdcard/Download/host-pack')
                with patch.object(a, 'FIXED_MANIFEST', manifest):
                    result = a.read_fixed_batch('/sdcard/Download/host-pack')
                    self.assertEqual(content, base64.b64decode(result['sources'][a.REGRESSION[0]]))
                    (root / 'phone-tests' / a.REGRESSION[4]).write_bytes(b'changed')
                    with self.assertRaisesRegex(RuntimeError, 'checksum differs'):
                        a.read_fixed_batch('/sdcard/Download/host-pack')


class TruncatedSnapshotTests(unittest.TestCase):
    def fixture(self):
        files = CandidateTests().fixture()
        files['/proc/susfs_path'] += a.PATH_TRUNCATION_LINE + '\n'
        files[a.PARAMS + 'hide_list'] = files['/proc/susfs_path']
        return files

    def collect(self, files):
        return CandidateTests().collect(files)

    def test_source_derived_truncation_retains_both_fragments_without_full_snapshot(self):
        files = self.fixture()
        with patch.object(a, '_retained_snapshot') as full:
            result = self.collect(files)
        full.assert_not_called()
        self.assertFalse(result['snapshot_complete'])
        self.assertFalse(result['controls_attempted'])
        self.assertNotIn('rules', result)
        for name in ('proc', 'sysfs'):
            record = result['path_interfaces'][name]
            raw = files[record['path']].encode()
            self.assertEqual(raw, record['text'].encode())
            self.assertEqual(len(raw), record['bytes'])
            self.assertEqual(a.hashlib.sha256(raw).hexdigest(), record['sha256'])
            self.assertTrue(record['truncation_reported'])
        self.assertEqual(a.KERNEL, result['kernel'])

    def test_other_getter_denial_does_not_hide_known_truncation(self):
        files = self.fixture()
        def read(path, *args, **kwargs):
            return files[str(path)]
        def read_bytes(path, *args, **kwargs):
            if str(path) == a.PARAMS + 'hide_list':
                raise PermissionError(13, 'Permission denied')
            return files[str(path)].encode()
        with patch.object(a.os, 'geteuid', return_value=0), patch.object(a.Path, 'read_text', read), \
                patch.object(a.Path, 'read_bytes', read_bytes):
            result = a.snapshot()
        self.assertEqual(13, result['path_interfaces']['sysfs']['errno'])
        self.assertFalse(result['snapshot_complete'])

    def test_unknown_truncation_format_stays_a_failure(self):
        files = self.fixture()
        files['/proc/susfs_path'] = files['/proc/susfs_path'].replace(a.PATH_TRUNCATION_LINE,
                                                                  'truncated: unexpected format')
        with self.assertRaisesRegex(RuntimeError, 'Unrecognized path truncation'):
            self.collect(files)

    def test_untruncated_alternate_page_does_not_invent_a_complete_list(self):
        files = self.fixture()
        files[a.PARAMS + 'hide_list'] = files[a.PARAMS + 'hide_list'].replace(a.PATH_TRUNCATION_LINE, '')
        result = self.collect(files)
        self.assertFalse(result['path_interfaces']['sysfs']['truncation_reported'])
        self.assertFalse(result['snapshot_complete'])
        self.assertNotIn('rules', result)

    def test_app_classifies_blocker_without_sources_fixtures_or_observation(self):
        result = self.collect(self.fixture())
        uname = a.os.uname_result(('Linux', 'phone', 'Brene-spoofed-release', 'spoofed-version', 'aarch64'))
        with tempfile.TemporaryDirectory() as directory, patch.object(a.Path, 'home', return_value=Path(directory)), \
                patch.object(a, '_retained_root_call', return_value=result) as root, \
                patch.object(a, 'EXPECTED_BOOT_ID', None), patch.object(a.os, 'geteuid', return_value=10362), \
                patch.object(a.os, 'uname', return_value=uname), patch.object(a, 'run_fixture') as fixture, \
                patch.object(a, 'module_assessment') as modules, patch.object(a, 'observation_start') as observation, \
                contextlib.redirect_stdout(io.StringIO()) as stdout:
            rc = a.terminal_main(lambda: a.regression('/sdcard/Download/owned-pack'))
            self.assertEqual(2, rc)
            root.assert_called_once_with('state')
            fixture.assert_not_called()
            modules.assert_not_called()
            observation.assert_not_called()
            self.assertFalse((Path(directory) / a.RUN_DIRECTORY).exists())
            reports = list(Path(directory).glob('rmgu-cp23-preflight-*.json'))
            self.assertEqual(1, len(reports))
            record = json.loads(reports[0].read_text())
            self.assertEqual('Brene-spoofed-release', record['app_uname_release'])
            self.assertEqual(a.KERNEL, record['kernel'])
            self.assertFalse(record['snapshot_complete'])
            self.assertEqual(0o600, reports[0].stat().st_mode & 0o777)
            self.assertIn('BLOCKED:', stdout.getvalue())
            self.assertNotIn('FAIL:', stdout.getvalue())
            self.assertNotIn('PASS:', stdout.getvalue())

    def test_malformed_blocked_reply_is_not_accepted(self):
        result = self.collect(self.fixture())
        result['controls_attempted'] = True
        with patch.object(a, '_retained_root_call', return_value=result), patch.object(a, 'EXPECTED_BOOT_ID', None), \
                patch.object(a.tempfile, 'NamedTemporaryFile') as report:
            with self.assertRaisesRegex(RuntimeError, 'Invalid blocked preflight reply'):
                a.root_call('state')
        report.assert_not_called()

    def test_read_only_cli_does_not_run_any_fixture_on_a_complete_snapshot(self):
        state = {'kernel': a.KERNEL, 'boot_id': 'owned-host-boot'}
        with patch.object(a.sys, 'argv', ['runner', '--preflight']), patch.object(a, 'preflight'), \
                patch.object(a, 'root_call', return_value=state) as root, patch.object(a, 'regression') as regression, \
                patch.object(a, 'observation_start') as observation, contextlib.redirect_stdout(io.StringIO()) as stdout:
            a.run()
        root.assert_called_once_with('state')
        regression.assert_not_called()
        observation.assert_not_called()
        self.assertIn('not an acceptance PASS', stdout.getvalue())


class ModuleBaselineTests(unittest.TestCase):
    text = 'BASELINE ACCESS ERRNO: ' + json.dumps({'root': {'modules': 0, 'symbols': 0, 'sysfs_list': 0},
                                                'app': {'modules': 13, 'symbols': 13, 'sysfs_list': 0}})
    reason = 'Native module/symbol/sysfs read baseline denied; controls untouched'

    def test_denied_baseline_is_unqualified_and_preserves_errno(self):
        result = a.assess_module_block(a.Blocked(self.reason), self.text)
        self.assertEqual('UNQUALIFIED', result['status'])
        self.assertFalse(result['controls_attempted'])
        self.assertEqual(13, result['access_errno']['app']['symbols'])

    def test_missing_errno_and_other_blockers_do_not_continue(self):
        with self.assertRaisesRegex(RuntimeError, 'Missing module baseline'):
            a.assess_module_block(a.Blocked(self.reason), '')
        with self.assertRaisesRegex(RuntimeError, 'different blocker'):
            a.assess_module_block(a.Blocked('No free slot'), self.text)
        with self.assertRaisesRegex(RuntimeError, 'Unexpected module baseline errno'):
            a.assess_module_block(a.Blocked(self.reason), self.text.replace('13', '2'))


class ChildExecutionTests(unittest.TestCase):
    def test_actual_child_failure_cannot_be_hidden_by_printed_pass(self):
        with tempfile.TemporaryDirectory() as directory, contextlib.redirect_stdout(io.StringIO()):
            with self.assertRaisesRegex(RuntimeError, 'exit code differs'):
                a.run_fixture('owned.py', b'print("PASS: claimed")\nraise SystemExit(7)\n', Path(directory))
            self.assertTrue((Path(directory) / 'owned.py.log').exists())

    def test_actual_child_partial_preserves_known_permission_limits(self):
        source = b'print("BLOCKED: self alias open_follow baseline errno=1; scope unqualified")\nprint("PARTIAL PASS: qualified remainder")\n'
        with tempfile.TemporaryDirectory() as directory:
            result = a.run_fixture('rmgu-susfs-map-lifetime-test-cp19.py', source, Path(directory))
        self.assertEqual('PARTIAL PASS', result['status'])
        self.assertEqual(1, len(result['blocked']))


class OrchestrationTests(unittest.TestCase):
    def state(self):
        return {'boot_id': 'owned-host-boot', 'mount_hide': 0, 'candidate': {'checkpoint': 23}, 'rules': {'path': []}}

    def sources(self):
        return {'manifest': a.FIXED_MANIFEST,
                'sources': {name: base64.b64encode(b'owned-host-input').decode() for name in a.REGRESSION}}

    def test_permission_block_runs_only_frozen_list_and_starts_observation(self):
        state = self.state()
        calls = []
        def root(op, **arguments):
            calls.append(op)
            return self.sources() if op == 'read_batch' else state
        def fixture(name, source, logs):
            calls.append(name)
            return {'name': name, 'status': 'PASS', 'sha256': a.FIXED_MANIFEST['files'][name]['sha256']}
        module = {'status': 'UNQUALIFIED', 'controls_attempted': False, 'access_errno': {'app': {}, 'root': {}}}
        with tempfile.TemporaryDirectory() as directory, patch.object(a.Path, 'home', return_value=Path(directory)), \
                patch.object(a, 'root_call', side_effect=root), patch.object(a, 'run_fixture', side_effect=fixture), \
                patch.object(a, 'module_assessment', return_value=module), patch.object(a, 'observation_start') as start, \
                contextlib.redirect_stdout(io.StringIO()):
            a.regression('/sdcard/Download/owned-pack')
            path = Path(directory) / a.RUN_DIRECTORY / 'regression.json'
            receipt = json.loads(path.read_text())
            self.assertTrue(receipt['complete'])
            self.assertEqual(list(a.REGRESSION), [entry['name'] for entry in receipt['results']])
            self.assertEqual('UNQUALIFIED', receipt['module_assessment']['status'])
            start.assert_called_once_with(path, '/sdcard/Download/owned-pack')
        self.assertEqual(list(a.REGRESSION), [item for item in calls if item in a.REGRESSION])

    def test_failed_fixture_or_changed_state_stops_next_fixture(self):
        for fail_fixture in (True, False):
            with self.subTest(fail_fixture=fail_fixture):
                state = self.state()
                calls = []
                reads = 0
                def root(op, **arguments):
                    nonlocal reads
                    if op == 'read_batch':
                        return self.sources()
                    reads += 1
                    if not fail_fixture and reads >= 3:
                        return dict(state, unexpected_change=True)
                    return state
                def fixture(name, source, logs):
                    calls.append(name)
                    if fail_fixture:
                        raise RuntimeError('Owned fixture failed')
                    return {'name': name, 'status': 'PASS'}
                with tempfile.TemporaryDirectory() as directory, patch.object(a.Path, 'home', return_value=Path(directory)), \
                        patch.object(a, 'root_call', side_effect=root), patch.object(a, 'run_fixture', side_effect=fixture), \
                        patch.object(a, 'module_assessment', return_value={'status': 'PASS'}), \
                        patch.object(a, 'observation_start') as start, contextlib.redirect_stdout(io.StringIO()):
                    with self.assertRaises(RuntimeError):
                        a.regression('/sdcard/Download/owned-pack')
                    receipt = json.loads((Path(directory) / a.RUN_DIRECTORY / 'regression.json').read_text())
                    self.assertFalse(receipt['complete'])
                    self.assertIn('error', receipt)
                    start.assert_not_called()
                self.assertEqual([a.REGRESSION[0]], calls)


class ObservationTests(unittest.TestCase):
    def test_short_clean_window_is_blocked_without_final_receipt(self):
        with self.assertRaises(a.Blocked):
            a.assess_observation({'state': {'boot_id': 'b'}}, {'boot_id': 'b'}, 1799, 'clean')

    def test_time_alone_or_reboot_or_changed_rules_cannot_pass(self):
        start = {'state': {'boot_id': 'b', 'rules': []}}
        for current, outcome in ((start['state'], 'unobserved'), (start['state'], 'issue'),
                                 ({'boot_id': 'new', 'rules': []}, 'clean'),
                                 ({'boot_id': 'b', 'rules': ['changed']}, 'clean')):
            with self.subTest(current=current, outcome=outcome):
                self.assertEqual('UNQUALIFIED', a.assess_observation(start, current, 1800, outcome))
        self.assertEqual('PASS', a.assess_observation(start, start['state'], 1800, 'clean'))

    def test_changed_receipt_is_rejected_before_root_read(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)
            regression = path / 'regression.json'
            regression.write_text('changed')
            observation = path / 'observation.json'
            observation.write_text(json.dumps({'kind': 'cp23-observation', 'uid': a.os.geteuid(),
                                               'regression': str(regression), 'regression_sha256': 'old-hash'}))
            with patch.object(a, 'root_call') as root:
                with self.assertRaisesRegex(RuntimeError, 'Regression receipt changed'):
                    a.observation_finish(observation, 'clean', '')
            root.assert_not_called()

    def test_pipeline_finish_command_has_explicit_stdin_script_argument(self):
        command = a.finish_command('/sdcard/Download/owned pack', Path('/owned home/observation.json'))
        self.assertIn('| python -u - --finish-observation', command)
        self.assertIn("'/owned home/observation.json'", command)
        self.assertIn('--outcome clean', command)


if __name__ == '__main__':
    unittest.main(verbosity=2)
