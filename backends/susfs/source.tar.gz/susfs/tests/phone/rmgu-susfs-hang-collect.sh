#!/system/bin/sh
# Read-only CP15/CP16 enable-stage capture. Run in a second Termux session.
# Avoid all SusFS sysfs/proc controls: a blocked parameter write holds their lock.
if [ "$(id -u)" != 0 ]; then
    echo 'Run this collector through su.'
    exit 1
fi
echo 'RMGU SusFS blocked enable-stage capture'
date
for p in /proc/[0-9]*; do
    [ -r "$p/cmdline" ] || continue
    c=$(tr '\000' ' ' < "$p/cmdline" 2>/dev/null)
    case "$c" in
        */parameters/map_rules*|*/parameters/map_stat*)
            echo "PROCESS $p: $c"
            cat "$p/status" "$p/wchan" "$p/stack" 2>&1
            ;;
    esac
done
echo 'RECENT KERNEL LOG'
dmesg 2>&1 | tail -100
echo 'Capture finished. No rules, controls or process signals changed.'
