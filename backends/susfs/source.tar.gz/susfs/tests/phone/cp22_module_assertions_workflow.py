def run():
    print('Module assertions runner revision: 4 (CP22 baseline diagnostics and retained helper failures)',flush=True)
    preflight();original=root_call('state');names=original['module_names']
    if len(names)>=16:raise Blocked('Module list has no free slot; controls untouched')
    root_view=root_call('module_observe',names=[])
    app_view=module_observe([], 'APP INVENTORY')
    print('BASELINE ACCESS ERRNO:',json.dumps({'root':root_view['access_errno'],
        'app':app_view['access_errno']},sort_keys=True),flush=True)
    if any(root_view['access_errno'].values()) or any(app_view['access_errno'].values()):
        raise Blocked('Native module/symbol/sysfs read baseline denied; controls untouched')
    candidates=sorted(set(root_view['modules'])&set(app_view['modules'])-set(names))
    candidates=[x for x in candidates if NAME.fullmatch(x) and x!='susfs_guard_lkm']
    baseline_root=root_call('module_observe',names=candidates)
    baseline_app=module_observe(candidates,'APP BASELINE')
    visible=[x for x in candidates if baseline_root['symbols'][x]>0 and baseline_app['symbols'][x]>0
       and all(v['sysfs'][x]['errno']==0 and v['sysfs'][x]['listed'] for v in (baseline_root,baseline_app))]
    if len(visible)<2:raise Blocked('Need two loaded, unconfigured modules with visible sysfs and tagged symbols; controls untouched')
    target,control=visible[:2]
    require(any(baseline_app['core'].values()) and baseline_app['core']==baseline_root['core'],'Unrelated core-symbol baseline not qualified')
    print('TARGET:',target,'CONTROL:',control,flush=True)
    journal=Path(tempfile.mkdtemp(prefix='rmgu-susfs-module-assertions.',dir=Path.home()))/'original.json'
    journal.write_text(json.dumps({'boot_id':boot_id(original),'uid':os.geteuid(),'target':target,'original':original},indent=2))
    print('OWNED JOURNAL:',journal,flush=True)
    active=False;restored=False
    try:
        for cycle in (1,2):
            active=True;state=root_call('module_write',action='add',name=target)
            require(state['module_names']==names+[target],'Owned ADD readback differs')
            for reader,view in (('app',module_observe([target,control],'APP ACTIVE')),
                                ('root',root_call('module_observe',names=[target,control]))):
                require(not any(view['access_errno'].values()),'Active module interfaces became inaccessible')
                require(target not in view['modules'] and view['symbols'][target]==0,'Selected module/table symbols remain visible')
                before=baseline_app if reader=='app' else baseline_root
                require(control in view['modules'] and view['symbols'][control]==before['symbols'][control]
                        and view['core']==before['core'],'Unrelated module/core symbols changed')
                item=view['sysfs'][target]
                if reader=='app':require(item['errno']==errno.ENOENT and not item['listed'],'App sysfs target remains visible')
                else:require(item['errno']==0 and item['listed'],'Root sysfs management access lost')
                require(view['sysfs'][control]==before['sysfs'][control],'Control sysfs changed')
            root_call('module_write',action='del',name=target);active=False
            require(root_call('state')==original,'Original rules/settings changed after DEL')
            for view,before in ((module_observe([target,control],'APP RESTORED'),baseline_app),
                                (root_call('module_observe',names=[target,control]),baseline_root)):
                require(target in view['modules'] and view['symbols'][target]==before['symbols'][target]
                        and view['sysfs'][target]==before['sysfs'][target],'Native target did not restore')
            print('CYCLE',cycle,'PASS',flush=True)
        restored=True
    finally:
        if active and not UNKNOWN:
            root_call('module_write',action='del',name=target)
            require(root_call('state')==original,'Owned cleanup did not restore original state')
        if UNKNOWN:print('Outcome unknown; inspect the retained root log before further controls.',flush=True)
    require(restored,'Module assertions incomplete')
    journal.unlink();journal.parent.rmdir()
    print('PASS: selected module/tagged-symbol removal in app/root tables, app sysfs hiding, root sysfs access, controls, two cycles and exact restoration.',flush=True)
    print('Scope: visible loaded platform modules. Independent always-on symbol-prefix filtering has no unfiltered phone baseline and remains unqualified.',flush=True)

if __name__=='__main__':sys.exit(terminal_main(run))
