"""Workflow embedded in the standalone CP21 maps identity phone runner."""


def require_map_routes(text):
    rows = [line for line in text.splitlines() if line.startswith('map_identity:')]
    if len(rows) != 1 or not re.fullmatch(r'map_identity: checkpoint=21 routes=2 maps=\d+ smaps=\d+ missed=\d+/\d+', rows[0]):
        raise RuntimeError('CP21 maps/smaps route diagnostic unavailable; no new rule sent')
    return rows[0]


def identity_profiles(real):
    return [{'ino': (1 << 40) + real['ino'] + 1, 'dev': os.makedev(0xabc, 0xdef01)},
            {'ino': 7 if real['ino'] != 7 else 8},
            {'dev': os.makedev(4094, 0xabcde)}]


def assess_identity(baseline, now, overrides, label):
    failures = []
    if (now['reader_uid'] != baseline['reader_uid'] or now['subject'] != baseline['subject']):
        failures.append(label + ' reader/owned subject identity changed')
    for view, rows in baseline['views'].items():
        for name, prior in rows.items():
            current = now['views'][view][name]
            chosen = overrides if name.startswith('target_') else None
            chosen = chosen or {}
            ino = chosen.get('ino', prior['ino']); dev = chosen.get('dev', prior['dev'])
            identity = '%02x:%02x %d' % (os.major(dev), os.minor(dev), ino)
            # Kernel padding is retained when a number shrinks; wider values
            # may move the path right. Every byte outside this run stays exact.
            gap = ' ' * max(0, len(prior['identity_text']) - len(identity)) + prior['gap']
            wanted = prior['prefix'] + identity + gap + prior['path']
            if current['ino'] != ino or current['dev'] != dev:
                failures.append(label + ' ' + view + ' ' + name + ' inode/device mismatch')
            if any(current[field] != prior[field] for field in ('start', 'end', 'perms', 'offset', 'prefix', 'path')):
                failures.append(label + ' ' + view + ' ' + name + ' range/permissions/offset/path changed')
            if current['raw'] != wanted:
                failures.append(label + ' ' + view + ' ' + name + ' header bytes or padding differ')
    for name, methods in baseline['files'].items():
        for method, prior in methods.items():
            current = now['files'][name][method]
            chosen = overrides if name == 'target' else None
            chosen = chosen or {}
            if current['errno'] or current['returncode'] != 0 or not current['buffer_guards']:
                failures.append(label + ' ' + name + ' native ' + method + ' failed')
                continue
            wanted = dict(prior['fields']); wanted.update(chosen)
            if current['fields'] != wanted or current.get('requested_mask') != prior.get('requested_mask'):
                failures.append(label + ' ' + name + ' native ' + method + ' metadata differs')
            allowed = set()
            for field in chosen:
                offset, width = ({'ino': (32, 8), 'dev': (136, 8)} if method == 'statx'
                                 else {'ino': (8, 8), 'dev': (0, 8)})[field]
                allowed.update(range(offset, offset + width))
            before = bytes.fromhex(prior['raw_hex']); after = bytes.fromhex(current['raw_hex'])
            if len(before) != len(after) or any(a != b and i not in allowed for i, (a, b) in enumerate(zip(before, after))):
                failures.append(label + ' ' + name + ' native ' + method + ' unrelated bytes changed')
    return failures


def require_identity_baseline(app, privileged, payload, real):
    if app['reader_uid'] < 10000 or privileged['reader_uid'] != 0:
        raise RuntimeError('Wrong app/root reader UID; no rules changed')
    if app['subject'] != payload['subject'] or privileged['subject'] != payload['subject']:
        raise RuntimeError('App/root do not observe the same owned process; no rules changed')
    for reader, snapshot in (('APP', app), ('ROOT', privileged)):
        for view, rows in snapshot['views'].items():
            if set(rows) != set(payload['slots']): raise RuntimeError('Owned mapping set incomplete; no rules changed')
            for name, row in rows.items():
                slot = payload['slots'][name]; actual = real[slot['file']]
                if (row['start'] != slot['start'] or row['end'] != slot['end'] or
                        row['offset'] != slot['offset'] or row['perms'] != 'rw-p' or
                        row['path'] != payload['paths'][slot['file']] or
                        row['ino'] != actual['ino'] or row['dev'] != actual['dev']):
                    raise RuntimeError(reader + ' baseline ' + view + ' ' + name + ' not native; no rules changed')
        for name, methods in snapshot['files'].items():
            for method, value in methods.items():
                if value['errno'] or value['returncode'] != 0 or not value['buffer_guards']:
                    raise RuntimeError(reader + ' baseline native metadata unavailable; no rules changed')
                if method == 'statx' and value['fields']['mask'] & 0x7ff != 0x7ff:
                    raise RuntimeError('Baseline statx basic fields missing; no rules changed')
                if any(value['fields'][field] != actual for field, actual in real[name].items()):
                    raise RuntimeError(reader + ' baseline native metadata differs; no rules changed')
        for table in ('maps', 'smaps'):
            if snapshot['views'][table + '_full'] != snapshot['views'][table + '_small']:
                raise RuntimeError(reader + ' baseline proc read sizes disagree; no rules changed')
    if app['views'] != privileged['views']:
        raise RuntimeError('App/root baseline headers disagree; no rules changed')


def identity_brief(label, app, privileged):
    result = {}
    for name, snapshot in (('app', app), ('root', privileged)):
        result[name] = {
            'reader_uid': snapshot['reader_uid'],
            'headers': {table: {slot: row['raw'] for slot, row in snapshot['views'][table + '_full'].items()}
                        for table in ('maps', 'smaps')},
            'small_reads_equal': {table: snapshot['views'][table + '_full'] == snapshot['views'][table + '_small']
                                  for table in ('maps', 'smaps')},
            'native': {file: {method: {field: row.get('fields', {}).get(field) for field in ('ino', 'dev')}
                             | {'errno': row['errno']} for method, row in methods.items()}
                       for file, methods in snapshot['files'].items()}}
    print(label + ': ' + json.dumps(result, separators=(',', ':')), flush=True)


def real_fields(value):
    return {'ino': value.st_ino, 'dev': value.st_dev, 'size': value.st_size,
            'nlink': value.st_nlink, 'blocks': value.st_blocks, 'blksize': value.st_blksize,
            'atime_ns': value.st_atime_ns, 'mtime_ns': value.st_mtime_ns, 'ctime_ns': value.st_ctime_ns}


def run_identity_fixture(original):
    fixture = Path(tempfile.mkdtemp(prefix='rmgu-susfs-kstat-maps.', dir=Path.home()))
    paths = {name: fixture / (name + '.bin') for name in ('target', 'control')}
    held = {}; mappings = []; records = []; failures = []; real = {}
    attempted = False; unknown = False; safe = True; chosen = None
    target = paths['target']; page = os.sysconf('SC_PAGE_SIZE')
    try:
        for name, path in paths.items():
            path.write_bytes((b'RMGU-kstat-' + name.encode() + b'\n').ljust(16 * page, b'\0'))
            path.chmod(0o600); held[name] = os.open(path, os.O_RDONLY | os.O_CLOEXEC)
        slots = {}
        for name, file, length, offset in (('target_main', 'target', 3, 0), ('target_alias', 'target', 5, 4),
                                          ('control_main', 'control', 2, 0), ('control_alias', 'control', 4, 6)):
            mapping = mmap.mmap(held[file], length * page, access=mmap.ACCESS_COPY, offset=offset * page)
            mappings.append(mapping)
            for index in range(0, length * page, page): _ = mapping[index]
            start = ct.addressof(ct.c_char.from_buffer(mapping))
            slots[name] = {'file': file, 'start': start, 'end': start + length * page, 'offset': offset * page}
        real = {name: real_fields(os.fstat(fd)) for name, fd in held.items()}
        payload = {'subject': process_identity(os.getpid()), 'paths': {name: str(path) for name, path in paths.items()},
                   'slots': slots}
        if payload['subject']['uids'] != [os.geteuid()] * 4:
            raise RuntimeError('Ordinary reader real/effective/saved/fs UIDs differ; no rules changed')
        helper = fixture / 'root-helper.py'
        helper.write_text(SHARED + "\nif __name__ == '__main__':\n    print(json.dumps(observe_subject(json.loads(sys.argv[1])), separators=(',', ':')), flush=True)\n")
        helper.chmod(0o600)
        for filename, value in (('original-rules.json', original), ('fixture.json', payload)):
            (fixture / filename).write_text(json.dumps(value, indent=2)); (fixture / filename).chmod(0o600)
        root_command = '/system/bin/toybox nsenter -t %d -m ' % os.getpid() + shlex.quote(sys.executable)
        root_command += ' ' + shlex.quote(str(helper)) + ' ' + shlex.quote(json.dumps(payload))
        print('OWNED SUBJECT: ' + json.dumps(payload['subject']), flush=True)
        def snapshots(label):
            app = observe_subject(payload, held)
            privileged = json.loads(root(root_command))
            records.append({'phase': label, 'app': app, 'root': privileged})
            identity_brief(label, app, privileged)
            return app, privileged
        app_before, root_before = snapshots('BASELINE')
        require_identity_baseline(app_before, root_before, payload, real)
        for cycle, chosen in enumerate(identity_profiles(real['target']), 1):
            if parse_control(root('cat ' + CONTROL))[0] != original:
                safe = False
                raise RuntimeError('Kstat rule table changed before ADD; no new rule sent')
            print('ENABLE %d identity overrides (flags=0x%x): %s' % (cycle, profile_flags(chosen), json.dumps(chosen)), flush=True)
            attempted = True
            write_owned('add', target, chosen)
            rules, _ = parse_control(root('cat ' + CONTROL))
            verify_owned(rules, original, target, real['target'], chosen)
            app, privileged = snapshots('ACTIVE ' + str(cycle))
            failures.extend(assess_identity(app_before, app, chosen, 'ACTIVE %d APP' % cycle))
            failures.extend(assess_identity(root_before, privileged, None, 'ACTIVE %d ROOT' % cycle))
            print('ACTIVE COUNTERS (diagnostic):\n' + root('cat ' + CONTROL), flush=True)
            # Verify ownership and unrelated rows again before removing the rule.
            verify_owned(parse_control(root('cat ' + CONTROL))[0], original, target, real['target'], chosen)
            print('DISABLE %d' % cycle, flush=True)
            write_owned('del', target)
            if parse_control(root('cat ' + CONTROL))[0] != original:
                raise RuntimeError('Exact original kstat rule list not restored')
            attempted = False
            app, privileged = snapshots('RESTORED ' + str(cycle))
            failures.extend(assess_identity(app_before, app, None, 'RESTORED %d APP' % cycle))
            failures.extend(assess_identity(root_before, privileged, None, 'RESTORED %d ROOT' % cycle))
        if parse_control(root('cat ' + CONTROL))[0] != original:
            safe = False; raise RuntimeError('Original rule list differs at final verification')
        print('FINAL COUNTERS (diagnostic):\n' + root('cat ' + CONTROL), flush=True)
    except RootCommandUnknown:
        unknown = True
        raise
    finally:
        if unknown: safe = False
        if attempted and not unknown:
            try:
                current, _ = parse_control(root('cat ' + CONTROL))
                mine = [line for line in current if line.startswith(str(target) + ' ')]
                if mine:
                    verify_owned(current, original, target, real['target'], chosen)
                    write_owned('del', target)
                if parse_control(root('cat ' + CONTROL))[0] != original:
                    raise RuntimeError('Original rule list differs')
            except BaseException as problem:
                if isinstance(problem, RootCommandUnknown): unknown = True
                safe = False; print('Rule restoration unverified: ' + str(problem), flush=True)
        elif attempted:
            print('Root outcome unknown; further rule commands skipped.', flush=True)
        elif not unknown and safe:
            try:
                if parse_control(root('cat ' + CONTROL))[0] != original:
                    raise RuntimeError('Original rule list differs during cleanup')
            except BaseException as problem:
                if isinstance(problem, RootCommandUnknown): unknown = True
                safe = False; print('Final rule verification unqualified: ' + str(problem), flush=True)
        for mapping in mappings:
            try: mapping.close()
            except BaseException as problem:
                safe = False; print('Owned mapping release failed: ' + str(problem), flush=True)
        for fd in held.values():
            try: os.close(fd)
            except OSError as problem:
                safe = False; print('Owned descriptor close failed: ' + str(problem), flush=True)
        if safe:
            shutil.rmtree(fixture)
            print('Cleanup complete; owned aliases/descriptors released, test rule and fixture removed, exact original list verified.', flush=True)
        else:
            evidence = fixture / 'observations.json'
            evidence.write_text(json.dumps({'records': records, 'failures': failures, 'root_outcome_unknown': unknown}, indent=2))
            evidence.chmod(0o600)
            print('RETAINED FIXTURE: ' + str(fixture), flush=True)
        if not safe: failures.append('Cleanup unqualified')
    if failures: raise RuntimeError('; '.join(dict.fromkeys(failures)))
    print('PASS: native inode/device identity in maps/smaps, two target/control aliases, full/small reads, wide and selected-field profiles, native stat consistency, root/control/header preservation, three cycles, exact restoration and cleanup.', flush=True)
    print('Scope: owned stable mappings on native AArch64; supercall payloads, compat ABI, redirect statfs, concurrent mapping/exec races, held proc descriptors, unloading and long-run stability remain unqualified.', flush=True)


def main():
    print('Kstat maps identity runner revision: 2 (CP21 maps/smaps listing routes and exact restoration)', flush=True)
    if os.geteuid() < 10000: raise RuntimeError('Run in ordinary Termux, outside a root shell')
    if os.uname().machine != 'aarch64' or os.uname().release != KERNEL:
        raise RuntimeError('This runner targets the pinned SM-S948B BZIG ARM64 kernel')
    print('App reader:', subprocess.check_output(['id'], text=True).strip(), flush=True)
    control = root('cat ' + CONTROL)
    require_map_routes(control)
    original, _ = parse_control(control)
    if len(original) >= 32: raise RuntimeError('Kstat rule table full; no controls changed')
    print('Saved original kstat rules: ' + str(len(original)), flush=True)
    run_identity_fixture(original)


if __name__ == '__main__':
    def interrupted(signum, frame): raise KeyboardInterrupt('signal ' + str(signum))
    signal.signal(signal.SIGINT, interrupted); signal.signal(signal.SIGTERM, interrupted)
    try: main()
    except (Exception, KeyboardInterrupt) as error:
        print('\nFAIL: ' + str(error), flush=True); sys.exit(1)
