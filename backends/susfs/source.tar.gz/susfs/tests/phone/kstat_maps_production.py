"""Compile the actual kstat maps callback/lookup with host kernel API stubs.

This checks production formatting and mutation behavior. It does not reproduce
the Samsung kprobe ABI, live registration, namespace permissions or locking.
"""
import os
from pathlib import Path
import re
import subprocess
import tempfile


def compile_callback(directory, source_dir=None):
    source_dir = Path(source_dir) if source_dir else Path(__file__).resolve().parents[2]
    source = (source_dir / 'kernel/susfs_kstat.c').read_text()
    abi = (Path(__file__).resolve().parents[2] / 'kernel/susfs_abi.h').read_text()
    def function(name):
        value = re.search(r'^static [^\n]*\b' + re.escape(name) + r'\([^;{]*\)\n\{\n.*?^\}\n',
                          source, re.M | re.S)
        if not value: raise RuntimeError('Production callback function unavailable: ' + name)
        return value.group()
    fragment = '\n'.join(re.findall(r'^#define KSTAT_SPOOF_\w+[^\n]*', abi, re.M)) + '\n'
    fragment += source[source.index('struct sus_kstat_entry {'):source.index('/* arm64 asm-generic struct stat offsets')]
    for name in ('susfs_kstat_gate_ok', 'susfs_kstat_table_empty', 'susfs_kstat_lookup'):
        fragment += function(name)
    map_start = source.index('static bool kstat_buf_replace')
    fragment += source[map_start:source.index('/* ---- per-syscall observability ----', map_start)]
    stubs = r'''
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <stdarg.h>
#include <assert.h>
#define SUS_KSTAT_MAX 32
#define KSTAT_PATH_MAX 256
#define DEFINE_MUTEX(name) int name
#define DEFINE_SPINLOCK(name) int name
#define READ_ONCE(value) (value)
#define spin_lock_irqsave(lock, flags) ((void)(lock), (void)(flags))
#define spin_unlock_irqrestore(lock, flags) ((void)(lock), (void)(flags))
#define MAJOR(dev) ((uint32_t)(dev) >> 20)
#define MINOR(dev) ((uint32_t)(dev) & 0xfffffu)
#define MKDEV(major, minor) (((uint32_t)(major) << 20) | (uint32_t)(minor))
typedef int atomic_t;
#define ATOMIC_INIT(value) (value)
static void atomic_inc(atomic_t *value) { ++*value; }
static int scnprintf(char *buffer, size_t size, const char *format, ...) {
    va_list args; va_start(args, format); int n = vsnprintf(buffer, size, format, args); va_end(args);
    return n < 0 ? 0 : (n < (int)size ? n : (int)size - 1);
}
struct host_uid { unsigned int val; };
static struct host_uid reader_uid;
static struct host_uid current_uid(void) { return reader_uid; }
struct seq_file { char *buf; size_t count, size; };
struct super_block { uint32_t s_dev; };
struct inode { unsigned long i_ino; struct super_block *i_sb; };
struct file { struct inode *inode; };
struct vm_area_struct { struct file *vm_file; };
struct kretprobe_instance { void *data; };
struct pt_regs;
struct kretprobe {
    struct { const char *symbol_name; void *addr; unsigned int flags; } kp;
    int (*entry_handler)(struct kretprobe_instance *, struct pt_regs *);
    int (*handler)(struct kretprobe_instance *, struct pt_regs *);
    size_t data_size; int maxactive, nmissed;
};
static struct kretprobe *registered[4];
static int registered_count;
static const char *fail_symbol;
static int register_kretprobe(struct kretprobe *p) {
    if (p->kp.addr && p->kp.symbol_name) return -22;
    if (fail_symbol && !strcmp(p->kp.symbol_name, fail_symbol)) return -22;
    p->kp.addr = p;
    registered[registered_count++] = p; return 0;
}
static void unregister_kretprobe(struct kretprobe *p) {
    for (int i=0; i<registered_count; i++) if (registered[i]==p) {
        memmove(registered+i,registered+i+1,(--registered_count-i)*sizeof(*registered)); return;
    }
    assert(0);
}
#define SUSFS_LOGI(...) ((void)0)
#define pr_warn(...) ((void)0)

struct pt_regs { unsigned long regs[31]; };
static struct inode *file_inode(struct file *file) { return file->inode; }
static bool susfs_ptr_plausible(const void *pointer) { return pointer != NULL; }
static uint32_t decode_device(uint32_t value) {
    return MKDEV((value & 0xfff00u) >> 8, (value & 0xffu) | ((value >> 12) & 0xfff00u));
}
static uint32_t new_encode_dev(uint32_t dev) {
    return (MINOR(dev) & 0xffu) | (MAJOR(dev) << 8) | ((MINOR(dev) & ~0xffu) << 12);
}
'''
    main = r'''
int main(int argc, char **argv) {
    if (argc >= 2 && !strcmp(argv[1], "registration")) {
        fail_symbol = "show_smap"; kstat_maps_arm();
        assert(!kstat_maps_registered && registered_count == 0);
        fail_symbol = NULL; kstat_maps_arm(); kstat_maps_arm();
        assert(kstat_maps_registered && registered_count == 2);
        kstat_maps_disarm(); assert(!kstat_maps_registered && !registered_count);
        return 0;
    }
    if (argc != 11) return 2;
    unsigned long rule_ino = strtoul(argv[1], NULL, 10);
    uint32_t dev = (uint32_t)strtoul(argv[2], NULL, 10);
    unsigned long current_ino = strtoul(argv[3], NULL, 10);
    kstat_entries[0].target_ino = rule_ino;
    kstat_entries[0].target_dev = dev;
    kstat_entries[0].spoofed_ino = strtoul(argv[4], NULL, 10);
    kstat_entries[0].spoofed_dev = strtoul(argv[5], NULL, 10);
    kstat_entries[0].flags = (unsigned int)strtoul(argv[6], NULL, 10);
    reader_uid.val = (unsigned int)strtoul(argv[7], NULL, 10);
    nkstat = 1;
    char input[1048576]; size_t count = fread(input, 1, sizeof(input), stdin);
    if (count == sizeof(input)) return 3;
    size_t capacity = (size_t)strtoul(argv[8], NULL, 10);
    if (capacity <= count || capacity > 2097152) return 4;
    unsigned char *storage = malloc(capacity + 32); if (!storage) return 5;
    memset(storage, 0x71, capacity + 32); memcpy(storage + 16, input, count);
    struct seq_file m = { .buf = (char *)storage + 16, .count = count, .size = capacity };
    struct super_block sb = { .s_dev = decode_device(dev) };
    struct inode inode = { .i_ino = current_ino, .i_sb = &sb };
    struct file file = { .inode = &inode };
    struct vm_area_struct vma = { .vm_file = &file };
    size_t start = (size_t)strtoul(argv[9], NULL, 10);
    if (start > count) return 6;
    const char *route = argv[10];
    kstat_maps_arm();
    struct kretprobe *probe = NULL;
    for (int i=0; i<registered_count; i++)
        if (!strcmp(registered[i]->kp.symbol_name, route)) probe=registered[i];
    /* smaps calls the formatter; maps models the observed inlined helper path. */
    if (!probe && !strcmp(route,"show_smap"))
        for (int i=0; i<registered_count; i++)
            if (!strcmp(registered[i]->kp.symbol_name,"show_map_vma")) probe=registered[i];
    struct kstat_map_args data;
    struct kretprobe_instance instance = { .data = &data };
    struct pt_regs regs = { .regs = { (unsigned long)&m, (unsigned long)&vma } };
    m.count = start;
    int skip = probe ? probe->entry_handler(&instance, &regs) : 1;
    m.count = count; regs.regs[0] = 0;
    if (!skip) probe->handler(&instance, &regs);
    for (int i = 0; i < 16; ++i) {
        assert(storage[i] == 0x71); assert(storage[capacity + 16 + i] == 0x71);
    }
    assert(m.count <= capacity);
    bool overflow = m.count == capacity;
    fwrite(m.buf, 1, overflow ? count : m.count, stdout);
    fprintf(stderr, "hits=%d rewrites=%d overflow=%d\n", n_kstat_map_hits, n_kstat_map_rewrites, overflow);
    free(storage); return 0;
}
'''
    path = Path(directory) / 'callback.c'; path.write_text(stubs + fragment + main)
    executable = Path(directory) / 'callback'
    subprocess.run([os.environ.get('CC', 'cc'), '-std=gnu11', '-O2', '-Wall', '-Wextra', '-Werror',
                    '-Wno-unused-function', '-Wno-unused-variable', '-Wno-unused-parameter',
                    str(path), '-o', str(executable)], check=True, capture_output=True, text=True)
    return executable


class ProductionCallback:
    def __init__(self, source_dir=None):
        self.directory = tempfile.TemporaryDirectory(prefix='kstat-maps-production-')
        try: self.executable = compile_callback(self.directory.name, source_dir)
        except BaseException:
            self.directory.cleanup(); raise

    def close(self): self.directory.cleanup()

    def rewrite(self, text, real_ino, real_dev, overrides, current_ino=None, uid=10362, capacity=None, start=0, route="show_map"):
        flags = (1 if 'ino' in overrides else 0) | (2 if 'dev' in overrides else 0)
        if 'flags' in overrides: flags = overrides['flags']
        arguments = (real_ino, real_dev, real_ino if current_ino is None else current_ino,
                     overrides.get('ino', real_ino), overrides.get('dev', real_dev), flags, uid,
                     len(text.encode()) + 4096 if capacity is None else capacity, start, route)
        result = subprocess.run([str(self.executable), *map(str, arguments)], input=text,
                                capture_output=True, text=True, check=True, timeout=10)
        return result.stdout, {key: int(value) for key, value in re.findall(r'(\w+)=(\d+)', result.stderr)}
