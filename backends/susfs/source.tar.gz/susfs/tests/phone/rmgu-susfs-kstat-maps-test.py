#!/usr/bin/env python3
"""CP21 owned kstat inode/device identity in maps and smaps.

Run from ordinary Termux with the CP21 module. Only the newly created
fixture path is added/deleted. No mapping-hide rule, global clear or unload.
"""
import ctypes as ct
import json
import mmap
import os
from pathlib import Path
import re
import shlex
import shutil
import signal
import subprocess
import sys
import tempfile

KERNEL = '6.12.69-android16-6-pb4d3caf-abogkiS948BXXS4BZIG-4k'
CONTROL = '/proc/susfs_kstat'
STATX_DIAGNOSTIC = 'statx: checkpoint=20 device_pair=1 dev_bits=32 time_bits=64'
ROOT_TIMEOUT = 30
OVERRIDE_FIELDS = ('ino', 'dev', 'nlink', 'size', 'atime_sec', 'atime_nsec',
                   'mtime_sec', 'mtime_nsec', 'ctime_sec', 'ctime_nsec', 'blocks', 'blksize')

class RootCommandUnknown(RuntimeError):
    """A timed-out/interrupted root command may still be blocked in the kernel."""

def root(command):
    with tempfile.TemporaryFile(mode='w+t') as output, tempfile.TemporaryFile(mode='w+t') as error:
        proc = subprocess.Popen(['su', '-c', command], stdin=subprocess.DEVNULL,
                                stdout=output, stderr=error, text=True, start_new_session=True)
        try:
            proc.wait(timeout=ROOT_TIMEOUT)
        except (subprocess.TimeoutExpired, KeyboardInterrupt) as problem:
            try:
                proc.kill()
            except (ProcessLookupError, PermissionError):
                pass
            try:
                proc.wait(timeout=1)
            except subprocess.TimeoutExpired:
                pass
            raise RootCommandUnknown('Root command outcome unknown; no further control commands will be sent.') from problem
        output.seek(0)
        error.seek(0)
        if proc.returncode:
            raise RuntimeError('Root command failed (%d): %s' % (proc.returncode, error.read().strip()))
        return output.read()

def parse_control(text):
    lines = text.splitlines()
    try:
        boundary = next(index for index, line in enumerate(lines) if line.startswith('maps: armed='))
    except StopIteration:
        raise RuntimeError('Kstat control format is not recognized')
    # CP20 prints the statx diagnostic after the rules and before maps counters.
    # Consume this exact line separately; never ignore arbitrary non-rule lines.
    if (boundary == 0 or lines[boundary - 1] != STATX_DIAGNOSTIC or
            lines.count(STATX_DIAGNOSTIC) != 1):
        raise RuntimeError('CP20 kstat diagnostic boundary is not recognized')
    rules = lines[:boundary - 1]
    if rules == ['(empty)']:
        rules = []
    elif not rules or any(not re.fullmatch(r'/\S+ ino=\d+ dev=\d+ flags=0x[0-9a-f]+ \[.+\]', line) for line in rules):
        raise RuntimeError('Invalid kstat rule list')
    counters = {}
    for line in lines[boundary:]:
        match = re.match(r'stat nr (\S+)\s+\((\d+)\): (.+)', line)
        if match:
            counters[int(match[2])] = {key: int(number) for key, number in re.findall(r'(\w+)=(\d+)', match[3])}
    if not {79, 80, 291}.issubset(counters): raise RuntimeError('Native kstat counters unavailable')
    return rules, counters

def command(operation, path, overrides=None):
    path = str(path)
    if any(char.isspace() for char in path) or len(os.fsencode(path)) >= 256:
        raise RuntimeError('Owned path is not compatible with the kstat control ABI')
    if operation == 'del': return 'del ' + path
    if operation != 'add': raise RuntimeError('Unknown rule operation')
    if not overrides or not set(overrides).issubset(OVERRIDE_FIELDS):
        raise RuntimeError('Invalid native field profile')
    for field, value in overrides.items():
        if type(value) is not int: raise RuntimeError('Field values must be integers')
        if field.endswith('_nsec'): limits = (0, 999999999)
        elif field.endswith('_sec'): limits = (-(1 << 63), (1 << 63) - 1)
        elif field in ('dev', 'nlink'): limits = (0, (1 << 32) - 1)
        elif field == 'blksize': limits = (1, (1 << 31) - 1)
        else: limits = (0, (1 << 63) - 1)
        if not limits[0] <= value <= limits[1]: raise RuntimeError('Field out of ABI range: ' + field)
    values = [str(overrides[field]) if field in overrides else 'default' for field in OVERRIDE_FIELDS]
    return 'add_sus_kstat_statically ' + path + ' ' + ' '.join(values)

def write_owned(operation, path, overrides=None):
    print('WRITE ' + operation.upper() + ' owned kstat rule', flush=True)
    root("printf '%s\\n' " + shlex.quote(command(operation, path, overrides)) + ' > ' + CONTROL)
    print('WRITE ' + operation.upper() + ' returned', flush=True)

def components(fields):
    values = {field: fields[field] for field in ('ino', 'dev', 'nlink', 'size', 'blocks', 'blksize')}
    for name in ('atime', 'mtime', 'ctime'):
        values[name + '_sec'], values[name + '_nsec'] = divmod(fields[name + '_ns'], 1000000000)
    return values

def profile_flags(overrides):
    return sum(1 << index for index, field in enumerate(OVERRIDE_FIELDS) if field in overrides)

def verify_owned(rules, original, target, real, overrides):
    prefix = str(target) + ' '
    mine = [line for line in rules if line.startswith(prefix)]
    if [line for line in rules if not line.startswith(prefix)] != original or len(mine) != 1:
        raise RuntimeError('Published kstat list does not contain only the owned addition')
    body = r' ino=(\d+) dev=(\d+) flags=0x([0-9a-f]+) \[ino=(\d+) dev=(\d+) nlink=(\d+) size=(-?\d+)'
    body += r' atime=(-?\d+)\.(\d+) mtime=(-?\d+)\.(\d+) ctime=(-?\d+)\.(\d+) blocks=(-?\d+) blksize=(-?\d+)\]'
    row = re.fullmatch(re.escape(str(target)) + body, mine[0])
    wanted = components(real); wanted.update(overrides)
    if (not row or tuple(map(int, row.group(1, 2))) != (real['ino'], real['dev']) or
            int(row[3], 16) != profile_flags(overrides) or
            tuple(map(int, row.groups()[3:])) != tuple(wanted[field] for field in OVERRIDE_FIELDS)):
        raise RuntimeError('Published owned field values or flags differ from the requested profile')

COMMON = r'''
import ctypes as ct
import json
import os
import struct
import sys

NUMBERS = {'aarch64': {'fstat': 80, 'newfstatat': 79, 'statx': 291},
           'x86_64': {'fstat': 5, 'newfstatat': 262, 'statx': 332}}


def decode_stat(data, architecture):
    if architecture == 'aarch64':
        if len(data) != 128: raise RuntimeError('Invalid AArch64 stat size')
        result = {'dev': struct.unpack_from('<Q', data, 0)[0],
                  'ino': struct.unpack_from('<Q', data, 8)[0],
                  'mode': struct.unpack_from('<I', data, 16)[0],
                  'nlink': struct.unpack_from('<I', data, 20)[0],
                  'uid': struct.unpack_from('<I', data, 24)[0],
                  'gid': struct.unpack_from('<I', data, 28)[0],
                  'rdev': struct.unpack_from('<Q', data, 32)[0],
                  'size': struct.unpack_from('<q', data, 48)[0],
                  'blksize': struct.unpack_from('<i', data, 56)[0],
                  'blocks': struct.unpack_from('<q', data, 64)[0]}
        time_start = 72
    elif architecture == 'x86_64':
        if len(data) != 144: raise RuntimeError('Invalid x86_64 stat size')
        result = {'dev': struct.unpack_from('<Q', data, 0)[0],
                  'ino': struct.unpack_from('<Q', data, 8)[0],
                  'nlink': struct.unpack_from('<Q', data, 16)[0],
                  'mode': struct.unpack_from('<I', data, 24)[0],
                  'uid': struct.unpack_from('<I', data, 28)[0],
                  'gid': struct.unpack_from('<I', data, 32)[0],
                  'rdev': struct.unpack_from('<Q', data, 40)[0],
                  'size': struct.unpack_from('<q', data, 48)[0],
                  'blksize': struct.unpack_from('<q', data, 56)[0],
                  'blocks': struct.unpack_from('<q', data, 64)[0]}
        time_start = 72
    else:
        raise RuntimeError('Unsupported stat architecture')
    for index, name in enumerate(('atime_ns', 'mtime_ns', 'ctime_ns')):
        seconds, nanos = struct.unpack_from('<qQ', data, time_start + 16 * index)
        result[name] = seconds * 1000000000 + nanos
    return result


def decode_statx(data):
    if len(data) != 256: raise RuntimeError('Invalid statx buffer size')
    result = {'mask': struct.unpack_from('<I', data, 0)[0],
              'blksize': struct.unpack_from('<I', data, 4)[0],
              'attributes': struct.unpack_from('<Q', data, 8)[0],
              'nlink': struct.unpack_from('<I', data, 16)[0],
              'uid': struct.unpack_from('<I', data, 20)[0],
              'gid': struct.unpack_from('<I', data, 24)[0],
              'mode': struct.unpack_from('<H', data, 28)[0],
              'ino': struct.unpack_from('<Q', data, 32)[0],
              'size': struct.unpack_from('<Q', data, 40)[0],
              'blocks': struct.unpack_from('<Q', data, 48)[0],
              'attributes_mask': struct.unpack_from('<Q', data, 56)[0],
              'rdev': os.makedev(*struct.unpack_from('<II', data, 128)),
              'dev': os.makedev(*struct.unpack_from('<II', data, 136)),
              'mnt_id': struct.unpack_from('<Q', data, 144)[0]}
    for name, offset in (('atime_ns', 64), ('btime_ns', 80), ('ctime_ns', 96), ('mtime_ns', 112)):
        seconds, nanos = struct.unpack_from('<qI', data, offset)
        result[name] = seconds * 1000000000 + nanos
    return result


class NativeStat:
    def __init__(self):
        self.architecture = os.uname().machine
        if self.architecture not in NUMBERS or sys.byteorder != 'little' or ct.sizeof(ct.c_void_p) != 8:
            raise RuntimeError('Unsupported native syscall ABI')
        self.numbers = NUMBERS[self.architecture]
        self.libc = ct.CDLL(None, use_errno=True)
        self.libc.syscall.restype = ct.c_long

    def call(self, operation, *arguments, mask=None):
        size = 256 if operation == 'statx' else (128 if self.architecture == 'aarch64' else 144)
        # Guards lie outside the ABI payload; no intentionally invalid user pointer.
        storage = ct.create_string_buffer(b'G' * 16 + b'\0' * size + b'G' * 16, size + 32)
        pointer = ct.c_void_p(ct.addressof(storage) + 16)
        ct.set_errno(0)
        call_arguments = list(arguments)
        if operation == 'newfstatat': call_arguments.insert(2, pointer)
        else: call_arguments.append(pointer)
        result = self.libc.syscall(ct.c_long(self.numbers[operation]), *call_arguments)
        if storage.raw[:16] != b'G' * 16 or storage.raw[-16:] != b'G' * 16:
            raise RuntimeError('Native stat buffer guard changed')
        value = {'errno': ct.get_errno() if result < 0 else 0, 'returncode': int(result),
                 'nr': self.numbers[operation], 'buffer_guards': True}
        if mask is not None: value['requested_mask'] = mask
        if result == 0:
            data = storage.raw[16:16 + size]
            value['raw_hex'] = data.hex()
            value['fields'] = decode_statx(data) if operation == 'statx' else decode_stat(data, self.architecture)
        return value

    def fstat(self, fd):
        return self.call('fstat', ct.c_int(fd))

    def at(self, path, fd=-100, flags=0):
        return self.call('newfstatat', ct.c_int(fd), ct.c_char_p(os.fsencode(path)), ct.c_int(flags))

    def statx(self, path, fd=-100, flags=0, mask=0x7ff):
        return self.call('statx', ct.c_int(fd), ct.c_char_p(os.fsencode(path)), ct.c_int(flags), ct.c_uint(mask), mask=mask)


def os_fields(value):
    return {key: getattr(value, 'st_' + key) for key in
            ('dev', 'ino', 'mode', 'nlink', 'uid', 'gid', 'rdev', 'size', 'blksize', 'blocks',
             'atime_ns', 'mtime_ns', 'ctime_ns')}


def observe(paths, held, native=None):
    native = native or NativeStat()
    result = {'uid': os.geteuid(), 'architecture': native.architecture, 'files': {}, 'negative': {}}
    for name, path in paths.items():
        fresh = os.open(path, os.O_RDONLY | os.O_CLOEXEC)
        try:
            methods = {'fstat_held': native.fstat(held[name]),
                       'fstat_fresh': native.fstat(fresh),
                       'newfstatat_path': native.at(path),
                       'newfstatat_held_empty': native.at('', held[name], 0x1000),
                       'statx_path': native.statx(path),
                       'statx_held_empty': native.statx('', held[name], 0x1000),
                       'statx_inode_mask': native.statx(path, mask=0x100),
                       'statx_size_mask': native.statx(path, mask=0x200),
                       'statx_nlink_mask': native.statx(path, mask=4),
                       'statx_times_mask': native.statx(path, mask=0xe0),
                       'statx_blocks_mask': native.statx(path, mask=0x400),
                       'statx_zero_mask': native.statx(path, mask=0)}
            result['files'][name] = methods
        finally:
            os.close(fresh)
    result['negative'] = {'invalid_fstat': native.fstat(-1),
                          'invalid_empty_statx': native.statx('', -1, 0x1000),
                          'missing_path': native.at(str(paths['target']) + '.absent')}
    return result


def root_observe(paths):
    held = {name: os.open(path, os.O_RDONLY | os.O_CLOEXEC) for name, path in paths.items()}
    try: return observe(paths, held)
    finally:
        for fd in held.values(): os.close(fd)


if False:
    print(json.dumps(root_observe(json.loads(sys.argv[1])), separators=(',', ':')), flush=True)
'''
OBSERVER = r'''
"""Observer embedded into the standalone CP20 phone runner and its root helper.

NativeStat is supplied by the qualified native runner support. This module only
reads existing proc files and the owned fixture; it sends no feature controls.
"""
import ctypes as ct
import json
import os
from pathlib import Path
import re

HEADER = re.compile(r'^([0-9a-f]+)-([0-9a-f]+) ([r-][w-][x-][ps]) '
                    r'([0-9a-f]+) ([0-9a-f]+):([0-9a-f]+) ([0-9]+)([ \t]*)(.*)$')
TABLE_LIMIT = 8 * 1024 * 1024


def process_identity(pid):
    directory = Path('/proc') / str(pid)
    stat = (directory / 'stat').read_text()
    suffix = stat[stat.rfind(')') + 2:].split()
    if not stat.startswith(str(pid) + ' (') or len(suffix) < 20:
        raise RuntimeError('Subject process stat is not recognized')
    status = (directory / 'status').read_text()
    match = re.search(r'^Uid:\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s*$', status, re.M)
    if not match: raise RuntimeError('Subject process UID is unavailable')
    return {'pid': int(pid), 'starttime': int(suffix[19]),
            'uids': list(map(int, match.groups())),
            'context': (directory / 'attr/current').read_text().rstrip('\0\n'),
            'mount_namespace': os.readlink(directory / 'ns/mnt')}


def read_table(path, chunk):
    fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC)
    parts = []; count = 0
    try:
        while True:
            part = os.read(fd, chunk)
            if not part: break
            count += len(part)
            if count > TABLE_LIMIT: raise RuntimeError('Proc table exceeded the bounded byte limit')
            parts.append(part)
    finally:
        os.close(fd)
    return b''.join(parts).decode('utf-8', errors='surrogateescape')


def parse_header(line):
    match = HEADER.fullmatch(line)
    if not match: return None
    return {'start': int(match[1], 16), 'end': int(match[2], 16),
            'perms': match[3], 'offset': int(match[4], 16),
            'major': int(match[5], 16), 'minor': int(match[6], 16),
            'dev': os.makedev(int(match[5], 16), int(match[6], 16)),
            'ino': int(match[7]), 'gap': match[8], 'path': match[9],
            'prefix': line[:match.start(5)],
            'identity_text': line[match.start(5):match.end(7)], 'raw': line}


def selected_rows(text, payload, table):
    headers = []
    for line in text.splitlines():
        row = parse_header(line)
        if row: headers.append(row)
        elif table == 'maps' and line:
            raise RuntimeError('Malformed maps row')
    files = set(payload['paths'].values())
    known = {(slot['start'], slot['end']) for slot in payload['slots'].values()}
    rows = [row for row in headers if row['path'] in files or (row['start'], row['end']) in known]
    result = {}
    for name, slot in payload['slots'].items():
        matches = [row for row in rows if (row['start'], row['end']) == (slot['start'], slot['end'])]
        if len(matches) != 1:
            raise RuntimeError('%s %s expected one owned range header, got %d' % (table, name, len(matches)))
        result[name] = matches[0]
    if len(rows) != len(payload['slots']):
        raise RuntimeError(table + ' has extra or duplicate owned mapping headers')
    return result


def observe_subject(payload, held=None):
    before = process_identity(payload['subject']['pid'])
    if before != payload['subject']: raise RuntimeError('Owned subject identity changed before observation')
    directory = Path('/proc/self') if before['pid'] == os.getpid() else Path('/proc') / str(before['pid'])
    views = {}
    for table in ('maps', 'smaps'):
        for style, chunk in (('full', 65536), ('small', 127)):
            text = read_table(directory / table, chunk)
            views[table + '_' + style] = selected_rows(text, payload, table)
    native = NativeStat()
    files = {}; opened = []
    try:
        for name, path in payload['paths'].items():
            if held is None:
                fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC); opened.append(fd)
            else: fd = held[name]
            files[name] = {
                'fstat': native.call('fstat', ct.c_int(fd)),
                'statx': native.call('statx', ct.c_int(-100), ct.c_char_p(os.fsencode(path)),
                                     ct.c_int(0), ct.c_uint(0x7ff), mask=0x7ff)}
    finally:
        for fd in opened: os.close(fd)
    after = process_identity(before['pid'])
    if after != before: raise RuntimeError('Owned subject identity changed during observation')
    return {'reader_uid': os.geteuid(), 'subject': before, 'views': views, 'files': files}
'''
SHARED = COMMON + '\n' + OBSERVER
exec(SHARED, globals())

"""Workflow embedded in the standalone CP21 maps identity phone runner."""


def require_map_routes(text):
    rows = [line for line in text.splitlines() if line.startswith('map_identity:')]
    if len(rows) != 1 or not re.fullmatch(r'map_identity: checkpoint=21 routes=2 maps=\d+ smaps=\d+ missed=\d+/\d+', rows[0]):
        raise RuntimeError('CP21 maps/smaps route diagnostic unavailable; no new rule sent')
    return rows[0]


def identity_profiles(real):
    return [{'ino': (1 << 40) + real['ino'] + 1, 'dev': os.makedev(0xabc, 0xdef01)},
            {'ino': 7 if real['ino'] != 7 else 8},
            {'dev': os.makedev(4094, 0xabcde)}]


def assess_identity(baseline, now, overrides, label):
    failures = []
    if (now['reader_uid'] != baseline['reader_uid'] or now['subject'] != baseline['subject']):
        failures.append(label + ' reader/owned subject identity changed')
    for view, rows in baseline['views'].items():
        for name, prior in rows.items():
            current = now['views'][view][name]
            chosen = overrides if name.startswith('target_') else None
            chosen = chosen or {}
            ino = chosen.get('ino', prior['ino']); dev = chosen.get('dev', prior['dev'])
            identity = '%02x:%02x %d' % (os.major(dev), os.minor(dev), ino)
            # Kernel padding is retained when a number shrinks; wider values
            # may move the path right. Every byte outside this run stays exact.
            gap = ' ' * max(0, len(prior['identity_text']) - len(identity)) + prior['gap']
            wanted = prior['prefix'] + identity + gap + prior['path']
            if current['ino'] != ino or current['dev'] != dev:
                failures.append(label + ' ' + view + ' ' + name + ' inode/device mismatch')
            if any(current[field] != prior[field] for field in ('start', 'end', 'perms', 'offset', 'prefix', 'path')):
                failures.append(label + ' ' + view + ' ' + name + ' range/permissions/offset/path changed')
            if current['raw'] != wanted:
                failures.append(label + ' ' + view + ' ' + name + ' header bytes or padding differ')
    for name, methods in baseline['files'].items():
        for method, prior in methods.items():
            current = now['files'][name][method]
            chosen = overrides if name == 'target' else None
            chosen = chosen or {}
            if current['errno'] or current['returncode'] != 0 or not current['buffer_guards']:
                failures.append(label + ' ' + name + ' native ' + method + ' failed')
                continue
            wanted = dict(prior['fields']); wanted.update(chosen)
            if current['fields'] != wanted or current.get('requested_mask') != prior.get('requested_mask'):
                failures.append(label + ' ' + name + ' native ' + method + ' metadata differs')
            allowed = set()
            for field in chosen:
                offset, width = ({'ino': (32, 8), 'dev': (136, 8)} if method == 'statx'
                                 else {'ino': (8, 8), 'dev': (0, 8)})[field]
                allowed.update(range(offset, offset + width))
            before = bytes.fromhex(prior['raw_hex']); after = bytes.fromhex(current['raw_hex'])
            if len(before) != len(after) or any(a != b and i not in allowed for i, (a, b) in enumerate(zip(before, after))):
                failures.append(label + ' ' + name + ' native ' + method + ' unrelated bytes changed')
    return failures


def require_identity_baseline(app, privileged, payload, real):
    if app['reader_uid'] < 10000 or privileged['reader_uid'] != 0:
        raise RuntimeError('Wrong app/root reader UID; no rules changed')
    if app['subject'] != payload['subject'] or privileged['subject'] != payload['subject']:
        raise RuntimeError('App/root do not observe the same owned process; no rules changed')
    for reader, snapshot in (('APP', app), ('ROOT', privileged)):
        for view, rows in snapshot['views'].items():
            if set(rows) != set(payload['slots']): raise RuntimeError('Owned mapping set incomplete; no rules changed')
            for name, row in rows.items():
                slot = payload['slots'][name]; actual = real[slot['file']]
                if (row['start'] != slot['start'] or row['end'] != slot['end'] or
                        row['offset'] != slot['offset'] or row['perms'] != 'rw-p' or
                        row['path'] != payload['paths'][slot['file']] or
                        row['ino'] != actual['ino'] or row['dev'] != actual['dev']):
                    raise RuntimeError(reader + ' baseline ' + view + ' ' + name + ' not native; no rules changed')
        for name, methods in snapshot['files'].items():
            for method, value in methods.items():
                if value['errno'] or value['returncode'] != 0 or not value['buffer_guards']:
                    raise RuntimeError(reader + ' baseline native metadata unavailable; no rules changed')
                if method == 'statx' and value['fields']['mask'] & 0x7ff != 0x7ff:
                    raise RuntimeError('Baseline statx basic fields missing; no rules changed')
                if any(value['fields'][field] != actual for field, actual in real[name].items()):
                    raise RuntimeError(reader + ' baseline native metadata differs; no rules changed')
        for table in ('maps', 'smaps'):
            if snapshot['views'][table + '_full'] != snapshot['views'][table + '_small']:
                raise RuntimeError(reader + ' baseline proc read sizes disagree; no rules changed')
    if app['views'] != privileged['views']:
        raise RuntimeError('App/root baseline headers disagree; no rules changed')


def identity_brief(label, app, privileged):
    result = {}
    for name, snapshot in (('app', app), ('root', privileged)):
        result[name] = {
            'reader_uid': snapshot['reader_uid'],
            'headers': {table: {slot: row['raw'] for slot, row in snapshot['views'][table + '_full'].items()}
                        for table in ('maps', 'smaps')},
            'small_reads_equal': {table: snapshot['views'][table + '_full'] == snapshot['views'][table + '_small']
                                  for table in ('maps', 'smaps')},
            'native': {file: {method: {field: row.get('fields', {}).get(field) for field in ('ino', 'dev')}
                             | {'errno': row['errno']} for method, row in methods.items()}
                       for file, methods in snapshot['files'].items()}}
    print(label + ': ' + json.dumps(result, separators=(',', ':')), flush=True)


def real_fields(value):
    return {'ino': value.st_ino, 'dev': value.st_dev, 'size': value.st_size,
            'nlink': value.st_nlink, 'blocks': value.st_blocks, 'blksize': value.st_blksize,
            'atime_ns': value.st_atime_ns, 'mtime_ns': value.st_mtime_ns, 'ctime_ns': value.st_ctime_ns}


def run_identity_fixture(original):
    fixture = Path(tempfile.mkdtemp(prefix='rmgu-susfs-kstat-maps.', dir=Path.home()))
    paths = {name: fixture / (name + '.bin') for name in ('target', 'control')}
    held = {}; mappings = []; records = []; failures = []; real = {}
    attempted = False; unknown = False; safe = True; chosen = None
    target = paths['target']; page = os.sysconf('SC_PAGE_SIZE')
    try:
        for name, path in paths.items():
            path.write_bytes((b'RMGU-kstat-' + name.encode() + b'\n').ljust(16 * page, b'\0'))
            path.chmod(0o600); held[name] = os.open(path, os.O_RDONLY | os.O_CLOEXEC)
        slots = {}
        for name, file, length, offset in (('target_main', 'target', 3, 0), ('target_alias', 'target', 5, 4),
                                          ('control_main', 'control', 2, 0), ('control_alias', 'control', 4, 6)):
            mapping = mmap.mmap(held[file], length * page, access=mmap.ACCESS_COPY, offset=offset * page)
            mappings.append(mapping)
            for index in range(0, length * page, page): _ = mapping[index]
            start = ct.addressof(ct.c_char.from_buffer(mapping))
            slots[name] = {'file': file, 'start': start, 'end': start + length * page, 'offset': offset * page}
        real = {name: real_fields(os.fstat(fd)) for name, fd in held.items()}
        payload = {'subject': process_identity(os.getpid()), 'paths': {name: str(path) for name, path in paths.items()},
                   'slots': slots}
        if payload['subject']['uids'] != [os.geteuid()] * 4:
            raise RuntimeError('Ordinary reader real/effective/saved/fs UIDs differ; no rules changed')
        helper = fixture / 'root-helper.py'
        helper.write_text(SHARED + "\nif __name__ == '__main__':\n    print(json.dumps(observe_subject(json.loads(sys.argv[1])), separators=(',', ':')), flush=True)\n")
        helper.chmod(0o600)
        for filename, value in (('original-rules.json', original), ('fixture.json', payload)):
            (fixture / filename).write_text(json.dumps(value, indent=2)); (fixture / filename).chmod(0o600)
        root_command = '/system/bin/toybox nsenter -t %d -m ' % os.getpid() + shlex.quote(sys.executable)
        root_command += ' ' + shlex.quote(str(helper)) + ' ' + shlex.quote(json.dumps(payload))
        print('OWNED SUBJECT: ' + json.dumps(payload['subject']), flush=True)
        def snapshots(label):
            app = observe_subject(payload, held)
            privileged = json.loads(root(root_command))
            records.append({'phase': label, 'app': app, 'root': privileged})
            identity_brief(label, app, privileged)
            return app, privileged
        app_before, root_before = snapshots('BASELINE')
        require_identity_baseline(app_before, root_before, payload, real)
        for cycle, chosen in enumerate(identity_profiles(real['target']), 1):
            if parse_control(root('cat ' + CONTROL))[0] != original:
                safe = False
                raise RuntimeError('Kstat rule table changed before ADD; no new rule sent')
            print('ENABLE %d identity overrides (flags=0x%x): %s' % (cycle, profile_flags(chosen), json.dumps(chosen)), flush=True)
            attempted = True
            write_owned('add', target, chosen)
            rules, _ = parse_control(root('cat ' + CONTROL))
            verify_owned(rules, original, target, real['target'], chosen)
            app, privileged = snapshots('ACTIVE ' + str(cycle))
            failures.extend(assess_identity(app_before, app, chosen, 'ACTIVE %d APP' % cycle))
            failures.extend(assess_identity(root_before, privileged, None, 'ACTIVE %d ROOT' % cycle))
            print('ACTIVE COUNTERS (diagnostic):\n' + root('cat ' + CONTROL), flush=True)
            # Verify ownership and unrelated rows again before removing the rule.
            verify_owned(parse_control(root('cat ' + CONTROL))[0], original, target, real['target'], chosen)
            print('DISABLE %d' % cycle, flush=True)
            write_owned('del', target)
            if parse_control(root('cat ' + CONTROL))[0] != original:
                raise RuntimeError('Exact original kstat rule list not restored')
            attempted = False
            app, privileged = snapshots('RESTORED ' + str(cycle))
            failures.extend(assess_identity(app_before, app, None, 'RESTORED %d APP' % cycle))
            failures.extend(assess_identity(root_before, privileged, None, 'RESTORED %d ROOT' % cycle))
        if parse_control(root('cat ' + CONTROL))[0] != original:
            safe = False; raise RuntimeError('Original rule list differs at final verification')
        print('FINAL COUNTERS (diagnostic):\n' + root('cat ' + CONTROL), flush=True)
    except RootCommandUnknown:
        unknown = True
        raise
    finally:
        if unknown: safe = False
        if attempted and not unknown:
            try:
                current, _ = parse_control(root('cat ' + CONTROL))
                mine = [line for line in current if line.startswith(str(target) + ' ')]
                if mine:
                    verify_owned(current, original, target, real['target'], chosen)
                    write_owned('del', target)
                if parse_control(root('cat ' + CONTROL))[0] != original:
                    raise RuntimeError('Original rule list differs')
            except BaseException as problem:
                if isinstance(problem, RootCommandUnknown): unknown = True
                safe = False; print('Rule restoration unverified: ' + str(problem), flush=True)
        elif attempted:
            print('Root outcome unknown; further rule commands skipped.', flush=True)
        elif not unknown and safe:
            try:
                if parse_control(root('cat ' + CONTROL))[0] != original:
                    raise RuntimeError('Original rule list differs during cleanup')
            except BaseException as problem:
                if isinstance(problem, RootCommandUnknown): unknown = True
                safe = False; print('Final rule verification unqualified: ' + str(problem), flush=True)
        for mapping in mappings:
            try: mapping.close()
            except BaseException as problem:
                safe = False; print('Owned mapping release failed: ' + str(problem), flush=True)
        for fd in held.values():
            try: os.close(fd)
            except OSError as problem:
                safe = False; print('Owned descriptor close failed: ' + str(problem), flush=True)
        if safe:
            shutil.rmtree(fixture)
            print('Cleanup complete; owned aliases/descriptors released, test rule and fixture removed, exact original list verified.', flush=True)
        else:
            evidence = fixture / 'observations.json'
            evidence.write_text(json.dumps({'records': records, 'failures': failures, 'root_outcome_unknown': unknown}, indent=2))
            evidence.chmod(0o600)
            print('RETAINED FIXTURE: ' + str(fixture), flush=True)
        if not safe: failures.append('Cleanup unqualified')
    if failures: raise RuntimeError('; '.join(dict.fromkeys(failures)))
    print('PASS: native inode/device identity in maps/smaps, two target/control aliases, full/small reads, wide and selected-field profiles, native stat consistency, root/control/header preservation, three cycles, exact restoration and cleanup.', flush=True)
    print('Scope: owned stable mappings on native AArch64; supercall payloads, compat ABI, redirect statfs, concurrent mapping/exec races, held proc descriptors, unloading and long-run stability remain unqualified.', flush=True)


def main():
    print('Kstat maps identity runner revision: 2 (CP21 maps/smaps listing routes and exact restoration)', flush=True)
    if os.geteuid() < 10000: raise RuntimeError('Run in ordinary Termux, outside a root shell')
    if os.uname().machine != 'aarch64' or os.uname().release != KERNEL:
        raise RuntimeError('This runner targets the pinned SM-S948B BZIG ARM64 kernel')
    print('App reader:', subprocess.check_output(['id'], text=True).strip(), flush=True)
    control = root('cat ' + CONTROL)
    require_map_routes(control)
    original, _ = parse_control(control)
    if len(original) >= 32: raise RuntimeError('Kstat rule table full; no controls changed')
    print('Saved original kstat rules: ' + str(len(original)), flush=True)
    run_identity_fixture(original)


if __name__ == '__main__':
    def interrupted(signum, frame): raise KeyboardInterrupt('signal ' + str(signum))
    signal.signal(signal.SIGINT, interrupted); signal.signal(signal.SIGTERM, interrupted)
    try: main()
    except (Exception, KeyboardInterrupt) as error:
        print('\nFAIL: ' + str(error), flush=True); sys.exit(1)
