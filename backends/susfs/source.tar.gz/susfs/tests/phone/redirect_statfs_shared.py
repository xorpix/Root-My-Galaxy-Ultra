"""Read-only native observer and exact redirect table parser for the phone runner."""
import ctypes as ct
import errno
import json
import os
from pathlib import Path
import re
import stat
import struct
import sys

REDIRECT_CONTROL = '/proc/susfs_open_redirect'
CP21_MARKER = 'map_identity: checkpoint=21 routes=2'
LIMIT = 1024 * 1024
RULE = re.compile(r'^(\S+) -> (\S+) uid=([0-4]) \(ino=(\d+) dev=(\d+) mnt=(\d+) \| rev: ino=(\d+) dev=(\d+)\)$')
HOOKS = re.compile(r'^hooks: open=[01] dpath=[01] statfs=[01] maps=[01] fdinfo=[01] '
                   r'\| rev hits: dpath=\d+ statfs=\d+ maps=\d+/\d+/\d+ fdinfo=\d+/\d+ '
                   r'\| su_sid=\d+ \| fdinfo_probes=\d+/\d+$')


def parse_redirect(text):
    rules = []; diagnostics = []; empty = False
    for line in text.splitlines():
        if line == '(empty)':
            if empty or rules: raise RuntimeError('Invalid redirect empty marker')
            empty = True
        elif RULE.fullmatch(line):
            if empty: raise RuntimeError('Redirect rules after empty marker')
            rules.append(line)
        elif HOOKS.fullmatch(line):
            diagnostics.append(line)
        else:
            raise RuntimeError('Invalid redirect rule list')
    # Deleted slots produce hooks alone, without an (empty) marker.
    if len(diagnostics) != 1 or len(set(rules)) != len(rules):
        raise RuntimeError('Invalid redirect diagnostics or duplicate rule')
    return {'rules': rules, 'diagnostics': diagnostics[0]}


def bounded_text(path):
    with open(path, 'rb') as stream:
        data = stream.read(LIMIT + 1)
    if len(data) > LIMIT: raise RuntimeError('Control read exceeded limit')
    return data.decode('utf-8', errors='strict')


def stable_statfs(value):
    if value['errno'] or value['returncode'] != 0 or not value['buffer_guards']:
        raise RuntimeError('Native statfs observation failed')
    data = bytes.fromhex(value['raw'])
    if len(data) != 120: raise RuntimeError('Unexpected native statfs width')
    # Free-space and file counts may change while other phone processes write.
    return (data[:16] + data[56:]).hex()


def filesystem_identity(value):
    stable_statfs(value)
    return value['fields']['type'], tuple(value['fields']['fsid'])


class NativeStatFS:
    def __init__(self):
        numbers = {'aarch64': (43, 44), 'x86_64': (137, 138)}
        machine = os.uname().machine
        if machine not in numbers or ct.sizeof(ct.c_void_p) != 8 or sys.byteorder != 'little':
            raise RuntimeError('Unsupported native statfs ABI')
        self.numbers = dict(zip(('statfs', 'fstatfs'), numbers[machine]))
        self.libc = ct.CDLL(None, use_errno=True)
        self.libc.syscall.restype = ct.c_long

    def call(self, operation, argument):
        storage = ct.create_string_buffer(b'G' * 16 + b'\xa5' * 120 + b'G' * 16, 152)
        pointer = ct.c_void_p(ct.addressof(storage) + 16)
        ct.set_errno(0)
        argument = ct.c_int(argument) if operation == 'fstatfs' else ct.c_char_p(os.fsencode(argument))
        result = int(self.libc.syscall(ct.c_long(self.numbers[operation]), argument, pointer))
        if storage.raw[:16] != b'G' * 16 or storage.raw[-16:] != b'G' * 16:
            raise RuntimeError('Native statfs buffer guard changed')
        value = {'nr': self.numbers[operation], 'returncode': result,
                 'errno': ct.get_errno() if result < 0 else 0, 'buffer_guards': True}
        if result == 0:
            data = storage.raw[16:136]
            names = ('type', 'bsize', 'blocks', 'bfree', 'bavail', 'files', 'ffree')
            fields = dict(zip(names, struct.unpack_from('<7Q', data)))
            fields['fsid'] = list(struct.unpack_from('<2I', data, 56))
            fields.update(zip(('namelen', 'frsize', 'flags'), struct.unpack_from('<3Q', data, 64)))
            fields['spare'] = list(struct.unpack_from('<4Q', data, 88))
            value.update(fields=fields, raw=data.hex())
        return value


class NativeXattr:
    """Descriptor xattrs through libc, including Python builds without os xattrs."""
    def __init__(self, attribute=b'security.selinux', limit=4096):
        if not isinstance(attribute, bytes) or not attribute or b'\0' in attribute:
            raise ValueError('Invalid native xattr name')
        if not 0 < limit <= 65536: raise ValueError('Invalid native xattr byte limit')
        self.attribute = attribute; self.limit = limit
        self.libc = ct.CDLL(None, use_errno=True)
        try:
            self.read = self.libc.fgetxattr; self.write = self.libc.fsetxattr
        except AttributeError as problem:
            raise RuntimeError('libc descriptor xattr functions unavailable') from problem
        self.read.argtypes = (ct.c_int, ct.c_char_p, ct.c_void_p, ct.c_size_t)
        self.read.restype = ct.c_ssize_t
        self.write.argtypes = (ct.c_int, ct.c_char_p, ct.c_void_p, ct.c_size_t, ct.c_int)
        self.write.restype = ct.c_int

    def get(self, fd):
        storage = ct.create_string_buffer(b'G' * 16 + b'\xa5' * self.limit + b'G' * 16, self.limit + 32)
        pointer = ct.c_void_p(ct.addressof(storage) + 16)
        ct.set_errno(0)
        count = int(self.read(fd, self.attribute, pointer, self.limit))
        problem = ct.get_errno()
        if storage.raw[:16] != b'G' * 16 or storage.raw[-16:] != b'G' * 16:
            raise RuntimeError('Native xattr buffer guard changed')
        if count < 0: raise OSError(problem or errno.EIO, 'fgetxattr: ' + os.strerror(problem or errno.EIO))
        if count > self.limit: raise RuntimeError('Native xattr exceeded byte limit')
        return storage.raw[16:16 + count]

    def set(self, fd, value):
        if not isinstance(value, bytes) or not value or len(value) > self.limit:
            raise ValueError('Empty or oversized native label')
        storage = ct.create_string_buffer(value, len(value))
        ct.set_errno(0)
        result = int(self.write(fd, self.attribute, ct.cast(storage, ct.c_void_p), len(value), 0))
        problem = ct.get_errno()
        if result < 0: raise OSError(problem or errno.EIO, 'fsetxattr: ' + os.strerror(problem or errno.EIO))
        if result != 0: raise RuntimeError('Unexpected native xattr write result')

    def copy(self, source_fd, destination_fd):
        value = self.get(source_fd)
        if not value: raise RuntimeError('Source SELinux label is empty')
        self.set(destination_fd, value)
        if self.get(destination_fd) != value: raise RuntimeError('Copied label readback differs')
        if self.get(source_fd) != value: raise RuntimeError('Source label changed during copy')
        return {'bytes': len(value), 'hex': value.hex(), 'verified': True,
                'method': 'libc fgetxattr/fsetxattr'}


def identity_from_stat(value):
    return {'ino': value.st_ino, 'dev': value.st_dev, 'uid': value.st_uid,
            'gid': value.st_gid, 'mode': value.st_mode, 'nlink': value.st_nlink}


def file_identity(path):
    return identity_from_stat(os.lstat(path))


def descriptor_identity(fd):
    return identity_from_stat(os.fstat(fd))


def verify_file(path, expected, directory=False):
    value = file_identity(path)
    if value != expected or not (stat.S_ISDIR(value['mode']) if directory else stat.S_ISREG(value['mode'])):
        raise RuntimeError('Owned fixture identity changed: ' + str(path))
    return value


def raw_device(value):
    return (os.major(value) << 20) | os.minor(value)


def fd_mount_id(fd):
    text = bounded_text('/proc/self/fdinfo/' + str(fd))
    rows = re.findall(r'^mnt_id:\s+(\d+)\s*$', text, re.M)
    if len(rows) != 1: raise RuntimeError('Descriptor mount ID unavailable')
    return int(rows[0])


def expected_rule(config):
    source = config['identities']['target']; destination = config['identities']['destination']
    return '%s -> %s uid=3 (ino=%d dev=%d mnt=%d | rev: ino=%d dev=%d)' % (
        config['paths']['target'], config['paths']['destination'], source['ino'], raw_device(source['dev']),
        config['source_mount_id'], destination['ino'], raw_device(destination['dev']))


def assert_subject(subject):
    observed = process_identity(subject['pid'])
    if observed != subject: raise RuntimeError('Owned reader identity changed')
    namespace = os.readlink('/proc/self/ns/mnt')
    if namespace != subject['mount_namespace']: raise RuntimeError('Root/app mount namespaces differ')


def observe_files(config, held):
    assert_subject(config['subject'])
    native = NativeStatFS(); paths = {}; descriptors = {}; opened = []
    try:
        for name, path in config['paths'].items():
            paths[name] = native.call('statfs', path)
            fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC); opened.append(fd)
            descriptors[name + '_fresh'] = {'statfs': native.call('fstatfs', fd),
                'content': os.pread(fd, 64, 0).hex()}
        for name, original_fd in held.items():
            # Root opens the same owned app descriptor's actual backing file.
            if os.getpid() == config['subject']['pid']:
                fd = original_fd
            else:
                fd = os.open('/proc/%d/fd/%d' % (config['subject']['pid'], original_fd),
                             os.O_RDONLY | os.O_CLOEXEC); opened.append(fd)
            descriptors[name] = {'statfs': native.call('fstatfs', fd),
                'proc_fd_statfs': native.call('statfs', '/proc/self/fd/' + str(fd)),
                'content': os.pread(fd, 64, 0).hex()}
        errors = {'missing_path': native.call('statfs', config['missing']),
                  'bad_fd': native.call('fstatfs', -1)}
    finally:
        for fd in opened: os.close(fd)
    assert_subject(config['subject'])
    return {'reader_uid': os.geteuid(), 'subject': config['subject'],
            'paths': paths, 'descriptors': descriptors, 'errors': errors}


def compact_observation(observation):
    def brief(value):
        fields = value.get('fields', {})
        return {'errno': value['errno'], 'type': fields.get('type'), 'fsid': fields.get('fsid'),
                'bsize': fields.get('bsize'), 'frsize': fields.get('frsize'),
                'namelen': fields.get('namelen'), 'flags': fields.get('flags')}
    return {'reader_uid': observation['reader_uid'],
            'paths': {name: brief(value) for name, value in observation['paths'].items()},
            'descriptors': {name: dict(brief(value['statfs']), content=value['content'])
                            for name, value in observation['descriptors'].items()},
            'errors': {name: value['errno'] for name, value in observation['errors'].items()}}
