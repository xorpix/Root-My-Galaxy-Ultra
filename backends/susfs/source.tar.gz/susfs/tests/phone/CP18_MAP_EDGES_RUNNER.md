# CP18 map-files coverage runner, revision 1

Use the currently loaded CP18 APK on SM-S948B / S948BXXS4BZIG. This is the
canonical map runner revision 7, delivered as rmgu-susfs-map-test-cp18-r1.py.
The kernel and APK are unchanged. The supplied phone result is pending.

```sh
su -c 'cat /sdcard/Download/rmgu-susfs-map-test-cp18-r1.py' | python -u
```

The ordinary Termux process retains the same target and control mappings from
baseline through hiding and restoration. Root controls use separate readers.
The runner requires an empty map-rule baseline, adds only its app-created
target inode/device rule, verifies publication, removes it and checks restored
access. Existing map/smaps/rollup, pagemap, memory-read, readlink, directory,
root-control and cleanup assertions remain.

## New direct access checks

The runner already knows each mapping's exact range from its own mapped buffer.
It probes that range directly with lstat, O_PATH|O_NOFOLLOW, followed stat and
read-only open/pread. Successful followed operations must describe the mapped
file and return its known bytes. Visible proc symlink inode numbers are not
required to stay equal across independent readers or dcache lifetimes.

If an app target operation succeeds at baseline, it must return ENOENT when
hidden. Surviving metadata access fails even when listing/readlink filtering
passes. A permission-blocked baseline is explicitly unqualified for that
operation; root/control/restored blocked scopes must keep their original error.
Some Android Python builds omit os.O_PATH, so the runner uses the supported
Linux ARM64/x86_64 UAPI value when necessary. It needs no os.getxattr.

CP18's map-files layer has no dedicated direct metadata/lookup guard. This
runner may expose that remaining gap. It removes the test rule and fixture
before reporting a completed failure; it never changes a failure into a full
implementation pass. This coverage is beyond the earlier stable listing and
readlink phone passes, which retain their original scope.

## Mapping changes during enumeration

A bounded thread creates and closes one-page aliases of the unrelated control
file, at most 256 times. The main target and control mappings remain alive.
The observer completes twelve 128-byte getdents64 walks and counts actual
mapping changes during the observation period. No observed changes leaves
the new scope unqualified; a returned stable hidden target name fails.

Native enumeration is not an atomic snapshot. Duplicates and control omissions
during mapping changes are collected as diagnostics, not mistaken for stable
cookie violations. The existing stable directory assertions still require no
duplicates and the visible control. Each dynamic walk has a shared eight-second
observation deadline and at most 4096 nonempty batches. Thread startup/join
waits are two seconds each. These userspace limits cannot interrupt a syscall
already stuck in the kernel; flushed READ markers identify the last operation.
Root commands retain their thirty-second completion bound and existing
unknown-outcome handling, which stops additional management reads/writes and
retains the fixture after a timeout.

This scope does not qualify other-process exec or changing the hidden target's
own mapping. Those races need separate implementation review and fixtures.

## Local validation

Twenty focused host tests pass. They include a real mapping-change worker and
real directory observer, malformed-dirent and deadline handling, metadata leak
rejection, wrong-followed-file rejection, blocked-scope handling and proc inode
changes between root readers. A simulated metadata leak exercises the complete
rule add/remove and fixture cleanup flow before FAIL. Existing root timeout
and retained-fixture cases still pass. Assertion fixtures model hiding; they
are not Samsung kernel evidence. No host or phone kernel was modified by the
test suite. Broader unchanged kernel/app tests were not rerun for this runner.
