"""Two owned redirect cycles, descriptor provenance, restoration and cleanup."""


class FixtureBlocked(RuntimeError):
    pass


class RootClient:
    def __init__(self, helper, subject):
        self.helper = helper; self.subject = subject; self.unknown = False

    def call(self, action, config):
        if self.unknown: raise RootCommandUnknown('Root outcome remains unknown; no further root commands sent.')
        payload = base64.b64encode(json.dumps(config, separators=(',', ':')).encode()).decode()
        arguments = ['/system/bin/toybox', 'nsenter', '-t', str(self.subject['pid']), '-m',
                     sys.executable, str(self.helper), action, payload]
        print('ROOT ' + action.upper(), flush=True)
        try:
            output = root(' '.join(shlex.quote(item) for item in arguments))
        except RootCommandUnknown:
            self.unknown = True
            raise
        try:
            value = json.loads(output)
        except (ValueError, TypeError) as problem:
            raise RuntimeError('Invalid root helper response; inspect rule state before cleanup') from problem
        if not value.get('ok'): raise RuntimeError(value.get('error', 'Root helper failed'))
        return value['value']


def check_filesystem(value, reference, label, errors):
    try:
        if stable_statfs(value) != stable_statfs(reference):
            errors.append(label + ': stable filesystem fields differ')
    except (RuntimeError, KeyError, ValueError) as problem:
        errors.append(label + ': ' + str(problem))


def check_phase(config, pair, references, active, errors, label, active_descriptor=False):
    source, destination = references
    contents = config['contents']
    if set(pair) != {'app', 'root'}: errors.append(label + ': missing reader view')
    for reader, observation in pair.items():
        app = reader == 'app'
        expected_uid = config['uid'] if app else 0
        if observation['reader_uid'] != expected_uid: errors.append(label + ' ' + reader + ': reader UID changed')
        if observation['subject'] != config['subject']: errors.append(label + ' ' + reader + ': subject changed')
        required = {name + '_fresh' for name in config['paths']} | {'target_before', 'source_control', 'destination_control'}
        if active_descriptor: required.add('target_active')
        if set(observation['paths']) != set(config['paths']): errors.append(label + ' ' + reader + ': path coverage differs')
        if set(observation['descriptors']) != required: errors.append(label + ' ' + reader + ': descriptor coverage differs')
        if set(observation['errors']) != {'missing_path', 'bad_fd'}: errors.append(label + ' ' + reader + ': error coverage differs')
        for name, value in observation['paths'].items():
            use_source = name in ('target', 'source_control') or (active and app and name == 'destination')
            check_filesystem(value, source if use_source else destination,
                             label + ' ' + reader + ' path ' + name, errors)
        for name, value in observation['descriptors'].items():
            if name == 'target_fresh':
                content = contents['destination'] if active and app else contents['target']
                reference = source
            elif name == 'destination_fresh':
                content = contents['destination']; reference = source if active and app else destination
            elif name == 'target_active':
                content = contents['destination']; reference = source if active and app else destination
            elif name in ('source_control_fresh', 'source_control', 'target_before'):
                content = contents['target'] if name == 'target_before' else contents['source_control']
                reference = source
            elif name in ('destination_control_fresh', 'destination_control'):
                content = contents['destination_control']; reference = destination
            else:
                errors.append(label + ' unexpected descriptor ' + name); continue
            check_filesystem(value['statfs'], reference, label + ' ' + reader + ' fd ' + name, errors)
            if name in {'target_before', 'source_control', 'destination_control', 'target_active'} and 'proc_fd_statfs' not in value:
                errors.append(label + ' ' + reader + ' proc-fd ' + name + ': missing observation')
            if 'proc_fd_statfs' in value:
                check_filesystem(value['proc_fd_statfs'], reference,
                                 label + ' ' + reader + ' proc-fd ' + name, errors)
            if value['content'] != content: errors.append(label + ' ' + reader + ' content ' + name + ': mismatch')
        for name, expected in (('missing_path', errno.ENOENT), ('bad_fd', errno.EBADF)):
            value = observation['errors'][name]
            if value['errno'] != expected or value['returncode'] != -1 or not value['buffer_guards']:
                errors.append(label + ' ' + reader + ' ' + name + ': native error changed')


def baseline_references(config, pair):
    source = pair['root']['paths']['target']; destination = pair['root']['paths']['destination']
    if config['identities']['target']['dev'] == config['identities']['destination']['dev']:
        raise FixtureBlocked('Source and destination backing devices are equal; no distinct filesystem challenge')
    if filesystem_identity(source) == filesystem_identity(destination) or stable_statfs(source) == stable_statfs(destination):
        raise FixtureBlocked('Source and destination filesystem identities are equal; statfs effect unqualified')
    problems = []
    check_phase(config, pair, (source, destination), False, problems, 'BASELINE')
    if problems: raise FixtureBlocked('Baseline unavailable or inconsistent: ' + '; '.join(problems))
    return source, destination


def observe_pair(client, config, held, label):
    print('READ ' + label + ' APP', flush=True)
    app = observe_files(config, held)
    root_config = dict(config, held=held)
    root_observation = client.call('observe', root_config)
    pair = {'app': app, 'root': root_observation}
    print(label + ': ' + json.dumps({name: compact_observation(value) for name, value in pair.items()},
                                   separators=(',', ':')), flush=True)
    return pair


def restore_rules(client, config):
    state = client.call('state', config)
    original = config['original_rules']
    if state['rules'] == original: return state
    if 'identities' not in config or state['rules'] != original + [expected_rule(config)]:
        raise RuntimeError('Unexpected rule state retained; refusing to remove another rule')
    return client.call('del', config)


def run_cycles(client, config, held, references, receipt):
    problems = []
    for cycle in (1, 2):
        print('ENABLE %d: only the owned source path, UID scheme 3' % cycle, flush=True)
        client.call('add', config)
        try:
            held['target_active'] = os.open(config['paths']['target'], os.O_RDONLY | os.O_CLOEXEC)
            pair = observe_pair(client, config, held, 'ACTIVE %d' % cycle)
            receipt['observations']['active_%d' % cycle] = pair
            check_phase(config, pair, references, True, problems, 'ACTIVE %d' % cycle, active_descriptor=True)
            print('DISABLE %d' % cycle, flush=True)
            client.call('del', config)
            # This descriptor still reads the destination after DEL; only the disguise ends.
            pair = observe_pair(client, config, held, 'RESTORED %d (active descriptor held)' % cycle)
            receipt['observations']['restored_%d' % cycle] = pair
            check_phase(config, pair, references, False, problems, 'RESTORED %d' % cycle, active_descriptor=True)
        finally:
            if 'target_active' in held: os.close(held.pop('target_active'))
        if problems: break
    return problems


def source_cleanup(config, helper):
    directory = Path(config['fixture'])
    known = {Path(config['paths'][name]).name for name in ('target', 'source_control')}
    known.add(helper.name)
    # receipt.json is created by this runner, including on a known failure.
    known.add('receipt.json')
    if not set(os.listdir(directory)).issubset(known): raise RuntimeError('Source fixture has extra entries; retained')
    if 'identities' in config:
        for name in ('target', 'source_control'): verify_file(config['paths'][name], config['identities'][name])
    for name in known:
        path = directory / name
        if path.exists(): path.unlink()
    directory.rmdir()


def main():
    print('Redirect statfs runner revision: 2 (CP21 native descriptor label copying and readback)', flush=True)
    if sys.argv[1:]: raise RuntimeError('This runner has no command-line options')
    if os.geteuid() < 10000 or os.uname().machine != 'aarch64' or os.uname().release != KERNEL:
        raise RuntimeError('Run from ordinary native AArch64 Termux on the qualified BZIG kernel')
    print('App reader: ' + subprocess.check_output(['id'], text=True).strip(), flush=True)
    subject = process_identity(os.getpid())
    fixture = Path(tempfile.mkdtemp(prefix='rmgu-susfs-redirect-statfs.', dir=str(Path.home())))
    helper = fixture / 'root-helper.py'; helper.write_text(ROOT_HELPER); helper.chmod(0o600)
    device_directory = '/dev/' + fixture.name
    contents = {'target': b'RMGU-statfs-original\n', 'source_control': b'RMGU-statfs-source-control\n',
                'destination': b'RMGU-statfs-redirected\n', 'destination_control': b'RMGU-statfs-destination-control\n'}
    config = {'fixture': str(fixture), 'device_directory': device_directory,
              'uid': os.geteuid(), 'gid': os.getegid(), 'subject': subject,
              'paths': {'target': str(fixture / 'target.txt'), 'source_control': str(fixture / 'control.txt'),
                        'destination': device_directory + '/redirected.txt',
                        'destination_control': device_directory + '/control.txt'},
              'contents': {name: value.hex() for name, value in contents.items()},
              'missing': str(fixture / 'missing.txt')}
    for name in ('target', 'source_control'):
        path = Path(config['paths'][name]); path.write_bytes(contents[name]); path.chmod(0o600)
    client = RootClient(helper, subject); held = {}; setup_attempted = False; controls_attempted = False
    receipt = {'runner_revision': 2, 'checkpoint': 21, 'config': config,
               'observations': {}, 'feature_controls_attempted': False, 'cleanup_complete': False}
    status = 'FAIL'; problem = None; cleanup_problem = None; problems = []
    try:
        state = client.call('state', config)
        config['original_rules'] = state['rules']; receipt['original_state'] = state
        print('Saved original redirect rules: ' + str(len(state['rules'])), flush=True)
        setup_attempted = True
        setup = client.call('setup', config)
        config['device_owned'] = setup['owned']; receipt['setup'] = setup
        if not setup['available']: raise FixtureBlocked('Owned /dev fixture unavailable: ' + str(setup['error']))
        labels = setup.get('labels', {})
        if set(labels) != {'directory', 'destination', 'destination_control'} or not all(
                value.get('verified') is True and value.get('bytes', 0) > 0 for value in labels.values()):
            raise FixtureBlocked('Owned fixture label verification receipt incomplete')
        print('FIXTURE LABELS: ' + json.dumps(labels, separators=(',', ':')), flush=True)
        # No feature write occurs until ordinary app access and a distinct-FS challenge pass.
        try:
            for name, path in config['paths'].items():
                fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC)
                try:
                    if os.pread(fd, 64, 0).hex() != config['contents'][name]:
                        raise RuntimeError('Fixture content mismatch: ' + name)
                finally:
                    os.close(fd)
            metadata = client.call('metadata', config); config.update(metadata)
            for name in ('target_before', 'source_control', 'destination_control'):
                path_name = 'target' if name == 'target_before' else name
                held[name] = os.open(config['paths'][path_name], os.O_RDONLY | os.O_CLOEXEC)
            pair = observe_pair(client, config, held, 'BASELINE')
            receipt['observations']['baseline'] = pair
            references = baseline_references(config, pair)
        except RootCommandUnknown:
            raise
        except (OSError, RuntimeError) as error:
            raise FixtureBlocked(str(error)) from error
        controls_attempted = True; receipt['feature_controls_attempted'] = True
        problems = run_cycles(client, config, held, references, receipt)
        if problems: raise RuntimeError('; '.join(problems))
        final = client.call('state', config)
        if final['rules'] != config['original_rules']: raise RuntimeError('Final rule table not restored')
        receipt['final_state'] = final
        print('FINAL REDIRECT DIAGNOSTICS: ' + final['diagnostics'], flush=True)
        status = 'PASS'
    except FixtureBlocked as error:
        status = 'BLOCKED'; problem = str(error)
    except (Exception, KeyboardInterrupt) as error:
        status = 'FAIL'; problem = '%s: %s' % (type(error).__name__, error)
    finally:
        for fd in held.values(): os.close(fd)
        held.clear()
        if not client.unknown:
            try:
                if controls_attempted: receipt['restored_state'] = restore_rules(client, config)
                if setup_attempted and 'device_owned' not in config:
                    raise RuntimeError('Setup ownership receipt unavailable; device fixture retained')
                if setup_attempted: receipt['device_cleanup'] = client.call('cleanup', config)
                receipt['cleanup_complete'] = True
            except (Exception, KeyboardInterrupt) as error:
                cleanup_problem = '%s: %s' % (type(error).__name__, error)
        else:
            cleanup_problem = 'Root outcome unknown; no further root/control commands sent. Fixtures retained.'
        if cleanup_problem: status = 'FAIL'
        receipt.update(result=status, error=problem, cleanup_error=cleanup_problem, root_outcome_unknown=client.unknown)
        (fixture / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    if cleanup_problem:
        status = 'FAIL'; print('CLEANUP UNQUALIFIED: ' + cleanup_problem, flush=True)
    elif status == 'PASS':
        try:
            source_cleanup(config, helper)
            print('Cleanup complete; descriptors closed, owned rule list restored, fixture names removed.', flush=True)
        except Exception as error:
            status = 'FAIL'; problem = str(error)
            receipt.update(result='FAIL', error=problem, cleanup_complete=False)
            if fixture.is_dir(): (fixture / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    if status != 'PASS':
        print('RETAINED EVIDENCE: ' + str(fixture), flush=True)
        print('Device fixture path: ' + device_directory, flush=True)
        print(status + ': ' + (problem or cleanup_problem or 'No complete filesystem qualification'), flush=True)
        print('Feature controls attempted: ' + str(controls_attempted), flush=True)
        return 2 if status == 'BLOCKED' else 1
    print('PASS: native statfs/fstatfs stable fields across distinct filesystems, redirected content, '
          'held/fresh and proc-fd views, root/control/error preservation, two cycles, exact rule restoration and cleanup.', flush=True)
    print('Scope: native AArch64 proc scheme 3 and owned stable files. Free-space/file counts are recorded but '
          'not compared exactly. Compat, supercalls, other UID schemes, redirect maps identity, concurrency, '
          'unloading and long-run stability remain unqualified.', flush=True)
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (Exception, KeyboardInterrupt) as error:
        print('FAIL: %s: %s' % (type(error).__name__, error), flush=True)
        raise SystemExit(1)
