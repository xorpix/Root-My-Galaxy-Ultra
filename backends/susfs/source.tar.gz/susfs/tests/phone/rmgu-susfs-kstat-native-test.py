#!/usr/bin/env python3
"""CP20 native metadata qualification. Run from ordinary Termux.

Uses only an owned inode/size rule. Native syscall results, rather than rewrite
counters alone, decide success. Load the CP20 module after rebooting first.
"""
import ctypes as ct
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import signal
import struct
import subprocess
import sys
import tempfile

KERNEL = '6.12.69-android16-6-pb4d3caf-abogkiS948BXXS4BZIG-4k'
CONTROL = '/proc/susfs_kstat'
MAP_STATS = '/sys/module/susfs_guard_lkm/parameters/map_stat'
STATX_DIAGNOSTIC = 'statx: checkpoint=20 device_pair=1 dev_bits=32 time_bits=64'
ROOT_TIMEOUT = 30


class RootCommandUnknown(RuntimeError):
    """A timed-out/interrupted root command may still be blocked in the kernel."""


def root(command):
    with tempfile.TemporaryFile(mode='w+t') as output, tempfile.TemporaryFile(mode='w+t') as error:
        proc = subprocess.Popen(['su', '-c', command], stdin=subprocess.DEVNULL,
                                stdout=output, stderr=error, text=True, start_new_session=True)
        try:
            proc.wait(timeout=ROOT_TIMEOUT)
        except (subprocess.TimeoutExpired, KeyboardInterrupt) as problem:
            try:
                proc.kill()
            except (ProcessLookupError, PermissionError):
                pass
            try:
                proc.wait(timeout=1)
            except subprocess.TimeoutExpired:
                pass
            raise RootCommandUnknown('Root command outcome unknown; no further control commands will be sent.') from problem
        output.seek(0)
        error.seek(0)
        if proc.returncode:
            raise RuntimeError('Root command failed (%d): %s' % (proc.returncode, error.read().strip()))
        return output.read()


COMMON = r'''
import ctypes as ct
import json
import os
import struct
import sys

NUMBERS = {'aarch64': {'fstat': 80, 'newfstatat': 79, 'statx': 291},
           'x86_64': {'fstat': 5, 'newfstatat': 262, 'statx': 332}}


def decode_stat(data, architecture):
    if architecture == 'aarch64':
        if len(data) != 128: raise RuntimeError('Invalid AArch64 stat size')
        result = {'dev': struct.unpack_from('<Q', data, 0)[0],
                  'ino': struct.unpack_from('<Q', data, 8)[0],
                  'mode': struct.unpack_from('<I', data, 16)[0],
                  'nlink': struct.unpack_from('<I', data, 20)[0],
                  'uid': struct.unpack_from('<I', data, 24)[0],
                  'gid': struct.unpack_from('<I', data, 28)[0],
                  'rdev': struct.unpack_from('<Q', data, 32)[0],
                  'size': struct.unpack_from('<q', data, 48)[0],
                  'blksize': struct.unpack_from('<i', data, 56)[0],
                  'blocks': struct.unpack_from('<q', data, 64)[0]}
        time_start = 72
    elif architecture == 'x86_64':
        if len(data) != 144: raise RuntimeError('Invalid x86_64 stat size')
        result = {'dev': struct.unpack_from('<Q', data, 0)[0],
                  'ino': struct.unpack_from('<Q', data, 8)[0],
                  'nlink': struct.unpack_from('<Q', data, 16)[0],
                  'mode': struct.unpack_from('<I', data, 24)[0],
                  'uid': struct.unpack_from('<I', data, 28)[0],
                  'gid': struct.unpack_from('<I', data, 32)[0],
                  'rdev': struct.unpack_from('<Q', data, 40)[0],
                  'size': struct.unpack_from('<q', data, 48)[0],
                  'blksize': struct.unpack_from('<q', data, 56)[0],
                  'blocks': struct.unpack_from('<q', data, 64)[0]}
        time_start = 72
    else:
        raise RuntimeError('Unsupported stat architecture')
    for index, name in enumerate(('atime_ns', 'mtime_ns', 'ctime_ns')):
        seconds, nanos = struct.unpack_from('<qQ', data, time_start + 16 * index)
        result[name] = seconds * 1000000000 + nanos
    return result


def decode_statx(data):
    if len(data) != 256: raise RuntimeError('Invalid statx buffer size')
    result = {'mask': struct.unpack_from('<I', data, 0)[0],
              'blksize': struct.unpack_from('<I', data, 4)[0],
              'attributes': struct.unpack_from('<Q', data, 8)[0],
              'nlink': struct.unpack_from('<I', data, 16)[0],
              'uid': struct.unpack_from('<I', data, 20)[0],
              'gid': struct.unpack_from('<I', data, 24)[0],
              'mode': struct.unpack_from('<H', data, 28)[0],
              'ino': struct.unpack_from('<Q', data, 32)[0],
              'size': struct.unpack_from('<Q', data, 40)[0],
              'blocks': struct.unpack_from('<Q', data, 48)[0],
              'attributes_mask': struct.unpack_from('<Q', data, 56)[0],
              'rdev': os.makedev(*struct.unpack_from('<II', data, 128)),
              'dev': os.makedev(*struct.unpack_from('<II', data, 136)),
              'mnt_id': struct.unpack_from('<Q', data, 144)[0]}
    for name, offset in (('atime_ns', 64), ('btime_ns', 80), ('ctime_ns', 96), ('mtime_ns', 112)):
        seconds, nanos = struct.unpack_from('<qI', data, offset)
        result[name] = seconds * 1000000000 + nanos
    return result


class NativeStat:
    def __init__(self):
        self.architecture = os.uname().machine
        if self.architecture not in NUMBERS or sys.byteorder != 'little' or ct.sizeof(ct.c_void_p) != 8:
            raise RuntimeError('Unsupported native syscall ABI')
        self.numbers = NUMBERS[self.architecture]
        self.libc = ct.CDLL(None, use_errno=True)
        self.libc.syscall.restype = ct.c_long

    def call(self, operation, *arguments, mask=None):
        size = 256 if operation == 'statx' else (128 if self.architecture == 'aarch64' else 144)
        # Guards lie outside the ABI payload; no intentionally invalid user pointer.
        storage = ct.create_string_buffer(b'G' * 16 + b'\0' * size + b'G' * 16, size + 32)
        pointer = ct.c_void_p(ct.addressof(storage) + 16)
        ct.set_errno(0)
        call_arguments = list(arguments)
        if operation == 'newfstatat': call_arguments.insert(2, pointer)
        else: call_arguments.append(pointer)
        result = self.libc.syscall(ct.c_long(self.numbers[operation]), *call_arguments)
        if storage.raw[:16] != b'G' * 16 or storage.raw[-16:] != b'G' * 16:
            raise RuntimeError('Native stat buffer guard changed')
        value = {'errno': ct.get_errno() if result < 0 else 0, 'returncode': int(result),
                 'nr': self.numbers[operation], 'buffer_guards': True}
        if mask is not None: value['requested_mask'] = mask
        if result == 0:
            data = storage.raw[16:16 + size]
            value['fields'] = decode_statx(data) if operation == 'statx' else decode_stat(data, self.architecture)
        return value

    def fstat(self, fd):
        return self.call('fstat', ct.c_int(fd))

    def at(self, path, fd=-100, flags=0):
        return self.call('newfstatat', ct.c_int(fd), ct.c_char_p(os.fsencode(path)), ct.c_int(flags))

    def statx(self, path, fd=-100, flags=0, mask=0x7ff):
        return self.call('statx', ct.c_int(fd), ct.c_char_p(os.fsencode(path)), ct.c_int(flags), ct.c_uint(mask), mask=mask)


def os_fields(value):
    return {key: getattr(value, 'st_' + key) for key in
            ('dev', 'ino', 'mode', 'nlink', 'uid', 'gid', 'rdev', 'size', 'blksize', 'blocks',
             'atime_ns', 'mtime_ns', 'ctime_ns')}


def observe(paths, held, native=None):
    native = native or NativeStat()
    result = {'uid': os.geteuid(), 'architecture': native.architecture, 'files': {}, 'negative': {}}
    for name, path in paths.items():
        fresh = os.open(path, os.O_RDONLY | os.O_CLOEXEC)
        try:
            methods = {'fstat_held': native.fstat(held[name]),
                       'fstat_fresh': native.fstat(fresh),
                       'newfstatat_path': native.at(path),
                       'newfstatat_held_empty': native.at('', held[name], 0x1000),
                       'statx_path': native.statx(path),
                       'statx_held_empty': native.statx('', held[name], 0x1000),
                       'statx_inode_mask': native.statx(path, mask=0x100),
                       'statx_size_mask': native.statx(path, mask=0x200)}
            result['files'][name] = methods
        finally:
            os.close(fresh)
    result['negative'] = {'invalid_fstat': native.fstat(-1),
                          'invalid_empty_statx': native.statx('', -1, 0x1000),
                          'missing_path': native.at(str(paths['target']) + '.absent')}
    return result


def root_observe(paths):
    held = {name: os.open(path, os.O_RDONLY | os.O_CLOEXEC) for name, path in paths.items()}
    try: return observe(paths, held)
    finally:
        for fd in held.values(): os.close(fd)


if __name__ == '__main__':
    print(json.dumps(root_observe(json.loads(sys.argv[1])), separators=(',', ':')), flush=True)
'''
exec(COMMON.replace("if __name__ == '__main__':", "if False:"), globals())


def parse_control(text):
    lines = text.splitlines()
    try:
        boundary = next(index for index, line in enumerate(lines) if line.startswith('maps: armed='))
    except StopIteration:
        raise RuntimeError('Kstat control format is not recognized')
    # CP20 prints the statx diagnostic after the rules and before maps counters.
    # Consume this exact line separately; never ignore arbitrary non-rule lines.
    if (boundary == 0 or lines[boundary - 1] != STATX_DIAGNOSTIC or
            lines.count(STATX_DIAGNOSTIC) != 1):
        raise RuntimeError('CP20 kstat diagnostic boundary is not recognized')
    rules = lines[:boundary - 1]
    if rules == ['(empty)']:
        rules = []
    elif not rules or any(not re.fullmatch(r'/\S+ ino=\d+ dev=\d+ flags=0x[0-9a-f]+ \[.+\]', line) for line in rules):
        raise RuntimeError('Invalid kstat rule list')
    counters = {}
    for line in lines[boundary:]:
        match = re.match(r'stat nr (\S+)\s+\((\d+)\): (.+)', line)
        if match:
            counters[int(match[2])] = {key: int(number) for key, number in re.findall(r'(\w+)=(\d+)', match[3])}
    if not {79, 80, 291}.issubset(counters): raise RuntimeError('Native kstat counters unavailable')
    return rules, counters


def command(operation, path, inode=None, size=None):
    path = str(path)
    if any(char.isspace() for char in path) or len(os.fsencode(path)) >= 256:
        raise RuntimeError('Owned path is not compatible with the kstat control ABI')
    if operation == 'del': return 'del ' + path
    if operation != 'add': raise RuntimeError('Unknown rule operation')
    values = [str(inode), 'default', 'default', str(size)] + ['default'] * 8
    return 'add_sus_kstat_statically ' + path + ' ' + ' '.join(values)


def write_owned(operation, path, inode=None, size=None):
    print('WRITE ' + operation.upper() + ' owned kstat rule', flush=True)
    root("printf '%s\\n' " + shlex.quote(command(operation, path, inode, size)) + ' > ' + CONTROL)
    print('WRITE ' + operation.upper() + ' returned', flush=True)


def verify_owned(rules, original, target, real, inode, size):
    prefix = str(target) + ' '
    mine = [line for line in rules if line.startswith(prefix)]
    if [line for line in rules if not line.startswith(prefix)] != original or len(mine) != 1:
        raise RuntimeError('Published kstat list does not contain only the owned addition')
    row = re.fullmatch(re.escape(str(target)) + r' ino=(\d+) dev=(\d+) flags=0x([0-9a-f]+) \[ino=(\d+) dev=\d+ nlink=\d+ size=(-?\d+) .+\]', mine[0])
    if not row or tuple(map(int, (row[1], row[2], row[4], row[5]))) != (real['ino'], real['dev'], inode, size) or int(row[3], 16) != 0x9:
        raise RuntimeError('Published owned inode/size rule differs from the requested values')


def assess(baseline, now, expected, label):
    failures = []
    if now['uid'] != baseline['uid'] or now['architecture'] != baseline['architecture']:
        failures.append(label + ' reader identity/ABI changed')
    for name, methods in baseline['files'].items():
        for method, prior in methods.items():
            current = now['files'][name][method]
            if prior['errno'] or current['errno'] or current['returncode'] != 0:
                failures.append(label + ' ' + name + ' ' + method + ' failed: errno=' + str(current['errno']))
                continue
            want = dict(prior['fields'])
            if name == 'target' and expected:
                effective = current.get('requested_mask', 0) | want.get('mask', 0)
                if 'mask' not in want or effective & 0x100: want['ino'] = expected['ino']
                if 'mask' not in want or effective & 0x200: want['size'] = expected['size']
            for field, value in want.items():
                # Values not advertised by statx are not asserted as native metadata.
                mask = {'mode': 0x3, 'nlink': 4, 'uid': 8, 'gid': 16, 'atime_ns': 32,
                        'mtime_ns': 64, 'ctime_ns': 128, 'ino': 256, 'size': 512,
                        'blocks': 1024, 'btime_ns': 2048, 'mnt_id': 4096}.get(field)
                if 'mask' in want and mask is not None and not (want['mask'] & mask): continue
                if current['fields'].get(field) != value:
                    failures.append(label + ' ' + name + ' ' + method + ' ' + field + ': expected ' + str(value) + ', got ' + str(current['fields'].get(field)))
    for method, prior in baseline['negative'].items():
        if now['negative'][method]['errno'] != prior['errno'] or now['negative'][method]['returncode'] != -1:
            failures.append(label + ' native error contract changed: ' + method)
    return failures


def require_baseline(app, privileged, real):
    if app['uid'] < 10000 or privileged['uid'] != 0: raise RuntimeError('Wrong app/root reader UID')
    for reader, snapshot in (('app', app), ('root', privileged)):
        for name, methods in snapshot['files'].items():
            for method, value in methods.items():
                if value['errno'] or value['returncode'] != 0:
                    raise RuntimeError(reader + ' baseline ' + method + ' unavailable; no rules changed')
                if method == 'statx_path' and value['fields']['mask'] & 0x300 != 0x300:
                    raise RuntimeError('Statx inode/size fields missing; no rules changed')
                for field, expected in real[name].items():
                    if 'mask' in value['fields'] and field in ('atime_ns', 'mtime_ns', 'ctime_ns'):
                        bit = {'atime_ns': 32, 'mtime_ns': 64, 'ctime_ns': 128}[field]
                        if not value['fields']['mask'] & bit: continue
                    if value['fields'].get(field) != expected:
                        raise RuntimeError(reader + ' native baseline ' + method + ' disagrees with real ' + field)
        errors = {name: value['errno'] for name, value in snapshot['negative'].items()}
        if errors != {'invalid_fstat': 9, 'invalid_empty_statx': 9, 'missing_path': 2}:
            raise RuntimeError('Native baseline errors unexpected; no rules changed')


def brief(label, app, privileged):
    values = {}
    for reader, snapshot in (('app', app), ('root', privileged)):
        values[reader] = {name: {method: [row.get('fields', {}).get('ino'), row.get('fields', {}).get('size'), row['errno']]
                                 for method, row in methods.items()} for name, methods in snapshot['files'].items()}
    print(label + ': ' + json.dumps(values, separators=(',', ':')), flush=True)


def run_fixture(original):
    fixture = Path(tempfile.mkdtemp(prefix='rmgu-susfs-kstat-native.', dir=os.getcwd()))
    fixture.chmod(0o700)
    paths = {name: fixture / (name + '.txt') for name in ('target', 'control')}
    held = {}; attempted = False; unknown = False; safe = True
    failures = []; records = []; target = paths['target']
    try:
        for name, path in paths.items():
            path.write_bytes(('RMGU native ' + name + '\n').encode()); path.chmod(0o600)
            held[name] = os.open(path, os.O_RDONLY | os.O_CLOEXEC)
        real = {name: os_fields(os.fstat(fd)) for name, fd in held.items()}
        helper = fixture / 'native-helper.py'; helper.write_text(COMMON); helper.chmod(0o600)
        (fixture / 'original-rules.json').write_text(json.dumps(original)); (fixture / 'original-rules.json').chmod(0o600)
        payload = json.dumps({name: str(path) for name, path in paths.items()})
        root_command = '/system/bin/toybox nsenter -t %d -m ' % os.getpid() + shlex.quote(sys.executable) + ' ' + shlex.quote(str(helper)) + ' ' + shlex.quote(payload)
        def snapshots(label):
            app = observe(paths, held)
            privileged = json.loads(root(root_command))
            if privileged['uid'] != 0: raise RuntimeError('Root reader is not UID 0')
            records.append({'phase': label, 'app': app, 'root': privileged})
            brief(label, app, privileged)
            return app, privileged
        baseline, root_baseline = snapshots('BASELINE')
        require_baseline(baseline, root_baseline, real)
        for cycle in (1, 2):
            chosen = {'ino': real['target']['ino'] + 100000000 + cycle, 'size': real['target']['size'] + 4096 * cycle}
            print('ENABLE %d expected app: %s' % (cycle, json.dumps(chosen)), flush=True)
            attempted = True
            write_owned('add', target, chosen['ino'], chosen['size'])
            rules, counters = parse_control(root('cat ' + CONTROL))
            verify_owned(rules, original, target, real['target'], chosen['ino'], chosen['size'])
            app, privileged = snapshots('ACTIVE ' + str(cycle))
            failures.extend(assess(baseline, app, chosen, 'ACTIVE ' + str(cycle) + ' APP'))
            failures.extend(assess(root_baseline, privileged, None, 'ACTIVE ' + str(cycle) + ' ROOT'))
            print('DISABLE %d' % cycle, flush=True)
            write_owned('del', target)
            rules, restored_counters = parse_control(root('cat ' + CONTROL))
            if rules != original: raise RuntimeError('Exact original kstat rule list not restored')
            attempted = False
            app, privileged = snapshots('RESTORED ' + str(cycle))
            failures.extend(assess(baseline, app, None, 'RESTORED ' + str(cycle) + ' APP'))
            failures.extend(assess(root_baseline, privileged, None, 'RESTORED ' + str(cycle) + ' ROOT'))
        print('NATIVE COUNTERS (diagnostic):\n' + root('cat ' + CONTROL), flush=True)
    except RootCommandUnknown:
        unknown = True
        raise
    finally:
        if unknown:
            safe = False
        if attempted:
            if unknown:
                safe = False; print('Root outcome unknown; further rule commands skipped.', flush=True)
            else:
                try:
                    current, _ = parse_control(root('cat ' + CONTROL))
                    if any(line.startswith(str(target) + ' ') for line in current): write_owned('del', target)
                    if parse_control(root('cat ' + CONTROL))[0] != original:
                        raise RuntimeError('Original kstat rules differ')
                except BaseException as problem:
                    safe = False; print('Rule restoration unverified: ' + str(problem), flush=True)
        for fd in held.values(): os.close(fd)
        if safe:
            shutil.rmtree(fixture)
            print('Cleanup complete; held descriptors closed, owned rule and fixture removed, exact original list verified.', flush=True)
        else:
            (fixture / 'observations.json').write_text(json.dumps({'records': records, 'failures': failures}, indent=2))
            (fixture / 'observations.json').chmod(0o600)
            print('RETAINED FIXTURE: ' + str(fixture), flush=True)
        if not safe: failures.append('Cleanup unqualified')
    if failures: raise RuntimeError('; '.join(dict.fromkeys(failures)))
    print('PASS: native fstat held/fresh, newfstatat path/empty-path, statx path/held/masks, root exclusion, control/error preservation, two cycles, exact restoration and cleanup.', flush=True)
    print('Scope: inode/size fields on native AArch64; compat ABI, other spoof fields, maps identity and redirect statfs remain unqualified.', flush=True)


def main():
    print('Native kstat runner revision: 3 (CP20 rule/diagnostic separation and held descriptors)', flush=True)
    if os.geteuid() < 10000: raise RuntimeError('Run in ordinary Termux, outside a root shell')
    if os.uname().machine != 'aarch64' or os.uname().release != KERNEL:
        raise RuntimeError('This runner targets the pinned SM-S948B BZIG ARM64 kernel')
    print('App reader:', subprocess.check_output(['id'], text=True).strip(), flush=True)
    diagnostics = root('cat ' + MAP_STATS)
    if not re.search(r'^map_metadata: checkpoint=19 ready=[01]\b', diagnostics, re.M):
        raise RuntimeError('Required map metadata guards unavailable; no controls changed')
    kstat_text = root('cat ' + CONTROL)
    if STATX_DIAGNOSTIC not in kstat_text.splitlines():
        raise RuntimeError('CP20 statx correction unavailable; no controls changed')
    original, _ = parse_control(kstat_text)
    if len(original) >= 32: raise RuntimeError('Kstat rule table full; no controls changed')
    print('Saved original kstat rules: ' + str(len(original)), flush=True)
    run_fixture(original)


if __name__ == '__main__':
    def interrupted(signum, frame): raise KeyboardInterrupt('signal ' + str(signum))
    signal.signal(signal.SIGINT, interrupted); signal.signal(signal.SIGTERM, interrupted)
    try: main()
    except (Exception, KeyboardInterrupt) as error:
        print('\nFAIL: ' + str(error), flush=True); sys.exit(1)
