#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0
"""Copy existing CP22 crash evidence. No SusFS controls or reproducer are run."""
import argparse
import base64
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import stat
import subprocess
import sys
import tempfile
import zipfile

FILE_CAP = 2 * 1024 * 1024
TOTAL_CAP = 32 * 1024 * 1024
PROBE_TIMEOUT = 20

# The optional privileged process accepts no filenames or feature commands.
# It streams each completed read so a timeout still preserves earlier evidence.
ENVIRONMENT_CODE = r'''
import base64, json, os, stat, subprocess, tempfile
from pathlib import Path
limit = 2 * 1024 * 1024
remaining = 16 * 1024 * 1024
def emit(record): print(json.dumps(record, separators=(',', ':')), flush=True)
def read_file(path):
    global remaining
    record = {'kind': 'file', 'path': str(path)}
    fd = None
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode):
            raise ValueError('Not a regular file')
        cap = min(limit, remaining)
        if cap <= 0:
            raise ValueError('Total collection limit reached')
        chunks = []; count = 0
        while count < cap + 1:
            part = os.read(fd, min(65536, cap + 1 - count))
            if not part: break
            chunks.append(part); count += len(part)
        data = b''.join(chunks)
        record.update(errno=0, bytes=min(len(data), cap), truncated=len(data)>cap,
                      mtime_ns=info.st_mtime_ns,
                      data_b64=base64.b64encode(data[:cap]).decode())
        remaining -= min(len(data), cap)
    except Exception as error:
        record.update(errno=getattr(error, 'errno', None), error=str(error))
    finally:
        if fd is not None: os.close(fd)
    emit(record)
def command(argv, label):
    record = {'kind': 'command', 'name': label, 'argv': argv}
    with tempfile.TemporaryFile() as output:
        try:
            child = subprocess.run(argv, stdout=output, stderr=subprocess.STDOUT,
                                   timeout=4, check=False)
            record['exit_code'] = child.returncode
        except Exception as error:
            record['error'] = str(error)
        output.seek(0); data = output.read(limit + 1)
    record.update(bytes=min(len(data),limit), truncated=len(data)>limit,
                  data_b64=base64.b64encode(data[:limit]).decode())
    emit(record)
emit({'kind':'identity', 'uid':os.geteuid(), 'pid':os.getpid()})
for name in ('/proc/sys/kernel/random/boot_id', '/proc/uptime', '/proc/version',
             '/proc/self/attr/current', '/proc/last_kmsg', '/proc/config.gz'):
    read_file(name)
try:
    directory = Path('/sys/fs/pstore')
    if directory.is_symlink(): raise ValueError('Pstore directory is a symlink')
    names = sorted(os.listdir(directory))
    emit({'kind':'directory', 'path':str(directory), 'entries':names,
          'limited':len(names)>32})
    for name in names[:32]: read_file(directory / name)
except Exception as error:
    emit({'kind':'directory', 'path':'/sys/fs/pstore',
          'errno':getattr(error,'errno',None), 'error':str(error)})
for prop in ('ro.boot.bootreason', 'sys.boot.reason', 'persist.sys.boot.reason'):
    command(['/system/bin/getprop', prop], 'getprop-' + prop)
command(['/system/bin/dmesg'], 'current-boot-dmesg')
'''


def read_regular(path, cap):
    """Read an owned evidence file without following symlinks or opening pipes."""
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode):
            raise ValueError('Not a regular evidence file')
        chunks = []
        count = 0
        while count < cap + 1:
            part = os.read(fd, min(65536, cap + 1 - count))
            if not part:
                break
            chunks.append(part)
            count += len(part)
        data = b''.join(chunks)
        return data[:cap], len(data) > cap, info
    finally:
        os.close(fd)


def probe(privileged=False):
    argv = [sys.executable, '-I', '-u', '-c', ENVIRONMENT_CODE]
    if privileged:
        argv = ['su', '-c', shlex.join(argv)]
    result = {'privileged_requested': privileged, 'records': []}
    with tempfile.TemporaryFile() as output:
        try:
            child = subprocess.Popen(argv, stdout=output, stderr=subprocess.STDOUT)
            try:
                result['exit_code'] = child.wait(timeout=PROBE_TIMEOUT)
            except subprocess.TimeoutExpired:
                result['timed_out'] = True
                child.kill()
                try:
                    child.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    result['termination_unconfirmed'] = True
        except OSError as error:
            result['error'] = str(error)
        output.seek(0)
        raw = output.read(TOTAL_CAP + 1)
    result['output_truncated'] = len(raw) > TOTAL_CAP
    for line in raw[:TOTAL_CAP].splitlines():
        try:
            record = json.loads(line)
            if not isinstance(record, dict):
                raise ValueError('Non-object reply')
            result['records'].append(record)
        except (ValueError, UnicodeError):
            result.setdefault('helper_messages', []).append(line.decode(errors='replace')[:4000])
    return result


def retained_files(home):
    entries = sorted(home.iterdir(), key=lambda p: p.lstat().st_mtime_ns, reverse=True)
    logs = [p for p in entries if p.name.startswith('rmgu-cp22-root-') and not p.is_symlink()][:16]
    fixtures = [p / 'fixture.json' for p in entries
                if p.name.startswith('rmgu-susfs-native-control.') and
                not p.is_symlink() and p.is_dir()][:8]
    return logs + fixtures


def collect(home, include_root=False):
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    directory = Path(tempfile.mkdtemp(prefix='rmgu-cp22-crash-' + stamp + '-', dir=home))
    os.chmod(directory, 0o700)
    archive_path = directory / 'rmgu-cp22-crash-evidence.zip'
    manifest = {'collector_revision': 1, 'collected_utc': stamp, 'reader_uid': os.geteuid(),
                'kind': 'Existing evidence only; not a feature test or crash reproduction',
                'kernel_controls_attempted': False, 'root_requested': include_root,
                'files': [], 'probes': [], 'limitations': [
                    'Access denial or an empty pstore does not disprove the reported crash.',
                    'dmesg describes the current boot, not necessarily the crashed boot.',
                    'No test rule, fixture, helper log or persistent crash record is removed.']}
    remaining = TOTAL_CAP
    with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for index, path in enumerate(retained_files(home)):
            entry = {'source': str(path)}
            try:
                if remaining <= 0:
                    raise ValueError('Total evidence limit reached')
                data, truncated, info = read_regular(path, min(FILE_CAP, remaining))
                name = 'retained/%02d-%s' % (index, path.name)
                archive.writestr(name, data)
                remaining -= len(data)
                entry.update(archive=name, bytes=len(data), truncated=truncated,
                             mtime_ns=info.st_mtime_ns, sha256=hashlib.sha256(data).hexdigest())
            except Exception as error:
                entry.update(errno=getattr(error, 'errno', None), error=str(error))
            manifest['files'].append(entry)
        for privileged in ([False, True] if include_root else [False]):
            print('Reading existing ' + ('root' if privileged else 'app') + ' crash evidence...', flush=True)
            result = probe(privileged)
            group = 'root' if privileged else 'app'
            for index, record in enumerate(result['records']):
                blob = record.pop('data_b64', None)
                if blob is None:
                    continue
                try:
                    data = base64.b64decode(blob, validate=True)
                    if len(data) > remaining:
                        raise ValueError('Total evidence limit reached')
                    name = group + '/%02d.bin' % index
                    archive.writestr(name, data)
                    remaining -= len(data)
                    record.update(archive=name, sha256=hashlib.sha256(data).hexdigest())
                except ValueError as error:
                    record['archive_error'] = str(error)
            manifest['probes'].append(result)
        archive.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
    os.chmod(archive_path, 0o600)
    downloads = Path('/sdcard/Download')
    delivered = archive_path
    try:
        target = downloads / (directory.name + '.zip')
        with target.open('xb') as output, archive_path.open('rb') as source:
            shutil.copyfileobj(source, output)
        delivered = target
    except OSError:
        pass
    print('EVIDENCE ZIP:', delivered, flush=True)
    print('Original evidence retained. No SusFS controls, module loading, cleanup or reboot performed.', flush=True)
    return archive_path, manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', action='store_true',
                        help='Also try existing su once; do not activate SusFS or root the phone to use this option.')
    args = parser.parse_args()
    collect(Path.home(), args.root)


if __name__ == '__main__':
    main()
