#!/usr/bin/env python3
"""Build a standalone phone runner from qualified common support and observers."""
import ast
from pathlib import Path


def build():
    directory = Path(__file__).resolve().parent
    source = (directory / 'rmgu-susfs-kstat-fields-test.py').read_text()
    tree = ast.parse(source)
    definitions = {node.name: ast.get_source_segment(source, node) for node in tree.body
                   if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
    common = next(ast.literal_eval(node.value) for node in tree.body if isinstance(node, ast.Assign)
                  and any(isinstance(target, ast.Name) and target.id == 'COMMON' for target in node.targets))
    common = common.replace("if __name__ == '__main__':", 'if False:')
    head = '''#!/usr/bin/env python3
"""CP21 owned kstat inode/device identity in maps and smaps.

Run from ordinary Termux with the CP21 module. Only the newly created
fixture path is added/deleted. No mapping-hide rule, global clear or unload.
"""
import ctypes as ct
import json
import mmap
import os
from pathlib import Path
import re
import shlex
import shutil
import signal
import subprocess
import sys
import tempfile

KERNEL = '6.12.69-android16-6-pb4d3caf-abogkiS948BXXS4BZIG-4k'
CONTROL = '/proc/susfs_kstat'
STATX_DIAGNOSTIC = 'statx: checkpoint=20 device_pair=1 dev_bits=32 time_bits=64'
ROOT_TIMEOUT = 30
OVERRIDE_FIELDS = ('ino', 'dev', 'nlink', 'size', 'atime_sec', 'atime_nsec',
                   'mtime_sec', 'mtime_nsec', 'ctime_sec', 'ctime_nsec', 'blocks', 'blksize')

'''
    result = head + '\n\n'.join(definitions[name] for name in
                                ('RootCommandUnknown', 'root', 'parse_control', 'command',
                                 'write_owned', 'components', 'profile_flags', 'verify_owned'))
    result += "\n\nCOMMON = r'''" + common + "'''\n"
    observer = (directory / 'kstat_maps_observer.py').read_text()
    result += "OBSERVER = r'''\n" + observer + "'''\n"
    result += "SHARED = COMMON + '\\n' + OBSERVER\nexec(SHARED, globals())\n\n"
    result += (directory / 'kstat_maps_workflow.py').read_text()
    return result


if __name__ == '__main__':
    (Path(__file__).with_name('rmgu-susfs-kstat-maps-test.py')).write_text(build())
