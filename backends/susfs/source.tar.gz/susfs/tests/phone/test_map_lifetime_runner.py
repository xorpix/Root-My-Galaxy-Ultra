#!/usr/bin/env python3
"""Actual Linux worker lifetime tests plus modeled hidden/denial assertions."""
import copy
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from types import SimpleNamespace
from unittest import mock

spec=importlib.util.spec_from_file_location('lifetime_runner',Path(__file__).with_name('rmgu-susfs-map-lifetime-test.py'))
r=importlib.util.module_from_spec(spec); spec.loader.exec_module(r)

def visible():
    methods={'lstat':{'errno':0,'mode':0o120600,'ino':999,'dev':21},
             'opath_nofollow':{'errno':0,'mode':0o120600,'ino':999,'dev':21},
             'stat_follow':{'errno':1},'open_follow':{'errno':1}}
    result={'reader_uid':10362,'identity':{'pid':100,'starttime':200,'uids':[10362]*4},
            'access_errno':{k:0 for k in ('maps','smaps','listdir','getdents64')},
            'duplicate_names':0,'duplicate_cookies':0,'items':{}}
    for name,ino,kind in (('alias',101,'target'),('control',102,'control')):
        result['items'][name]={'range':'1000-2000','kind':kind,'ino':ino,'dev':22,'expected_hex':'aa'*16,
                              'maps_rows':1,'smaps_rows':1,'listing_rows':1,'small_rows':1,
                              'metadata':copy.deepcopy(methods),'readlink':{'errno':0,'value':'/fixture','identity_errno':0,'ino':ino,'dev':22},
                              'pagemap':{'errno':0,'bytes':8,'present':True,'metadata':'0xa100000000000000'},
                              'mem':{'errno':0,'bytes':16,'hex':'aa'*16},
                              'process_vm_readv':{'errno':0,'bytes':16,'hex':'aa'*16}}
    return result

def hidden():
    result=visible(); item=result['items']['alias']
    for k in ('maps_rows','smaps_rows','listing_rows','small_rows'): item[k]=0
    item['metadata']={k:{'errno':2} for k in item['metadata']}
    item['readlink']={'errno':2,'value':''}
    item['pagemap']={'errno':0,'bytes':0,'present':False,'metadata':'0x0'}
    item['mem']={'errno':5,'bytes':-1,'hex':''}
    item['process_vm_readv']={'errno':14,'bytes':-1,'hex':''}
    return result

class AssertionTests(unittest.TestCase):
    def test_hidden_target_and_control_are_checked(self):
        issues,blocked=r.assessment(visible(),hidden(),True,'HIDDEN')
        self.assertEqual([],issues); self.assertTrue(blocked)

    def test_accessible_lstat_leak_fails(self):
        now=hidden(); now['items']['alias']['metadata']['lstat']=visible()['items']['alias']['metadata']['lstat']
        self.assertTrue(any('lstat' in x for x in r.assessment(visible(),now,True,'HIDDEN')[0]))

    def test_opaque_path_leak_fails_independently(self):
        now=hidden(); now['items']['alias']['metadata']['opath_nofollow']=visible()['items']['alias']['metadata']['opath_nofollow']
        self.assertTrue(any('opath_nofollow' in x for x in r.assessment(visible(),now,True,'HIDDEN')[0]))

    def test_same_address_control_reuse_must_stay_visible(self):
        before=visible(); now=visible(); now['items']['alias']['kind']='control'
        self.assertEqual([],r.assessment(before,now,True,'REUSE')[0])
        now['items']['alias']['metadata']['lstat']={'errno':2}
        self.assertTrue(r.assessment(before,now,True,'REUSE')[0])

    def test_control_memory_omission_fails(self):
        now=hidden(); now['items']['control']['mem']={'errno':5,'bytes':-1,'hex':''}
        self.assertTrue(any('control mem' in x for x in r.assessment(visible(),now,True,'HIDDEN')[0]))

    def test_wrong_readlink_identity_fails(self):
        now=visible(); now['items']['control']['readlink']['ino']=101
        self.assertTrue(any('readlink describes' in x for x in r.assessment(visible(),now,False,'VISIBLE')[0]))

    def test_wrong_followed_inode_fails(self):
        before=visible(); now=visible()
        for v in (before,now): v['items']['control']['metadata']['stat_follow']={'errno':0,'ino':102,'dev':22,'mode':0o100600}
        now['items']['control']['metadata']['stat_follow']['ino']=101
        self.assertTrue(any('wrong backing' in x for x in r.assessment(before,now,False,'VISIBLE')[0]))

    def test_blocked_cross_process_maps_stays_unqualified(self):
        before=visible(); now=hidden()
        for v in (before,now): v['access_errno']['maps']=13; v['items']['alias']['maps_rows']=None; v['items']['control']['maps_rows']=None
        issues,blocked=r.assessment(before,now,True,'PARENT')
        self.assertEqual([],issues); self.assertTrue(any('maps baseline errno=13' in x for x in blocked))

    def test_permission_blocked_control_cannot_change_errno(self):
        before=visible(); now=hidden(); now['items']['control']['metadata']['open_follow']={'errno':13}
        self.assertTrue(any('blocked visible baseline' in x for x in r.assessment(before,now,True,'HIDDEN')[0]))

    def test_pagemap_leak_fails(self):
        now=hidden(); now['items']['alias']['pagemap']=visible()['items']['alias']['pagemap']
        self.assertTrue(any('pagemap' in x for x in r.assessment(visible(),now,True,'HIDDEN')[0]))

    def test_restore_must_restore_access(self):
        self.assertTrue(r.assessment(visible(),hidden(),False,'RESTORED')[0])

    def test_root_exclusion_requires_target_to_stay_visible(self):
        self.assertTrue(r.assessment(visible(),hidden(),False,'ROOT')[0])

    def test_pid_reuse_is_rejected(self):
        expected=visible()['identity']; now=copy.deepcopy(expected); now['starttime']+=1
        with self.assertRaisesRegex(RuntimeError,'starttime'): r.same_worker(expected,now)

    def test_uid_change_is_rejected(self):
        expected=visible()['identity']; now=copy.deepcopy(expected); now['uids']=[0]*4
        with self.assertRaisesRegex(RuntimeError,'uids'): r.same_worker(expected,now)

    def test_context_change_is_rejected(self):
        expected=visible()['identity']; expected['context']={'errno':0,'value':'u:r:untrusted_app:s0'}
        now=copy.deepcopy(expected); now['context']['value']='u:r:ksu:s0'
        with self.assertRaisesRegex(RuntimeError,'context'): r.same_worker(expected,now)

    def test_optional_namespace_permission_denial_is_not_inferred_as_identity_change(self):
        expected=visible()['identity']; expected['mount_namespace']={'errno':0,'value':'mnt:[100]'}
        now=copy.deepcopy(expected); now['mount_namespace']={'errno':13,'value':None}
        r.same_worker(expected,now)

    def test_procfs_pid_mismatch_is_rejected(self):
        expected=visible()['identity']; expected['proc_pid']=999
        now=copy.deepcopy(expected); now['proc_pid']=1000
        with self.assertRaisesRegex(RuntimeError,'proc_pid'): r.same_worker(expected,now)

    def test_worker_self_metadata_baseline_must_be_accessible(self):
        now=visible(); now['items']['alias']['metadata']['lstat']={'errno':13}
        with self.assertRaisesRegex(RuntimeError,'no rules changed'): r.require_self_baseline(now)

    def test_vacant_rows_inspect_actual_file_backed_overlap(self):
        item={'kind':'vacant','address':0x1000,'size':0x1000}
        self.assertEqual(1,r.exact_rows('1000-2000 rw-p 00000000 00:16 101 /fixture\n',item))
        self.assertEqual(0,r.exact_rows('1000-5000 ---p 00000000 00:00 0\n',item))

class ActualWorkerTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='susfs-map-life-host-'); self.fixture=Path(self.temp.name)
        self.nonce='owned-host-fixture'; self.sequence=0; self.error=tempfile.TemporaryFile(mode='w+t')
        (self.fixture/'target.bin').write_bytes(b'T'*65536); (self.fixture/'control.bin').write_bytes(b'C'*65536)
        r.atomic_json(self.fixture/'owner.json',{'nonce':self.nonce})
        self.helper=self.fixture/'worker.py'; self.helper.write_text(r.COMMON+'\nif __name__=="__main__": helper_main()\n')
        self.proc=subprocess.Popen([sys.executable,str(self.helper),'worker',str(self.fixture),'0','0',self.nonce],
                                   stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=self.error,start_new_session=True)
        self.initial=r.wait_reply(self.proc,self.fixture,0,self.nonce,self.error)

    def tearDown(self):
        self.assertTrue(r.stop_worker(self.proc,self.fixture,self.sequence+1,self.nonce,self.error))
        self.error.close(); self.temp.cleanup()

    def command(self,op,pages=1):
        self.sequence+=1
        r.atomic_json(self.fixture/'request.json',{'nonce':self.nonce,'sequence':self.sequence,'operation':op,'pages':pages})
        return r.wait_reply(self.proc,self.fixture,self.sequence,self.nonce,self.error)

    def test_actual_baseline_observer_and_permission_scoping(self):
        own=self.initial['self']; r.require_self_baseline(own)
        self.assertEqual([],r.assessment(own,own,False,'HOST SELF')[0])
        parent=r.observe(self.proc.pid,self.initial['items'],'HOST PARENT',self.initial['identity']['proc_pid'])
        self.assertEqual([],r.assessment(parent,parent,False,'HOST PARENT')[0])
        if os.environ.get('SUSFS_LIFETIME_EVIDENCE'):
            Path(os.environ['SUSFS_LIFETIME_EVIDENCE']).write_text(json.dumps({'hardware_validated':False,
                'kind':'Actual Linux worker/observer; native host permission blocks retained','self':own,'parent':parent},indent=2)+'\n')

    def test_actual_address_reuse_changes_file_identity_and_direct_bytes(self):
        first=self.initial['items']['alias']; control=self.command('control')['items']['alias']; target=self.command('target')['items']['alias']
        self.assertEqual(first['address'],control['address']); self.assertEqual(first['address'],target['address'])
        self.assertNotEqual(first['ino'],control['ino']); self.assertEqual(first['ino'],target['ino'])
        self.assertEqual(b'C'*16,bytes.fromhex(control['direct_hex']))
        self.assertEqual(b'T'*16,bytes.fromhex(target['direct_hex']))

    def test_actual_vacancy_removes_range_without_dereferencing_prot_none(self):
        value=self.command('vacant'); item=value['self']['items']['alias']
        self.assertEqual('vacant',item['kind']); self.assertEqual(0,item['listing_rows'])
        self.assertEqual(2,item['metadata']['lstat']['errno']); self.assertIn('memory_skipped',item)

    def test_actual_different_lengths_reuse_same_owned_address(self):
        first=self.initial['items']['alias']; second=self.command('target',2)['items']['alias']
        self.assertEqual(first['address'],second['address']); self.assertEqual(first['size']*2,second['size'])

    def test_actual_exec_keeps_owned_pid_and_starttime(self):
        value=self.command('exec'); self.assertEqual(1,value['epoch'])
        r.same_worker(self.initial['identity'],value['identity'])
        self.assertEqual(self.proc.pid,value['identity']['pid'])
        self.assertEqual(0,value['self']['items']['alias']['metadata']['lstat']['errno'])
        cmdline=(Path('/proc')/str(value['identity']['proc_pid'])/'cmdline').read_bytes().split(b'\0')
        self.assertIn(b'1',cmdline)

    def test_real_reply_nonce_mismatch_is_rejected(self):
        with self.assertRaisesRegex(RuntimeError,'ownership'):
            r.wait_reply(self.proc,self.fixture,0,'wrong nonce',self.error)

    def test_failed_child_startup_returns_captured_error_without_hanging(self):
        bad=subprocess.Popen([sys.executable,'-c','raise RuntimeError("startup marker")'],stderr=self.error,stdout=subprocess.DEVNULL)
        with self.assertRaisesRegex(RuntimeError,'startup marker'):
            r.wait_reply(bad,self.fixture,999,self.nonce,self.error,timeout=2)
        bad.wait(timeout=2)

    def test_slot_rejects_out_of_reservation_length(self):
        slot=r.OwnedSlot(pages=1)
        try:
            with self.assertRaisesRegex(RuntimeError,'outside'): slot.replace(self.fixture/'target.bin',pages=2)
        finally: slot.close()

class WorkflowTests(unittest.TestCase):
    def run_workflow(self,mode='ok'):
        temp=tempfile.TemporaryDirectory(prefix='susfs-life-workflow-'); fixture=Path(temp.name)/'fixture'; fixture.mkdir()
        state={'active':False,'epoch':0,'kind':'target','pages':1,'ops':[],'rule_reads':0,'stop_calls':0}
        identity={'pid':100,'proc_pid':100,'starttime':200,'uids':[10362]*4}
        proc=SimpleNamespace(pid=100)
        diag='vm: pin_calls=0\nlisting: maps_calls=0\nmap_files: ready=1 route=kprobe divert_checked=1\nmap_metadata: checkpoint=19 ready=1\n'
        def items():
            values={}
            for name,kind,addr,pages in (('alias',state['kind'],0x10000,state['pages']),('control','control',0x50000,1)):
                if kind=='vacant':
                    values[name]={'kind':kind,'address':addr,'size':4096*pages,'ino':0,'major':0,'minor':0,'path':'','direct_hex':''}
                else:
                    path=fixture/(kind+'.bin'); v=os.stat(path)
                    values[name]={'kind':kind,'address':addr,'size':4096*pages,'ino':v.st_ino,
                                  'major':os.major(v.st_dev),'minor':os.minor(v.st_dev),'path':str(path),'direct_hex':path.read_bytes()[:16].hex()}
            return values
        def snapshot(known,reader):
            value=visible(); value['identity']=copy.deepcopy(identity); value['reader_uid']=0 if reader=='root' else 10362
            for name,known_item in known.items():
                row=value['items'][name]; row.update(kind=known_item['kind'],ino=known_item['ino'],
                    dev=os.makedev(known_item['major'],known_item['minor']),expected_hex=known_item['direct_hex'])
                row['readlink'].update(ino=row['ino'],dev=row['dev'])
                for method in ('mem','process_vm_readv'): row[method]['hex']=row['expected_hex']
                absent=known_item['kind']=='vacant' or (state['active'] and name=='alias' and known_item['kind']=='target' and reader!='root')
                if absent:
                    for k in ('maps_rows','smaps_rows','listing_rows','small_rows'): row[k]=0
                    row['metadata']={k:{'errno':2} for k in row['metadata']}; row['readlink']={'errno':2,'value':''}
                    if known_item['kind']=='vacant':
                        for k in ('pagemap','mem','process_vm_readv'): row.pop(k)
                    else:
                        row['pagemap']={'errno':0,'bytes':0,'present':False,'metadata':'0x0'}
                        row['mem']={'errno':5,'bytes':-1,'hex':''}; row['process_vm_readv']={'errno':14,'bytes':-1,'hex':''}
                    if mode=='leak' and known_item['kind']=='target' and reader=='self':
                        row['metadata']['lstat']={'errno':0,'mode':0o120600,'ino':999,'dev':21}
            return value
        def wait(proc_arg,fixture_arg,seq,nonce,error,timeout=10):
            if seq:
                request=r.read_json(fixture/'request.json'); op=request['operation']
                if op in ('target','control','vacant'): state['kind']=op; state['pages']=request['pages']
                if op=='exec': state['epoch']=1; state['kind']='target'; state['pages']=2
            known=items()
            return {'nonce':nonce,'sequence':seq,'identity':copy.deepcopy(identity),'epoch':state['epoch'],
                    'items':known,'self':snapshot(known,'self')}
        def rules():
            state['rule_reads']+=1
            if not state['active']: return []
            v=os.stat(fixture/'target.bin')
            return [(v.st_ino,(os.major(v.st_dev)<<20)|os.minor(v.st_dev))]
        def write(op,path):
            state['ops'].append(op)
            if op=='add' and mode=='timeout':
                state['active']=True; raise r.RootCommandTimeout('unknown ADD outcome')
            if op=='add' and mode=='returned_error': raise RuntimeError('ADD returned failure')
            state['active']=op=='add'
        def root(command,progress=False):
            if command=='cat '+r.STATS: return diag
            payload=json.loads(r.base64.b64decode(r.shlex.split(command)[-1]))
            return json.dumps(snapshot(payload['items'],'root'))
        def stop(*args): state['stop_calls']+=1; return mode!='unreaped'
        out=io.StringIO(); failure=None
        try:
            with mock.patch.object(r.os,'geteuid',return_value=10362), \
                 mock.patch.object(r.os,'uname',return_value=SimpleNamespace(machine='aarch64',release=r.KERNEL)), \
                 mock.patch.object(r.subprocess,'check_output',return_value='uid=10362'), \
                 mock.patch.object(r.subprocess,'Popen',return_value=proc), \
                 mock.patch.object(r.tempfile,'mkdtemp',return_value=str(fixture)), \
                 mock.patch.object(r,'read_rules',side_effect=rules), \
                 mock.patch.object(r,'write_rule',side_effect=write), \
                 mock.patch.object(r,'root',side_effect=root), \
                 mock.patch.object(r,'observe',side_effect=lambda pid,known,label,proc_pid=None:snapshot(known,'parent')), \
                 mock.patch.object(r,'process_identity',return_value=identity), \
                 mock.patch.object(r,'wait_reply',side_effect=wait), \
                 mock.patch.object(r,'stop_worker',side_effect=stop), \
                 mock.patch.object(r.sys,'argv',['lifetime','--cycles','1']),redirect_stdout(out):
                try: r.main()
                except RuntimeError as error: failure=error
            state.update(fixture_exists=fixture.exists(),receipt_exists=(fixture/'observations.json').exists())
        finally: temp.cleanup()
        return state,out.getvalue(),failure

    def test_complete_workflow_restores_rule_reaps_worker_and_cleans_fixture(self):
        state,out,error=self.run_workflow()
        self.assertIsNone(error); self.assertEqual(['add','del'],state['ops'])
        self.assertFalse(state['active']); self.assertFalse(state['fixture_exists']); self.assertEqual(1,state['stop_calls'])
        self.assertIn('HIDDEN AFTER EXEC',out); self.assertIn('RESTORED AFTER EXEC',out); self.assertIn('PARTIAL PASS',out)

    def test_metadata_leak_is_reported_after_verified_rule_removal_and_cleanup(self):
        state,out,error=self.run_workflow('leak')
        self.assertIsNotNone(error); self.assertIn('lstat',str(error))
        self.assertEqual(['add','del'],state['ops']); self.assertFalse(state['active']); self.assertFalse(state['fixture_exists'])
        self.assertIn('Cleanup complete',out)

    def test_unknown_root_write_outcome_stops_all_further_rule_commands(self):
        state,out,error=self.run_workflow('timeout')
        self.assertIsInstance(error,r.RootCommandTimeout); self.assertEqual(['add'],state['ops'])
        self.assertEqual(1,state['rule_reads']); self.assertTrue(state['fixture_exists']); self.assertTrue(state['receipt_exists'])
        self.assertIn('further rule commands skipped',out); self.assertNotIn('Cleanup complete',out)

    def test_returned_add_error_qualifies_empty_rule_cleanup(self):
        state,out,error=self.run_workflow('returned_error')
        self.assertIn('ADD returned failure',str(error)); self.assertEqual(['add'],state['ops'])
        self.assertFalse(state['active']); self.assertFalse(state['fixture_exists']); self.assertIn('Cleanup complete',out)

    def test_unreaped_owned_worker_prevents_fixture_deletion(self):
        state,out,error=self.run_workflow('unreaped')
        self.assertIn('Cleanup incomplete',str(error)); self.assertEqual(['add','del'],state['ops'])
        self.assertFalse(state['active']); self.assertTrue(state['fixture_exists']); self.assertTrue(state['receipt_exists'])
        self.assertNotIn('Cleanup complete;',out)

    def test_stop_waits_are_bounded_and_only_the_owned_popen_is_signaled(self):
        proc=mock.Mock(); proc.poll.return_value=None
        proc.wait.side_effect=subprocess.TimeoutExpired('owned',2)
        with mock.patch.object(r,'atomic_json'),mock.patch.object(r,'wait_reply',side_effect=RuntimeError('blocked')):
            self.assertFalse(r.stop_worker(proc,Path('/owned'),1,'nonce',None))
        proc.terminate.assert_called_once_with(); proc.kill.assert_called_once_with()
        self.assertTrue(all(call.kwargs['timeout']==2 for call in proc.wait.call_args_list))

    def test_interrupted_root_command_is_an_unknown_outcome(self):
        proc=mock.Mock(); proc.wait.side_effect=[KeyboardInterrupt('interrupt'),0]
        with mock.patch.object(r.subprocess,'Popen',return_value=proc):
            with self.assertRaisesRegex(r.RootCommandTimeout,'was interrupted; its outcome is unknown'):
                r.root('owned write')
        proc.kill.assert_called_once_with()
        self.assertEqual([r.ROOT_TIMEOUT,1],[call.kwargs['timeout'] for call in proc.wait.call_args_list])

    def test_interrupted_unreapable_root_child_does_not_block_a_second_wait(self):
        proc=mock.Mock(); proc.wait.side_effect=[KeyboardInterrupt('interrupt'),subprocess.TimeoutExpired('owned',1)]
        proc.kill.side_effect=PermissionError('cannot signal root')
        with mock.patch.object(r.subprocess,'Popen',return_value=proc):
            with self.assertRaises(r.RootCommandTimeout): r.root('owned write')
        self.assertEqual(2,proc.wait.call_count)

if __name__=='__main__': unittest.main()
