"""The frozen BZIG closing run, followed by an explicit observation report."""
import argparse
import contextlib
from datetime import datetime, timezone

DEFAULT_DIRECTORY = '/sdcard/Download/RMGU-SUSFS-CP23-final-tests'
RUN_DIRECTORY = 'rmgu-susfs-cp23-final'


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def uptime():
    return float(Path('/proc/uptime').read_text().split()[0])


def save_receipt(path, value):
    require(not path.exists(), 'Receipt already exists; preserve its existing result: ' + str(path))
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
    os.chmod(path, 0o600)


def assess_log(name, rc, text):
    require(rc == 0, 'Test exit code differs: ' + name)
    lines = text.splitlines()
    require(not any(re.match(r'^FAIL:', line) for line in lines), 'Fixture reported FAIL: ' + name)
    endings = [line for line in lines if re.match(r'^(?:PARTIAL )?PASS:', line)]
    require(endings, 'No terminal PASS: ' + name)
    partial = endings[-1].startswith('PARTIAL PASS:')
    blocked = [line for line in lines if line.startswith('BLOCKED:')]
    permitted = name in ('rmgu-susfs-map-test-cp19.py', 'rmgu-susfs-map-lifetime-test-cp19.py')
    if partial or blocked:
        require(permitted and partial and blocked, 'New blocked/partial scope: ' + name)
        require(all(re.search(r' (?:stat_follow|open_follow) baseline errno=(?:1|13); scope unqualified$', line)
                    for line in blocked), 'Mapping test has a new baseline blocker: ' + name)
    return {'status': 'PARTIAL PASS' if partial else 'PASS', 'blocked': blocked, 'terminal': endings[-1]}


def assess_module_block(error, text):
    require(str(error) == 'Native module/symbol/sysfs read baseline denied; controls untouched',
            'Module assertion has a different blocker: ' + str(error))
    lines = [line for line in text.splitlines() if line.startswith('BASELINE ACCESS ERRNO:')]
    require(len(lines) == 1, 'Missing module baseline errno breakdown')
    access = json.loads(lines[0].split(':', 1)[1])
    require(isinstance(access, dict) and set(access) == {'app', 'root'}, 'Invalid module reader breakdown')
    for values in access.values():
        require(isinstance(values, dict) and set(values) == {'modules', 'symbols', 'sysfs_list'} and
                all(type(value) is int and value in (0, errno.EACCES, errno.EPERM) for value in values.values()),
                'Unexpected module baseline errno')
    require(any(value for values in access.values() for value in values.values()),
            'Module baseline blocker has no denied read')
    return {'status': 'UNQUALIFIED', 'reason': str(error), 'access_errno': access,
            'controls_attempted': False,
            'scope': 'Module/symbol/sysfs effects remain unqualified; permission denial is not hiding evidence.'}


def module_assessment(log):
    denied = None
    with log.open('w') as stream, contextlib.redirect_stdout(stream), contextlib.redirect_stderr(stream):
        try:
            run_module_assertions()
        except Blocked as error:
            denied = error
            print('BLOCKED:', error, flush=True)
    text = log.read_text()
    if denied is not None:
        return assess_module_block(denied, text)
    require(any(line.startswith('PASS: selected module/tagged-symbol') for line in text.splitlines()),
            'Module assertions did not finish with PASS')
    require(not any(line.startswith(('FAIL:', 'BLOCKED:')) for line in text.splitlines()),
            'Module assertion log contains an unresolved failure')
    return {'status': 'PASS', 'controls_attempted': True,
            'scope': 'Visible platform module/tagged-symbol assertions; independent always-on prefix filtering remains unqualified.'}


def run_fixture(name, source, logs):
    runner = logs / ('input-' + name)
    runner.write_bytes(source)
    log = logs / (name + '.log')
    arguments = [sys.executable, '-u'] if name.endswith('.py') else ['sh']
    started = time.monotonic()
    with runner.open('rb') as stdin, log.open('wb') as stdout:
        child = subprocess.Popen(arguments, stdin=stdin, stdout=stdout, stderr=subprocess.STDOUT, cwd=Path.home())
        try:
            while True:
                try:
                    rc = child.wait(timeout=min(15, max(0.1, 240 - (time.monotonic() - started))))
                    break
                except subprocess.TimeoutExpired:
                    elapsed = time.monotonic() - started
                    if elapsed >= 240:
                        raise Unknown('Fixture exceeded 240 seconds; no further tests launched. Log: ' + str(log))
                    print('  still running (%.0f seconds); full log retained' % elapsed, flush=True)
        except BaseException:
            child.send_signal(signal.SIGINT)
            try:
                child.wait(timeout=15)
            except subprocess.TimeoutExpired:
                print('Fixture has not exited; no additional controls or tests will be sent.', flush=True)
            raise
    require(log.stat().st_size <= 16 * 1024 * 1024, 'Fixture log exceeded limit: ' + str(log))
    text = log.read_text(errors='replace')
    try:
        result = assess_log(name, rc, text)
    except Exception:
        print('FAILED LOG:', log, flush=True)
        print(text[-6000:], flush=True)
        raise
    return dict(result, name=name, log=str(log), sha256=hashlib.sha256(source).hexdigest())


def finish_command(directory, observation):
    script = str(Path(directory) / 'rmgu-susfs-acceptance-test-cp23.py')
    root = 'cat ' + shlex.quote(script)
    return 'su -c ' + shlex.quote(root) + ' | python -u - --finish-observation ' + shlex.quote(str(observation)) + ' --outcome clean'


def regression(directory):
    before = root_call('state')
    if before['mount_hide'] != 0:
        raise Blocked('Retained mount fixture requires its disabled baseline; current settings untouched')
    sources = root_call('read_batch', directory=directory)
    logs = Path.home() / RUN_DIRECTORY
    require(not logs.exists(), 'An earlier closing run exists; preserve and inspect it before repeating: ' + str(logs))
    logs.mkdir(mode=0o700)
    path = logs / 'regression.json'
    receipt = {'kind': 'cp23-fixed-regression', 'checkpoint': 23, 'uid': os.geteuid(),
               'started': timestamp(), 'original': before, 'manifest': sources['manifest'],
               'results': [], 'complete': False}
    print('EVIDENCE:', logs, flush=True)
    try:
        print('A2: module baseline/assertions', flush=True)
        module_log = logs / 'module-assertions.log'
        receipt['module_assessment'] = dict(module_assessment(module_log), log=str(module_log))
        require(root_call('state') == before, 'Original rules/settings changed after module assessment')
        print('A2:', receipt['module_assessment']['status'], flush=True)
        if receipt['module_assessment']['status'] == 'UNQUALIFIED':
            print('BASELINE ACCESS ERRNO:', json.dumps(receipt['module_assessment']['access_errno'], sort_keys=True), flush=True)
            print('Module/symbol/sysfs effects remain unqualified; controls untouched.', flush=True)
        for index, name in enumerate(REGRESSION, 1):
            print('REGRESSION %d/%d: %s' % (index, len(REGRESSION), name), flush=True)
            source = base64.b64decode(sources['sources'][name], validate=True)
            result = run_fixture(name, source, logs)
            after = root_call('state')
            require(after == before, 'Original rules/settings changed after ' + name)
            receipt['results'].append(dict(result, restoration=True))
            print(name, result['status'], 'and exact rules/settings restored', flush=True)
        receipt.update(complete=True, finished=timestamp(), final=root_call('state'))
        require(receipt['final'] == before, 'Final original state differs')
    except BaseException as error:
        receipt['error'] = type(error).__name__ + ': ' + str(error)
        receipt['stopped'] = timestamp()
        raise
    finally:
        save_receipt(path, receipt)
    print('PASS: frozen 11-fixture regression; exact rules/settings restored after each test.', flush=True)
    print('REGRESSION RECEIPT:', path, flush=True)
    print('Existing baseline-blocked scopes remain unqualified.', flush=True)
    observation_start(path, directory)


def observation_start(path, directory):
    receipt = json.loads(path.read_text())
    validate_regression_receipt(receipt)
    current = root_call('state')
    require(current == receipt['final'], 'Candidate settings changed after regression')
    target = path.parent / 'observation.json'
    save_receipt(target, {'kind': 'cp23-observation', 'uid': os.geteuid(), 'started': timestamp(),
                         'start_uptime': uptime(), 'state': current, 'regression': str(path),
                         'regression_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                         'source_directory': str(directory)})
    print('Observation started. Use the phone normally for at least 30 minutes.', flush=True)
    print('Keep the same CP23 activation and settings; note any new freeze, crash or reboot.', flush=True)
    print('OBSERVATION RECEIPT:', target, flush=True)
    print('After 30 minutes, if there was no new issue, run:', flush=True)
    print(finish_command(directory, target), flush=True)
    print('If an issue occurred, use --outcome issue --notes "what happened". If you did not observe the phone, use --outcome unobserved.', flush=True)


def validate_regression_receipt(receipt):
    require(receipt.get('kind') == 'cp23-fixed-regression' and receipt.get('complete') is True and
            receipt.get('checkpoint') == 23 and receipt.get('manifest') == FIXED_MANIFEST,
            'A completed fixed CP23 regression receipt is required')
    require(receipt['uid'] == os.geteuid() and receipt['final'] == receipt['original'], 'Regression identity/state differs')
    results = receipt['results']
    require([item['name'] for item in results] == list(REGRESSION) and
            all(item['status'] in ('PASS', 'PARTIAL PASS') and item['restoration'] is True and
                item['sha256'] == FIXED_MANIFEST['files'][item['name']]['sha256'] for item in results),
            'Fixed regression results are incomplete or differ')
    require(receipt['module_assessment']['status'] in ('PASS', 'UNQUALIFIED'), 'Module assessment incomplete')
    return receipt


def assess_observation(start, current, elapsed, outcome):
    # A reboot, changed state, reported issue or absent observation cannot pass.
    if outcome != 'clean' or start['state']['boot_id'] != current['boot_id'] or start['state'] != current:
        return 'UNQUALIFIED'
    if elapsed < 1800:
        raise Blocked('Observation is only %.1f minutes; 30 minutes are required' % (elapsed / 60))
    return 'PASS'


def observation_finish(path, outcome, notes):
    start = json.loads(path.read_text())
    require(start.get('kind') == 'cp23-observation' and start['uid'] == os.geteuid(), 'Invalid observation receipt')
    regression_path = Path(start['regression'])
    require(hashlib.sha256(regression_path.read_bytes()).hexdigest() == start['regression_sha256'], 'Regression receipt changed')
    receipt = validate_regression_receipt(json.loads(regression_path.read_text()))
    current = root_call('state')
    elapsed = uptime() - start['start_uptime']
    status = assess_observation(start, current, elapsed, outcome)
    result = {'kind': 'cp23-observation-result', 'status': status, 'started': start['started'],
              'finished': timestamp(), 'elapsed_seconds': elapsed, 'outcome_reported_by_user': outcome,
              'notes': notes, 'same_boot': start['state']['boot_id'] == current['boot_id'],
              'state_unchanged': start['state'] == current, 'module_assessment': receipt['module_assessment'],
              'limits': ['Baseline-blocked module/symbol/sysfs effects if recorded by A2',
                         'Baseline-blocked mapping stat_follow/open_follow reads',
                         'Optional non-su UID-0 native-control reader: baseline EACCES',
                         'App bootconfig reads and emitted AVC effect unavailable in prior observation',
                         'Compat/other kernels, arbitrary races, live unloading and long-run stability'],
              'scope': 'Frozen native BZIG functional regression and one 30-minute ordinary-use observation.'}
    target = path.parent / 'observation-result.json'
    save_receipt(target, result)
    print(status + ': ordinary-use observation; user outcome=' + outcome, flush=True)
    print('RESULT:', target, flush=True)
    if status != 'PASS':
        raise Blocked('Observed issue, absent observation, reboot or changed configuration remains unqualified')
    print('PASS: A5 completed within the frozen scope. Existing unqualified effects remain explicit; no additional mandatory fixture is added.', flush=True)


def run():
    print('Final acceptance runner revision: 2 (CP23 complete-snapshot guard and read-only preflight evidence)', flush=True)
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--preflight', action='store_true', help='read candidate state only; launch no fixtures')
    group.add_argument('--regression', metavar='EXTRACTED_DOWNLOAD_DIRECTORY')
    group.add_argument('--start-observation', type=Path, metavar='REGRESSION_JSON')
    group.add_argument('--finish-observation', type=Path, metavar='OBSERVATION_JSON')
    parser.add_argument('--outcome', choices=('clean', 'issue', 'unobserved'))
    parser.add_argument('--notes', default='')
    args = parser.parse_args()
    preflight()
    if args.preflight:
        state = root_call('state')
        print('READ-ONLY PREFLIGHT: complete original rules/settings captured; no fixture controls sent.', flush=True)
        print('Native kernel:', state['kernel'], 'boot:', state['boot_id'], flush=True)
        print('This is a preflight result, not an acceptance PASS.', flush=True)
    elif args.finish_observation:
        require(args.outcome is not None, 'An explicit --outcome is required; elapsed time alone is not a pass')
        observation_finish(args.finish_observation, args.outcome, args.notes)
    elif args.start_observation:
        observation_start(args.start_observation, args.regression or DEFAULT_DIRECTORY)
    else:
        regression(args.regression or DEFAULT_DIRECTORY)


if __name__ == '__main__':
    sys.exit(terminal_main(run))
