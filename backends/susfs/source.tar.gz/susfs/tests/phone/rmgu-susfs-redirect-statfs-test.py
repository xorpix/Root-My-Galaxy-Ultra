#!/usr/bin/env python3
"""CP21 native redirect statfs qualification; run from ordinary Termux.

Creates owned source files and two labelled files in a private /dev directory.
Uses scheme 3 for two owned rules; preserves existing rules. No mount, policy,
kernel-module, global-clear, or feature-flag changes. Root commands bounded.
"""
import base64
import ctypes as ct
import errno
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import tempfile

KERNEL = '6.12.69-android16-6-pb4d3caf-abogkiS948BXXS4BZIG-4k'
ROOT_TIMEOUT = 30

class RootCommandUnknown(RuntimeError):
    """A timed-out/interrupted root command may still be blocked in the kernel."""

def root(command):
    with tempfile.TemporaryFile(mode='w+t') as output, tempfile.TemporaryFile(mode='w+t') as error:
        proc = subprocess.Popen(['su', '-c', command], stdin=subprocess.DEVNULL,
                                stdout=output, stderr=error, text=True, start_new_session=True)
        try:
            proc.wait(timeout=ROOT_TIMEOUT)
        except (subprocess.TimeoutExpired, KeyboardInterrupt) as problem:
            try:
                proc.kill()
            except (ProcessLookupError, PermissionError):
                pass
            try:
                proc.wait(timeout=1)
            except subprocess.TimeoutExpired:
                pass
            raise RootCommandUnknown('Root command outcome unknown; no further control commands will be sent.') from problem
        output.seek(0)
        error.seek(0)
        if proc.returncode:
            raise RuntimeError('Root command failed (%d): %s' % (proc.returncode, error.read().strip()))
        return output.read()

SHARED = '"""Read-only native observer and exact redirect table parser for the phone runner."""\nimport ctypes as ct\nimport errno\nimport json\nimport os\nfrom pathlib import Path\nimport re\nimport stat\nimport struct\nimport sys\n\nREDIRECT_CONTROL = \'/proc/susfs_open_redirect\'\nCP21_MARKER = \'map_identity: checkpoint=21 routes=2\'\nLIMIT = 1024 * 1024\nRULE = re.compile(r\'^(\\S+) -> (\\S+) uid=([0-4]) \\(ino=(\\d+) dev=(\\d+) mnt=(\\d+) \\| rev: ino=(\\d+) dev=(\\d+)\\)$\')\nHOOKS = re.compile(r\'^hooks: open=[01] dpath=[01] statfs=[01] maps=[01] fdinfo=[01] \'\n                   r\'\\| rev hits: dpath=\\d+ statfs=\\d+ maps=\\d+/\\d+/\\d+ fdinfo=\\d+/\\d+ \'\n                   r\'\\| su_sid=\\d+ \\| fdinfo_probes=\\d+/\\d+$\')\n\n\ndef parse_redirect(text):\n    rules = []; diagnostics = []; empty = False\n    for line in text.splitlines():\n        if line == \'(empty)\':\n            if empty or rules: raise RuntimeError(\'Invalid redirect empty marker\')\n            empty = True\n        elif RULE.fullmatch(line):\n            if empty: raise RuntimeError(\'Redirect rules after empty marker\')\n            rules.append(line)\n        elif HOOKS.fullmatch(line):\n            diagnostics.append(line)\n        else:\n            raise RuntimeError(\'Invalid redirect rule list\')\n    # Deleted slots produce hooks alone, without an (empty) marker.\n    if len(diagnostics) != 1 or len(set(rules)) != len(rules):\n        raise RuntimeError(\'Invalid redirect diagnostics or duplicate rule\')\n    return {\'rules\': rules, \'diagnostics\': diagnostics[0]}\n\n\ndef bounded_text(path):\n    with open(path, \'rb\') as stream:\n        data = stream.read(LIMIT + 1)\n    if len(data) > LIMIT: raise RuntimeError(\'Control read exceeded limit\')\n    return data.decode(\'utf-8\', errors=\'strict\')\n\n\ndef stable_statfs(value):\n    if value[\'errno\'] or value[\'returncode\'] != 0 or not value[\'buffer_guards\']:\n        raise RuntimeError(\'Native statfs observation failed\')\n    data = bytes.fromhex(value[\'raw\'])\n    if len(data) != 120: raise RuntimeError(\'Unexpected native statfs width\')\n    # Free-space and file counts may change while other phone processes write.\n    return (data[:16] + data[56:]).hex()\n\n\ndef filesystem_identity(value):\n    stable_statfs(value)\n    return value[\'fields\'][\'type\'], tuple(value[\'fields\'][\'fsid\'])\n\n\nclass NativeStatFS:\n    def __init__(self):\n        numbers = {\'aarch64\': (43, 44), \'x86_64\': (137, 138)}\n        machine = os.uname().machine\n        if machine not in numbers or ct.sizeof(ct.c_void_p) != 8 or sys.byteorder != \'little\':\n            raise RuntimeError(\'Unsupported native statfs ABI\')\n        self.numbers = dict(zip((\'statfs\', \'fstatfs\'), numbers[machine]))\n        self.libc = ct.CDLL(None, use_errno=True)\n        self.libc.syscall.restype = ct.c_long\n\n    def call(self, operation, argument):\n        storage = ct.create_string_buffer(b\'G\' * 16 + b\'\\xa5\' * 120 + b\'G\' * 16, 152)\n        pointer = ct.c_void_p(ct.addressof(storage) + 16)\n        ct.set_errno(0)\n        argument = ct.c_int(argument) if operation == \'fstatfs\' else ct.c_char_p(os.fsencode(argument))\n        result = int(self.libc.syscall(ct.c_long(self.numbers[operation]), argument, pointer))\n        if storage.raw[:16] != b\'G\' * 16 or storage.raw[-16:] != b\'G\' * 16:\n            raise RuntimeError(\'Native statfs buffer guard changed\')\n        value = {\'nr\': self.numbers[operation], \'returncode\': result,\n                 \'errno\': ct.get_errno() if result < 0 else 0, \'buffer_guards\': True}\n        if result == 0:\n            data = storage.raw[16:136]\n            names = (\'type\', \'bsize\', \'blocks\', \'bfree\', \'bavail\', \'files\', \'ffree\')\n            fields = dict(zip(names, struct.unpack_from(\'<7Q\', data)))\n            fields[\'fsid\'] = list(struct.unpack_from(\'<2I\', data, 56))\n            fields.update(zip((\'namelen\', \'frsize\', \'flags\'), struct.unpack_from(\'<3Q\', data, 64)))\n            fields[\'spare\'] = list(struct.unpack_from(\'<4Q\', data, 88))\n            value.update(fields=fields, raw=data.hex())\n        return value\n\n\nclass NativeXattr:\n    """Descriptor xattrs through libc, including Python builds without os xattrs."""\n    def __init__(self, attribute=b\'security.selinux\', limit=4096):\n        if not isinstance(attribute, bytes) or not attribute or b\'\\0\' in attribute:\n            raise ValueError(\'Invalid native xattr name\')\n        if not 0 < limit <= 65536: raise ValueError(\'Invalid native xattr byte limit\')\n        self.attribute = attribute; self.limit = limit\n        self.libc = ct.CDLL(None, use_errno=True)\n        try:\n            self.read = self.libc.fgetxattr; self.write = self.libc.fsetxattr\n        except AttributeError as problem:\n            raise RuntimeError(\'libc descriptor xattr functions unavailable\') from problem\n        self.read.argtypes = (ct.c_int, ct.c_char_p, ct.c_void_p, ct.c_size_t)\n        self.read.restype = ct.c_ssize_t\n        self.write.argtypes = (ct.c_int, ct.c_char_p, ct.c_void_p, ct.c_size_t, ct.c_int)\n        self.write.restype = ct.c_int\n\n    def get(self, fd):\n        storage = ct.create_string_buffer(b\'G\' * 16 + b\'\\xa5\' * self.limit + b\'G\' * 16, self.limit + 32)\n        pointer = ct.c_void_p(ct.addressof(storage) + 16)\n        ct.set_errno(0)\n        count = int(self.read(fd, self.attribute, pointer, self.limit))\n        problem = ct.get_errno()\n        if storage.raw[:16] != b\'G\' * 16 or storage.raw[-16:] != b\'G\' * 16:\n            raise RuntimeError(\'Native xattr buffer guard changed\')\n        if count < 0: raise OSError(problem or errno.EIO, \'fgetxattr: \' + os.strerror(problem or errno.EIO))\n        if count > self.limit: raise RuntimeError(\'Native xattr exceeded byte limit\')\n        return storage.raw[16:16 + count]\n\n    def set(self, fd, value):\n        if not isinstance(value, bytes) or not value or len(value) > self.limit:\n            raise ValueError(\'Empty or oversized native label\')\n        storage = ct.create_string_buffer(value, len(value))\n        ct.set_errno(0)\n        result = int(self.write(fd, self.attribute, ct.cast(storage, ct.c_void_p), len(value), 0))\n        problem = ct.get_errno()\n        if result < 0: raise OSError(problem or errno.EIO, \'fsetxattr: \' + os.strerror(problem or errno.EIO))\n        if result != 0: raise RuntimeError(\'Unexpected native xattr write result\')\n\n    def copy(self, source_fd, destination_fd):\n        value = self.get(source_fd)\n        if not value: raise RuntimeError(\'Source SELinux label is empty\')\n        self.set(destination_fd, value)\n        if self.get(destination_fd) != value: raise RuntimeError(\'Copied label readback differs\')\n        if self.get(source_fd) != value: raise RuntimeError(\'Source label changed during copy\')\n        return {\'bytes\': len(value), \'hex\': value.hex(), \'verified\': True,\n                \'method\': \'libc fgetxattr/fsetxattr\'}\n\n\ndef identity_from_stat(value):\n    return {\'ino\': value.st_ino, \'dev\': value.st_dev, \'uid\': value.st_uid,\n            \'gid\': value.st_gid, \'mode\': value.st_mode, \'nlink\': value.st_nlink}\n\n\ndef file_identity(path):\n    return identity_from_stat(os.lstat(path))\n\n\ndef descriptor_identity(fd):\n    return identity_from_stat(os.fstat(fd))\n\n\ndef verify_file(path, expected, directory=False):\n    value = file_identity(path)\n    if value != expected or not (stat.S_ISDIR(value[\'mode\']) if directory else stat.S_ISREG(value[\'mode\'])):\n        raise RuntimeError(\'Owned fixture identity changed: \' + str(path))\n    return value\n\n\ndef raw_device(value):\n    return (os.major(value) << 20) | os.minor(value)\n\n\ndef fd_mount_id(fd):\n    text = bounded_text(\'/proc/self/fdinfo/\' + str(fd))\n    rows = re.findall(r\'^mnt_id:\\s+(\\d+)\\s*$\', text, re.M)\n    if len(rows) != 1: raise RuntimeError(\'Descriptor mount ID unavailable\')\n    return int(rows[0])\n\n\ndef expected_rule(config):\n    source = config[\'identities\'][\'target\']; destination = config[\'identities\'][\'destination\']\n    return \'%s -> %s uid=3 (ino=%d dev=%d mnt=%d | rev: ino=%d dev=%d)\' % (\n        config[\'paths\'][\'target\'], config[\'paths\'][\'destination\'], source[\'ino\'], raw_device(source[\'dev\']),\n        config[\'source_mount_id\'], destination[\'ino\'], raw_device(destination[\'dev\']))\n\n\ndef assert_subject(subject):\n    observed = process_identity(subject[\'pid\'])\n    if observed != subject: raise RuntimeError(\'Owned reader identity changed\')\n    namespace = os.readlink(\'/proc/self/ns/mnt\')\n    if namespace != subject[\'mount_namespace\']: raise RuntimeError(\'Root/app mount namespaces differ\')\n\n\ndef observe_files(config, held):\n    assert_subject(config[\'subject\'])\n    native = NativeStatFS(); paths = {}; descriptors = {}; opened = []\n    try:\n        for name, path in config[\'paths\'].items():\n            paths[name] = native.call(\'statfs\', path)\n            fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC); opened.append(fd)\n            descriptors[name + \'_fresh\'] = {\'statfs\': native.call(\'fstatfs\', fd),\n                \'content\': os.pread(fd, 64, 0).hex()}\n        for name, original_fd in held.items():\n            # Root opens the same owned app descriptor\'s actual backing file.\n            if os.getpid() == config[\'subject\'][\'pid\']:\n                fd = original_fd\n            else:\n                fd = os.open(\'/proc/%d/fd/%d\' % (config[\'subject\'][\'pid\'], original_fd),\n                             os.O_RDONLY | os.O_CLOEXEC); opened.append(fd)\n            descriptors[name] = {\'statfs\': native.call(\'fstatfs\', fd),\n                \'proc_fd_statfs\': native.call(\'statfs\', \'/proc/self/fd/\' + str(fd)),\n                \'content\': os.pread(fd, 64, 0).hex()}\n        errors = {\'missing_path\': native.call(\'statfs\', config[\'missing\']),\n                  \'bad_fd\': native.call(\'fstatfs\', -1)}\n    finally:\n        for fd in opened: os.close(fd)\n    assert_subject(config[\'subject\'])\n    return {\'reader_uid\': os.geteuid(), \'subject\': config[\'subject\'],\n            \'paths\': paths, \'descriptors\': descriptors, \'errors\': errors}\n\n\ndef compact_observation(observation):\n    def brief(value):\n        fields = value.get(\'fields\', {})\n        return {\'errno\': value[\'errno\'], \'type\': fields.get(\'type\'), \'fsid\': fields.get(\'fsid\'),\n                \'bsize\': fields.get(\'bsize\'), \'frsize\': fields.get(\'frsize\'),\n                \'namelen\': fields.get(\'namelen\'), \'flags\': fields.get(\'flags\')}\n    return {\'reader_uid\': observation[\'reader_uid\'],\n            \'paths\': {name: brief(value) for name, value in observation[\'paths\'].items()},\n            \'descriptors\': {name: dict(brief(value[\'statfs\']), content=value[\'content\'])\n                            for name, value in observation[\'descriptors\'].items()},\n            \'errors\': {name: value[\'errno\'] for name, value in observation[\'errors\'].items()}}\n\n\ndef process_identity(pid):\n    directory = Path(\'/proc\') / str(pid)\n    stat = (directory / \'stat\').read_text()\n    suffix = stat[stat.rfind(\')\') + 2:].split()\n    if not stat.startswith(str(pid) + \' (\') or len(suffix) < 20:\n        raise RuntimeError(\'Subject process stat is not recognized\')\n    status = (directory / \'status\').read_text()\n    match = re.search(r\'^Uid:\\s+(\\d+)\\s+(\\d+)\\s+(\\d+)\\s+(\\d+)\\s*$\', status, re.M)\n    if not match: raise RuntimeError(\'Subject process UID is unavailable\')\n    return {\'pid\': int(pid), \'starttime\': int(suffix[19]),\n            \'uids\': list(map(int, match.groups())),\n            \'context\': (directory / \'attr/current\').read_text().rstrip(\'\\0\\n\'),\n            \'mount_namespace\': os.readlink(directory / \'ns/mnt\')}\n'
exec(SHARED, globals())

ROOT_HELPER = '"""Read-only native observer and exact redirect table parser for the phone runner."""\nimport ctypes as ct\nimport errno\nimport json\nimport os\nfrom pathlib import Path\nimport re\nimport stat\nimport struct\nimport sys\n\nREDIRECT_CONTROL = \'/proc/susfs_open_redirect\'\nCP21_MARKER = \'map_identity: checkpoint=21 routes=2\'\nLIMIT = 1024 * 1024\nRULE = re.compile(r\'^(\\S+) -> (\\S+) uid=([0-4]) \\(ino=(\\d+) dev=(\\d+) mnt=(\\d+) \\| rev: ino=(\\d+) dev=(\\d+)\\)$\')\nHOOKS = re.compile(r\'^hooks: open=[01] dpath=[01] statfs=[01] maps=[01] fdinfo=[01] \'\n                   r\'\\| rev hits: dpath=\\d+ statfs=\\d+ maps=\\d+/\\d+/\\d+ fdinfo=\\d+/\\d+ \'\n                   r\'\\| su_sid=\\d+ \\| fdinfo_probes=\\d+/\\d+$\')\n\n\ndef parse_redirect(text):\n    rules = []; diagnostics = []; empty = False\n    for line in text.splitlines():\n        if line == \'(empty)\':\n            if empty or rules: raise RuntimeError(\'Invalid redirect empty marker\')\n            empty = True\n        elif RULE.fullmatch(line):\n            if empty: raise RuntimeError(\'Redirect rules after empty marker\')\n            rules.append(line)\n        elif HOOKS.fullmatch(line):\n            diagnostics.append(line)\n        else:\n            raise RuntimeError(\'Invalid redirect rule list\')\n    # Deleted slots produce hooks alone, without an (empty) marker.\n    if len(diagnostics) != 1 or len(set(rules)) != len(rules):\n        raise RuntimeError(\'Invalid redirect diagnostics or duplicate rule\')\n    return {\'rules\': rules, \'diagnostics\': diagnostics[0]}\n\n\ndef bounded_text(path):\n    with open(path, \'rb\') as stream:\n        data = stream.read(LIMIT + 1)\n    if len(data) > LIMIT: raise RuntimeError(\'Control read exceeded limit\')\n    return data.decode(\'utf-8\', errors=\'strict\')\n\n\ndef stable_statfs(value):\n    if value[\'errno\'] or value[\'returncode\'] != 0 or not value[\'buffer_guards\']:\n        raise RuntimeError(\'Native statfs observation failed\')\n    data = bytes.fromhex(value[\'raw\'])\n    if len(data) != 120: raise RuntimeError(\'Unexpected native statfs width\')\n    # Free-space and file counts may change while other phone processes write.\n    return (data[:16] + data[56:]).hex()\n\n\ndef filesystem_identity(value):\n    stable_statfs(value)\n    return value[\'fields\'][\'type\'], tuple(value[\'fields\'][\'fsid\'])\n\n\nclass NativeStatFS:\n    def __init__(self):\n        numbers = {\'aarch64\': (43, 44), \'x86_64\': (137, 138)}\n        machine = os.uname().machine\n        if machine not in numbers or ct.sizeof(ct.c_void_p) != 8 or sys.byteorder != \'little\':\n            raise RuntimeError(\'Unsupported native statfs ABI\')\n        self.numbers = dict(zip((\'statfs\', \'fstatfs\'), numbers[machine]))\n        self.libc = ct.CDLL(None, use_errno=True)\n        self.libc.syscall.restype = ct.c_long\n\n    def call(self, operation, argument):\n        storage = ct.create_string_buffer(b\'G\' * 16 + b\'\\xa5\' * 120 + b\'G\' * 16, 152)\n        pointer = ct.c_void_p(ct.addressof(storage) + 16)\n        ct.set_errno(0)\n        argument = ct.c_int(argument) if operation == \'fstatfs\' else ct.c_char_p(os.fsencode(argument))\n        result = int(self.libc.syscall(ct.c_long(self.numbers[operation]), argument, pointer))\n        if storage.raw[:16] != b\'G\' * 16 or storage.raw[-16:] != b\'G\' * 16:\n            raise RuntimeError(\'Native statfs buffer guard changed\')\n        value = {\'nr\': self.numbers[operation], \'returncode\': result,\n                 \'errno\': ct.get_errno() if result < 0 else 0, \'buffer_guards\': True}\n        if result == 0:\n            data = storage.raw[16:136]\n            names = (\'type\', \'bsize\', \'blocks\', \'bfree\', \'bavail\', \'files\', \'ffree\')\n            fields = dict(zip(names, struct.unpack_from(\'<7Q\', data)))\n            fields[\'fsid\'] = list(struct.unpack_from(\'<2I\', data, 56))\n            fields.update(zip((\'namelen\', \'frsize\', \'flags\'), struct.unpack_from(\'<3Q\', data, 64)))\n            fields[\'spare\'] = list(struct.unpack_from(\'<4Q\', data, 88))\n            value.update(fields=fields, raw=data.hex())\n        return value\n\n\nclass NativeXattr:\n    """Descriptor xattrs through libc, including Python builds without os xattrs."""\n    def __init__(self, attribute=b\'security.selinux\', limit=4096):\n        if not isinstance(attribute, bytes) or not attribute or b\'\\0\' in attribute:\n            raise ValueError(\'Invalid native xattr name\')\n        if not 0 < limit <= 65536: raise ValueError(\'Invalid native xattr byte limit\')\n        self.attribute = attribute; self.limit = limit\n        self.libc = ct.CDLL(None, use_errno=True)\n        try:\n            self.read = self.libc.fgetxattr; self.write = self.libc.fsetxattr\n        except AttributeError as problem:\n            raise RuntimeError(\'libc descriptor xattr functions unavailable\') from problem\n        self.read.argtypes = (ct.c_int, ct.c_char_p, ct.c_void_p, ct.c_size_t)\n        self.read.restype = ct.c_ssize_t\n        self.write.argtypes = (ct.c_int, ct.c_char_p, ct.c_void_p, ct.c_size_t, ct.c_int)\n        self.write.restype = ct.c_int\n\n    def get(self, fd):\n        storage = ct.create_string_buffer(b\'G\' * 16 + b\'\\xa5\' * self.limit + b\'G\' * 16, self.limit + 32)\n        pointer = ct.c_void_p(ct.addressof(storage) + 16)\n        ct.set_errno(0)\n        count = int(self.read(fd, self.attribute, pointer, self.limit))\n        problem = ct.get_errno()\n        if storage.raw[:16] != b\'G\' * 16 or storage.raw[-16:] != b\'G\' * 16:\n            raise RuntimeError(\'Native xattr buffer guard changed\')\n        if count < 0: raise OSError(problem or errno.EIO, \'fgetxattr: \' + os.strerror(problem or errno.EIO))\n        if count > self.limit: raise RuntimeError(\'Native xattr exceeded byte limit\')\n        return storage.raw[16:16 + count]\n\n    def set(self, fd, value):\n        if not isinstance(value, bytes) or not value or len(value) > self.limit:\n            raise ValueError(\'Empty or oversized native label\')\n        storage = ct.create_string_buffer(value, len(value))\n        ct.set_errno(0)\n        result = int(self.write(fd, self.attribute, ct.cast(storage, ct.c_void_p), len(value), 0))\n        problem = ct.get_errno()\n        if result < 0: raise OSError(problem or errno.EIO, \'fsetxattr: \' + os.strerror(problem or errno.EIO))\n        if result != 0: raise RuntimeError(\'Unexpected native xattr write result\')\n\n    def copy(self, source_fd, destination_fd):\n        value = self.get(source_fd)\n        if not value: raise RuntimeError(\'Source SELinux label is empty\')\n        self.set(destination_fd, value)\n        if self.get(destination_fd) != value: raise RuntimeError(\'Copied label readback differs\')\n        if self.get(source_fd) != value: raise RuntimeError(\'Source label changed during copy\')\n        return {\'bytes\': len(value), \'hex\': value.hex(), \'verified\': True,\n                \'method\': \'libc fgetxattr/fsetxattr\'}\n\n\ndef identity_from_stat(value):\n    return {\'ino\': value.st_ino, \'dev\': value.st_dev, \'uid\': value.st_uid,\n            \'gid\': value.st_gid, \'mode\': value.st_mode, \'nlink\': value.st_nlink}\n\n\ndef file_identity(path):\n    return identity_from_stat(os.lstat(path))\n\n\ndef descriptor_identity(fd):\n    return identity_from_stat(os.fstat(fd))\n\n\ndef verify_file(path, expected, directory=False):\n    value = file_identity(path)\n    if value != expected or not (stat.S_ISDIR(value[\'mode\']) if directory else stat.S_ISREG(value[\'mode\'])):\n        raise RuntimeError(\'Owned fixture identity changed: \' + str(path))\n    return value\n\n\ndef raw_device(value):\n    return (os.major(value) << 20) | os.minor(value)\n\n\ndef fd_mount_id(fd):\n    text = bounded_text(\'/proc/self/fdinfo/\' + str(fd))\n    rows = re.findall(r\'^mnt_id:\\s+(\\d+)\\s*$\', text, re.M)\n    if len(rows) != 1: raise RuntimeError(\'Descriptor mount ID unavailable\')\n    return int(rows[0])\n\n\ndef expected_rule(config):\n    source = config[\'identities\'][\'target\']; destination = config[\'identities\'][\'destination\']\n    return \'%s -> %s uid=3 (ino=%d dev=%d mnt=%d | rev: ino=%d dev=%d)\' % (\n        config[\'paths\'][\'target\'], config[\'paths\'][\'destination\'], source[\'ino\'], raw_device(source[\'dev\']),\n        config[\'source_mount_id\'], destination[\'ino\'], raw_device(destination[\'dev\']))\n\n\ndef assert_subject(subject):\n    observed = process_identity(subject[\'pid\'])\n    if observed != subject: raise RuntimeError(\'Owned reader identity changed\')\n    namespace = os.readlink(\'/proc/self/ns/mnt\')\n    if namespace != subject[\'mount_namespace\']: raise RuntimeError(\'Root/app mount namespaces differ\')\n\n\ndef observe_files(config, held):\n    assert_subject(config[\'subject\'])\n    native = NativeStatFS(); paths = {}; descriptors = {}; opened = []\n    try:\n        for name, path in config[\'paths\'].items():\n            paths[name] = native.call(\'statfs\', path)\n            fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC); opened.append(fd)\n            descriptors[name + \'_fresh\'] = {\'statfs\': native.call(\'fstatfs\', fd),\n                \'content\': os.pread(fd, 64, 0).hex()}\n        for name, original_fd in held.items():\n            # Root opens the same owned app descriptor\'s actual backing file.\n            if os.getpid() == config[\'subject\'][\'pid\']:\n                fd = original_fd\n            else:\n                fd = os.open(\'/proc/%d/fd/%d\' % (config[\'subject\'][\'pid\'], original_fd),\n                             os.O_RDONLY | os.O_CLOEXEC); opened.append(fd)\n            descriptors[name] = {\'statfs\': native.call(\'fstatfs\', fd),\n                \'proc_fd_statfs\': native.call(\'statfs\', \'/proc/self/fd/\' + str(fd)),\n                \'content\': os.pread(fd, 64, 0).hex()}\n        errors = {\'missing_path\': native.call(\'statfs\', config[\'missing\']),\n                  \'bad_fd\': native.call(\'fstatfs\', -1)}\n    finally:\n        for fd in opened: os.close(fd)\n    assert_subject(config[\'subject\'])\n    return {\'reader_uid\': os.geteuid(), \'subject\': config[\'subject\'],\n            \'paths\': paths, \'descriptors\': descriptors, \'errors\': errors}\n\n\ndef compact_observation(observation):\n    def brief(value):\n        fields = value.get(\'fields\', {})\n        return {\'errno\': value[\'errno\'], \'type\': fields.get(\'type\'), \'fsid\': fields.get(\'fsid\'),\n                \'bsize\': fields.get(\'bsize\'), \'frsize\': fields.get(\'frsize\'),\n                \'namelen\': fields.get(\'namelen\'), \'flags\': fields.get(\'flags\')}\n    return {\'reader_uid\': observation[\'reader_uid\'],\n            \'paths\': {name: brief(value) for name, value in observation[\'paths\'].items()},\n            \'descriptors\': {name: dict(brief(value[\'statfs\']), content=value[\'content\'])\n                            for name, value in observation[\'descriptors\'].items()},\n            \'errors\': {name: value[\'errno\'] for name, value in observation[\'errors\'].items()}}\n\n\ndef process_identity(pid):\n    directory = Path(\'/proc\') / str(pid)\n    stat = (directory / \'stat\').read_text()\n    suffix = stat[stat.rfind(\')\') + 2:].split()\n    if not stat.startswith(str(pid) + \' (\') or len(suffix) < 20:\n        raise RuntimeError(\'Subject process stat is not recognized\')\n    status = (directory / \'status\').read_text()\n    match = re.search(r\'^Uid:\\s+(\\d+)\\s+(\\d+)\\s+(\\d+)\\s+(\\d+)\\s*$\', status, re.M)\n    if not match: raise RuntimeError(\'Subject process UID is unavailable\')\n    return {\'pid\': int(pid), \'starttime\': int(suffix[19]),\n            \'uids\': list(map(int, match.groups())),\n            \'context\': (directory / \'attr/current\').read_text().rstrip(\'\\0\\n\'),\n            \'mount_namespace\': os.readlink(directory / \'ns/mnt\')}\n\n"""Embedded root helper; only mutations to the named owned fixture and its rule."""\n\n\ndef create_device_fixture(config, directory):\n    """Called only after root_action validates the private /dev destination."""\n    owned = {}; labels = {}; available = False; problem = None; descriptors = []\n    try:\n        native = NativeXattr()\n        source_directory = os.open(config[\'fixture\'], os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)\n        descriptors.append(source_directory)\n        source_file = os.open(config[\'paths\'][\'target\'], os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)\n        descriptors.append(source_file)\n        for fd, directory_expected in ((source_directory, True), (source_file, False)):\n            identity = descriptor_identity(fd)\n            if (identity[\'uid\'], identity[\'gid\']) != (config[\'uid\'], config[\'gid\']):\n                raise RuntimeError(\'Source label fixture owner differs\')\n            if not (stat.S_ISDIR(identity[\'mode\']) if directory_expected else stat.S_ISREG(identity[\'mode\'])):\n                raise RuntimeError(\'Source label fixture type differs\')\n            if not native.get(fd): raise RuntimeError(\'Source SELinux label is empty\')\n        os.mkdir(directory, 0o700)\n        # Keep a receipt even if the first open or ownership operation fails.\n        owned[\'directory\'] = file_identity(directory)\n        directory_fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)\n        descriptors.append(directory_fd)\n        os.fchown(directory_fd, config[\'uid\'], config[\'gid\'])\n        owned[\'directory\'] = descriptor_identity(directory_fd)\n        labels[\'directory\'] = native.copy(source_directory, directory_fd)\n        for name in (\'destination\', \'destination_control\'):\n            path = config[\'paths\'][name]\n            if Path(path).parent != directory: raise RuntimeError(\'Invalid device fixture child\')\n            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)\n            descriptors.append(fd)\n            owned[name] = descriptor_identity(fd)\n            os.fchown(fd, config[\'uid\'], config[\'gid\'])\n            owned[name] = descriptor_identity(fd)\n            labels[name] = native.copy(source_file, fd)\n            data = bytes.fromhex(config[\'contents\'][name])\n            if os.write(fd, data) != len(data): raise RuntimeError(\'Short fixture content write\')\n        for name, expected in owned.items():\n            verify_file(directory if name == \'directory\' else config[\'paths\'][name], expected,\n                        directory=(name == \'directory\'))\n        available = True\n    except Exception as error:\n        problem = \'%s: %s\' % (type(error).__name__, error)\n    finally:\n        for fd in reversed(descriptors): os.close(fd)\n    return {\'available\': available, \'error\': problem, \'owned\': owned, \'labels\': labels}\n\n\ndef root_action(action, config):\n    if os.geteuid() != 0: raise RuntimeError(\'Root helper did not obtain uid 0\')\n    assert_subject(config[\'subject\'])\n    if action == \'state\':\n        marker = bounded_text(\'/proc/susfs_kstat\')\n        if CP21_MARKER not in marker: raise RuntimeError(\'CP21 maps identity marker missing\')\n        return parse_redirect(bounded_text(REDIRECT_CONTROL))\n    if action == \'setup\':\n        directory = Path(config[\'device_directory\'])\n        if directory.parent != Path(\'/dev\') or directory.name != Path(config[\'fixture\']).name:\n            raise RuntimeError(\'Invalid owned device fixture path\')\n        if not directory.name.startswith(\'rmgu-susfs-redirect-statfs.\'):\n            raise RuntimeError(\'Invalid fixture prefix\')\n        return create_device_fixture(config, directory)\n    if action == \'metadata\':\n        identities = {name: file_identity(path) for name, path in config[\'paths\'].items()}\n        opened = os.open(config[\'paths\'][\'target\'], os.O_RDONLY | os.O_CLOEXEC)\n        try:\n            mount_id = fd_mount_id(opened)\n        finally:\n            os.close(opened)\n        return {\'identities\': identities, \'source_mount_id\': mount_id}\n    if action == \'observe\':\n        return observe_files(config, config[\'held\'])\n    if action in (\'add\', \'del\'):\n        original = config[\'original_rules\']; own = expected_rule(config)\n        before = original if action == \'add\' else original + [own]\n        after = original + [own] if action == \'add\' else original\n        current = parse_redirect(bounded_text(REDIRECT_CONTROL))\n        if current[\'rules\'] != before: raise RuntimeError(\'Redirect rule list changed before \' + action)\n        for name, path in config[\'paths\'].items(): verify_file(path, config[\'identities\'][name])\n        if any(len(os.fsencode(path)) >= 256 or any(char.isspace() for char in path)\n               for path in config[\'paths\'].values()): raise RuntimeError(\'Unsupported fixture path width/spacing\')\n        text = (\'add_open_redirect %s %s 3\\n\' % (config[\'paths\'][\'target\'], config[\'paths\'][\'destination\'])\n                if action == \'add\' else \'del %s\\n\' % config[\'paths\'][\'target\'])\n        with open(REDIRECT_CONTROL, \'wb\', buffering=0) as stream:\n            if stream.write(text.encode()) != len(text.encode()): raise RuntimeError(\'Short redirect control write\')\n        current = parse_redirect(bounded_text(REDIRECT_CONTROL))\n        if current[\'rules\'] != after: raise RuntimeError(\'Redirect rule publication/restoration mismatch\')\n        return current\n    if action == \'cleanup\':\n        if parse_redirect(bounded_text(REDIRECT_CONTROL))[\'rules\'] != config[\'original_rules\']:\n            raise RuntimeError(\'Rules must be restored before fixture cleanup\')\n        directory = Path(config[\'device_directory\']); owned = config[\'device_owned\']\n        if \'directory\' not in owned: return {\'removed\': True, \'created\': False}\n        verify_file(directory, owned[\'directory\'], directory=True)\n        children = {Path(config[\'paths\'][name]).name for name in owned if name != \'directory\'}\n        if set(os.listdir(directory)) != children:\n            raise RuntimeError(\'Owned device directory contains changed or extra entries\')\n        for name in owned:\n            if name != \'directory\': verify_file(config[\'paths\'][name], owned[name])\n        for name in owned:\n            if name != \'directory\': os.unlink(config[\'paths\'][name])\n        os.rmdir(directory)\n        return {\'removed\': True, \'created\': True}\n    raise RuntimeError(\'Unknown helper action\')\n\n\nif __name__ == \'__main__\':\n    import base64\n    import traceback\n    try:\n        payload = json.loads(base64.b64decode(sys.argv[2], validate=True))\n        result = root_action(sys.argv[1], payload)\n        assert_subject(payload[\'subject\'])\n        print(json.dumps({\'ok\': True, \'value\': result}, separators=(\',\', \':\')))\n    except Exception as problem:\n        print(json.dumps({\'ok\': False, \'error\': \'%s: %s\' % (type(problem).__name__, problem)}, separators=(\',\', \':\')))\n'

"""Two owned redirect cycles, descriptor provenance, restoration and cleanup."""


class FixtureBlocked(RuntimeError):
    pass


class RootClient:
    def __init__(self, helper, subject):
        self.helper = helper; self.subject = subject; self.unknown = False

    def call(self, action, config):
        if self.unknown: raise RootCommandUnknown('Root outcome remains unknown; no further root commands sent.')
        payload = base64.b64encode(json.dumps(config, separators=(',', ':')).encode()).decode()
        arguments = ['/system/bin/toybox', 'nsenter', '-t', str(self.subject['pid']), '-m',
                     sys.executable, str(self.helper), action, payload]
        print('ROOT ' + action.upper(), flush=True)
        try:
            output = root(' '.join(shlex.quote(item) for item in arguments))
        except RootCommandUnknown:
            self.unknown = True
            raise
        try:
            value = json.loads(output)
        except (ValueError, TypeError) as problem:
            raise RuntimeError('Invalid root helper response; inspect rule state before cleanup') from problem
        if not value.get('ok'): raise RuntimeError(value.get('error', 'Root helper failed'))
        return value['value']


def check_filesystem(value, reference, label, errors):
    try:
        if stable_statfs(value) != stable_statfs(reference):
            errors.append(label + ': stable filesystem fields differ')
    except (RuntimeError, KeyError, ValueError) as problem:
        errors.append(label + ': ' + str(problem))


def check_phase(config, pair, references, active, errors, label, active_descriptor=False):
    source, destination = references
    contents = config['contents']
    if set(pair) != {'app', 'root'}: errors.append(label + ': missing reader view')
    for reader, observation in pair.items():
        app = reader == 'app'
        expected_uid = config['uid'] if app else 0
        if observation['reader_uid'] != expected_uid: errors.append(label + ' ' + reader + ': reader UID changed')
        if observation['subject'] != config['subject']: errors.append(label + ' ' + reader + ': subject changed')
        required = {name + '_fresh' for name in config['paths']} | {'target_before', 'source_control', 'destination_control'}
        if active_descriptor: required.add('target_active')
        if set(observation['paths']) != set(config['paths']): errors.append(label + ' ' + reader + ': path coverage differs')
        if set(observation['descriptors']) != required: errors.append(label + ' ' + reader + ': descriptor coverage differs')
        if set(observation['errors']) != {'missing_path', 'bad_fd'}: errors.append(label + ' ' + reader + ': error coverage differs')
        for name, value in observation['paths'].items():
            use_source = name in ('target', 'source_control') or (active and app and name == 'destination')
            check_filesystem(value, source if use_source else destination,
                             label + ' ' + reader + ' path ' + name, errors)
        for name, value in observation['descriptors'].items():
            if name == 'target_fresh':
                content = contents['destination'] if active and app else contents['target']
                reference = source
            elif name == 'destination_fresh':
                content = contents['destination']; reference = source if active and app else destination
            elif name == 'target_active':
                content = contents['destination']; reference = source if active and app else destination
            elif name in ('source_control_fresh', 'source_control', 'target_before'):
                content = contents['target'] if name == 'target_before' else contents['source_control']
                reference = source
            elif name in ('destination_control_fresh', 'destination_control'):
                content = contents['destination_control']; reference = destination
            else:
                errors.append(label + ' unexpected descriptor ' + name); continue
            check_filesystem(value['statfs'], reference, label + ' ' + reader + ' fd ' + name, errors)
            if name in {'target_before', 'source_control', 'destination_control', 'target_active'} and 'proc_fd_statfs' not in value:
                errors.append(label + ' ' + reader + ' proc-fd ' + name + ': missing observation')
            if 'proc_fd_statfs' in value:
                check_filesystem(value['proc_fd_statfs'], reference,
                                 label + ' ' + reader + ' proc-fd ' + name, errors)
            if value['content'] != content: errors.append(label + ' ' + reader + ' content ' + name + ': mismatch')
        for name, expected in (('missing_path', errno.ENOENT), ('bad_fd', errno.EBADF)):
            value = observation['errors'][name]
            if value['errno'] != expected or value['returncode'] != -1 or not value['buffer_guards']:
                errors.append(label + ' ' + reader + ' ' + name + ': native error changed')


def baseline_references(config, pair):
    source = pair['root']['paths']['target']; destination = pair['root']['paths']['destination']
    if config['identities']['target']['dev'] == config['identities']['destination']['dev']:
        raise FixtureBlocked('Source and destination backing devices are equal; no distinct filesystem challenge')
    if filesystem_identity(source) == filesystem_identity(destination) or stable_statfs(source) == stable_statfs(destination):
        raise FixtureBlocked('Source and destination filesystem identities are equal; statfs effect unqualified')
    problems = []
    check_phase(config, pair, (source, destination), False, problems, 'BASELINE')
    if problems: raise FixtureBlocked('Baseline unavailable or inconsistent: ' + '; '.join(problems))
    return source, destination


def observe_pair(client, config, held, label):
    print('READ ' + label + ' APP', flush=True)
    app = observe_files(config, held)
    root_config = dict(config, held=held)
    root_observation = client.call('observe', root_config)
    pair = {'app': app, 'root': root_observation}
    print(label + ': ' + json.dumps({name: compact_observation(value) for name, value in pair.items()},
                                   separators=(',', ':')), flush=True)
    return pair


def restore_rules(client, config):
    state = client.call('state', config)
    original = config['original_rules']
    if state['rules'] == original: return state
    if 'identities' not in config or state['rules'] != original + [expected_rule(config)]:
        raise RuntimeError('Unexpected rule state retained; refusing to remove another rule')
    return client.call('del', config)


def run_cycles(client, config, held, references, receipt):
    problems = []
    for cycle in (1, 2):
        print('ENABLE %d: only the owned source path, UID scheme 3' % cycle, flush=True)
        client.call('add', config)
        try:
            held['target_active'] = os.open(config['paths']['target'], os.O_RDONLY | os.O_CLOEXEC)
            pair = observe_pair(client, config, held, 'ACTIVE %d' % cycle)
            receipt['observations']['active_%d' % cycle] = pair
            check_phase(config, pair, references, True, problems, 'ACTIVE %d' % cycle, active_descriptor=True)
            print('DISABLE %d' % cycle, flush=True)
            client.call('del', config)
            # This descriptor still reads the destination after DEL; only the disguise ends.
            pair = observe_pair(client, config, held, 'RESTORED %d (active descriptor held)' % cycle)
            receipt['observations']['restored_%d' % cycle] = pair
            check_phase(config, pair, references, False, problems, 'RESTORED %d' % cycle, active_descriptor=True)
        finally:
            if 'target_active' in held: os.close(held.pop('target_active'))
        if problems: break
    return problems


def source_cleanup(config, helper):
    directory = Path(config['fixture'])
    known = {Path(config['paths'][name]).name for name in ('target', 'source_control')}
    known.add(helper.name)
    # receipt.json is created by this runner, including on a known failure.
    known.add('receipt.json')
    if not set(os.listdir(directory)).issubset(known): raise RuntimeError('Source fixture has extra entries; retained')
    if 'identities' in config:
        for name in ('target', 'source_control'): verify_file(config['paths'][name], config['identities'][name])
    for name in known:
        path = directory / name
        if path.exists(): path.unlink()
    directory.rmdir()


def main():
    print('Redirect statfs runner revision: 2 (CP21 native descriptor label copying and readback)', flush=True)
    if sys.argv[1:]: raise RuntimeError('This runner has no command-line options')
    if os.geteuid() < 10000 or os.uname().machine != 'aarch64' or os.uname().release != KERNEL:
        raise RuntimeError('Run from ordinary native AArch64 Termux on the qualified BZIG kernel')
    print('App reader: ' + subprocess.check_output(['id'], text=True).strip(), flush=True)
    subject = process_identity(os.getpid())
    fixture = Path(tempfile.mkdtemp(prefix='rmgu-susfs-redirect-statfs.', dir=str(Path.home())))
    helper = fixture / 'root-helper.py'; helper.write_text(ROOT_HELPER); helper.chmod(0o600)
    device_directory = '/dev/' + fixture.name
    contents = {'target': b'RMGU-statfs-original\n', 'source_control': b'RMGU-statfs-source-control\n',
                'destination': b'RMGU-statfs-redirected\n', 'destination_control': b'RMGU-statfs-destination-control\n'}
    config = {'fixture': str(fixture), 'device_directory': device_directory,
              'uid': os.geteuid(), 'gid': os.getegid(), 'subject': subject,
              'paths': {'target': str(fixture / 'target.txt'), 'source_control': str(fixture / 'control.txt'),
                        'destination': device_directory + '/redirected.txt',
                        'destination_control': device_directory + '/control.txt'},
              'contents': {name: value.hex() for name, value in contents.items()},
              'missing': str(fixture / 'missing.txt')}
    for name in ('target', 'source_control'):
        path = Path(config['paths'][name]); path.write_bytes(contents[name]); path.chmod(0o600)
    client = RootClient(helper, subject); held = {}; setup_attempted = False; controls_attempted = False
    receipt = {'runner_revision': 2, 'checkpoint': 21, 'config': config,
               'observations': {}, 'feature_controls_attempted': False, 'cleanup_complete': False}
    status = 'FAIL'; problem = None; cleanup_problem = None; problems = []
    try:
        state = client.call('state', config)
        config['original_rules'] = state['rules']; receipt['original_state'] = state
        print('Saved original redirect rules: ' + str(len(state['rules'])), flush=True)
        setup_attempted = True
        setup = client.call('setup', config)
        config['device_owned'] = setup['owned']; receipt['setup'] = setup
        if not setup['available']: raise FixtureBlocked('Owned /dev fixture unavailable: ' + str(setup['error']))
        labels = setup.get('labels', {})
        if set(labels) != {'directory', 'destination', 'destination_control'} or not all(
                value.get('verified') is True and value.get('bytes', 0) > 0 for value in labels.values()):
            raise FixtureBlocked('Owned fixture label verification receipt incomplete')
        print('FIXTURE LABELS: ' + json.dumps(labels, separators=(',', ':')), flush=True)
        # No feature write occurs until ordinary app access and a distinct-FS challenge pass.
        try:
            for name, path in config['paths'].items():
                fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC)
                try:
                    if os.pread(fd, 64, 0).hex() != config['contents'][name]:
                        raise RuntimeError('Fixture content mismatch: ' + name)
                finally:
                    os.close(fd)
            metadata = client.call('metadata', config); config.update(metadata)
            for name in ('target_before', 'source_control', 'destination_control'):
                path_name = 'target' if name == 'target_before' else name
                held[name] = os.open(config['paths'][path_name], os.O_RDONLY | os.O_CLOEXEC)
            pair = observe_pair(client, config, held, 'BASELINE')
            receipt['observations']['baseline'] = pair
            references = baseline_references(config, pair)
        except RootCommandUnknown:
            raise
        except (OSError, RuntimeError) as error:
            raise FixtureBlocked(str(error)) from error
        controls_attempted = True; receipt['feature_controls_attempted'] = True
        problems = run_cycles(client, config, held, references, receipt)
        if problems: raise RuntimeError('; '.join(problems))
        final = client.call('state', config)
        if final['rules'] != config['original_rules']: raise RuntimeError('Final rule table not restored')
        receipt['final_state'] = final
        print('FINAL REDIRECT DIAGNOSTICS: ' + final['diagnostics'], flush=True)
        status = 'PASS'
    except FixtureBlocked as error:
        status = 'BLOCKED'; problem = str(error)
    except (Exception, KeyboardInterrupt) as error:
        status = 'FAIL'; problem = '%s: %s' % (type(error).__name__, error)
    finally:
        for fd in held.values(): os.close(fd)
        held.clear()
        if not client.unknown:
            try:
                if controls_attempted: receipt['restored_state'] = restore_rules(client, config)
                if setup_attempted and 'device_owned' not in config:
                    raise RuntimeError('Setup ownership receipt unavailable; device fixture retained')
                if setup_attempted: receipt['device_cleanup'] = client.call('cleanup', config)
                receipt['cleanup_complete'] = True
            except (Exception, KeyboardInterrupt) as error:
                cleanup_problem = '%s: %s' % (type(error).__name__, error)
        else:
            cleanup_problem = 'Root outcome unknown; no further root/control commands sent. Fixtures retained.'
        if cleanup_problem: status = 'FAIL'
        receipt.update(result=status, error=problem, cleanup_error=cleanup_problem, root_outcome_unknown=client.unknown)
        (fixture / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    if cleanup_problem:
        status = 'FAIL'; print('CLEANUP UNQUALIFIED: ' + cleanup_problem, flush=True)
    elif status == 'PASS':
        try:
            source_cleanup(config, helper)
            print('Cleanup complete; descriptors closed, owned rule list restored, fixture names removed.', flush=True)
        except Exception as error:
            status = 'FAIL'; problem = str(error)
            receipt.update(result='FAIL', error=problem, cleanup_complete=False)
            if fixture.is_dir(): (fixture / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    if status != 'PASS':
        print('RETAINED EVIDENCE: ' + str(fixture), flush=True)
        print('Device fixture path: ' + device_directory, flush=True)
        print(status + ': ' + (problem or cleanup_problem or 'No complete filesystem qualification'), flush=True)
        print('Feature controls attempted: ' + str(controls_attempted), flush=True)
        return 2 if status == 'BLOCKED' else 1
    print('PASS: native statfs/fstatfs stable fields across distinct filesystems, redirected content, '
          'held/fresh and proc-fd views, root/control/error preservation, two cycles, exact rule restoration and cleanup.', flush=True)
    print('Scope: native AArch64 proc scheme 3 and owned stable files. Free-space/file counts are recorded but '
          'not compared exactly. Compat, supercalls, other UID schemes, redirect maps identity, concurrency, '
          'unloading and long-run stability remain unqualified.', flush=True)
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (Exception, KeyboardInterrupt) as error:
        print('FAIL: %s: %s' % (type(error).__name__, error), flush=True)
        raise SystemExit(1)
