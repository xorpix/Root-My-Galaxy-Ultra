#!/usr/bin/env python3
"""CP17 SM-S948B BZIG uname and log-control assertion test.

Run from ordinary Termux: su -c 'cat /sdcard/Download/rmgu-susfs-identity-test-cp17.py' | python -u
Recover a retained snapshot with: python -u - --recover /absolute/saved/fixture
Only temporary uname release/version and log flags are changed. Original
settings are saved before the first write and restored with readback. Bootconfig
is read-only and AVC controls are untouched. Uname applies to app AND root readers.
Kernel message suppression, probe unloading and bootconfig spoofing are not
qualified by this test. No os.getxattr dependency or external Python package.
"""
import argparse
import base64
import ctypes as ct
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import tempfile

KERNEL = '6.12.69-android16-6-pb4d3caf-abogkiS948BXXS4BZIG-4k'
ROOT_TIMEOUT = 30
PARAMS = '/sys/module/susfs_guard_lkm/parameters/'
LOG = '/proc/susfs_enable_log'
FIELDS = ('sysname', 'nodename', 'release', 'version', 'machine', 'domainname')

class ManagementUnknown(RuntimeError):
    pass

# The root helper uses the exact CP17 susfs_abi.h layouts: uname 136 bytes,
# err offset 132; bool payload 8 bytes, err offset 4. No reboot command is sent:
# the custom magic numbers are the SusFS control protocol.
HELPER = r'''
import ctypes as ct
import hashlib
import json
import os
from pathlib import Path
import sys
import base64

PARAMS = '/sys/module/susfs_guard_lkm/parameters/'
LOG = '/proc/susfs_enable_log'
FIELDS = ('sysname', 'nodename', 'release', 'version', 'machine', 'domainname')

class Uts(ct.Structure):
    _fields_ = [(name, ct.c_char * 65) for name in FIELDS]
class UnamePayload(ct.Structure):
    _fields_ = [('release', ct.c_char * 65), ('version', ct.c_char * 65), ('err', ct.c_int)]
class BoolPayload(ct.Structure):
    _fields_ = [('enabled', ct.c_bool), ('err', ct.c_int)]
class QueryPayload(ct.Structure):
    _fields_ = [('value', ct.c_char * 16), ('err', ct.c_int)]

def layout_check():
    if (ct.sizeof(Uts), ct.sizeof(UnamePayload), UnamePayload.err.offset,
        ct.sizeof(BoolPayload), BoolPayload.err.offset, ct.sizeof(QueryPayload),
        QueryPayload.err.offset) != (390,136,132,8,4,20,16):
        raise RuntimeError('Unexpected native ctypes ABI layout')

def uname():
    libc = ct.CDLL(None, use_errno=True)
    libc.uname.argtypes = [ct.POINTER(Uts)]
    libc.uname.restype = ct.c_int
    value = Uts()
    ct.set_errno(0)
    if libc.uname(ct.byref(value)):
        raise OSError(ct.get_errno(), 'uname')
    return {name:bytes(getattr(value,name)).decode('utf-8') for name in FIELDS}

def control(command, value, expected=0):
    value.err = 126
    libc = ct.CDLL(None, use_errno=True)
    libc.syscall.restype = ct.c_long
    ct.set_errno(0)
    result = libc.syscall(ct.c_long(142), ct.c_uint(0xDEADBEEF),
                          ct.c_uint(0xFAFAFAFA), ct.c_uint(command), ct.byref(value))
    error = ct.get_errno() if result < 0 else 0
    reply = {'syscall':int(result), 'errno':error, 'reply':value.err}
    if result != 0 or value.err != expected:
        raise RuntimeError('SusFS control 0x%x: %s, expected reply %d' % (command,reply,expected))
    return reply

def read_value(path):
    # Remove the getter's one newline, preserving bytes in the stored string.
    text = Path(path).read_bytes().decode('utf-8')
    return text[:-1] if text.endswith('\n') else text

def boolean(text):
    if text in ('Y','1'): return True
    if text in ('N','0'): return False
    raise RuntimeError('Invalid boolean state: '+repr(text))

def fingerprint(path):
    try:
        data = Path(path).read_bytes()
        return {'errno':0,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    except OSError as error:
        return {'errno':error.errno}

def state():
    proc_log = read_value(LOG)
    module_log = boolean(read_value(PARAMS+'enable_log'))
    if proc_log not in ('0','1') or (proc_log=='1') != module_log:
        raise RuntimeError('Proc and parameter log states disagree')
    return {'uid':os.geteuid(), 'uname':uname(), 'settings':{
        'release':read_value(PARAMS+'release'),
        'version':read_value(PARAMS+'version'),
        'uname_enabled':boolean(read_value(PARAMS+'uname_spoof_enabled')),
        'log_enabled':module_log},
        'bootconfig':fingerprint('/proc/bootconfig'),
        'cmdline':fingerprint('/proc/cmdline')}

def write(path, data):
    encoded = data.encode('utf-8') if isinstance(data,str) else data
    if not isinstance(encoded,bytes) or not encoded:
        raise RuntimeError('Control writes must contain at least one byte: '+path)
    fd = os.open(path, os.O_WRONLY)
    try:
        n = os.write(fd, encoded)
        if n != len(encoded): raise RuntimeError('Short control write: '+path)
    finally:
        os.close(fd)

def validate_settings(settings):
    if not isinstance(settings,dict) or set(settings) != {'release','version','uname_enabled','log_enabled'}:
        raise RuntimeError('Invalid saved settings fields')
    for field in ('release','version'):
        value = settings[field]
        if not isinstance(value,str) or '\0' in value or '\n' in value or '\r' in value or len(value.encode('utf-8'))>64:
            raise RuntimeError('Original uname setting cannot be restored exactly: '+field)
    if type(settings['uname_enabled']) is not bool or type(settings['log_enabled']) is not bool:
        raise RuntimeError('Saved flags must be booleans')
    if settings['uname_enabled']:
        raise RuntimeError('Existing uname spoofing is enabled; no settings were changed')

def settings_diff(expected, observed):
    return {field:{'expected':expected.get(field),'observed':observed.get(field)}
            for field in sorted(set(expected)|set(observed))
            if field not in expected or field not in observed or expected[field] != observed[field]}

def write_string_parameter(path, value):
    # module_param_string copies the C string literally. A newline is data.
    # A NUL byte represents an empty C string in an explicit nonempty write.
    encoded = value.encode('utf-8')
    if b'\0' in encoded or len(encoded)>64:
        raise RuntimeError('Invalid string parameter value: '+path)
    write(path,encoded+b'\0')

def restore_settings(original):
    validate_settings(original)
    failures = []
    try:
        write(PARAMS+'uname_spoof_enabled','0')
        if boolean(read_value(PARAMS+'uname_spoof_enabled')):
            raise RuntimeError('Uname spoofing did not disable')
    except Exception as error:
        failures.append(PARAMS+'uname_spoof_enabled: '+str(error))
    if not failures:
        for field in ('release','version'):
            try: write_string_parameter(PARAMS+field,original[field])
            except Exception as error: failures.append(PARAMS+field+': '+str(error))
    try: write(LOG,'1' if original['log_enabled'] else '0')
    except Exception as error: failures.append(LOG+': '+str(error))
    check = {'expected':original,'write_errors':failures}
    try:
        result = state()
        check['observed'] = result['settings']
        check['difference'] = settings_diff(original,result['settings'])
    except Exception as error:
        check['readback_error'] = str(error)
        print('RESTORE CHECK: '+json.dumps(check),file=sys.stderr,flush=True)
        raise RuntimeError('Restored settings could not be read back') from error
    if failures or check['difference']:
        print('RESTORE CHECK: '+json.dumps(check),file=sys.stderr,flush=True)
        raise RuntimeError('Restored settings differ from original or a restore write failed')
    result['restore_check'] = check
    return result

def action(name, args):
    layout_check()
    if os.geteuid() != 0: raise RuntimeError('Management helper is not UID 0')
    reply = None
    if name == 'preflight':
        query = QueryPayload()
        control(0x555e1, query)
        if bytes(query.value) != b'v2.3.0': raise RuntimeError('Unexpected SusFS version')
        diagnostics = Path(PARAMS+'map_stat').read_text()
        if 'route=kprobe' not in diagnostics or 'divert_checked=1' not in diagnostics:
            raise RuntimeError('CP17 module is required')
    elif name == 'uname':
        value = UnamePayload()
        for field in ('release','version'):
            encoded = args[field].encode('ascii')
            if len(encoded)>64 or b'\0' in encoded: raise RuntimeError('Invalid uname input')
            setattr(value,field,encoded)
        reply = control(0x55590,value,args.get('expected_reply',0))
    elif name == 'log_abi':
        reply = control(0x555a0,BoolPayload(bool(args['enabled']),126))
    elif name == 'log_proc':
        write(LOG,'1' if args['enabled'] else '0')
    elif name == 'invalid_log':
        try: write(LOG,'x')
        except OSError as error:
            if error.errno != 22: raise
            reply = {'errno':error.errno}
        else: raise RuntimeError('Invalid log value was accepted')
    elif name == 'restore':
        return restore_settings(args['settings'])
    elif name != 'state':
        raise RuntimeError('Unknown action')
    result = state()
    if reply is not None: result['control_reply'] = reply
    return result

if __name__ == '__main__':
    try:
        result = action(sys.argv[1],json.loads(base64.b64decode(sys.argv[2])))
        print(json.dumps(result),flush=True)
    except Exception as error:
        print(type(error).__name__+': '+str(error),file=sys.stderr,flush=True)
        sys.exit(1)
'''

APP = {}
exec(HELPER.split("if __name__ == '__main__':",1)[0], APP)

def root(command):
    with tempfile.TemporaryFile(mode='w+t') as output, tempfile.TemporaryFile(mode='w+t') as error:
        process = subprocess.Popen(['su','-c',command], stdin=subprocess.DEVNULL,
            stdout=output, stderr=error, text=True, start_new_session=True)
        try:
            process.wait(timeout=ROOT_TIMEOUT)
        except (subprocess.TimeoutExpired, KeyboardInterrupt) as cause:
            try: process.kill()
            except (ProcessLookupError, PermissionError): pass
            try: process.wait(timeout=1)
            except subprocess.TimeoutExpired: pass
            raise ManagementUnknown('Root command did not complete; no further controls will be sent. '
                'Retain the saved settings and reboot before retrying.') from cause
        output.seek(0)
        error.seek(0)
        if process.returncode:
            raise RuntimeError('Root command failed (%d): %s' % (process.returncode,error.read().strip()))
        return output.read()

def call(helper, name, args=None):
    print('ROOT '+name.upper(),flush=True)
    encoded = base64.b64encode(json.dumps(args or {}).encode()).decode()
    argv = ['/system/bin/toybox','nsenter','-t',str(os.getpid()),'-m',
            sys.executable,str(helper),name,encoded]
    result = json.loads(root(' '.join(shlex.quote(part) for part in argv)))
    if result['uid'] != 0: raise RuntimeError('Root reader is not UID 0')
    return result

def check_uname(expected, label, root_state):
    observed = APP['uname']()
    print(label+': '+json.dumps({'app':observed,'root':root_state['uname']}),flush=True)
    if observed != expected or root_state['uname'] != expected:
        raise RuntimeError(label+' uname differs from the chosen values or changes unrelated fields')

def validate_original(original):
    if not isinstance(original,dict) or type(original.get('uid')) is not int or original['uid'] != 0:
        raise RuntimeError('Snapshot is not an original root state')
    APP['validate_settings'](original.get('settings'))
    value = original.get('uname')
    if not isinstance(value,dict) or set(value) != set(FIELDS):
        raise RuntimeError('Invalid saved uname fields')
    if any(not isinstance(value[field],str) or '\0' in value[field] or len(value[field].encode('utf-8'))>64 for field in FIELDS):
        raise RuntimeError('Invalid saved uname value')
    if value['release'] != KERNEL or value['machine'] != 'aarch64':
        raise RuntimeError('Saved snapshot is not from the SM-S948B BZIG kernel')
    for field in ('bootconfig','cmdline'):
        fp = original.get(field)
        if not isinstance(fp,dict) or type(fp.get('errno')) is not int or fp['errno']<0:
            raise RuntimeError('Invalid saved fingerprint: '+field)
        if fp['errno'] == 0:
            digest = fp.get('sha256')
            if set(fp) != {'errno','bytes','sha256'} or type(fp.get('bytes')) is not int or fp['bytes']<0 or not isinstance(digest,str) or len(digest)!=64 or any(c not in '0123456789abcdef' for c in digest):
                raise RuntimeError('Invalid saved fingerprint: '+field)
        elif set(fp) != {'errno'}:
            raise RuntimeError('Invalid saved fingerprint: '+field)

def verify_restore(original, restored, label='RESTORED'):
    difference = APP['settings_diff'](original['settings'],restored['settings'])
    print(label+' SETTINGS: '+json.dumps({'expected':original['settings'],
        'observed':restored['settings'],'difference':difference}),flush=True)
    if difference: raise RuntimeError('Restored settings mismatch: '+json.dumps(difference))
    check_uname(original['uname'],label,restored)
    for field in ('bootconfig','cmdline'):
        if restored[field] != original[field]:
            raise RuntimeError(field+' read-only fingerprint differs from the saved snapshot')

def save_json(path, value):
    path.write_text(json.dumps(value,indent=2)+'\n')
    path.chmod(0o600)

def make_helper(prefix):
    fixture = Path(tempfile.mkdtemp(prefix=prefix,dir=os.getcwd()))
    helper = fixture/'root-reader.py'
    helper.write_text(HELPER)
    helper.chmod(0o600)
    return fixture,helper

def remove_fixture(fixture):
    for path in fixture.iterdir(): path.unlink()
    fixture.rmdir()

def app_preflight(recovery=False):
    if os.geteuid() < 10000: raise RuntimeError('Run from ordinary Termux, outside a root shell')
    if os.uname().machine != 'aarch64' or (not recovery and os.uname().release != KERNEL):
        raise RuntimeError('This runner requires the SM-S948B BZIG kernel with uname spoofing disabled')
    APP['layout_check']()
    print('Identity runner revision: 2 (CP17 exact string restoration and snapshot recovery)',flush=True)
    print('App reader: '+subprocess.check_output(['id'],text=True).strip(),flush=True)

def recover(directory):
    app_preflight(recovery=True)
    source = Path(directory).expanduser()
    if not source.is_absolute(): raise RuntimeError('Recovery requires an absolute saved fixture path')
    source = source.resolve(strict=True)
    snapshot = source/'original-settings.json'
    if not source.is_dir() or snapshot.stat().st_size>65536:
        raise RuntimeError('Invalid saved fixture')
    original = json.loads(snapshot.read_bytes().decode('utf-8'))
    validate_original(original)
    fixture,helper = make_helper('rmgu-susfs-identity-recovery.')
    save_json(fixture/'original-settings.json',original)
    verified = False
    unknown = False
    attempted = False
    try:
        print('RECOVERY SOURCE: '+str(snapshot),flush=True)
        current = call(helper,'preflight')
        save_json(source/'recovery-before.json',current)
        print('RECOVERY BEFORE: '+json.dumps(current),flush=True)
        print('RECOVERY DIFFERENCE: '+json.dumps(APP['settings_diff'](original['settings'],current['settings'])),flush=True)
        for field in ('sysname','nodename','machine','domainname'):
            if current['uname'][field] != original['uname'][field]:
                raise RuntimeError('Saved and current '+field+' differ; no restoration writes were sent')
        if not current['settings']['uname_enabled'] and current['uname'] != original['uname']:
            raise RuntimeError('Native uname differs from the saved snapshot; no restoration writes were sent')
        for field in ('bootconfig','cmdline'):
            if current[field] != original[field]:
                raise RuntimeError(field+' fingerprint differs from the saved snapshot; no restoration writes were sent')
        if current['settings'] == original['settings']:
            restored = current
            print('Saved settings already match; no restoration writes are needed.',flush=True)
        else:
            attempted = True
            restored = call(helper,'restore',{'settings':original['settings']})
        verify_restore(original,restored,'RECOVERY RESTORED')
        save_json(source/'recovery-verified.json',{'runner_revision':2,'verified':True,
            'restore_writes_sent':attempted,'original':original,'restored':restored})
        verified = True
    except ManagementUnknown:
        unknown = True
        raise
    finally:
        if verified:
            remove_fixture(fixture)
        elif unknown or attempted:
            print('RETAINED RECOVERY FIXTURE: '+str(fixture),flush=True)
        else:
            remove_fixture(fixture)
        print('Original snapshot retained: '+str(snapshot),flush=True)
        if unknown:
            print('Root command completion is unknown. Reboot before any further control writes.',flush=True)
    print('RECOVERY PASS: exact saved settings, app/root uname and read-only fingerprints verified.',flush=True)
    print('Recovery performed no spoof tests. The saved fixture and verification receipt are retained.',flush=True)

def exercise(helper, original):
    base = original['uname']
    for index, logging in ((1,True),(2,False)):
        response = call(helper,'log_abi',{'enabled':logging})
        if response['settings']['log_enabled'] != logging:
            raise RuntimeError('Log supercall did not change both state views')
        suffix = '-r%d%x' % (index,os.getpid())
        chosen = dict(base, release=base['release'][:64-len(suffix)]+suffix,
                      version='RMGU CP17 uname test %d %d' % (os.getpid(),index))
        print('SET UNAME '+str(index)+' (global app/root view)',flush=True)
        response = call(helper,'uname',{'release':chosen['release'],'version':chosen['version']})
        if not response['settings']['uname_enabled']:
            raise RuntimeError('Uname control did not enable spoofing')
        check_uname(chosen,'ACTIVE '+str(index),response)
    before = response['settings']
    response = call(helper,'uname',{'release':'','version':'RMGU rejected test','expected_reply':-22})
    if response['settings'] != before: raise RuntimeError('Rejected uname changed settings')
    check_uname(chosen,'AFTER REJECTED UNAME',response)
    print('SET UNAME DEFAULT',flush=True)
    response = call(helper,'uname',{'release':'default','version':'default'})
    check_uname(base,'DEFAULT',response)
    for enabled in (True,False):
        response = call(helper,'log_proc',{'enabled':enabled})
        if response['settings']['log_enabled'] != enabled:
            raise RuntimeError('Log proc write did not change both state views')
    before = response['settings']
    response = call(helper,'invalid_log')
    if response['settings'] != before: raise RuntimeError('Rejected log input changed settings')

def run():
    app_preflight()
    fixture,helper = make_helper('rmgu-susfs-identity.')
    original = None
    attempted = False
    unknown = False
    unverified = False
    problem = None
    try:
        original = call(helper,'preflight')
        validate_original(original)
        snapshot = fixture/'original-settings.json'
        save_json(snapshot,original)
        print('SAVED ORIGINAL: '+json.dumps(original),flush=True)
        check_uname(original['uname'],'BASELINE',original)
        attempted = True
        exercise(helper,original)
    except ManagementUnknown as error:
        unknown = True
        problem = error
    except (Exception,KeyboardInterrupt) as error:
        problem = error
    finally:
        if attempted and not unknown:
            try:
                restored = call(helper,'restore',{'settings':original['settings']})
                verify_restore(original,restored)
                print('Exact original uname and log settings restored and verified.',flush=True)
            except ManagementUnknown as error:
                unknown = True
                problem = error
            except (Exception,KeyboardInterrupt) as error:
                unverified = True
                problem = RuntimeError('Restoration could not be verified: '+str(error))
        if unknown or unverified:
            print('RETAINED FIXTURE: '+str(fixture),flush=True)
            if unknown:
                print('Root command completion is unknown. Keep the fixture and reboot before further control writes.',flush=True)
            else:
                print('Restoration is unqualified. Keep original-settings.json; use --recover with this fixture.',flush=True)
        else:
            remove_fixture(fixture)
            print('Cleanup complete; test helper and saved snapshot removed.',flush=True)
    if problem: raise problem
    print('PASS: uname spoofing in app/root, default values, log flag roundtrips, invalid-value rejection, '
          'exact setting restoration and cleanup.',flush=True)
    print('Scope: log state is tested; kernel message suppression and probe unloading are unqualified. '
          'Bootconfig and AVC settings were not written.',flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='CP17 identity test or exact saved-settings recovery')
    parser.add_argument('--recover',metavar='SAVED_FIXTURE',help='restore a retained original-settings.json without spoof tests')
    args = parser.parse_args()
    try:
        if args.recover: recover(args.recover)
        else: run()
    except (Exception,KeyboardInterrupt) as error:
        print('\nFAIL: '+str(error),flush=True)
        sys.exit(1)
