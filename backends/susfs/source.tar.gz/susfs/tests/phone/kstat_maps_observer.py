"""Observer embedded into the standalone CP20 phone runner and its root helper.

NativeStat is supplied by the qualified native runner support. This module only
reads existing proc files and the owned fixture; it sends no feature controls.
"""
import ctypes as ct
import json
import os
from pathlib import Path
import re

HEADER = re.compile(r'^([0-9a-f]+)-([0-9a-f]+) ([r-][w-][x-][ps]) '
                    r'([0-9a-f]+) ([0-9a-f]+):([0-9a-f]+) ([0-9]+)([ \t]*)(.*)$')
TABLE_LIMIT = 8 * 1024 * 1024


def process_identity(pid):
    directory = Path('/proc') / str(pid)
    stat = (directory / 'stat').read_text()
    suffix = stat[stat.rfind(')') + 2:].split()
    if not stat.startswith(str(pid) + ' (') or len(suffix) < 20:
        raise RuntimeError('Subject process stat is not recognized')
    status = (directory / 'status').read_text()
    match = re.search(r'^Uid:\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s*$', status, re.M)
    if not match: raise RuntimeError('Subject process UID is unavailable')
    return {'pid': int(pid), 'starttime': int(suffix[19]),
            'uids': list(map(int, match.groups())),
            'context': (directory / 'attr/current').read_text().rstrip('\0\n'),
            'mount_namespace': os.readlink(directory / 'ns/mnt')}


def read_table(path, chunk):
    fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC)
    parts = []; count = 0
    try:
        while True:
            part = os.read(fd, chunk)
            if not part: break
            count += len(part)
            if count > TABLE_LIMIT: raise RuntimeError('Proc table exceeded the bounded byte limit')
            parts.append(part)
    finally:
        os.close(fd)
    return b''.join(parts).decode('utf-8', errors='surrogateescape')


def parse_header(line):
    match = HEADER.fullmatch(line)
    if not match: return None
    return {'start': int(match[1], 16), 'end': int(match[2], 16),
            'perms': match[3], 'offset': int(match[4], 16),
            'major': int(match[5], 16), 'minor': int(match[6], 16),
            'dev': os.makedev(int(match[5], 16), int(match[6], 16)),
            'ino': int(match[7]), 'gap': match[8], 'path': match[9],
            'prefix': line[:match.start(5)],
            'identity_text': line[match.start(5):match.end(7)], 'raw': line}


def selected_rows(text, payload, table):
    headers = []
    for line in text.splitlines():
        row = parse_header(line)
        if row: headers.append(row)
        elif table == 'maps' and line:
            raise RuntimeError('Malformed maps row')
    files = set(payload['paths'].values())
    known = {(slot['start'], slot['end']) for slot in payload['slots'].values()}
    rows = [row for row in headers if row['path'] in files or (row['start'], row['end']) in known]
    result = {}
    for name, slot in payload['slots'].items():
        matches = [row for row in rows if (row['start'], row['end']) == (slot['start'], slot['end'])]
        if len(matches) != 1:
            raise RuntimeError('%s %s expected one owned range header, got %d' % (table, name, len(matches)))
        result[name] = matches[0]
    if len(rows) != len(payload['slots']):
        raise RuntimeError(table + ' has extra or duplicate owned mapping headers')
    return result


def observe_subject(payload, held=None):
    before = process_identity(payload['subject']['pid'])
    if before != payload['subject']: raise RuntimeError('Owned subject identity changed before observation')
    directory = Path('/proc/self') if before['pid'] == os.getpid() else Path('/proc') / str(before['pid'])
    views = {}
    for table in ('maps', 'smaps'):
        for style, chunk in (('full', 65536), ('small', 127)):
            text = read_table(directory / table, chunk)
            views[table + '_' + style] = selected_rows(text, payload, table)
    native = NativeStat()
    files = {}; opened = []
    try:
        for name, path in payload['paths'].items():
            if held is None:
                fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC); opened.append(fd)
            else: fd = held[name]
            files[name] = {
                'fstat': native.call('fstat', ct.c_int(fd)),
                'statx': native.call('statx', ct.c_int(-100), ct.c_char_p(os.fsencode(path)),
                                     ct.c_int(0), ct.c_uint(0x7ff), mask=0x7ff)}
    finally:
        for fd in opened: os.close(fd)
    after = process_identity(before['pid'])
    if after != before: raise RuntimeError('Owned subject identity changed during observation')
    return {'reader_uid': os.geteuid(), 'subject': before, 'views': views, 'files': files}
