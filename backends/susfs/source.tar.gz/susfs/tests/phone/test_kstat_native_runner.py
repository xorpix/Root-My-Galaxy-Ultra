import copy
import importlib.util
import io
import json
import os
from pathlib import Path
import shlex
import struct
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('native_runner', Path(__file__).with_name('rmgu-susfs-kstat-native-test.py'))
r = importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
format_spec = importlib.util.spec_from_file_location('control_format', Path(__file__).with_name('kstat_control_format.py'))
control_format = importlib.util.module_from_spec(format_spec); format_spec.loader.exec_module(control_format)


def control_text(rules=(), cp20=True):
    marker = r.STATX_DIAGNOSTIC + '\n' if cp20 else ''
    return '\n'.join(list(rules) or ['(empty)']) + '\n' + marker + 'maps: armed=1 hits=0 rewrites=0\n' + '\n'.join(
        'stat nr %-16s (%d): ok=10 rw=0 | err=0 nobuf=0 empty=10 gate=0 lookup=0 noflag=0 uacc=0' % (name, nr)
        for name, nr in (('newfstatat', 79), ('fstat', 80), ('statx', 291))) + '\n'


class NativeHostTests(unittest.TestCase):
    def test_cp19_is_rejected_before_creating_or_writing_fixture(self):
        with patch.object(r.os, 'geteuid', return_value=10362), \
             patch.object(r.os, 'uname', return_value=SimpleNamespace(machine='aarch64', release=r.KERNEL)), \
             patch.object(r.subprocess, 'check_output', return_value='uid=10362'), \
             patch.object(r, 'root', side_effect=['map_metadata: checkpoint=19 ready=1\n', control_text(cp20=False)]) as root, \
             patch.object(r, 'run_fixture') as fixture, patch('sys.stdout', new_callable=io.StringIO):
            with self.assertRaisesRegex(RuntimeError, 'CP20 statx correction unavailable'): r.main()
            fixture.assert_not_called()
            self.assertEqual(['cat ' + r.MAP_STATS, 'cat ' + r.CONTROL], [call.args[0] for call in root.call_args_list])

    def test_cp20_marker_allows_same_native_assertions_and_owned_rule_workflow(self):
        text = control_text()
        with patch.object(r.os, 'geteuid', return_value=10362), \
             patch.object(r.os, 'uname', return_value=SimpleNamespace(machine='aarch64', release=r.KERNEL)), \
             patch.object(r.subprocess, 'check_output', return_value='uid=10362'), \
             patch.object(r, 'root', side_effect=['map_metadata: checkpoint=19 ready=1\n', text]), \
             patch.object(r, 'run_fixture') as fixture, patch('sys.stdout', new_callable=io.StringIO):
            r.main(); fixture.assert_called_once_with([])

    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(); self.addCleanup(self.directory.cleanup)
        self.paths = {name: Path(self.directory.name) / (name + '.txt') for name in ('target', 'control')}
        for name, path in self.paths.items(): path.write_text('native ' + name + '\n')
        self.held = {name: os.open(path, os.O_RDONLY) for name, path in self.paths.items()}
        self.addCleanup(lambda: [os.close(fd) for fd in self.held.values()])

    def sample(self): return r.observe(self.paths, self.held)

    def test_real_syscalls_match_native_stat_fields_and_preserve_guards(self):
        value = self.sample()
        for name, methods in value['files'].items():
            real = r.os_fields(os.fstat(self.held[name]))
            for method, row in methods.items():
                self.assertEqual(0, row['errno'], method); self.assertTrue(row['buffer_guards'])
                for key, expected in real.items():
                    if 'mask' in row['fields'] and key in ('atime_ns', 'mtime_ns', 'ctime_ns'):
                        bit = {'atime_ns': 32, 'mtime_ns': 64, 'ctime_ns': 128}[key]
                        if not row['fields']['mask'] & bit: continue
                    self.assertEqual(expected, row['fields'][key], method + ' ' + key)

    def test_real_fd_and_missing_path_errors(self):
        self.assertEqual({'invalid_fstat': 9, 'invalid_empty_statx': 9, 'missing_path': 2},
                         {key: row['errno'] for key, row in self.sample()['negative'].items()})

    def test_held_fd_identifies_open_file_after_path_replacement(self):
        before = os.fstat(self.held['target'])
        self.paths['target'].unlink(); self.paths['target'].write_text('replacement content longer\n')
        methods = self.sample()['files']['target']
        self.assertEqual(before.st_ino, methods['fstat_held']['fields']['ino'])
        self.assertNotEqual(before.st_ino, methods['fstat_fresh']['fields']['ino'])
        self.assertEqual(before.st_size, methods['statx_held_empty']['fields']['size'])
        self.assertNotEqual(before.st_size, methods['statx_path']['fields']['size'])

    def test_real_readers_and_complete_baseline_are_accepted(self):
        app = self.sample(); app['uid'] = 10362
        root = self.sample(); root['uid'] = 0
        real = {name: r.os_fields(os.fstat(fd)) for name, fd in self.held.items()}
        r.require_baseline(app, root, real)

    def test_leak_in_only_held_fstat_is_detected(self):
        before = self.sample(); now = copy.deepcopy(before)
        chosen = {'ino': before['files']['target']['fstat_held']['fields']['ino'] + 100, 'size': 12345}
        for row in now['files']['target'].values(): row['fields'].update(chosen)
        now['files']['target']['fstat_held'] = copy.deepcopy(before['files']['target']['fstat_held'])
        issues = r.assess(before, now, chosen, 'ACTIVE')
        self.assertTrue(any('fstat_held ino' in message for message in issues))

    def test_statx_size_leak_mask_and_unrelated_field_changes_fail(self):
        before = self.sample(); now = copy.deepcopy(before)
        chosen = {'ino': 123456789, 'size': 54321}
        for row in now['files']['target'].values(): row['fields'].update(chosen)
        now['files']['target']['statx_path']['fields']['size'] = before['files']['target']['statx_path']['fields']['size']
        now['files']['target']['statx_path']['fields']['mask'] ^= 0x200
        now['files']['control']['fstat_fresh']['fields']['gid'] += 1
        messages = r.assess(before, now, chosen, 'ACTIVE')
        for needle in ('statx_path size', 'statx_path mask', 'control fstat_fresh gid'):
            self.assertTrue(any(needle in message for message in messages), needle)

    def test_root_spoof_and_restoration_failure_are_detected(self):
        before = self.sample(); now = copy.deepcopy(before)
        for row in now['files']['target'].values(): row['fields']['ino'] += 1
        self.assertTrue(r.assess(before, now, None, 'ROOT'))
        self.assertTrue(r.assess(before, now, None, 'RESTORED'))

    def test_error_contract_change_is_detected(self):
        before = self.sample(); now = copy.deepcopy(before)
        now['negative']['invalid_fstat']['errno'] = 14
        self.assertTrue(any('error contract' in message for message in r.assess(before, now, None, 'ACTIVE')))

    def test_blocked_required_statx_baseline_stops_before_mutation(self):
        app = self.sample(); app['uid'] = 10362; privileged = self.sample(); privileged['uid'] = 0
        app['files']['target']['statx_path'] = {'errno': 13, 'returncode': -1}
        real = {name: r.os_fields(os.fstat(fd)) for name, fd in self.held.items()}
        with self.assertRaisesRegex(RuntimeError, 'no rules changed'): r.require_baseline(app, privileged, real)


class AbiTests(unittest.TestCase):
    def test_write_outside_stat_payload_is_detected(self):
        native = r.NativeStat()
        class CorruptingLibc:
            def syscall(self, nr, *args):
                r.ct.c_ubyte.from_address(args[-1].value - 1).value = ord('X')
                return 0
        native.libc = CorruptingLibc()
        with self.assertRaisesRegex(RuntimeError, 'guard changed'): native.fstat(10)

    def test_aarch64_layout_keeps_64bit_inode_size_and_times(self):
        raw = bytearray(128)
        struct.pack_into('<QQIIIIQ', raw, 0, 0xabc, 0x12345678abcdef12, 0o100600, 7, 10362, 100, 3)
        struct.pack_into('<qiiq', raw, 48, 0x1234567890, 4096, 0, 128)
        struct.pack_into('<qQqQqQ', raw, 72, 200, 300, 400, 500, 600, 700)
        value = r.decode_stat(raw, 'aarch64')
        self.assertEqual(0x12345678abcdef12, value['ino']); self.assertEqual(0x1234567890, value['size'])
        self.assertEqual(0o100600, value['mode']); self.assertEqual(7, value['nlink'])
        self.assertEqual(10362, value['uid']); self.assertEqual(400000000500, value['mtime_ns'])

    def test_statx_devices_and_mount_id_use_distinct_offsets(self):
        raw = bytearray(256)
        struct.pack_into('<I', raw, 0, 0x17ff); struct.pack_into('<QQ', raw, 32, 0xabcdef0123456789, 0x123456789)
        struct.pack_into('<IIIIQ', raw, 128, 1, 2, 254, 81, 9999)
        value = r.decode_statx(raw)
        self.assertEqual(os.makedev(254, 81), value['dev']); self.assertEqual(os.makedev(1, 2), value['rdev'])
        self.assertEqual(9999, value['mnt_id']); self.assertEqual(0xabcdef0123456789, value['ino'])

    def test_control_has_only_inode_and_size_flags_and_preserves_other_rules(self):
        value = r.command('add', '/data/test', 999, 8192).split()
        self.assertEqual(14, len(value)); self.assertEqual(['999', 'default', 'default', '8192'], value[2:6])
        original = ['/data/other ino=1 dev=2 flags=0x9 [ino=3 dev=2 nlink=1 size=4 atime=0.0]']
        owned = '/data/test ino=101 dev=22 flags=0x9 [ino=999 dev=22 nlink=1 size=8192 atime=0.0]'
        rules, counters = r.parse_control(control_text(original + [owned]))
        r.verify_owned(rules, original, '/data/test', {'ino': 101, 'dev': 22}, 999, 8192)
        self.assertEqual({79, 80, 291}, set(counters))
        with self.assertRaisesRegex(RuntimeError, 'owned addition'):
            r.verify_owned([owned], original, '/data/test', {'ino': 101, 'dev': 22}, 999, 8192)

    def test_unsafe_proc_control_path_is_rejected(self):
        for value in ('/data/a b', '/data/a\nb', '/data/' + 'x' * 260):
            with self.assertRaises(RuntimeError): r.command('add', value, 10, 20)


class FakeControl:
    def __init__(self, fail=None, original=()):
        self.original = list(original); self.rules = self.original.copy()
        self.chosen = None; self.paths = None; self.writes = []; self.fail = fail
        self.original_observe = r.observe; self.made_unknown = False

    def rule(self, target):
        real = r.os_fields(os.stat(target))
        return str(target) + ' ino=%d dev=%d flags=0x9 [ino=%d dev=%d nlink=1 size=%d atime=0.0]' % (
            real['ino'], real['dev'], self.chosen['ino'], real['dev'], self.chosen['size'])

    def root(self, command):
        if self.made_unknown: raise AssertionError('Root command after unknown mutation')
        if command.startswith('cat '): return control_text(self.rules)
        tokens = shlex.split(command)
        if tokens[0] == 'printf':
            fields = tokens[2].split(); self.writes.append(fields[0]); target = fields[1]
            if fields[0] == 'add_sus_kstat_statically':
                if self.fail == 'add-return': raise RuntimeError('Returned ADD failure')
                if self.fail == 'add-unknown':
                    self.made_unknown = True; raise r.RootCommandUnknown('Modeled root timeout')
                self.chosen = {'ino': int(fields[2]), 'size': int(fields[5])}; self.rules = self.original + [self.rule(target)]
            elif fields[0] == 'del':
                self.chosen = None; self.rules = self.original.copy()
                if self.fail == 'foreign-rule': self.rules = ['/data/foreign ino=1 dev=2 flags=0x9 [ino=3 dev=2 nlink=1 size=4 atime=0.0]']
            else: raise AssertionError('Unexpected global mutation')
            return ''
        paths = json.loads(tokens[-1]); self.paths = paths
        with patch.object(r, 'observe', self.original_observe):
            value = r.root_observe(paths)
        value['uid'] = 0
        return json.dumps(value)

    def observe(self, paths, held):
        value = self.original_observe(paths, held); value['uid'] = 10362
        if self.chosen:
            for method, row in value['files']['target'].items():
                if self.fail == 'held-leak' and method == 'fstat_held': continue
                row['fields'].update(self.chosen)
        return value


class WorkflowTests(unittest.TestCase):
    def workflow(self, failure=None, original=()):
        owner = FakeControl(failure, original)
        with tempfile.TemporaryDirectory() as directory:
            previous = os.getcwd(); os.chdir(directory)
            try:
                with patch.object(r, 'root', owner.root), patch.object(r, 'observe', owner.observe), patch('sys.stdout', new=io.StringIO()) as output:
                    if failure:
                        with self.assertRaises((RuntimeError, r.RootCommandUnknown)): r.run_fixture(list(original))
                    else: r.run_fixture(list(original))
                retained = list(Path(directory).glob('rmgu-susfs-kstat-native.*'))
                if failure in ('add-unknown', 'foreign-rule'):
                    self.assertEqual(1, len(retained)); self.assertTrue((retained[0] / 'original-rules.json').exists())
                    self.assertTrue((retained[0] / 'observations.json').exists())
                    self.assertNotIn('Cleanup complete', output.getvalue())
                else:
                    self.assertEqual([], retained); self.assertIn('Cleanup complete', output.getvalue())
                return owner.writes, output.getvalue()
            finally: os.chdir(previous)

    def test_two_updates_restore_and_remove_only_owned_rules(self):
        writes, output = self.workflow()
        self.assertEqual(['add_sus_kstat_statically', 'del'] * 2, writes); self.assertIn('PASS:', output)

    def test_two_cycles_preserve_nonempty_original_rule_list(self):
        original = ['/data/other ino=1 dev=2 flags=0x9 [ino=3 dev=2 nlink=1 size=4 atime=0.0]']
        writes, output = self.workflow(original=original)
        self.assertEqual(['add_sus_kstat_statically', 'del'] * 2, writes)
        self.assertIn(original[0], output); self.assertIn('exact original list verified', output)

    def test_held_descriptor_leak_reports_failure_after_cleanup(self): self.workflow('held-leak')

    def test_returned_add_error_cleans_fixture_and_keeps_original_list(self):
        writes, _ = self.workflow('add-return'); self.assertEqual(['add_sus_kstat_statically'], writes)

    def test_unknown_add_never_sends_cleanup_controls(self):
        writes, _ = self.workflow('add-unknown'); self.assertEqual(['add_sus_kstat_statically'], writes)

    def test_restore_conflict_retains_recovery_data(self): self.workflow('foreign-rule')

    def test_root_wait_and_kill_reap_are_bounded(self):
        process = unittest.mock.Mock(); process.wait.side_effect = [r.subprocess.TimeoutExpired('su', 30), r.subprocess.TimeoutExpired('su', 1)]
        with patch.object(r.subprocess, 'Popen', return_value=process):
            with self.assertRaises(r.RootCommandUnknown): r.root('read-only')
        self.assertEqual([unittest.mock.call(timeout=30), unittest.mock.call(timeout=1)], process.wait.call_args_list)
        process.kill.assert_called_once()

    def test_interrupted_root_write_also_has_unknown_outcome(self):
        process = unittest.mock.Mock(); process.wait.side_effect = [KeyboardInterrupt(), r.subprocess.TimeoutExpired('su', 1)]
        with patch.object(r.subprocess, 'Popen', return_value=process):
            with self.assertRaises(r.RootCommandUnknown): r.root('owned write')
        self.assertEqual([unittest.mock.call(timeout=30), unittest.mock.call(timeout=1)], process.wait.call_args_list)
        process.kill.assert_called_once()


class ControlFormatTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.outputs = control_format.production_outputs()

    def test_actual_kernel_empty_output_separates_rules_marker_and_counters(self):
        text = self.outputs['empty']
        self.assertEqual(['(empty)', r.STATX_DIAGNOSTIC,
                          'maps: armed=1 hits=0 rewrites=0'], text.splitlines()[:3])
        rules, counters = r.parse_control(text)
        self.assertEqual([], rules); self.assertTrue({79, 80, 291}.issubset(counters))

    def test_actual_kernel_nonempty_output_preserves_exact_rule_rows(self):
        foreign, _ = r.parse_control(self.outputs['foreign'])
        self.assertEqual(['/data/other ino=1 dev=22 flags=0x9 [ino=3 dev=22 nlink=1 size=4 '
                          'atime=0.0 mtime=0.0 ctime=0.0 blocks=0 blksize=4096]'], foreign)
        combined, _ = r.parse_control(self.outputs['combined'])
        r.verify_owned(combined, foreign, '/data/test', {'ino': 101, 'dev': 22}, 999, 8192)
        self.assertEqual(foreign, combined[:1])

    def test_actual_kernel_output_reaches_fixture_without_preflight_writes(self):
        for name, expected in (('empty', []), ('foreign', r.parse_control(self.outputs['foreign'])[0])):
            with self.subTest(table=name), patch.object(r.os, 'geteuid', return_value=10362), \
                 patch.object(r.os, 'uname', return_value=SimpleNamespace(machine='aarch64', release=r.KERNEL)), \
                 patch.object(r.subprocess, 'check_output', return_value='uid=10362'), \
                 patch.object(r, 'root', side_effect=['map_metadata: checkpoint=19 ready=1\n', self.outputs[name]]) as root, \
                 patch.object(r, 'run_fixture') as fixture, patch('sys.stdout', new_callable=io.StringIO):
                r.main(); fixture.assert_called_once_with(expected)
                self.assertEqual(['cat ' + r.MAP_STATS, 'cat ' + r.CONTROL], [call.args[0] for call in root.call_args_list])

    def test_missing_or_wrong_marker_is_rejected(self):
        for replacement in ('', 'statx: checkpoint=19 device_pair=0 dev_bits=16 time_bits=32\n'):
            with self.subTest(marker=replacement), self.assertRaisesRegex(RuntimeError, 'boundary'):
                r.parse_control(self.outputs['empty'].replace(r.STATX_DIAGNOSTIC + '\n', replacement))

    def test_duplicate_or_misplaced_marker_is_rejected(self):
        text = self.outputs['empty']
        moved = text.replace(r.STATX_DIAGNOSTIC + '\n', '') + r.STATX_DIAGNOSTIC + '\n'
        for malformed in (text + r.STATX_DIAGNOSTIC + '\n', moved):
            with self.assertRaisesRegex(RuntimeError, 'boundary'): r.parse_control(malformed)

    def test_unknown_lines_in_rule_region_are_not_ignored(self):
        for extra in ('unrecognized diagnostic', 'statx: unrelated=1', '/data/broken ino=123'):
            with self.subTest(line=extra), self.assertRaisesRegex(RuntimeError, 'rule list'):
                r.parse_control(self.outputs['empty'].replace(r.STATX_DIAGNOSTIC, extra + '\n' + r.STATX_DIAGNOSTIC))

    def test_empty_sentinel_cannot_be_mixed_with_a_rule(self):
        with self.assertRaisesRegex(RuntimeError, 'rule list'):
            r.parse_control('(empty)\n' + self.outputs['owned'])

    def test_required_native_counters_are_still_required(self):
        text = '\n'.join(line for line in self.outputs['empty'].splitlines() if not line.startswith('stat nr statx '))
        with self.assertRaisesRegex(RuntimeError, 'counters unavailable'): r.parse_control(text)

    def test_malformed_rule_region_stops_main_before_fixture_or_controls(self):
        text = self.outputs['empty'].replace('(empty)', 'invalid rule')
        with patch.object(r.os, 'geteuid', return_value=10362), \
             patch.object(r.os, 'uname', return_value=SimpleNamespace(machine='aarch64', release=r.KERNEL)), \
             patch.object(r.subprocess, 'check_output', return_value='uid=10362'), \
             patch.object(r, 'root', side_effect=['map_metadata: checkpoint=19 ready=1\n', text]) as root, \
             patch.object(r, 'run_fixture') as fixture, patch('sys.stdout', new_callable=io.StringIO):
            with self.assertRaisesRegex(RuntimeError, 'rule list'): r.main()
            fixture.assert_not_called()
            self.assertEqual(['cat ' + r.MAP_STATS, 'cat ' + r.CONTROL], [call.args[0] for call in root.call_args_list])


if __name__ == '__main__': unittest.main(verbosity=2)
