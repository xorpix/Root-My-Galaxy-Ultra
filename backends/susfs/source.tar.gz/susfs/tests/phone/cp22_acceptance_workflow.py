import argparse
from datetime import datetime,timezone

def timestamp():return datetime.now(timezone.utc).isoformat()
def uptime():return float(Path('/proc/uptime').read_text().split()[0])
def save_receipt(path,value):
    require(not path.exists(),'Receipt already exists; use its existing result')
    with path.open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')
    os.chmod(path,0o600)

def assess_log(name,rc,text):
    require(rc==0,'Test exit code differs: '+name)
    lines=text.splitlines()
    require(not any(re.match(r'^FAIL:',x) for x in lines),'Fixture reported FAIL: '+name)
    endings=[x for x in lines if re.match(r'^(?:PARTIAL )?PASS:',x)]
    require(endings,'No terminal PASS: '+name)
    partial=endings[-1].startswith('PARTIAL PASS:')
    blocked=[x for x in lines if x.startswith('BLOCKED:')]
    permitted=name in ('rmgu-susfs-map-test-cp19.py','rmgu-susfs-map-lifetime-test-cp19.py')
    if partial or blocked:
        require(permitted and partial and blocked,'New blocked/partial scope: '+name)
        require(all(re.search(r' (?:stat_follow|open_follow) baseline errno=(?:1|13); scope unqualified$',x) for x in blocked),
                'Mapping test has a new baseline blocker: '+name)
    return {'status':'PARTIAL PASS' if partial else 'PASS','blocked':blocked,'terminal':endings[-1]}

def regression(directory):
    before=root_call('state')
    if before['mount_hide']!=0:raise Blocked('Retained mount fixture requires its qualified disabled baseline; current settings untouched')
    sources=root_call('read_batch',directory=directory)
    logs=Path(tempfile.mkdtemp(prefix='rmgu-susfs-cp22-regression.',dir=Path.home()))
    receipt={'kind':'cp22-fixed-regression','uid':os.geteuid(),'started':timestamp(),
             'original':before,'manifest':sources['manifest'],'results':[],'complete':False}
    path=logs/'regression.json'
    print('EVIDENCE:',logs,flush=True)
    try:
        for index,name in enumerate(REGRESSION,1):
            print('REGRESSION %d/%d: %s'%(index,len(REGRESSION),name),flush=True)
            source=base64.b64decode(sources['sources'][name],validate=True)
            runner=logs/('input-'+name);runner.write_bytes(source)
            log=logs/(name+'.log')
            arguments=[sys.executable,'-u'] if name.endswith('.py') else ['sh']
            with runner.open('rb') as stdin,log.open('wb') as stdout:
                child=subprocess.Popen(arguments,stdin=stdin,stdout=stdout,stderr=subprocess.STDOUT,cwd=Path.home())
                try:rc=child.wait(timeout=240)
                except subprocess.TimeoutExpired:
                    child.send_signal(signal.SIGINT)
                    try:child.wait(timeout=15)
                    except subprocess.TimeoutExpired:pass
                    raise Unknown('Fixture exceeded its time limit; no further tests launched. Log: '+str(log))
                except BaseException:
                    child.send_signal(signal.SIGINT);raise
            require(log.stat().st_size<=16*1024*1024,'Fixture log exceeded limit')
            result=assess_log(name,rc,log.read_text(errors='replace'))
            after=root_call('state');require(after==before,'Original rules/settings changed after '+name)
            receipt['results'].append(dict(result,name=name,log=str(log),restoration=True))
            print(name,result['status'],'and exact state restored',flush=True)
        receipt.update(complete=True,finished=timestamp(),final=root_call('state'))
        require(receipt['final']==before,'Final original state differs')
    finally:save_receipt(path,receipt)
    print('PASS: fixed 11-fixture regression and exact original state after each test.',flush=True)
    print('REGRESSION RECEIPT:',path,flush=True)
    print('Known baseline-blocked mapping follow/open scopes remain unqualified. This does not record the 30-minute observation.',flush=True)

def observation_start(path):
    receipt=json.loads(path.read_text())
    require(receipt.get('kind')=='cp22-fixed-regression' and receipt.get('complete') is True and
            [x['name'] for x in receipt['results']]==list(REGRESSION) and
            all(x['status'] in ('PASS','PARTIAL PASS') and x['restoration'] for x in receipt['results']),
            'A completed fixed regression receipt is required')
    require(receipt['uid']==os.geteuid() and receipt['final']==receipt['original'],'Regression identity/state differs')
    current=root_call('state');require(current==receipt['final'],'Candidate settings changed after regression')
    target=path.parent/'observation.json'
    save_receipt(target,{'kind':'cp22-observation','uid':os.geteuid(),'started':timestamp(),
                         'start_uptime':uptime(),'state':current,'regression':str(path)})
    print('Observation started. Use the phone normally for at least 30 minutes and record any new crash or hang.',flush=True)
    print('OBSERVATION RECEIPT:',target,flush=True)

def assess_observation(start,current,elapsed,outcome):
    require(start['state']['boot_id']==current['boot_id'],'Boot changed during observation')
    if elapsed<1800:raise Blocked('Observation is only %.1f minutes; 30 minutes are required'%(elapsed/60))
    return 'PASS' if outcome=='clean' and start['state']==current else 'UNQUALIFIED'

def observation_finish(path,outcome,notes):
    start=json.loads(path.read_text())
    require(start.get('kind')=='cp22-observation' and start['uid']==os.geteuid(),'Invalid observation receipt')
    current=root_call('state');elapsed=uptime()-start['start_uptime']
    status=assess_observation(start,current,elapsed,outcome)
    result={'kind':'cp22-observation-result','status':status,'started':start['started'],'finished':timestamp(),
            'elapsed_seconds':elapsed,'outcome_reported_by_user':outcome,'notes':notes,
            'same_boot':True,'state_unchanged':start['state']==current,
            'scope':'One bounded ordinary-use observation; no long-run or concurrent-race qualification.'}
    target=path.parent/'observation-result.json';save_receipt(target,result)
    print(status+': 30-minute ordinary-use observation; user outcome='+outcome,flush=True)
    print('RESULT:',target,flush=True)
    if status!='PASS':raise Blocked('Observed issue, absent observation, or changed configuration remains unqualified')

def run():
    print('Acceptance runner revision: 5 (CP22 suspended after reported device freeze/reboot)',flush=True)
    require_cp22_phone_tests_enabled()
    parser=argparse.ArgumentParser()
    group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--regression',metavar='EXTRACTED_DOWNLOAD_DIRECTORY')
    group.add_argument('--start-observation',type=Path,metavar='REGRESSION_JSON')
    group.add_argument('--finish-observation',type=Path,metavar='OBSERVATION_JSON')
    parser.add_argument('--outcome',choices=('clean','issue','unobserved'));parser.add_argument('--notes',default='')
    args=parser.parse_args();preflight()
    if args.regression:regression(args.regression)
    elif args.start_observation:observation_start(args.start_observation)
    else:
        require(args.outcome is not None,'An explicit --outcome is required; elapsed time alone is not a pass')
        observation_finish(args.finish_observation,args.outcome,args.notes)

if __name__=='__main__':sys.exit(terminal_main(run))
