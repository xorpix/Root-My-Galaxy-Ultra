import copy
import importlib.util
import io
import json
import mmap
import os
from pathlib import Path
import shlex
import tempfile
import unittest
from unittest.mock import patch
from contextlib import contextmanager


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).with_name(filename))
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


r = module('maps_identity_runner', 'rmgu-susfs-kstat-maps-test.py')
builder = module('maps_identity_builder', 'build_kstat_maps_runner.py')
formatting = module('maps_formatting', 'kstat_control_format.py')
producer = module('maps_field_producer', 'test_kstat_fields_runner.py')
production = module('maps_production', 'kstat_maps_production.py')
FOREIGN = producer.FOREIGN


@contextmanager
def host_proc_paths():
    # This executor has a PID namespace/proc mount mismatch. Redirect only its
    # own numeric proc identity reads to real /proc/self; no phone API is changed.
    original = Path.read_text
    def read(path, *args, **kwargs):
        prefix = '/proc/%d/' % os.getpid()
        name = str(path)
        if name.startswith(prefix): path = Path('/proc/self/' + name[len(prefix):])
        value = original(path, *args, **kwargs)
        if name == prefix + 'stat': value = str(os.getpid()) + value[value.index(' ('):]
        return value
    with patch.object(Path, 'read_text', read): yield


def namespace_stub(path):
    # Container namespace links are denied even for its own process. This is a
    # named host API stub, not evidence of Samsung namespace/credential access.
    if str(path) == '/proc/%d/ns/mnt' % os.getpid(): return 'host-mount-namespace-stub'
    raise AssertionError('Unexpected namespace request: ' + str(path))


def control_text(rules): return producer.control(rules)


def apply_identity(value, overrides, hook, uid=10362):
    for view, rows in value['views'].items():
        for name, row in list(rows.items()):
            if name.startswith('target_'):
                changed, _ = hook.rewrite(row['raw'] + '\n', row['ino'], row['dev'], overrides, uid=uid, route="show_smap" if view.startswith("smaps") else "show_map")
                rows[name] = r.parse_header(changed.rstrip('\n'))
    for row in value['files']['target'].values():
        producer.apply_profile(row, overrides, os.uname().machine)


class ProcObserverTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.hook = production.ProductionCallback()
    @classmethod
    def tearDownClass(cls): cls.hook.close()

    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(); self.addCleanup(self.directory.cleanup)
        self.paths = {name: Path(self.directory.name) / (name + '.bin') for name in ('target', 'control')}
        self.held = {}; self.mappings = []; slots = {}; page = os.sysconf('SC_PAGE_SIZE')
        for name, path in self.paths.items():
            path.write_bytes(b'owned fixture\n'.ljust(16 * page, b'\0'))
            self.held[name] = os.open(path, os.O_RDONLY)
        self.addCleanup(lambda: [os.close(fd) for fd in self.held.values()])
        for name, file, length, offset in (('target_main', 'target', 3, 0), ('target_alias', 'target', 5, 4),
                                          ('control_main', 'control', 2, 0), ('control_alias', 'control', 4, 6)):
            mapping = mmap.mmap(self.held[file], length * page, access=mmap.ACCESS_COPY, offset=offset * page)
            self.mappings.append(mapping)
            for index in range(0, length * page, page): _ = mapping[index]
            start = r.ct.addressof(r.ct.c_char.from_buffer(mapping))
            slots[name] = {'file': file, 'start': start, 'end': start + length * page, 'offset': offset * page}
        self.addCleanup(lambda: [value.close() for value in self.mappings])
        with host_proc_paths(), patch.object(r.os, 'readlink', namespace_stub):
            self.payload = {'subject': r.process_identity(os.getpid()), 'paths': {name: str(path) for name, path in self.paths.items()}, 'slots': slots}
            self.real = {name: r.real_fields(os.fstat(fd)) for name, fd in self.held.items()}
            self.before = r.observe_subject(self.payload, self.held)

    def active(self, profile):
        value = copy.deepcopy(self.before); apply_identity(value, profile, self.hook); return value

    def test_actual_proc_full_small_maps_smaps_and_native_metadata_with_namespace_stub(self):
        r.require_identity_baseline(dict(self.before, reader_uid=10362), dict(self.before, reader_uid=0), self.payload, self.real)
        self.assertEqual([], r.assess_identity(self.before, self.before, None, 'NATIVE'))
        self.assertEqual(4, len(self.before['views']))
        for rows in self.before['views'].values(): self.assertEqual(4, len(rows))

    def test_all_profiles_accept_production_callback_headers_and_independent_uapi_values(self):
        for profile in r.identity_profiles(self.real['target']):
            self.assertEqual([], r.assess_identity(self.before, self.active(profile), profile, 'ACTIVE'))

    def test_shrinking_inode_preserves_name_column(self):
        profile = r.identity_profiles(self.real['target'])[1]; now = self.active(profile)
        for view, rows in now['views'].items():
            prior = self.before['views'][view]['target_main']['raw']
            self.assertEqual(prior.index(str(self.paths['target'])), rows['target_main']['raw'].index(str(self.paths['target'])))

    def test_each_alias_each_view_inode_or_device_leak_is_detected(self):
        profile = r.identity_profiles(self.real['target'])[0]
        for view in self.before['views']:
            for slot in ('target_main', 'target_alias'):
                for field in ('ino', 'dev'):
                    value = self.active(profile); value['views'][view][slot][field] = self.before['views'][view][slot][field]
                    self.assertTrue(r.assess_identity(self.before, value, profile, 'ACTIVE'))

    def test_control_or_root_spoof_is_detected(self):
        profile = r.identity_profiles(self.real['target'])[0]
        self.assertTrue(r.assess_identity(self.before, self.active(profile), None, 'ROOT'))
        value = self.active(profile); value['views']['smaps_small']['control_alias']['ino'] = profile['ino']
        self.assertTrue(r.assess_identity(self.before, value, profile, 'ACTIVE'))

    def test_changed_range_offset_permissions_path_padding_is_detected(self):
        profile = r.identity_profiles(self.real['target'])[0]
        for field, change in [('start', 1), ('end', 1), ('offset', 4096), ('perms', 'r--p'), ('path', '/data/wrong')]:
            value = self.active(profile); row = value['views']['maps_full']['target_main']
            row[field] = row[field] + change if isinstance(change, int) else change
            self.assertTrue(r.assess_identity(self.before, value, profile, 'ACTIVE'))
        value = self.active(profile); value['views']['smaps_small']['target_alias']['raw'] += ' '
        self.assertTrue(r.assess_identity(self.before, value, profile, 'ACTIVE'))

    def test_statx_leak_guard_and_unrelated_bytes_are_detected(self):
        profile = r.identity_profiles(self.real['target'])[0]
        for failure in ('leak', 'guard', 'bytes'):
            value = self.active(profile); row = value['files']['target']['statx']
            if failure == 'leak': value['files']['target']['statx'] = copy.deepcopy(self.before['files']['target']['statx'])
            elif failure == 'guard': row['buffer_guards'] = False
            else:
                payload = bytearray.fromhex(row['raw_hex']); payload[200] ^= 1; row['raw_hex'] = payload.hex()
            self.assertTrue(r.assess_identity(self.before, value, profile, 'ACTIVE'))

    def test_duplicate_missing_or_wrong_range_headers_are_rejected(self):
        lines = [row['raw'] for row in self.before['views']['maps_full'].values()]
        for selected in (lines + lines[:1], lines[1:]):
            with self.assertRaises(RuntimeError): r.selected_rows('\n'.join(selected), self.payload, 'maps')
        with self.assertRaises(RuntimeError): r.selected_rows('\n'.join(lines + ['broken header']), self.payload, 'maps')

    def test_smaps_metric_lines_are_not_confused_with_headers(self):
        text = '\n'.join(row['raw'] + '\nRss:    4 kB\nVmFlags: rd wr mr mw me ac sd' for row in self.before['views']['smaps_full'].values())
        self.assertEqual(self.before['views']['smaps_full'], r.selected_rows(text, self.payload, 'smaps'))

    def test_changed_process_identity_and_bounded_table_reads_stop(self):
        value = copy.deepcopy(self.payload); value['subject']['starttime'] += 1
        with host_proc_paths(), patch.object(r.os, 'readlink', namespace_stub), self.assertRaisesRegex(RuntimeError, 'identity changed'):
            r.observe_subject(value, self.held)
        file = Path(self.directory.name) / 'table'; file.write_text('x' * 128)
        with patch.object(r, 'TABLE_LIMIT', 64), self.assertRaisesRegex(RuntimeError, 'bounded byte limit'):
            r.read_table(file, 16)

    def test_non_native_baseline_fails_before_control_mutation(self):
        app = dict(self.before, reader_uid=10362); root = dict(self.before, reader_uid=0)
        value = copy.deepcopy(app); value['views']['maps_full']['target_alias']['ino'] += 1
        with self.assertRaisesRegex(RuntimeError, 'no rules changed'): r.require_identity_baseline(value, root, self.payload, self.real)


class ProductionHookTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.hook = production.ProductionCallback()
    @classmethod
    def tearDownClass(cls): cls.hook.close()

    def test_real_callback_two_aliases_in_seq_buffer_preserve_control_and_metrics(self):
        prefix = 'a000-b000 rw-p 00000000 fe:51 202    /data/control\nRss: 4 kB\n'
        first = '1000-2000 rw-p 00000000 fe:51 101    /data/target\n'
        second = '3000-5000 rw-p 00004000 fe:51 101    /data/target\n'
        profile = {'ino': (1 << 40) + 101, 'dev': os.makedev(0xabc, 0xdef01)}
        one, count = self.hook.rewrite(prefix + first, 101, 65105, profile, start=len(prefix))
        final, count2 = self.hook.rewrite(one + 'Rss: 8 kB\n' + second, 101, 65105, profile, start=len(one + 'Rss: 8 kB\n'))
        self.assertTrue(final.startswith(prefix)); self.assertIn('Rss: 8 kB', final)
        self.assertEqual(2, final.count('abc:def01 %d' % profile['ino']))
        self.assertEqual({'hits': 1, 'rewrites': 1, 'overflow': 0}, count); self.assertEqual(count, count2)

    def test_root_gate_and_unrelated_inode_leave_buffer_identical(self):
        line = '1000-2000 rw-p 00000000 fe:51 101    /data/target\n'
        for kwargs in ({'uid': 0}, {'current_ino': 202}):
            value, count = self.hook.rewrite(line, 101, 65105, {'ino': 7}, **kwargs)
            self.assertEqual(line, value); self.assertEqual({'hits': 0, 'rewrites': 0, 'overflow': 0}, count)

    def test_non_identity_flags_do_not_rewrite_maps(self):
        line = '1000-2000 rw-p 00000000 fe:51 101    /data/target\n'
        value, count = self.hook.rewrite(line, 101, 65105, {'flags': 4})
        self.assertEqual(line, value); self.assertEqual({'hits': 0, 'rewrites': 0, 'overflow': 0}, count)

    def test_buffer_growth_failure_leaves_bytes_and_guards_intact(self):
        line = '1000-2000 rw-p 00000000 fe:51 101    /data/target\n'
        value, count = self.hook.rewrite(line, 101, 65105, {'ino': (1 << 40) + 101}, capacity=len(line.encode()) + 1)
        self.assertEqual(line, value); self.assertEqual({'hits': 1, 'rewrites': 0, 'overflow': 1}, count)


class ControlTests(unittest.TestCase):
    def test_cp21_route_marker_required_and_legacy_marker_is_rejected(self):
        text = formatting.production_outputs()['empty']
        self.assertIn('checkpoint=21 routes=2', r.require_map_routes(text))
        with self.assertRaises(RuntimeError): r.require_map_routes(text.replace('checkpoint=21', 'checkpoint=20'))

    def test_generated_standalone_matches_source_components(self):
        self.assertEqual(Path(r.__file__).read_text(), builder.build())

    def test_profiles_roundtrip_actual_static_receiver_and_control_output(self):
        real = {'ino': 101, 'dev': 22, 'size': 19, 'nlink': 1, 'blocks': 8, 'blksize': 4096,
                'atime_ns': 1000000002, 'mtime_ns': 3000000004, 'ctime_ns': 5000000006}
        profiles = r.identity_profiles(real)
        output = formatting.production_outputs(commands=[shlex.split(r.command('add', '/data/test', profile)) for profile in profiles])
        original, _ = r.parse_control(output['foreign'])
        for i, profile in enumerate(profiles): r.verify_owned(r.parse_control(output['command' + str(i)])[0], original, '/data/test', real, profile)
        self.assertEqual([3, 1, 2], [r.profile_flags(profile) for profile in profiles])


class FakeControl:
    def __init__(self, hook, failure=None, original=()):
        self.hook = hook; self.failure = failure; self.original = list(original); self.rules = list(original)
        self.profile = None; self.unknown = False; self.writes = []

    def root(self, command):
        if self.unknown: raise AssertionError('Command sent after unknown root outcome')
        if command.startswith('cat '): return control_text(self.rules)
        tokens = shlex.split(command)
        if tokens[0] == 'printf':
            argv = shlex.split(tokens[2]); self.writes.append(argv[0]); target = argv[1]
            if argv[0] == 'add_sus_kstat_statically':
                if self.failure == 'unknown': self.unknown = True; raise r.RootCommandUnknown('modeled unknown ADD')
                if self.failure == 'returned-error': raise RuntimeError('modeled returned ADD error')
                self.profile = {field: int(value) for field, value in zip(r.OVERRIDE_FIELDS, argv[2:]) if value != 'default'}
                real = r.real_fields(os.stat(target)); fields = r.components(real); fields.update(self.profile)
                row = target + ' ino=%d dev=%d flags=0x%x [ino=%d dev=%d nlink=%d size=%d atime=%d.%d mtime=%d.%d ctime=%d.%d blocks=%d blksize=%d]' % (
                    real['ino'], real['dev'], r.profile_flags(self.profile), *(fields[field] for field in r.OVERRIDE_FIELDS))
                self.rules = self.original + [row]
            else:
                if argv[0] != 'del': raise AssertionError('Unexpected mutation: ' + argv[0])
                if self.failure == 'cleanup-del-unknown':
                    self.unknown = True; raise r.RootCommandUnknown('modeled unknown cleanup DEL')
                self.profile = None; self.rules = list(self.original)
                if self.failure == 'conflict': self.rules.append(FOREIGN)
            return ''
        if self.profile and self.failure == 'cleanup-del-unknown':
            raise RuntimeError('modeled returned root observer failure')
        value = self.observe(json.loads(tokens[-1]), privileged=True)
        return json.dumps(value)

    def observe(self, payload, held=None, privileged=False):
        value = NATIVE_OBSERVE(payload, held); value['reader_uid'] = 0 if privileged else 10362
        if self.profile and (not privileged or self.failure == 'root-spoof'):
            apply_identity(value, self.profile, self.hook)
            if self.failure == 'map-leak':
                for rows in value['views'].values():
                    prior = NATIVE_OBSERVE(payload, held)
                    rows['target_alias'] = next(iter(prior['views'].values()))['target_alias']
        return value


NATIVE_OBSERVE = r.observe_subject


class WorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.hook = production.ProductionCallback()
    @classmethod
    def tearDownClass(cls): cls.hook.close()

    def workflow(self, failure=None, original=()):
        owner = FakeControl(self.hook, failure, original)
        with tempfile.TemporaryDirectory() as directory:
            with host_proc_paths(), patch.object(r.Path, 'home', return_value=Path(directory)), patch.object(r.os, 'readlink', namespace_stub), \
                    patch.object(r, 'root', owner.root), patch.object(r, 'observe_subject', owner.observe), patch('sys.stdout', new=io.StringIO()) as output:
                if failure:
                    with self.assertRaises(RuntimeError): r.run_identity_fixture(list(original))
                else: r.run_identity_fixture(list(original))
            fixtures = list(Path(directory).glob('rmgu-susfs-kstat-maps.*'))
            if failure in ('unknown', 'conflict', 'cleanup-del-unknown'):
                self.assertEqual(1, len(fixtures)); self.assertTrue((fixtures[0] / 'original-rules.json').is_file())
                self.assertTrue((fixtures[0] / 'observations.json').is_file()); self.assertNotIn('Cleanup complete', output.getvalue())
                if failure in ('unknown', 'cleanup-del-unknown'):
                    self.assertTrue(json.loads((fixtures[0] / 'observations.json').read_text())['root_outcome_unknown'])
            else:
                self.assertEqual([], fixtures); self.assertIn('Cleanup complete', output.getvalue())
            return owner.writes, output.getvalue()

    def test_three_cycles_and_exact_empty_table_restoration(self):
        writes, output = self.workflow(); self.assertEqual(['add_sus_kstat_statically', 'del'] * 3, writes); self.assertIn('PASS:', output)

    def test_foreign_original_rules_preserved(self):
        writes, output = self.workflow(original=[FOREIGN]); self.assertEqual(['add_sus_kstat_statically', 'del'] * 3, writes); self.assertIn('PASS:', output)

    def test_map_leak_fails_after_exact_cleanup(self): self.workflow('map-leak')
    def test_root_spoof_fails_after_exact_cleanup(self): self.workflow('root-spoof')
    def test_changed_rules_retain_fixture_and_do_not_clear(self): self.workflow('conflict')

    def test_unknown_add_stops_all_subsequent_root_commands(self):
        writes, _ = self.workflow('unknown'); self.assertEqual(['add_sus_kstat_statically'], writes)

    def test_unknown_cleanup_delete_is_recorded_and_stops_further_root_commands(self):
        writes, _ = self.workflow('cleanup-del-unknown'); self.assertEqual(['add_sus_kstat_statically', 'del'], writes)

    def test_returned_add_error_leaves_foreign_rules_intact(self):
        writes, _ = self.workflow('returned-error', original=[FOREIGN]); self.assertEqual(['add_sus_kstat_statically'], writes)


if __name__ == '__main__': unittest.main(verbosity=2)
