# CP21 maps identity repair

CP20 phone runner revision 1 completed cleanup but failed every target `maps`
identity assertion. `smaps`, native stat, roots and controls retained their tested
behavior. Repeated native/field transcripts are recorded as the same earlier runs.

CP21 replaces the helper-only kretprobe with paired `show_map` / `show_smap`
return probes. The initial count scopes the edit to the new header, with token
boundaries so a prior alias, inode prefix or pathname cannot match. Capacity
failure marks a seq_file overflow for retry. Hook registration is serialized
before rule publication, rolls back a partial pair, and resets stale addresses
before retry. Route-specific rewrite counters and missed probes are diagnostic.

The pinned DDK vmlinux calls the helper from both listing functions. It does not
prove the cause of missing maps delivery on the Samsung kernel. The host bypass
model reproduces the phone asymmetry, and the new boundary callbacks cover both
modeled paths. Real-header/ARM64 checks qualify compiled types and probe targets;
phone hook delivery remains pending.

Use the CP21 APK after a full reboot, then activate root and SusFS. Do not unload
or replace a live kernel module. From ordinary Termux:

```sh
su -c 'cat /sdcard/Download/rmgu-susfs-kstat-maps-test-cp21.py' | python -u
```

Runner revision 2 requires the CP21 route marker before adding any private rule.
It retains two target/control aliases, wide/selected-field profiles, full/small
maps and smaps reads, native fstat/statx consistency, roots/controls, three exact
restoration cycles and bounded root commands. It does not qualify concurrency,
held proc descriptors, compat, supercalls, unloading or long-run stability.

Host checks:

```sh
CP20_SOURCE=/absolute/path/to/cp20/source python3 -m unittest discover -s tests/phone -p 'test_kstat_maps*.py' -v
```

The host proc observer uses real self maps/smaps/native metadata. This executor
requires explicit API stubs for namespace links and its PID/proc-mount mismatch;
phone identity code is unchanged. Root/app credentials and control operations
are modeled. The actual production C callbacks and registration flow are compiled
with kernel API stubs; this is not kernel execution.
