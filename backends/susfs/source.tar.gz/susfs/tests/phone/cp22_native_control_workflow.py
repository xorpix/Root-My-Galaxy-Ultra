PROFILE={'spoofed_ino':(1<<40)+17,'spoofed_dev':3740974081,'spoofed_nlink':65537,
         'spoofed_size':(1<<32)+8193,'spoofed_atime_tv_sec':(1<<33)+101,
         'spoofed_atime_tv_nsec':123456789,'spoofed_mtime_tv_sec':-(1<<32)-7,
         'spoofed_mtime_tv_nsec':234567890,'spoofed_ctime_tv_sec':(1<<34)+303,
         'spoofed_ctime_tv_nsec':345678901,'spoofed_blocks':(1<<33)+123,
         'spoofed_blksize':8192}
FIELDS=('ino','dev','nlink','size','blocks','blksize','atime_ns','mtime_ns','ctime_ns')
AUTO=('ino','dev','blocks','blksize','atime_ns','mtime_ns','ctime_ns')

def static_expected(profile):
    result={name:profile['spoofed_'+name] for name in ('ino','dev','nlink','size','blocks','blksize')}
    for name in ('atime','mtime','ctime'):
        result[name+'_ns']=profile['spoofed_'+name+'_tv_sec']*1000000000+profile['spoofed_'+name+'_tv_nsec']
    return result

def compare_stat(observation,expected,label):
    for method,value in observation.items():
        require(value['errno']==0,label+' '+method+' failed')
        for name in FIELDS+('mode','uid','gid','rdev'):
            require(value['fields'][name]==expected[name],label+' '+method+' '+name+' differs')

def owned(state,original,kind,prefix):
    def is_owned(row):
        if kind=='path':return row.startswith('path='+prefix+' ')
        return row.startswith(prefix+' ')
    current=state['rules'][kind]
    rows=[x for x in current if is_owned(x)]
    require(len(rows)==1,'Owned rule readback missing or duplicated')
    foreign=[x for x in current if not is_owned(x)]
    require(foreign==original['rules'][kind],'Foreign rules changed')
    for key in original:
        if key=='rules':
            for other in CONTROLS:
                if other!=kind:require(state['rules'][other]==original['rules'][other],'Other rule table changed')
        else:require(state[key]==original[key],'Unrelated setting changed: '+key)
    return rows[0]

def app_path(path,hidden=False):
    try: info=os.stat(path);code=0
    except OSError as e:info=None;code=e.errno
    require(code==(errno.ENOENT if hidden else 0),'Path stat effect differs')
    try: value=Path(path).read_bytes();code=0
    except OSError as e:value=None;code=e.errno
    require(code==(errno.ENOENT if hidden else 0),'Path read effect differs')
    require((Path(path).name in os.listdir(Path(path).parent))!=hidden,'Path listing effect differs')
    return value

def app_negative():
    code=RUNTIME+"\nimport resource\nresource.setrlimit(resource.RLIMIT_CORE,(0,0))\nprint(json.dumps(supercall(COMMANDS['version'],QueryPayload(),True)),flush=True)\n"
    try: child=subprocess.run([sys.executable,'-c',code],capture_output=True,text=True,timeout=15)
    except subprocess.TimeoutExpired:raise Blocked('Disposable ordinary-app syscall baseline timed out; no ADD attempted')
    if child.returncode==-signal.SIGSYS:return 'Ordinary app reboot(2) query baseline blocked by SIGSYS/seccomp'
    require(child.returncode==0,'Ordinary app negative reader failed: '+child.stderr[-1000:])
    result=json.loads(child.stdout)
    require(result['syscall']==-1 and result['errno'] in (errno.EPERM,errno.EINVAL) and result['reply']==126 and not result['value'],
            'Ordinary app unexpectedly acquired native control access')
    return None

def run():
    print('Native control runner revision: 5 (CP22 suspended after reported device freeze/reboot)',flush=True)
    require_cp22_phone_tests_enabled()
    preflight();layouts();original=root_call('state');blocked=[]
    denied=app_negative()
    if denied:blocked.append(denied)
    queries=root_call('queries')
    for name,expected in (('version','v2.3.0'),('variant','GKI')):
        value=queries[name];require(value['syscall']==0 and value['reply']==0 and value['value']==expected,'Native '+name+' query failed')
    features={'CONFIG_KSU_SUSFS_'+x for x in ('SUS_PATH','SUS_MOUNT','SUS_KSTAT','SPOOF_UNAME','ENABLE_LOG',
              'HIDE_KSU_SUSFS_SYMBOLS','SPOOF_CMDLINE_OR_BOOTCONFIG','OPEN_REDIRECT','SUS_MAP')}|{'SUSFS_GUARD_LKM_HIDE_MODULES'}
    value=queries['features'];require(value['syscall']==0 and value['reply']==0 and set(value['value'].splitlines())==features,'Native feature query differs')
    missing=Path.home()/('rmgu-cp22-absent-'+str(os.getpid()))
    require(not missing.exists(),'Negative-test pathname unexpectedly exists')
    invalid=root_call('invalid',missing=str(missing))
    for name,result,expected in invalid:
        if name.startswith('unsupported'):
            require(result['syscall']==-1 and result['errno'] in (errno.EINVAL,errno.EPERM) and result['reply']==126,'Unsupported payload contract differs')
        else:require(result['syscall']==0 and result['reply']==expected,'Invalid-input error differs: '+name+' '+repr(result))
    require(root_call('state')==original,'Query/invalid payloads changed rules/settings')
    base=Path(tempfile.mkdtemp(prefix='rmgu-susfs-native-control.',dir=Path.home()))
    cfg={'base':str(base),'home':str(Path.home()),'uid':os.geteuid(),'boot_id':boot_id(original),
         'subject':identity(os.getpid()),'directory':[base.stat().st_dev,base.stat().st_ino],
         'original':original}
    (base/'fixture.json').write_text(json.dumps(cfg));os.chmod(base/'fixture.json',0o600)
    print('OWNED FIXTURE:',base,flush=True)
    for name in FILES:
        if name=='loop':continue
        (base/name).write_bytes(('CP22-'+name+'\n').encode()+b'\0'*8192);os.chmod(base/name,0o600)
    fds=[];maps=[];complete=False
    def call(op,**arguments):return root_call(op,cfg=cfg,**arguments)
    def control(kind,name,**arguments):return call('control',kind=kind,name=name,**arguments)['state']
    def delete(kind,name):
        call('del',kind=kind,name=name)
        require(root_call('state')==original,'Exact original state did not restore after '+kind+' DEL')
    try:
        real=call('setup')
        # Read the helper context without changing any caller credentials.
        helper=call('reader')
        root_su=helper['context']==original['settings']['or_su_ctx']
        if root_su:
            optional=call('non_su')
            print('NON-SU BASELINE:',json.dumps(optional,sort_keys=True),flush=True)
            if not optional['qualified']:blocked.append('Owned non-su UID-0 baseline unavailable: '+optional['reason'])
        else:
            optional={'qualified':False}
            blocked.append('UID-0 reader is '+helper['context']+'; configured SU-domain reader baseline unavailable')
        require(call('files')==read_contents(base),'App/root redirect content baseline differs')
        app_path(base/'plain')
        owned(control('path','plain'),original,'path',str(base/'plain'))
        app_path(base/'plain',True);require(call('path_read',name='plain')==('CP22-plain\n'.encode()+b'\0'*8192).hex(),'Root plain-path control changed')
        delete('path','plain');app_path(base/'plain')
        row=owned(control('loop','loop'),original,'path',str(base/'loop'))
        require('pending: no inode yet' in row,'Absent LOOP did not register a pending owned rule')
        os.rename(base/'spare',base/'loop')
        row=owned(control('loop','loop'),original,'path',str(base/'loop'))
        require('pending:' not in row,'LOOP re-add did not resolve the owned inode')
        app_path(base/'loop',True);require(call('path_read',name='loop')==('CP22-spare\n'.encode()+b'\0'*8192).hex(),'Root LOOP read changed')
        delete('path','loop');app_path(base/'loop')
        owned(control('loop','loop'),original,'path',str(base/'loop'));app_path(base/'loop',True)
        owned(control('loop','loop'),original,'path',str(base/'loop'))
        delete('path','loop');app_path(base/'loop')
        ranges={}
        for name in ('map_target','map_control'):
            fd=os.open(base/name,os.O_RDWR|os.O_CLOEXEC);fds.append(fd)
            mm=mmap.mmap(fd,4096,access=mmap.ACCESS_COPY);maps.append(mm)
            address=ct.addressof(ct.c_char.from_buffer(mm));ranges[name]='%x-%x'%(address,address+4096)
        before=map_rows(os.getpid(),ranges);require(before==call('maps',ranges=ranges),'Map app/root baseline differs')
        require(all(len(rows)==1 for view in before.values() for rows in view.values()),'Map ranges not qualified')
        state=control('map','map_target')
        st=real['map_target'];key='ino=%d dev=%d'%(st['ino'],(os.major(st['dev'])<<20)|os.minor(st['dev']))
        require(state['rules']['map']==original['rules']['map']+[key],'Native map ADD readback differs')
        after=map_rows(os.getpid(),ranges)
        for kind in ('maps','smaps'):
            require(after[kind]['map_target']==[] and after[kind]['map_control']==before[kind]['map_control'],'Native map effect/control differs')
        require(call('maps',ranges=ranges)==before,'Root mapped view changed')
        delete('map','map_target');require(map_rows(os.getpid(),ranges)==before,'Native mapped view did not restore')
        fd=os.open(base/'static',os.O_RDONLY|os.O_CLOEXEC);fds.append(fd)
        baseline=call('stat',name='static')['fstat_fresh']['fields'];compare_stat(stat_observe(base/'static',fd),baseline,'STATIC baseline')
        owned(control('static','static',profile=PROFILE),original,'kstat',str(base/'static'))
        expected=dict(baseline,**static_expected(PROFILE));compare_stat(stat_observe(base/'static',fd),expected,'STATIC active')
        compare_stat(call('stat',name='static'),baseline,'STATIC root')
        current_control=call('stat',name='control')['fstat_fresh']['fields'];compare_stat(stat_observe(base/'control'),current_control,'STATIC control')
        native=NativeStat();require(native.fstat(-1)['errno']==errno.EBADF and native.statx('',-1,0x1000)['errno']==errno.EBADF
             and native.at(base/'missing')['errno']==errno.ENOENT,'Native error preservation differs')
        delete('kstat','static');compare_stat(stat_observe(base/'static',fd),baseline,'STATIC restored')
        old_fd=os.open(base/'dynamic',os.O_RDONLY|os.O_CLOEXEC);fds.append(old_fd)
        old=call('stat',name='dynamic')['fstat_fresh']['fields'];compare_stat(stat_observe(base/'dynamic',old_fd),old,'DYNAMIC baseline')
        owned(control('kstat','dynamic'),original,'kstat',str(base/'dynamic'))
        compare_stat(stat_observe(base/'dynamic',old_fd),old,'DYNAMIC captured')
        (base/'replacement').write_bytes(b'CP22-replacement\n'+b'\0'*16384);os.replace(base/'replacement',base/'dynamic')
        fresh=call('stat',name='dynamic')['fstat_fresh']['fields'];require(fresh['ino']!=old['ino'],'Replacement reused the held original inode')
        compare_stat(stat_observe(base/'dynamic'),fresh,'DYNAMIC before UPDATE')
        owned(control('update','dynamic'),original,'kstat',str(base/'dynamic'))
        expected=dict(fresh,**{key:old[key] for key in AUTO});compare_stat(stat_observe(base/'dynamic'),expected,'DYNAMIC updated')
        held_real=call('held',fd=old_fd)['fstat_fresh']['fields']
        held_app=native.fstat(old_fd);require(held_app['errno']==0 and all(held_app['fields'][key]==held_real[key] for key in FIELDS),'Old held descriptor stayed targeted after UPDATE')
        delete('kstat','dynamic');compare_stat(stat_observe(base/'dynamic'),fresh,'DYNAMIC restored')
        baseline_contents=read_contents(base)
        for scheme in range(5):
            owned(control('redirect','redirect',scheme=scheme),original,'redirect',str(base/'redirect'))
            app=read_contents(base);privileged=call('files')
            expected_app=baseline_contents['destination'] if scheme in (2,3,4) else baseline_contents['redirect']
            expected_root=baseline_contents['destination'] if scheme==0 or (scheme in (1,2) and not root_su) else baseline_contents['redirect']
            require(app['redirect']==expected_app and privileged['redirect']==expected_root,'UID scheme %d app/SU-root effect differs'%scheme)
            for view in (app,privileged):require(view['destination']==baseline_contents['destination'] and view['control']==baseline_contents['control'],'UID-scheme controls changed')
            if optional['qualified']:
                non_su=call('non_su');require(non_su['qualified'] and non_su['context']==optional['context'],'Non-su baseline changed')
                require(non_su['files']['redirect']==(baseline_contents['destination'] if scheme in (0,1,2) else baseline_contents['redirect']), 'Non-su UID-0 scheme effect differs')
            delete('redirect','redirect');require(read_contents(base)==baseline_contents and call('files')==baseline_contents,'Redirect content did not restore')
            print('UID SCHEME',scheme,'PASS in available scopes',flush=True)
        complete=True
    finally:
        for mm in reversed(maps):mm.close()
        for fd in reversed(fds):os.close(fd)
        if not UNKNOWN:
            result=call('cleanup',original=original)
            require(result=={'restored':True},'Owned cleanup confirmation differs')
            print('Cleanup complete; native fixture released and exact original rules/settings verified.',flush=True)
        else:print('RETAINED EVIDENCE:',base,'Root outcome unknown; no further controls or fixture deletion attempted.',flush=True)
    require(complete,'Native control coverage incomplete')
    for reason in blocked:print('BLOCKED:',reason,'; scope unqualified',flush=True)
    print(('PARTIAL PASS' if blocked else 'PASS')+': native queries, payload guards/errors, PATH/LOOP/MAP, static/dynamic kstat ADD/UPDATE, redirect schemes 0–4, available app/root/control effects and exact restoration.',flush=True)
    print('Scope: native AArch64, owned serial fixtures. Blocked identity baselines, compat, concurrent races, unloading and long-run stability remain unqualified.',flush=True)

if __name__=='__main__':sys.exit(terminal_main(run))
