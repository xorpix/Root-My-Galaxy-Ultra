#!/usr/bin/env python3
"""CP18 BZIG bootconfig restoration and AVC control/audit validation.
Run from ordinary Termux via su -c cat | python -u.
Only native /proc/bootconfig's presented text and the AVC audit flag are changed.
No policy, SELinux enforcement, module unload, uname or /proc/cmdline writes.
The original bootconfig entries are retained in both temporary test values.
Root commands are bounded. Unknown completion stops subsequent controls.
The owned audit worker uses a private release file and has a 180-second deadline.
Audit-only: python -u - --audit-only (does not write bootconfig).
Startup-only: python -u - --startup-only (does not send feature controls).
Recovery: python -u - --recover /absolute/retained/fixture
"""
import argparse
import base64
import ctypes as ct
import json
import os
from pathlib import Path
import re
import secrets
import select
import shlex
import subprocess
import sys
import tempfile
import time

KERNEL='6.12.69-android16-6-pb4d3caf-abogkiS948BXXS4BZIG-4k'
ROOT_TIMEOUT=30
PARAMS='/sys/module/susfs_guard_lkm/parameters/'
class ManagementUnknown(RuntimeError): pass
class WorkerStartupError(RuntimeError):
 def __init__(self,message,diagnostics):
  super().__init__(message); self.diagnostics=diagnostics

HELPER=r'''
import base64
import ctypes as ct
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time
import traceback
PARAMS='/sys/module/susfs_guard_lkm/parameters/'
AVC='/proc/susfs_avc_spoof'
class Boot(ct.Structure): _fields_=[('text',ct.c_char*8192),('err',ct.c_int)]
class Flag(ct.Structure): _fields_=[('enabled',ct.c_ubyte),('err',ct.c_int)]
class Query(ct.Structure): _fields_=[('value',ct.c_char*16),('err',ct.c_int)]
def layout():
 if (ct.sizeof(Boot),Boot.err.offset,ct.sizeof(Flag),Flag.err.offset,ct.sizeof(Query),Query.err.offset)!=(8196,8192,8,4,20,16):
  raise RuntimeError('Unexpected native ABI layout')
def control(command,value,expected=0):
 value.err=126
 libc=ct.CDLL(None,use_errno=True); libc.syscall.restype=ct.c_long; ct.set_errno(0)
 rc=libc.syscall(ct.c_long(142),ct.c_uint(0xDEADBEEF),ct.c_uint(0xFAFAFAFA),ct.c_uint(command),ct.byref(value))
 reply={'syscall':int(rc),'errno':ct.get_errno() if rc<0 else 0,'reply':value.err}
 if rc!=0 or value.err!=expected: raise RuntimeError('Control 0x%x: %s, expected %d'%(command,reply,expected))
 return reply

def raw(path):
 try:
  data=Path(path).read_bytes()
  return {'errno':0,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'base64':base64.b64encode(data).decode()}
 except OSError as error: return {'errno':error.errno}
def param(name):
 text=Path(PARAMS+name).read_bytes().decode()
 return text[:-1] if text.endswith('\n') else text

def parse_boot(text):
 values={k:int(v) for k,v in re.findall(r'(\w+)=(-?\d+)',text)}
 for key in ('checkpoint','restore','active','captured','values','sets','resets','conflicts','last_error'):
  if key not in values: raise RuntimeError('Missing bootconfig diagnostic '+key)
 return values

def parse_avc(text):
 m=re.fullmatch(r'([01]) \((.*)\)\n?',text)
 if not m: raise RuntimeError('Invalid AVC state: '+repr(text))
 values={k:int(v) for k,v in re.findall(r'(\w+)=(-?\d+)',m[2])}
 values['enabled']=m[1]=='1'
 for key in ('su_sid','priv_app_sid','enter','hits','registered','tsid_arg','abi_checked','checkpoint','last_error'):
  if key not in values: raise RuntimeError('Missing AVC diagnostic '+key)
 if values['registered']!=int(values['enabled']): raise RuntimeError('AVC flag and registration disagree')
 return values

def state():
 return {'uid':os.geteuid(),'kernel':os.uname().release,
         'boot':parse_boot(param('bootconfig_stat')),'avc':parse_avc(Path(AVC).read_text()),
         'bootconfig':raw('/proc/bootconfig'),'cmdline':raw('/proc/cmdline'),
         'settings':{key:param(key) for key in ('bootconfig','avc_su_ctx','avc_priv_app_ctx','release','version','uname_spoof_enabled','enable_log')},
         'enforce':raw('/sys/fs/selinux/enforce'),'boot_id':raw('/proc/sys/kernel/random/boot_id')}

def write(path,data):
 if not isinstance(data,bytes) or not data: raise RuntimeError('Control write must contain bytes')
 fd=os.open(path,os.O_WRONLY)
 try:
  if os.write(fd,data)!=len(data): raise RuntimeError('Short control write: '+path)
 finally: os.close(fd)

def original_ok(saved):
 if saved.get('uid')!=0 or saved.get('kernel')!='6.12.69-android16-6-pb4d3caf-abogkiS948BXXS4BZIG-4k': raise RuntimeError('Invalid original kernel snapshot')
 if saved.get('boot',{}).get('active')!=0 or type(saved.get('avc',{}).get('enabled')) is not bool: raise RuntimeError('Invalid original feature state')
 for name in ('bootconfig','cmdline','enforce','boot_id'):
  value=saved.get(name,{})
  if value.get('errno')!=0: raise RuntimeError('Original root '+name+' was unreadable')
  data=base64.b64decode(value['base64'],validate=True)
  if len(data)!=value['bytes'] or hashlib.sha256(data).hexdigest()!=value['sha256']: raise RuntimeError('Invalid original '+name+' fingerprint')
 if set(saved.get('settings',{}))!={'bootconfig','avc_su_ctx','avc_priv_app_ctx','release','version','uname_spoof_enabled','enable_log'}: raise RuntimeError('Invalid original setting fields')
 if saved.get('runner_scope','full') not in ('full','audit_only'): raise RuntimeError('Invalid saved runner scope')

def restoration_ok(saved,current):
 original_ok(saved)
 if current['boot']['active']!=0 or current['avc']['enabled']!=saved['avc']['enabled']: raise RuntimeError('Feature states not restored')
 for key in ('bootconfig','cmdline','settings','enforce','kernel','boot_id'):
  if saved[key]!=current[key]: raise RuntimeError('Restoration mismatch: '+key)

def worker_stage(name):
 print('worker stage='+name,file=sys.stderr,flush=True)

def worker_namespaces(pid,trace=False):
 directory=Path('/proc')/str(pid); disabled=False
 if trace: worker_stage('pid_namespace')
 try: pid_namespace=os.readlink(directory/'ns/pid')
 except FileNotFoundError:
  if os.geteuid()!=0: raise
  if trace: worker_stage('pid_namespace_config')
  config=gzip.decompress(Path('/proc/config.gz').read_bytes()).decode()
  if '# CONFIG_PID_NS is not set' not in config.splitlines():
   raise RuntimeError('PID namespace link unavailable; running kernel configuration does not establish CONFIG_PID_NS=n')
  pid_namespace=None; disabled=True
 if trace: worker_stage('mount_namespace')
 mount_namespace=os.readlink(directory/'ns/mnt')
 return {'pid_namespace':pid_namespace,'pid_namespace_disabled':disabled,'mount_namespace':mount_namespace}

def worker_identity(pid,trace=False,include_namespaces=True):
 if type(pid) is not int or pid<=1: raise RuntimeError('Invalid owned worker PID')
 directory=Path('/proc')/str(pid)
 if trace: worker_stage('proc_stat')
 stat=(directory/'stat').read_text(); fields=stat[stat.rfind(')')+2:].split()
 if len(fields)<20 or fields[0] in ('Z','X'): raise RuntimeError('Owned worker is no longer live')
 if trace: worker_stage('proc_status')
 status=(directory/'status').read_text()
 uid=re.search(r'^Uid:\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)',status,re.M)
 if not uid: raise RuntimeError('Missing owned worker credentials')
 if trace: worker_stage('proc_context')
 context=(directory/'attr/current').read_bytes().rstrip(b'\0\n').decode()
 result={'pid':pid,'uids':[int(value) for value in uid.groups()],
         'starttime':int(fields[19]),'context':context}
 if include_namespaces: result.update(worker_namespaces(pid,trace))
 return result

def worker_wait(release,token):
 deadline=time.monotonic()+180
 while time.monotonic()<deadline:
  try:
   if release.read_text()==token: return
   raise RuntimeError('Invalid owned worker release token')
  except FileNotFoundError: time.sleep(0.05)
 raise RuntimeError('Owned worker release deadline expired')

def audit_logs(tag):
 sources={}; lines=[]; limit=1024*1024
 commands={'dmesg':['/system/bin/toybox','dmesg'],
           'logcat':['/system/bin/logcat','-b','all','-d','-t','2048']}
 for name,command in commands.items():
  with tempfile.TemporaryFile(mode='w+b') as out,tempfile.TemporaryFile(mode='w+b') as err:
   try:
    process=subprocess.run(command,stdout=out,stderr=err,timeout=5)
    out.seek(0,2); size=out.tell(); out.seek(max(0,size-limit))
    text=out.read(limit).decode(errors='replace')
    err.seek(0); error=err.read(2048).decode(errors='replace')
    found=[line for line in text.splitlines() if tag in line and 'avc:' in line][-32:]
    sources[name]={'returncode':process.returncode,'bytes':size,'tail_limited':size>limit,'matched_lines':len(found),'stderr':error}
    if process.returncode==0: lines.extend(found)
   except (OSError,subprocess.TimeoutExpired) as error:
    sources[name]={'unavailable':str(error),'matched_lines':0}
 return {'lines':list(dict.fromkeys(lines)),'sources':sources}

def action(name,args):
 layout()
 if os.geteuid()!=0: raise RuntimeError('Management helper must be UID 0')
 if name=='worker':
  worker_stage('arguments')
  uid=args['uid']
  if type(uid) is not int or uid<10000: raise RuntimeError('Invalid fixture UID')
  worker_stage('release_path')
  release=Path(__file__).resolve().with_name('audit.release'); token=args['token']
  if not re.fullmatch(r'[0-9a-f]{32}',token) or release.exists(): raise RuntimeError('Invalid owned worker release handshake')
  worker_stage('namespaces_before_credentials')
  namespaces=worker_namespaces(os.getpid(),trace=True)
  worker_stage('setgroups'); os.setgroups([])
  worker_stage('setgid'); os.setgid(uid)
  worker_stage('setuid'); os.setuid(uid)
  libc=ct.CDLL(None,use_errno=True)
  worker_stage('dumpable')
  if libc.prctl(ct.c_int(4),ct.c_ulong(1),ct.c_ulong(0),ct.c_ulong(0),ct.c_ulong(0)): raise OSError(ct.get_errno(),'PR_SET_DUMPABLE')
  info=worker_identity(os.getpid(),trace=True,include_namespaces=False); info.update(namespaces)
  info.update(uid=os.geteuid(),dumpable=libc.prctl(ct.c_int(3),ct.c_ulong(0),ct.c_ulong(0),ct.c_ulong(0),ct.c_ulong(0)))
  worker_stage('ready')
  print(json.dumps(info),flush=True)
  worker_wait(release,token)
  return None
 if name=='preflight':
  q=Query(); control(0x555e1,q)
  if bytes(q.value)!=b'v2.3.0': raise RuntimeError('Unexpected SusFS version')
  current=state()
  if current['boot']['checkpoint']!=18 or current['boot']['restore']!=1 or current['avc']['checkpoint']!=18 or current['avc']['abi_checked']!=1 or current['avc']['tsid_arg']!=1:
   raise RuntimeError('CP18 BZIG module with checked target SID ABI is required')
  return current
 if name=='boot_set':
  data=base64.b64decode(args['base64'],validate=True)
  if not data or len(data)>8191 or b'\0' in data: raise RuntimeError('Invalid bootconfig text')
  value=Boot(); value.text=data; control(0x555b0,value)
 elif name=='boot_invalid':
  before=state()['bootconfig']
  control(0x555b0,Boot(),-22)
  value=Boot(); ct.memset(ct.addressof(value),ord('x'),8192); control(0x555b0,value,-36)
  if state()['bootconfig']!=before: raise RuntimeError('Rejected bootconfig changed native view')
 elif name=='boot_reset': write(PARAMS+'bootconfig_reset',b'1')
 elif name=='avc_abi': control(0x60010,Flag(int(args['enabled']),126))
 elif name=='avc_proc': write(AVC,b'1' if args['enabled'] else b'0')
 elif name=='avc_invalid':
  before=state()['avc']['enabled']
  control(0x60010,Flag(2,126),-22)
  for data in (b'x',b'1x',b'0junk'):
   try: write(AVC,data)
   except OSError as error:
    if error.errno!=22: raise
   else: raise RuntimeError('Invalid AVC control accepted: '+repr(data))
  if state()['avc']['enabled']!=before: raise RuntimeError('Rejected AVC changed state')
 elif name=='restore':
  saved=args['original']; original_ok(saved); errors=[]
  if state()['boot_id']!=saved['boot_id']: raise RuntimeError('Saved snapshot belongs to a different boot; no restore writes sent')
  writes=[(AVC,b'1' if saved['avc']['enabled'] else b'0')]
  if saved.get('runner_scope','full')!='audit_only': writes.insert(0,(PARAMS+'bootconfig_reset',b'1'))
  for path,data in writes:
   try: write(path,data)
   except Exception as error: errors.append(path+': '+str(error))
  current=state()
  if errors: raise RuntimeError('Restoration write errors: '+repr(errors))
  restoration_ok(saved,current)
  return current
 elif name=='worker_check':
  result=state()
  for key,pid in (('worker',args['pid']),('reader',args['reader_pid'])):
   try: result[key]={'identity':worker_identity(pid),'errno':0}
   except (OSError,RuntimeError) as error: result[key]={'errno':getattr(error,'errno',None),'error':str(error)}
  return result
 elif name=='audit_log':
  tag=args['tag']
  if len(tag)>15 or not re.fullmatch(r'RM18[0-9a-f]+[BA]',tag): raise RuntimeError('Invalid audit fixture tag')
  result=state()
  result['audit']=audit_logs(tag)
  return result
 elif name!='state': raise RuntimeError('Unknown action')
 return state()
if __name__=='__main__':
 try:
  value=action(sys.argv[1],json.loads(base64.b64decode(sys.argv[2])))
  if value is not None: print(json.dumps(value),flush=True)
 except Exception as error:
  if len(sys.argv)>1 and sys.argv[1]=='worker': traceback.print_exc(file=sys.stderr)
  print(type(error).__name__+': '+str(error),file=sys.stderr,flush=True); sys.exit(1)
'''
APP={}; exec(HELPER.split("if __name__=='__main__':",1)[0],APP)

def root(command):
 with tempfile.TemporaryFile(mode='w+t') as out,tempfile.TemporaryFile(mode='w+t') as err:
  process=subprocess.Popen(['su','-c',command],stdin=subprocess.DEVNULL,stdout=out,stderr=err,text=True,start_new_session=True)
  try: process.wait(timeout=ROOT_TIMEOUT)
  except (subprocess.TimeoutExpired,KeyboardInterrupt) as cause:
   try: process.kill()
   except (ProcessLookupError,PermissionError): pass
   try: process.wait(timeout=1)
   except subprocess.TimeoutExpired: pass
   raise ManagementUnknown('Root command completion is unknown; no further controls. Retain snapshot and reboot before retrying.') from cause
  out.seek(0); err.seek(0)
  if process.returncode: raise RuntimeError('Root command failed (%d): %s'%(process.returncode,err.read().strip()))
  return out.read()

def command(helper,name,args=None):
 encoded=base64.b64encode(json.dumps(args or {}).encode()).decode()
 return ' '.join(shlex.quote(s) for s in ['/system/bin/toybox','nsenter','-t',str(os.getpid()),'-m',sys.executable,str(helper),name,encoded])

def call(helper,name,args=None):
 print('ROOT '+name.upper(),flush=True)
 result=json.loads(root(command(helper,name,args)))
 if result['uid']!=0: raise RuntimeError('Root reader is not UID 0')
 return result

def save(path,value):
 path.write_text(json.dumps(value,indent=2)+'\n'); path.chmod(0o600)

def fixture_new(prefix):
 directory=Path(tempfile.mkdtemp(prefix=prefix,dir=os.getcwd()))
 helper=directory/'root-helper.py'; helper.write_text(HELPER); helper.chmod(0o600)
 return directory,helper

def fixture_remove(directory):
 for path in directory.iterdir(): path.unlink()
 directory.rmdir()

def preflight():
 print('Boot/AVC runner revision: 5 (CP18 signal-zero audit and dual log sources)',flush=True)
 if os.geteuid()<10000 or os.uname().release!=KERNEL or os.uname().machine!='aarch64': raise RuntimeError('Run from ordinary Termux on the BZIG kernel, with uname spoofing disabled')
 APP['layout']()
 print('App reader: '+subprocess.check_output(['id'],text=True).strip(),flush=True)

def app_views(): return {key:APP['raw']('/proc/'+key) for key in ('bootconfig','cmdline')}

def check_views(original,current,app_original,expected,label):
 if current['bootconfig']['errno']!=0 or base64.b64decode(current['bootconfig']['base64'])!=expected: raise RuntimeError(label+' root bootconfig differs')
 for key in ('cmdline','settings','enforce','kernel','boot_id'):
  if current[key]!=original[key]: raise RuntimeError(label+' changed '+key)
 app=app_views()
 for key in app:
  if app_original[key]['errno']:
   if app[key]!=app_original[key]: raise RuntimeError(label+' changed blocked app '+key+' scope')
  elif key=='bootconfig':
   if app[key]['errno'] or base64.b64decode(app[key]['base64'])!=expected: raise RuntimeError(label+' app bootconfig differs')
  elif app[key]!=app_original[key]: raise RuntimeError(label+' app cmdline differs')
 print(label+': '+json.dumps({'active':current['boot']['active'],'root_bootconfig_sha256':current['bootconfig']['sha256'],'app_errno':app['bootconfig']['errno'],'avc':current['avc']}),flush=True)

def comm_set(value):
 libc=ct.CDLL(None,use_errno=True)
 if libc.prctl(ct.c_int(15),ct.c_char_p(value),ct.c_ulong(0),ct.c_ulong(0),ct.c_ulong(0)): raise OSError(ct.get_errno(),'PR_SET_NAME')

def audit_probe(pid,tag):
 if type(pid) is not int or pid<=1: raise RuntimeError('Invalid owned audit PID')
 if len(tag)>15 or not re.fullmatch(r'RM18[0-9a-f]+[BA]',tag): raise RuntimeError('Invalid audit fixture tag')
 libc=ct.CDLL(None,use_errno=True); original=ct.create_string_buffer(16)
 if libc.prctl(ct.c_int(16),ct.byref(original),ct.c_ulong(0),ct.c_ulong(0),ct.c_ulong(0)): raise OSError(ct.get_errno(),'PR_GET_NAME')
 try:
  comm_set(tag.encode())
  try:
   os.kill(pid,0)
   return 0
  except OSError as error: return error.errno
 finally: comm_set(original.value)

def worker_errors(process):
 stream=process.__dict__.get('_worker_stderr')
 if stream is not None:
  stream.seek(0); data=stream.read(16385)
 else:
  data=b''
  while len(data)<16385:
   ready,_,_=select.select([process.stderr],[],[],0)
   if not ready: break
   chunk=os.read(process.stderr.fileno(),min(4096,16385-len(data)))
   if not chunk: break
   data+=chunk
 return {'returncode':process.returncode,'stderr':data[:16384].decode(errors='replace'),'stderr_limit_reached':len(data)>16384}

def worker_stop(process,release,token,capture=False):
 try:
  try:
   release.write_text(token); release.chmod(0o600)
  except OSError as cause: raise ManagementUnknown('Owned audit fixture could not be released; reboot before further controls') from cause
  try: process.wait(timeout=5)
  except subprocess.TimeoutExpired as cause: raise ManagementUnknown('Owned audit fixture did not exit after release; reboot before further controls') from cause
  if capture: return worker_errors(process)
 finally:
  process.stdout.close()
  stream=process.__dict__.get('_worker_stderr')
  if stream is not None: stream.close()
  elif process.stderr is not None: process.stderr.close()

def worker_start(helper,release,token):
 errors=tempfile.TemporaryFile(mode='w+b')
 try:
  process=subprocess.Popen(['su','-c',command(helper,'worker',{'uid':os.geteuid(),'token':token})],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=errors,start_new_session=True)
 except BaseException:
  errors.close(); raise
 process._worker_stderr=errors
 deadline=time.monotonic()+ROOT_TIMEOUT; data=b''
 try:
  while b'\n' not in data and len(data)<8192:
   remaining=deadline-time.monotonic()
   if remaining<=0: raise ManagementUnknown('Audit fixture startup completion is unknown')
   ready,_,_=select.select([process.stdout],[],[],remaining)
   if not ready: raise ManagementUnknown('Audit fixture startup completion is unknown')
   chunk=os.read(process.stdout.fileno(),4096)
   if not chunk: raise RuntimeError('Audit fixture exited during startup')
   data+=chunk
  info=json.loads(data.split(b'\n')[0])
  if info['uid']!=os.geteuid() or info['uids']!=[os.geteuid()]*4 or info['dumpable']!=1 or type(info['pid']) is not int or info['pid']<=1 or type(info['starttime']) is not int or info['starttime']<=0: raise RuntimeError('Invalid owned audit fixture')
  return process,info
 except BaseException as error:
  diagnostics=worker_stop(process,release,token,capture=True)
  diagnostics.update(startup_stdout=data.decode(errors='replace'),message=str(error))
  if isinstance(error,(ManagementUnknown,KeyboardInterrupt)): raise
  raise WorkerStartupError('Audit fixture startup failed: '+str(error),diagnostics) from error

def worker_verified(helper,info,label):
 current=call(helper,'worker_check',{'pid':info['pid'],'reader_pid':os.getpid()})
 observed=current['worker']; reader=current['reader']
 expected={key:info[key] for key in ('pid','uids','starttime','context','pid_namespace','pid_namespace_disabled','mount_namespace')}
 identity=reader.get('identity',{})
 reader_ok=reader.get('errno')==0 and identity.get('pid')==os.getpid() and identity.get('uids')==[os.geteuid()]*4
 namespaces_ok=reader_ok and all(identity.get(key)==info[key] for key in ('pid_namespace','pid_namespace_disabled','mount_namespace'))
 ok=observed.get('errno')==0 and observed.get('identity')==expected and namespaces_ok
 print('WORKER '+label+': '+json.dumps({'verified':ok,'observed':observed,'reader':reader,'namespaces_verified':namespaces_ok}),flush=True)
 if not ok: print('AUDIT UNQUALIFIED: owned worker lifetime or identity could not be verified.',flush=True)
 return ok

def audit_qualified(receipt,source,target):
 before=receipt['baseline_errno']; after=receipt['active_errno']
 if before in (1,13) and after!=before: raise RuntimeError('AVC spoofing changed the fixture access outcome')
 if before not in (1,13) or not all(receipt['worker_checks']) or len(receipt['worker_checks'])!=4: return False
 def correlated(lines,tag):
  return [line for line in lines if re.search(r'\bcomm="'+re.escape(tag)+r'"',line)
          and re.search(r'\bpid='+str(receipt['reader_pid'])+r'\b',line)
          and re.search(r'\btclass=process(?:\s|$)',line)
          and re.search(r'avc:\s+denied\s+\{\s*signull\s*\}',line)]
 def context(line):
  match=re.search(r'(?:^|\s)tcontext=(\S+)',line)
  return match[1] if match else None
 base=correlated(receipt['baseline_audit']['lines'],receipt['tags'][0])
 active=correlated(receipt['active_audit']['lines'],receipt['tags'][1])
 if not any(context(line)==source for line in base): return False
 if active and any(context(line)!=target for line in active): raise RuntimeError('Correlated active AVC did not show replacement target context')
 return any(context(line)==target for line in active) and receipt['hits_after']>receipt['hits_before']

def audit_exercise(helper,original,fixture):
 process=None; release=helper.with_name('audit.release'); token=secrets.token_hex(16); checks=[]
 try:
  try: process,info=worker_start(helper,release,token)
  except ManagementUnknown: raise
  except Exception as error:
   if isinstance(error,WorkerStartupError):
    save(fixture/'worker-startup-error.json',error.diagnostics)
    print('WORKER STARTUP ERROR: '+json.dumps(error.diagnostics),flush=True)
   print('AUDIT UNQUALIFIED: fixture unavailable: '+str(error),flush=True); return False
  print('OWNED AUDIT FIXTURE: '+json.dumps(info),flush=True)
  if info['context']!=original['settings']['avc_su_ctx']:
   print('AUDIT UNQUALIFIED: fixture has a different SELinux domain',flush=True); return False
  if not worker_verified(helper,info,'STARTUP'): return False
  call(helper,'avc_abi',{'enabled':False})
  nonce=secrets.token_hex(2); tags=['RM18%x%sB'%(os.getpid(),nonce),'RM18%x%sA'%(os.getpid(),nonce)]
  checks.append(worker_verified(helper,info,'BEFORE BASELINE'))
  if not checks[-1]: return False
  print('PROBE BASELINE: signal=0 target_pid='+str(info['pid'])+' (no signal delivery)',flush=True)
  baseline_errno=audit_probe(info['pid'],tags[0])
  checks.append(worker_verified(helper,info,'AFTER BASELINE'))
  if not checks[-1]: return False
  baseline=call(helper,'audit_log',{'tag':tags[0]})
  active=call(helper,'avc_abi',{'enabled':True})
  checks.append(worker_verified(helper,info,'BEFORE ACTIVE'))
  if not checks[-1]: return False
  print('PROBE ACTIVE: signal=0 target_pid='+str(info['pid'])+' (no signal delivery)',flush=True)
  active_errno=audit_probe(info['pid'],tags[1])
  checks.append(worker_verified(helper,info,'AFTER ACTIVE'))
  if not checks[-1]: return False
  observed=call(helper,'audit_log',{'tag':tags[1]})
  receipt={'probe':{'operation':'kill','signal':0,'permission':'signull','class':'process'},'fixture':info,'reader_pid':os.getpid(),'tags':tags,'worker_checks':checks,'baseline_errno':baseline_errno,'active_errno':active_errno,'baseline_audit':baseline['audit'],'active_audit':observed['audit'],'hits_before':active['avc']['hits'],'hits_after':observed['avc']['hits']}
  save(fixture/'audit-evidence.json',receipt); print('AUDIT EVIDENCE: '+json.dumps(receipt),flush=True)
  if audit_qualified(receipt,original['settings']['avc_su_ctx'],original['settings']['avc_priv_app_ctx']):
   print('AUDIT PASS: verified live worker, correlated target context changed; access denial remained the same.',flush=True); return True
  print('AUDIT UNQUALIFIED: no complete correlated denial pair; policy or log access may prevent observing it.',flush=True)
  return False
 finally:
  if process is not None:
   worker_stop(process,release,token)

def startup_collect():
 preflight(); fixture,helper=fixture_new('rmgu-susfs-avc-startup.'); before=None; process=None; diagnostics={}; error=None
 try:
  before=call(helper,'preflight'); save(fixture/'before.json',before)
  release=helper.with_name('audit.release'); token=secrets.token_hex(16)
  try:
   process,info=worker_start(helper,release,token)
   diagnostics['fixture']=info
   diagnostics['verified']=worker_verified(helper,info,'STARTUP')
  except WorkerStartupError as cause:
   diagnostics=cause.diagnostics; error=str(cause)
  finally:
   if process is not None: diagnostics['exit']=worker_stop(process,release,token,capture=True)
  after=call(helper,'state')
  APP['restoration_ok'](before,after)
  if before['boot']!=after['boot'] or before['avc']['enabled']!=after['avc']['enabled'] or before['avc']['registered']!=after['avc']['registered']: raise RuntimeError('Startup collector observed a changed feature state')
  save(fixture/'after.json',after)
  diagnostics.update(error=error,feature_controls_sent=False,states_unchanged=True)
 except BaseException as cause:
  diagnostics.update(error=str(cause),feature_controls_sent=False)
  save(fixture/'startup-evidence.json',diagnostics)
  print('RETAINED STARTUP EVIDENCE: '+str(fixture),flush=True)
  raise
 save(fixture/'startup-evidence.json',diagnostics)
 print('STARTUP EVIDENCE: '+json.dumps(diagnostics),flush=True)
 print('RETAINED STARTUP EVIDENCE: '+str(fixture),flush=True)
 print('STARTUP COLLECTION COMPLETE: no feature controls sent; original feature flags and native data verified.',flush=True)

def exercise(helper,original,app_original,fixture):
 native=base64.b64decode(original['bootconfig']['base64'])
 for i in (1,2):
  chosen=native+(b'' if native.endswith(b'\n') else b'\n')+('rmgu.cp18.probe = "%d-%d"\n'%(os.getpid(),i)).encode()
  response=call(helper,'boot_set',{'base64':base64.b64encode(chosen).decode()})
  if response['boot']['active']!=1: raise RuntimeError('Bootconfig set did not activate')
  check_views(original,response,app_original,chosen,'ACTIVE '+str(i))
 response=call(helper,'boot_invalid'); check_views(original,response,app_original,chosen,'REJECTED BOOTCONFIG')
 for i in (1,2):
  response=call(helper,'boot_reset')
  if response['boot']['active']!=0: raise RuntimeError('Bootconfig reset remained active')
  check_views(original,response,app_original,native,'RESET '+str(i))
 response=call(helper,'boot_set',{'base64':base64.b64encode(chosen).decode()})
 check_views(original,response,app_original,chosen,'REAPPLIED')
 response=call(helper,'boot_reset'); check_views(original,response,app_original,native,'NATIVE AGAIN')
 for route in ('avc_abi','avc_proc'):
  for enabled in (True,False,True,False):
   response=call(helper,route,{'enabled':enabled})
   if response['avc']['enabled']!=enabled or response['avc']['registered']!=int(enabled): raise RuntimeError('AVC state did not match '+route)
   print('AVC '+route+': '+json.dumps(response['avc']),flush=True)
 call(helper,'avc_invalid')
 return audit_exercise(helper,original,fixture)

def recover(directory):
 preflight(); source=Path(directory).expanduser()
 if not source.is_absolute(): raise RuntimeError('Recovery needs an absolute retained fixture path')
 source=source.resolve(strict=True); snapshot=source/'original-state.json'
 if snapshot.stat().st_size>131072: raise RuntimeError('Invalid snapshot size')
 original=json.loads(snapshot.read_text()); APP['original_ok'](original)
 fixture,helper=fixture_new('rmgu-susfs-boot-avc-recovery.')
 save(fixture/'original-state.json',original); verified=False
 try:
  current=call(helper,'preflight')
  for key in ('cmdline','settings','enforce','kernel','boot_id'):
   if current[key]!=original[key]: raise RuntimeError('Recovery preflight differs in '+key+'; no writes sent')
  current=call(helper,'restore',{'original':original}); APP['restoration_ok'](original,current)
  if (source/'app-original.json').exists():
   app_original=json.loads((source/'app-original.json').read_text())
   check_views(original,current,app_original,base64.b64decode(original['bootconfig']['base64']),'RECOVERY RESTORED')
  save(source/'recovery-verified.json',current); verified=True
  print('RECOVERY PASS: saved native bootconfig and AVC flag restored; original snapshot retained.',flush=True)
 finally:
  if verified: fixture_remove(fixture)
  else: print('RETAINED RECOVERY FIXTURE: '+str(fixture),flush=True)

def run(audit_only=False):
 preflight(); fixture,helper=fixture_new('rmgu-susfs-boot-avc.')
 original=None; attempted=False; unknown=False; restored_ok=False; problem=None; qualified=False; blocked=False
 try:
  original=call(helper,'preflight'); APP['original_ok'](original)
  if not original['avc']['su_sid'] or not original['avc']['priv_app_sid']: raise RuntimeError('Configured AVC SID resolution failed; no test writes sent')
  native=base64.b64decode(original['bootconfig']['base64'])
  if b'\0' in native or len(native)+100>8191: raise RuntimeError('Native bootconfig cannot fit an intact fixture; no test writes sent')
  original['runner_scope']='audit_only' if audit_only else 'full'
  app_original=app_views(); save(fixture/'original-state.json',original); save(fixture/'app-original.json',app_original)
  for key,value in app_original.items():
   if value['errno']:
    blocked=not audit_only; print('BLOCKED APP /proc/'+key+': errno='+str(value['errno'])+'; app scope unqualified',flush=True)
   elif value!=original[key]: raise RuntimeError('Baseline app/root '+key+' disagree')
  print('SAVED ORIGINAL: '+json.dumps({'boot':original['boot'],'avc':original['avc'],'bootconfig':{k:v for k,v in original['bootconfig'].items() if k!='base64'},'cmdline':{k:v for k,v in original['cmdline'].items() if k!='base64'}}),flush=True)
  attempted=True; qualified=audit_exercise(helper,original,fixture) if audit_only else exercise(helper,original,app_original,fixture)
 except ManagementUnknown as error: unknown=True; problem=error
 except (Exception,KeyboardInterrupt) as error: problem=error
 finally:
  if attempted and not unknown:
   try:
    restored=call(helper,'restore',{'original':original}); APP['restoration_ok'](original,restored)
    check_views(original,restored,app_original,native,'RESTORED'); restored_ok=True
   except ManagementUnknown as error: unknown=True; problem=error
   except (Exception,KeyboardInterrupt) as error: problem=RuntimeError('Restoration could not be verified: '+str(error))
  if unknown or (attempted and not restored_ok):
   print('RETAINED FIXTURE: '+str(fixture),flush=True)
   print('Root completion unknown; reboot before further writes.' if unknown else 'Keep original-state.json and use --recover with this fixture.',flush=True)
  else:
   fixture_remove(fixture)
   print('Cleanup complete; native bootconfig, exact AVC flag and unrelated settings verified.' if attempted else 'No test controls sent; temporary helper removed.',flush=True)
 if problem: raise problem
 scope=('AVC audit pair, exact original flag restoration and cleanup; no bootconfig writes' if qualified else 'exact original AVC flag restoration and cleanup; AVC audit pair unqualified; no bootconfig writes') if audit_only else 'bootconfig update/reset/reapply, AVC control roundtrips, invalid rejection, exact restoration and cleanup'
 print(('PASS' if qualified and not blocked else 'PARTIAL PASS')+': '+scope+'.',flush=True)
 if not qualified: print('Actual AVC target-context rewriting remains unqualified on this device.',flush=True)
 print('Scope: probe unloading and kernel log suppression were not tested.',flush=True)

if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__)
 mode=parser.add_mutually_exclusive_group()
 mode.add_argument('--recover',metavar='SAVED_FIXTURE')
 mode.add_argument('--audit-only',action='store_true',help='Check the owned AVC audit pair without bootconfig writes')
 mode.add_argument('--startup-only',action='store_true',help='Collect worker startup errors without feature control writes')
 args=parser.parse_args()
 try:
  if args.recover: recover(args.recover)
  elif args.startup_only: startup_collect()
  else: run(audit_only=args.audit_only)
 except (Exception,KeyboardInterrupt) as error:
  print('\nFAIL: '+str(error),flush=True); sys.exit(1)
