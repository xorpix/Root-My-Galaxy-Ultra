import base64
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

spec = importlib.util.spec_from_file_location('crash_collector',
    Path(__file__).with_name('rmgu-susfs-cp22-crash-collect.py'))
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)


class CrashCollectorTests(unittest.TestCase):
    def test_retains_binary_bytes_and_reports_truncation(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'log'
            path.write_bytes(b'a\x00b\xffextra')
            data, truncated, _ = c.read_regular(path, 4)
            self.assertEqual(b'a\x00b\xff', data)
            self.assertTrue(truncated)

    def test_symlink_file_is_not_followed(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'log'
            path.symlink_to('/etc/passwd')
            with self.assertRaises(OSError): c.read_regular(path, 100)

    def test_directory_is_not_read_as_evidence(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(ValueError): c.read_regular(directory, 100)

    def test_fixture_directory_symlink_is_not_traversed(self):
        with tempfile.TemporaryDirectory() as directory, tempfile.TemporaryDirectory() as foreign:
            home = Path(directory)
            (Path(foreign) / 'fixture.json').write_text('foreign')
            (home / 'rmgu-susfs-native-control.link').symlink_to(foreign)
            self.assertEqual([], c.retained_files(home))

    def test_default_collection_never_requests_su_and_preserves_source(self):
        with tempfile.TemporaryDirectory() as directory:
            home = Path(directory)
            source = home / 'rmgu-cp22-root-last'
            source.write_bytes(b'last\x00output')
            fixture = home / 'rmgu-susfs-native-control.owned'
            fixture.mkdir(); (fixture / 'fixture.json').write_text('{"boot_id":"old"}')
            record = {'kind':'file','path':'/sys/fs/pstore/dmesg-ramoops-0',
                      'data_b64':base64.b64encode(b'panic\n').decode(),'errno':0}
            with patch.object(c, 'probe', return_value={'records':[record]}) as probe,\
                    patch.object(c.sys,'stdout',io.StringIO()):
                archive, manifest = c.collect(home)
            probe.assert_called_once_with(False)
            self.assertFalse(manifest['root_requested'])
            self.assertFalse(manifest['kernel_controls_attempted'])
            self.assertEqual(b'last\x00output', source.read_bytes())
            self.assertTrue((fixture / 'fixture.json').exists())
            with zipfile.ZipFile(archive) as opened:
                self.assertIsNone(opened.testzip())
                receipt = json.loads(opened.read('manifest.json'))
                saved = receipt['probes'][0]['records'][0]['archive']
                self.assertEqual(b'panic\n', opened.read(saved))

    def test_explicit_root_adds_only_one_optional_probe(self):
        with tempfile.TemporaryDirectory() as directory,\
                patch.object(c, 'probe', side_effect=[{'records':[]},{'records':[],'error':'no su'}]) as probe,\
                patch.object(c.sys,'stdout',io.StringIO()):
            _, manifest = c.collect(Path(directory), True)
        self.assertEqual([False,True],[call.args[0] for call in probe.call_args_list])
        self.assertEqual('no su',manifest['probes'][1]['error'])

    def test_timeout_keeps_completed_evidence_records(self):
        code = 'import time\nprint(\'{"kind":"identity","uid":10362}\',flush=True)\ntime.sleep(5)\n'
        with patch.object(c,'ENVIRONMENT_CODE',code),patch.object(c,'PROBE_TIMEOUT',0.15):
            result = c.probe(False)
        self.assertTrue(result['timed_out'])
        self.assertEqual([{'kind':'identity','uid':10362}],result['records'])

    def test_non_json_helper_error_is_preserved(self):
        with patch.object(c,'ENVIRONMENT_CODE','print("reader permission denied")'):
            result = c.probe(False)
        self.assertEqual(['reader permission denied'],result['helper_messages'])


if __name__ == '__main__': unittest.main()
