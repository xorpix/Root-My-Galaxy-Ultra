# Statx production rewriter coverage

Run `python3 tests/kstat_statx/run.py --sanitizers --json evidence.json`.
The runner extracts the actual `susfs_kstat.c` rule table, snapshot, lookup,
statx offsets, field macros and rewriter. It uses the host Linux statx UAPI
layout and small kernel API stubs; it does not reproduce the rewrite logic.

Eleven cases cover the reported 254:81 lookup failure, inode/device identity,
20-bit minor numbers, 32-bit device writes, signed 64-bit timestamp writes,
request/returned masks, byte preservation, root/app gating, unrelated controls,
empty/no-flag rules, read/write faults, unlocked user accesses, snapshot lifetime
and the shared statx layout for compat dispatch. Each write stays within a
guarded 256-byte buffer. These are host checks, not phone qualification.
