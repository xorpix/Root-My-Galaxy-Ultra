#!/usr/bin/env python3
"""Exercise the production statx rewriter and rule lookup with kernel API stubs."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile


def function(source, name):
    match = re.search(r'^static [^\n]*\b' + re.escape(name) + r'\([^;{]*\)\n\{\n.*?^\}\n',
                      source, re.M | re.S)
    if not match:
        raise ValueError('Missing production function: ' + name)
    return match.group()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-dir', type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument('--sanitizers', action='store_true')
    parser.add_argument('--json', type=Path)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    source = args.source_dir.resolve() / 'kernel/susfs_kstat.c'
    text = source.read_text()
    fragment = '#define SUS_KSTAT_MAX 32\n#define KSTAT_PATH_MAX 256\n'
    fragment += text[text.index('struct sus_kstat_entry {'):text.index('/* arm64 asm-generic struct stat offsets')]
    for name in ('susfs_kstat_gate_ok', 'susfs_kstat_table_empty', 'susfs_kstat_lookup'):
        fragment += function(text, name)
    start = text.index('struct kstat_call_counters {')
    fragment += text[start:text.index('#define KSTAT_COUNTERS', start)]
    start = text.index('struct kstat_call_state {')
    fragment += text[start:text.index('/* Rewrite the requested fields of the native user statbuf.', start)]
    start = text.index('#define STATX_F_INO')
    fragment += text[start:text.index('/* ---- the ONE sys_exit tracepoint', start)]
    cases = ['phone-device', 'device-identity', 'wide-device', 'masks', 'field-widths',
             'gates-control', 'empty-noflag', 'read-faults', 'write-faults',
             'snapshot', 'compat-layout']
    results = []
    with tempfile.TemporaryDirectory(prefix='susfs-statx-host-') as directory:
        directory = Path(directory)
        header = directory / 'production.h'
        header.write_text(fragment)
        executable = directory / 'statx'
        flags = ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-no-pie'] if args.sanitizers else ['-O2']
        subprocess.run([os.environ.get('CC', 'cc'), '-std=gnu11', '-Wall', '-Wextra', '-Werror',
                        '-Wno-unused-function', '-Wno-unused-variable', '-Wno-unused-parameter', *flags,
                        '-I', str(here), '-DPRODUCTION="' + str(header) + '"',
                        str(here / 'statx_test.c'), '-o', str(executable)], check=True)
        for case in cases:
            env = dict(os.environ)
            if args.sanitizers:
                env.update(ASAN_OPTIONS='detect_leaks=0:abort_on_error=1', UBSAN_OPTIONS='halt_on_error=1')
            result = subprocess.run([str(executable), case], capture_output=True, text=True, env=env, timeout=20)
            results.append(dict(case=case, exit_code=result.returncode,
                                stdout=result.stdout.strip(), stderr=result.stderr.strip()))
            print(result.stdout.strip() or 'FAIL ' + case + ': ' + result.stderr.strip())
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(dict(kind='production statx C and lookup with host kernel API stubs',
                                            source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                                            sanitizers=args.sanitizers, hardware_validated=False,
                                            results=results), indent=2) + '\n')
    return int(any(result['exit_code'] for result in results))


if __name__ == '__main__':
    raise SystemExit(main())
