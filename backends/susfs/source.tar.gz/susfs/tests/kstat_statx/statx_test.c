/* SPDX-License-Identifier: GPL-2.0 */
#include "../feature_hooks/host_kernel.h"
#include <stddef.h>
#include <linux/stat.h>
#include "../../kernel/susfs_abi.h"

typedef uint64_t u64;
typedef int64_t s64;
typedef int32_t s32;
typedef uint16_t u16;
#define static_assert _Static_assert
#define __user
#define DEFINE_MUTEX(name) int name
#define DEFINE_SPINLOCK(name) int name
static int lock_depth;
#define spin_lock_irqsave(lock, flags) do { (void)(lock); (flags) = 0; assert(!lock_depth); lock_depth++; } while (0)
#define spin_unlock_irqrestore(lock, flags) do { (void)(lock); (void)(flags); assert(lock_depth == 1); lock_depth--; } while (0)
struct timespec64 { s64 tv_sec; long tv_nsec; };
static struct { unsigned int val; } test_uid = {10362};
#define current_uid() test_uid
/* Linux kdev_t encoding, checked below against fixed values independently of
 * the lookup and field rewrite. No host libc dev_t encoding is substituted. */
#define MAJOR(dev) ((unsigned int)((dev) >> 20))
#define MINOR(dev) ((unsigned int)((dev) & 0xfffff))
#define MKDEV(major, minor) (((uint32_t)(major) << 20) | (uint32_t)(minor))
static u32 new_encode_dev(dev_t dev)
{
    unsigned int major = MAJOR(dev), minor = MINOR(dev);
    return (minor & 0xff) | (major << 8) | ((minor & ~0xff) << 12);
}
static dev_t new_decode_dev(u32 encoded)
{
    return MKDEV((encoded & 0xfff00) >> 8, (encoded & 0xff) | ((encoded >> 12) & 0xfff00));
}

struct guarded_statx { unsigned char before[16]; struct statx value; unsigned char after[16]; };
static struct guarded_statx buffer;
static int reads, writes, fail_read, fail_write;
static bool mutate_on_write;
static void mutate_rule(void);
static void bounds(const void *address, size_t size)
{
    assert(!lock_depth);
    uintptr_t start = (uintptr_t)&buffer.value, ptr = (uintptr_t)address;
    assert(ptr >= start && size <= sizeof(buffer.value) && ptr - start <= sizeof(buffer.value) - size);
}
static unsigned long copy_from_user(void *to, const void *from, size_t size)
{
    bounds(from, size);
    if (++reads == fail_read) return size;
    memcpy(to, from, size); return 0;
}
static unsigned long copy_to_user(void *to, const void *from, size_t size)
{
    bounds(to, size);
    if (++writes == fail_write) return size;
    if (mutate_on_write) { mutate_on_write = false; mutate_rule(); }
    memcpy(to, from, size); return 0;
}

/* Host model of the load-time umount gate (issue #34): nothing resolves on the host, so the gate
 * answers the pre-#34 way - app uids and nothing else.  The extracted production fragment's gate
 * calls this replica instead of ksu_umount_gate.h's inline, keeping every other expectation here
 * byte-identical to what it tested before the KSU integration landed in the kernel sources. */
static inline bool susfs_is_current_proc_umounted_app(void)
{
    return current_uid().val >= 10000;
}
#include PRODUCTION

static struct kstat_call_counters counters;
static struct kstat_call_state state = { .cnt = &counters };
static void mutate_rule(void) { memset(kstat_entries, 0, sizeof(kstat_entries)); nkstat = 0; }
static struct statx baseline(void)
{
    struct statx value;
    memset(&value, 0xa5, sizeof(value));
    value.stx_mask = STATX_BASIC_STATS | STATX_BTIME;
    value.stx_dev_major = 254; value.stx_dev_minor = 81;
    value.stx_ino = 784642; value.stx_size = 19;
    value.stx_nlink = 1; value.stx_blksize = 4096; value.stx_blocks = 8;
    value.stx_atime.tv_sec = 1791519606; value.stx_atime.tv_nsec = 123456789;
    value.stx_mtime.tv_sec = 1791519607; value.stx_mtime.tv_nsec = 234567890;
    value.stx_ctime.tv_sec = 1791519608; value.stx_ctime.tv_nsec = 345678901;
    return value;
}
static void reset(void)
{
    memset(&counters, 0, sizeof(counters)); memset(kstat_entries, 0, sizeof(kstat_entries));
    nkstat = 1; test_uid.val = 10362; reads = writes = fail_read = fail_write = lock_depth = 0;
    mutate_on_write = false; state.compat = false;
    memset(&buffer, 0xd7, sizeof(buffer)); buffer.value = baseline();
    kstat_entries[0] = (struct sus_kstat_entry){
        .target_ino = 784642, .target_dev = 65105, .spoofed_ino = 100784643, .spoofed_size = 4115,
        .flags = KSTAT_SPOOF_INO | KSTAT_SPOOF_SIZE,
    };
}
static bool rewrite(u32 request)
{
    bool changed = susfs_kstat_spoof_statx(&state, (unsigned long)&buffer.value, request);
    for (size_t i = 0; i < 16; i++) assert(buffer.before[i] == 0xd7 && buffer.after[i] == 0xd7);
    assert(!lock_depth); return changed;
}
static void unchanged(struct statx expected) { assert(!memcmp(&buffer.value, &expected, sizeof(expected))); }
static void matched(void)
{
    struct statx expected = baseline(); expected.stx_ino = 100784643; expected.stx_size = 4115;
    assert(rewrite(STATX_BASIC_STATS)); unchanged(expected);
    assert(counters.rewrite.value == 1 && !counters.miss_lookup.value && !counters.uaccess.value);
}
int main(int argc, char **argv)
{
    assert(argc == 2); const char *name = argv[1]; reset();
    if (!strcmp(name, "phone-device")) {
        assert(new_encode_dev(MKDEV(254, 81)) == 65105);
        matched();
    } else if (!strcmp(name, "device-identity")) {
        /* The inode alone and the device major alone must not select a rule. */
        buffer.value.stx_dev_minor = 82; struct statx expected = buffer.value;
        assert(!rewrite(STATX_BASIC_STATS)); unchanged(expected); assert(counters.miss_lookup.value == 1);
        reset(); buffer.value.stx_ino++; expected = buffer.value;
        assert(!rewrite(STATX_BASIC_STATS)); unchanged(expected); assert(counters.miss_lookup.value == 1);
        reset(); buffer.value.stx_dev_major++; expected = buffer.value;
        assert(!rewrite(STATX_BASIC_STATS)); unchanged(expected);
    } else if (!strcmp(name, "wide-device")) {
        const u32 majors[] = {0, 1, 254, 4095}, minors[] = {0, 81, 256, 0xabcde, 0xfffff};
        assert(new_encode_dev(MKDEV(1, 256)) == 0x100100);
        assert(new_encode_dev(MKDEV(4095, 0xfffff)) == 0xffffffff);
        for (size_t a = 0; a < sizeof(majors)/sizeof(*majors); a++)
            for (size_t b = 0; b < sizeof(minors)/sizeof(*minors); b++) {
                reset(); buffer.value.stx_dev_major = majors[a]; buffer.value.stx_dev_minor = minors[b];
                kstat_entries[0].target_dev = new_encode_dev(MKDEV(majors[a], minors[b]));
                struct statx expected = buffer.value; expected.stx_ino = 100784643; expected.stx_size = 4115;
                assert(rewrite(STATX_BASIC_STATS)); unchanged(expected);
            }
        reset(); kstat_entries[0].flags = KSTAT_SPOOF_DEV;
        kstat_entries[0].spoofed_dev = 0xabcfffde;
        struct statx expected = baseline(); expected.stx_dev_major = 4095; expected.stx_dev_minor = 0xabcde;
        assert(rewrite(STATX_BASIC_STATS)); unchanged(expected);
    } else if (!strcmp(name, "masks")) {
        const u32 masks[] = {0, STATX_INO, STATX_SIZE, STATX_BASIC_STATS, STATX_BTIME};
        for (size_t a = 0; a < sizeof(masks)/sizeof(*masks); a++)
            for (size_t b = 0; b < sizeof(masks)/sizeof(*masks); b++) {
                reset(); buffer.value.stx_mask = masks[b]; struct statx expected = buffer.value;
                u32 effective = masks[a] | masks[b];
                if (effective & STATX_INO) expected.stx_ino = 100784643;
                if (effective & STATX_SIZE) expected.stx_size = 4115;
                assert(rewrite(masks[a]) == !!(effective & (STATX_INO | STATX_SIZE))); unchanged(expected);
                assert(counters.match_noflag.value == !(effective & (STATX_INO | STATX_SIZE)));
            }
    } else if (!strcmp(name, "field-widths")) {
        kstat_entries[0].flags = KSTAT_SPOOF_NLINK | KSTAT_SPOOF_BLKSIZE | KSTAT_SPOOF_BLOCKS |
            KSTAT_SPOOF_ATIME_TV_SEC | KSTAT_SPOOF_ATIME_TV_NSEC | KSTAT_SPOOF_MTIME_TV_SEC |
            KSTAT_SPOOF_MTIME_TV_NSEC | KSTAT_SPOOF_CTIME_TV_SEC | KSTAT_SPOOF_CTIME_TV_NSEC;
        kstat_entries[0].spoofed_nlink = 0x81234567; kstat_entries[0].spoofed_blksize = 65536;
        kstat_entries[0].spoofed_blocks = 0x100000001LL;
        kstat_entries[0].spoofed_atime_tv_sec = 0x100000002L; kstat_entries[0].spoofed_atime_tv_nsec = 1234567;
        kstat_entries[0].spoofed_mtime_tv_sec = -123; kstat_entries[0].spoofed_mtime_tv_nsec = 2345678;
        kstat_entries[0].spoofed_ctime_tv_sec = -0x100000003L; kstat_entries[0].spoofed_ctime_tv_nsec = 3456789;
        struct statx expected = baseline(); expected.stx_nlink = 0x81234567; expected.stx_blksize = 65536;
        expected.stx_blocks = 0x100000001ULL;
        expected.stx_atime.tv_sec = 0x100000002LL; expected.stx_atime.tv_nsec = 1234567;
        expected.stx_mtime.tv_sec = -123; expected.stx_mtime.tv_nsec = 2345678;
        expected.stx_ctime.tv_sec = -0x100000003LL; expected.stx_ctime.tv_nsec = 3456789;
        assert(rewrite(STATX_BASIC_STATS)); unchanged(expected);
    } else if (!strcmp(name, "gates-control")) {
        const unsigned int uids[] = {0, 1000, 9999, 10000, 10362};
        for (size_t i = 0; i < sizeof(uids)/sizeof(*uids); i++) {
            reset(); test_uid.val = uids[i];
            if (uids[i] >= 10000) matched();
            else { assert(!rewrite(STATX_BASIC_STATS)); unchanged(baseline()); assert(!reads && !writes && counters.miss_gate.value == 1); }
        }
        reset(); buffer.value.stx_ino = 932120; buffer.value.stx_size = 20; struct statx expected = buffer.value;
        assert(!rewrite(STATX_BASIC_STATS)); unchanged(expected); assert(counters.miss_lookup.value == 1);
    } else if (!strcmp(name, "empty-noflag")) {
        nkstat = 0; assert(!rewrite(STATX_BASIC_STATS)); unchanged(baseline());
        assert(!reads && !writes && counters.miss_empty.value == 1);
        reset(); kstat_entries[0].flags = 0;
        assert(!rewrite(STATX_BASIC_STATS)); unchanged(baseline()); assert(counters.match_noflag.value == 1);
    } else if (!strcmp(name, "read-faults")) {
        for (int i = 1; i <= 4; i++) {
            reset(); fail_read = i; assert(!rewrite(STATX_BASIC_STATS)); unchanged(baseline());
            assert(reads == i && !writes && counters.uaccess.value == 1 && !counters.rewrite.value);
        }
    } else if (!strcmp(name, "write-faults")) {
        for (int i = 1; i <= 2; i++) {
            reset(); fail_write = i; assert(!rewrite(STATX_BASIC_STATS));
            struct statx expected = baseline(); if (i == 2) expected.stx_ino = 100784643;
            unchanged(expected); assert(writes == i && counters.uaccess.value == 1 && !counters.rewrite.value);
        }
    } else if (!strcmp(name, "snapshot")) {
        mutate_on_write = true; matched(); assert(!nkstat);
        buffer.value = baseline(); assert(!rewrite(STATX_BASIC_STATS)); unchanged(baseline());
    } else if (!strcmp(name, "compat-layout")) {
        state.compat = true; matched();
    } else return 2;
    printf("PASS statx/%s\n", name); return 0;
}
