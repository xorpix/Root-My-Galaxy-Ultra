/* SPDX-License-Identifier: GPL-2.0 */
#include <assert.h>
#include <errno.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MODULE_NAME_LEN 56
typedef struct { unsigned int val; } kuid_t;
static _Thread_local kuid_t host_uid, host_euid;
#define GLOBAL_ROOT_UID ((kuid_t){0})
static kuid_t current_uid(void) { return host_uid; }
static kuid_t current_euid(void) { return host_euid; }
static bool uid_eq(kuid_t a, kuid_t b) { return a.val == b.val; }
#define GFP_KERNEL 0
#define PAGE_SIZE 4096
#define READ_ONCE(v) __atomic_load_n(&(v),__ATOMIC_ACQUIRE)
#define SUSFS_LOGI(...) ((void)0)
typedef _Atomic int atomic_t;
#define ATOMIC_INIT(v) (v)
static void atomic_inc(atomic_t *p) { atomic_fetch_add(p,1); }
static int atomic_read(atomic_t *p) { return atomic_load(p); }
static _Thread_local bool host_config_owned;
static _Thread_local int host_spin_depth;
static atomic_t host_waiting,host_allocations;
#define DEFINE_MUTEX(n) pthread_mutex_t n=PTHREAD_MUTEX_INITIALIZER
#define DEFINE_SPINLOCK(n) pthread_mutex_t n=PTHREAD_MUTEX_INITIALIZER
static void mutex_lock(pthread_mutex_t *p)
{
    assert(!host_spin_depth && "sleeping mutex acquired while holding module spinlock");
    int rc=pthread_mutex_trylock(p);
    if(rc==EBUSY) { atomic_inc(&host_waiting); assert(!pthread_mutex_lock(p)); atomic_fetch_sub(&host_waiting,1); }
    else assert(!rc);
    assert(!host_config_owned); host_config_owned=true;
}
static void mutex_unlock(pthread_mutex_t *p)
{ assert(host_config_owned); host_config_owned=false; assert(!pthread_mutex_unlock(p)); }
static void spin_lock(pthread_mutex_t *p) { assert(!pthread_mutex_lock(p)); host_spin_depth++; }
static void spin_unlock(pthread_mutex_t *p) { assert(host_spin_depth>0); host_spin_depth--; assert(!pthread_mutex_unlock(p)); }
#define spin_lock_irqsave(p,f) do { (f)=0; spin_lock(p); } while(0)
#define spin_unlock_irqrestore(p,f) do { (void)(f); spin_unlock(p); } while(0)
static void *kvmalloc(size_t n,int flags)
{ (void)flags; void *p=malloc(n); if(p) atomic_inc(&host_allocations); return p; }
static void *kvmalloc_array(size_t n,size_t size,int flags) { return kvmalloc(n*size,flags); }
static void kvfree(void *p) { if(p) { atomic_fetch_sub(&host_allocations,1); free(p); } }
static int strscpy(char *out,const char *in,size_t size)
{ size_t n=strlen(in); if(n>=size) n=size-1; memcpy(out,in,n); out[n]=0; return (int)n; }
static int scnprintf(char *out,size_t size,const char *format,...)
{ if(!size) return 0; va_list ap; va_start(ap,format); int n=vsnprintf(out,size,format,ap); va_end(ap); return n<(int)size ? n : (int)size-1; }
static int sus_path_add_self_hidden(const char *path);
static int sus_path_del_path(const char *path);
static int susfs_control_get(void) { return 0; }
static void susfs_control_put(void) {}
static bool sus_path_lsm_active(void) { return true; }
