#!/usr/bin/env python3
"""Compile and run the actual module-name controller with path/lock stubs."""
import argparse
import json
import os
from pathlib import Path
import resource
import subprocess
import tempfile

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-dir',type=Path,default=Path(__file__).resolve().parents[2])
parser.add_argument('--json',type=Path)
args=parser.parse_args()
here=Path(__file__).resolve().parent
source=(args.source_dir/'kernel/susfs_hide_syms.c').read_text()
fragment=source[source.index('#define HIDE_MODULES_MAX'):source.index('/* ---- the two frontends ---- */')]
cases=['exact-list','parse-failure-preserves-list','rescan-late-module','distinct-sysfs-errors','long-module-path','capacity','concurrent-writers']
results=[]
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
with tempfile.TemporaryDirectory(prefix='susfs-module-control-host-') as temporary:
    root=Path(temporary)
    production=root/'production.h'
    production.write_text(fragment)
    def compile_program(header,exe):
        return subprocess.run([os.environ.get('CC','cc'),'-std=gnu11','-Wall','-Wextra','-Werror',
                               '-Wno-unused-function','-pthread','-O2','-I',str(here),
                               '-DPRODUCTION="'+str(header)+'"',str(here/'module_control_test.c'),'-o',str(exe)],
                              capture_output=True,text=True)
    exe=root/'test'
    built=compile_program(production,exe)
    if built.returncode: raise RuntimeError(built.stderr)
    for case in cases:
        run=subprocess.run([str(exe),case],capture_output=True,text=True,timeout=15)
        results.append({'case':case,'exit_code':run.returncode,'stdout':run.stdout.strip(),'stderr':run.stderr.strip()})
        print(run.stdout.strip() or 'FAIL '+case+': '+run.stderr.strip())
    changed=root/'unserialized.h'
    changed.write_text(fragment.replace('mutex_lock(&hide_modules_config_lock);','/* negative control: no config lock */').replace('mutex_unlock(&hide_modules_config_lock);','/* no unlock */'))
    bad=root/'negative'
    built=compile_program(changed,bad)
    # Removing the lock leaves its declaration unused: allow only that warning.
    if built.returncode and 'unused-variable' in built.stderr:
        changed.write_text(changed.read_text().replace('static DEFINE_MUTEX(hide_modules_config_lock);',''))
        built=compile_program(changed,bad)
    if built.returncode: raise RuntimeError('Negative control did not compile: '+built.stderr)
    run=subprocess.run([str(bad),'concurrent-writers'],capture_output=True,text=True,timeout=15)
    negative={'case':'missing-writer-serialization','passed':run.returncode!=0 and 'Assertion' in run.stderr,
              'exit_code':run.returncode,'stderr':run.stderr.replace(temporary,'<temporary>').strip()}
    print(('PASS ' if negative['passed'] else 'FAIL ')+'missing-writer-serialization negative control')
if args.json:
    args.json.parent.mkdir(parents=True,exist_ok=True)
    args.json.write_text(json.dumps({'kind':'actual production module controller with instrumented kernel stubs',
                                    'hardware_validated':False,'results':results,'negative_control':negative},indent=2)+'\n')
raise SystemExit(any(r['exit_code'] for r in results) or not negative['passed'])
