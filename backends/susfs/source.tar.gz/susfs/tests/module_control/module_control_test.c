/* SPDX-License-Identifier: GPL-2.0 */
#include "host_kernel.h"
#include PRODUCTION

static char applied[16][MODULE_NAME_LEN];
static int napplied,host_path_calls,host_path_error;
static bool host_late_loaded,host_block_next,host_inside,host_release;
static pthread_mutex_t block_lock=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t block_cv=PTHREAD_COND_INITIALIZER;
static int sus_path_add_self_hidden(const char *path)
{
    assert(host_config_owned && !host_spin_depth);
    const char *name=path+strlen("/sys/module/"); host_path_calls++;
    if(!strcmp(name,"late") && !host_late_loaded) return -ENOENT;
    if(!strcmp(name,"error")) return host_path_error;
    pthread_mutex_lock(&block_lock);
    if(host_block_next) {
        host_block_next=false; host_inside=true; pthread_cond_broadcast(&block_cv);
        while(!host_release) pthread_cond_wait(&block_cv,&block_lock);
    }
    pthread_mutex_unlock(&block_lock);
    for(int i=0;i<napplied;i++) assert(strcmp(applied[i],name));
    assert(napplied<16); strscpy(applied[napplied++],name,MODULE_NAME_LEN); return 0;
}
static int sus_path_del_path(const char *path)
{
    assert(host_config_owned && !host_spin_depth);
    const char *name=path+strlen("/sys/module/");
    for(int i=0;i<napplied;i++) if(!strcmp(applied[i],name)) {
        memmove(applied[i],applied[i+1],(size_t)(napplied-i-1)*MODULE_NAME_LEN); napplied--; return 1;
    }
    return 0;
}
static atomic_t writer_finished;
static void *writer(void *arg)
{ assert(!hide_modules_command(arg,false)); atomic_inc(&writer_finished); return NULL; }
static void clean(void)
{ assert(!hide_modules_command("clear",false)); assert(!napplied && !n_hide_modules && !n_hide_modules_applied && !atomic_read(&host_allocations)); }

int main(int argc,char **argv)
{
    assert(argc==2); const char *name=argv[1]; char buf[PAGE_SIZE];
    if(!strcmp(name,"exact-list")) {
        assert(!hide_modules_command("alpha,beta",true) && napplied==2);
        assert(hide_module_name_match("alpha") && !hide_module_name_match("alpha_suffix"));
        assert(!hide_modules_command("add beta",false) && n_hide_modules==2);
        assert(!hide_modules_command("del beta",false) && n_hide_modules==1 && napplied==1);
        assert(hide_modules_command("del beta",false)==-ENOENT && napplied==1);
    } else if(!strcmp(name,"parse-failure-preserves-list")) {
        assert(!hide_modules_command("set alpha",false)); int calls=host_path_calls;
        assert(hide_modules_command("bogus",false)==-EINVAL && n_hide_modules==1 && host_path_calls==calls);
        char longname[MODULE_NAME_LEN+10]; memset(longname,'x',sizeof(longname)-1); longname[sizeof(longname)-1]=0;
        assert(hide_modules_command(longname,true)==-ENAMETOOLONG && n_hide_modules==1 && host_path_calls==calls);
        assert(!hide_modules_command("add beta",false) && napplied==2);
    } else if(!strcmp(name,"rescan-late-module")) {
        assert(!hide_modules_command("set alpha late",false) && n_hide_modules==2 && napplied==1);
        assert(atomic_read(&n_sysfs_rules_absent)==1 && !atomic_read(&n_sysfs_rules_errors));
        host_late_loaded=true; assert(!hide_modules_command("rescan",false));
        assert(n_hide_modules==2 && napplied==2 && atomic_read(&n_sysfs_rescans)==1);
        assert(!strcmp(hide_modules[0],"alpha") && !strcmp(hide_modules[1],"late"));
    } else if(!strcmp(name,"distinct-sysfs-errors")) {
        host_path_error=-EACCES; assert(!hide_modules_command("set late error alpha",false));
        assert(atomic_read(&n_sysfs_rules_failed)==2 && atomic_read(&n_sysfs_rules_absent)==1 && atomic_read(&n_sysfs_rules_errors)==1 && napplied==1);
        assert(hide_modules_format(buf,sizeof(buf))>0 && strstr(buf,"sysfs: absent=1 errors=1 rescans=0"));
        assert(strstr(buf,"names: late error alpha\n"));
    } else if(!strcmp(name,"long-module-path")) {
        char cmd[4+MODULE_NAME_LEN]; memcpy(cmd,"add ",4); memset(cmd+4,'x',MODULE_NAME_LEN-1); cmd[sizeof(cmd)-1]=0;
        assert(!hide_modules_command(cmd,false) && napplied==1);
        assert(strlen(applied[0])==MODULE_NAME_LEN-1 && !strcmp(applied[0],cmd+4));
    } else if(!strcmp(name,"capacity")) {
        for(int i=0;i<HIDE_MODULES_MAX;i++) { char cmd[50]; snprintf(cmd,sizeof(cmd),"add module%d",i); assert(!hide_modules_command(cmd,false)); }
        assert(hide_modules_command("add overflow",false)==-ENOSPC && napplied==16);
    } else if(!strcmp(name,"concurrent-writers")) {
        pthread_t first,second; host_block_next=true;
        assert(!pthread_create(&first,NULL,writer,"add alpha"));
        pthread_mutex_lock(&block_lock); while(!host_inside) pthread_cond_wait(&block_cv,&block_lock); pthread_mutex_unlock(&block_lock);
        assert(!pthread_create(&second,NULL,writer,"add beta"));
        for(int i=0;i<2000 && !atomic_read(&host_waiting);i++) usleep(1000);
        assert(atomic_read(&host_waiting)==1 && !atomic_read(&writer_finished));
        assert(hide_module_name_match("alpha") && !hide_module_name_match("beta"));
        pthread_mutex_lock(&block_lock); host_release=true; pthread_cond_broadcast(&block_cv); pthread_mutex_unlock(&block_lock);
        assert(!pthread_join(first,NULL) && !pthread_join(second,NULL));
        assert(n_hide_modules==2 && napplied==2 && n_hide_modules_applied==2);
        assert(hide_module_name_match("alpha") && hide_module_name_match("beta"));
    } else assert(!"unknown case");
    clean(); printf("PASS %s\n",name); return 0;
}
