/* SPDX-License-Identifier: GPL-2.0 */
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include PRODUCTION

/* Host model of the relevant native registration rule, not a kernel probe. */
static int register_model(struct kprobe *kp, bool fail_after_lookup)
{
    assert(kp->symbol_name && !kp->addr);
    kp->addr = (void *)0x1234;
    kp->flags &= KPROBE_FLAG_DISABLED;
    if (fail_after_lookup)
        return -1;
    return (kp->flags & KPROBE_FLAG_DISABLED) ? 0 : 1;
}

static void unregister_model(struct kprobe *kp)
{
    kp->flags |= KPROBE_FLAG_DISABLED;
}

int main(int argc, char **argv)
{
    assert(argc == 2);
    bool ret = !strncmp(argv[1], "kretprobe-", 10);
    struct kretprobe rp = { .kp = { .symbol_name = "test_symbol" } };
    struct kprobe *kp = &rp.kp;
    const char *symbol = kp->symbol_name;
    const char *scenario = strchr(argv[1], '-') + 1;

    if (!strcmp(scenario, "cycles")) {
        for (int i = 0; i < 16; i++) {
            assert(register_model(kp, false) == 1);
            unregister_model(kp);
            assert(kp->addr && (kp->flags & KPROBE_FLAG_DISABLED));
            if (ret) susfs_krp_forget_addr(&rp);
            else susfs_kp_forget_addr(kp);
            assert(!kp->addr && !(kp->flags & KPROBE_FLAG_DISABLED));
            assert(kp->symbol_name == symbol);
        }
    } else if (!strcmp(scenario, "failed-lookup")) {
        kp->flags = KPROBE_FLAG_DISABLED;
        assert(register_model(kp, true) == -1 && kp->addr);
        if (ret) susfs_krp_forget_addr(&rp);
        else susfs_kp_forget_addr(kp);
        assert(register_model(kp, false) == 1);
    } else if (!strcmp(scenario, "preserve-flags")) {
        kp->flags = KPROBE_FLAG_GONE | KPROBE_FLAG_DISABLED | KPROBE_FLAG_OPTIMIZED;
        kp->addr = (void *)0x1234;
        if (ret) susfs_krp_forget_addr(&rp);
        else susfs_kp_forget_addr(kp);
        assert(!kp->addr && kp->symbol_name == symbol);
        assert(kp->flags == (KPROBE_FLAG_GONE | KPROBE_FLAG_OPTIMIZED));
    } else if (!strcmp(scenario, "idempotent")) {
        if (ret) { susfs_krp_forget_addr(&rp); susfs_krp_forget_addr(&rp); }
        else { susfs_kp_forget_addr(kp); susfs_kp_forget_addr(kp); }
        assert(!kp->addr && !kp->flags && kp->symbol_name == symbol);
    } else return 2;
    puts("PASS");
    return 0;
}
