#!/usr/bin/env python3
"""Exercise the production probe reuse helpers with a native-rule host model."""
import argparse
import json
import os
from pathlib import Path
import resource
import subprocess
import tempfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--sanitizers', action='store_true')
p.add_argument('--json', type=Path)
a = p.parse_args()
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
here = Path(__file__).resolve().parent
source = (here.parents[1] / 'kernel/susfs_kprobe.h').read_text()
without_fix = source.replace('kp->flags &= ~KPROBE_FLAG_DISABLED;', '')
without_fix = without_fix.replace('krp->kp.flags &= ~KPROBE_FLAG_DISABLED;', '')
assert source != without_fix
cases = [f'{kind}-{case}' for kind in ('kprobe', 'kretprobe')
         for case in ('cycles', 'failed-lookup', 'preserve-flags', 'idempotent')]
results = []
env = dict(os.environ, ASAN_OPTIONS='detect_leaks=0:abort_on_error=1', UBSAN_OPTIONS='halt_on_error=1')
with tempfile.TemporaryDirectory(prefix='susfs-probe-reuse-') as temporary:
    tmp = Path(temporary)
    (tmp / 'linux').mkdir()
    (tmp / 'linux/kprobes.h').write_text('''
#include <stddef.h>
#define KPROBE_FLAG_GONE 1
#define KPROBE_FLAG_DISABLED 2
#define KPROBE_FLAG_OPTIMIZED 4
struct kprobe { void *addr; const char *symbol_name; unsigned int flags; };
struct kretprobe { struct kprobe kp; };
''')
    for label, text in [('production', source), ('without-fix', without_fix)]:
        header = tmp / (label + '.h')
        header.write_text(text)
        exe = tmp / label
        flags = (['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-no-pie']
                 if a.sanitizers else ['-O2'])
        subprocess.run([os.environ.get('CC', 'cc'), '-std=gnu11', '-Wall', '-Wextra', '-Werror',
                        *flags, '-I', str(tmp), f'-DPRODUCTION="{header}"',
                        str(here / 'reuse_test.c'), '-o', str(exe)], check=True)
        for case in cases:
            if label == 'without-fix' and case.endswith('idempotent'):
                continue
            run = subprocess.run([str(exe), case], env=env, capture_output=True, text=True, timeout=10)
            passed = run.returncode == 0 if label == 'production' else run.returncode != 0
            results.append(dict(build=label, case=case, passed=passed, exit_code=run.returncode,
                                stdout=run.stdout, stderr=run.stderr[:3000]))
            print(('PASS ' if passed else 'FAIL ') + label + '/' + case)
if a.json:
    a.json.parent.mkdir(parents=True, exist_ok=True)
    a.json.write_text(json.dumps(dict(kind='actual helper header with host registration model',
                                     sanitizers=a.sanitizers, hardware_validated=False,
                                     results=results), indent=2) + '\n')
raise SystemExit(any(not result['passed'] for result in results))
