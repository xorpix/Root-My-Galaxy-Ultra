#!/usr/bin/env python3
"""Verify production redirect startup, fallback cleanup and refusal behavior."""
import argparse
import importlib.util
import os
from pathlib import Path
import re
import subprocess
import tempfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--sanitizers', action='store_true')
a = p.parse_args()
root = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('extract', root / 'tests/path_creds/run.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
source = (root / 'kernel/susfs_or_entry.c').read_text()
hook_table = source[source.index('static struct susfs_fp_hook or_hooks[]'):source.index('bool susfs_or_entry_armed')]
names = re.findall(r'\.name = "([^"]+)"', hook_table)
assert len(names) == 5
hooks = 'static struct susfs_fp_hook or_hooks[] = {' + ','.join('{.name="' + n + '"}' for n in names) + '};\n'
slots = re.findall(r'^static [^;\n]*\(\*(or_\w+_fn)\)', source, re.M)
assert len(slots) == 9
declarations = '\n'.join('static void *' + n + ';' for n in slots)
production = declarations + '\n' + hooks + '\n'
production += '\n\n'.join(extract.function(source, n) for n in (
    'susfs_or_entry_armed', 'susfs_or_entry_hits', 'or_entry_stat_get', 'susfs_or_entry_init'))
cases = ['pending', 'success', 'disabled', 'protected-table', 'protected-table-refused', 'missing-all', 'optional-missing', 'fail-all']
cases += ['missing-' + str(i) for i in range(7)]
cases += ['fail-' + str(i) for i in range(5)]
cases += ['fault-after-' + str(i) for i in range(5)]
flags = ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-no-pie'] if a.sanitizers else ['-O2']
env = dict(os.environ, ASAN_OPTIONS='detect_leaks=0:abort_on_error=1', UBSAN_OPTIONS='halt_on_error=1')
here = Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix='susfs-redirect-startup-') as work:
    work = Path(work)
    def build(text, label):
        header = work / (label + '.h')
        header.write_text(text)
        exe = work / label
        subprocess.run([os.environ.get('CC', 'cc'), '-std=gnu11', '-Wall', '-Wextra', '-Werror',
                        '-Wno-unused-parameter', *flags, '-DPRODUCTION="' + str(header) + '"',
                        str(here / 'startup_test.c'), '-o', str(exe)], check=True)
        return exe
    exe = build(production, 'startup')
    for case in cases:
        subprocess.run([str(exe), case], check=True, env=env, timeout=15)
    mutations = [
        ('required-symbol-lost', '|| !or_fd_install_fn ||\n\t    !or_put_unused_fd_fn)',
         '|| !or_fd_install_fn)', None, None, 'missing-6'),
        ('fallback-cleanup-lost', 'susfs_fp_remove(&or_hooks[i]);',
         '(void)susfs_fp_remove;', None, None, 'fault-after-1'),
        ('failed-fallback-published', 'if (!rc)\n\t\t\tsmp_store_release',
         'if (rc)\n\t\t\tsmp_store_release', None, None, 'protected-table-refused'),
        ('first-fault-stop-lost', 'table_fault = true;\n\t\t\tbreak;',
         'table_fault = true;\n\t\t\tcontinue;', None, None, 'protected-table'),
    ]
    for label, old, new, old2, new2, case in mutations:
        assert old in production
        changed = production.replace(old, new, 1)
        if old2:
            assert old2 in changed
            changed = changed.replace(old2, new2, 1)
        mutated = build(changed, label)
        result = subprocess.run([str(mutated), case], env=env, capture_output=True, timeout=15)
        assert result.returncode != 0, 'mutation escaped: ' + label
        print('PASS mutation rejected: ' + label)
