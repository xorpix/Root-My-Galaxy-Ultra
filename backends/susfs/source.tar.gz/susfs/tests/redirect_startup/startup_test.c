/* SPDX-License-Identifier: GPL-2.0 */
#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define READ_ONCE(x) (x)
#define WRITE_ONCE(x,v) ((x) = (v))
#define smp_store_release(p,v) (*(p)=(v))
#define ARRAY_SIZE(x) (sizeof(x) / sizeof((x)[0]))
#define PAGE_SIZE 4096
#define CONFIG_COMPAT 1
#define IS_ENABLED(x) (x)
#define SUSFS_OR_ENTRY_KIND_COUNT 5
#define SUSFS_LOGI(...) ((void)0)
#define pr_warn(...) ((void)0)
#define scnprintf snprintf
struct kernel_param { int unused; };
struct susfs_fp_hook { const char *name; bool installed, compat_installed; };
static bool or_entry_ready, or_entry_param = true;
static bool or_entry_probe_active;
static int fallback_rc;
static int or_entry_hits;
#define atomic_read(p) (*(p))
static unsigned int missing;
static bool optional_missing;
static int installs, removals, lookups, failures[5];
static const char *const required[] = {
    "getname_flags", "filename_lookup", "putname", "filp_open",
    "get_unused_fd_flags", "fd_install", "put_unused_fd",
};
static unsigned long find_kernel_symbol_exact(const char *name)
{
    unsigned int i;
    lookups++;
    for (i = 0; i < ARRAY_SIZE(required); i++)
        if (!strcmp(name, required[i]))
            return missing & (1U << i) ? 0 : 1;
    assert(!strcmp(name, "fsnotify_open") || !strcmp(name, "check_zeroed_user"));
    return optional_missing ? 0 : 1;
}
static int susfs_fp_install(struct susfs_fp_hook *hook)
{
    int rc = failures[installs++];
    if (!rc)
        hook->installed = hook->compat_installed = true;
    return rc;
}
static void susfs_fp_remove(struct susfs_fp_hook *h) {removals++;h->installed=h->compat_installed=false;}
static int or_entry_probe_start(void);
#include PRODUCTION
static int or_entry_probe_start(void)
{
    assert(removals == 5);
    for (int i = 0; i < 5; i++)
        assert(!or_hooks[i].installed && !or_hooks[i].compat_installed);
    or_entry_probe_active = !fallback_rc;
    return fallback_rc;
}
int main(int argc, char **argv)
{
    char buf[PAGE_SIZE];
    int target = -1, fault_at = -1, i;
    assert(argc == 2);
    const char *c = argv[1];
    if (!strcmp(c, "pending")) {
        or_entry_stat_get(buf, NULL);
        assert(!strcmp(buf, "armed=0 entries=0/5 hits=0\n"));
        puts("PASS pending");
        return 0;
    }
    if (!strncmp(c, "protected-table", 15)) {
        for (i = 0; i < 5; i++) failures[i] = -EFAULT;
        fault_at = 0;
        if (strstr(c, "refused")) fallback_rc = -EOPNOTSUPP;
    } else if (!strncmp(c, "fault-after-", 12)) {
        fault_at = atoi(c + 12);
        assert(fault_at >= 0 && fault_at < 5);
        failures[fault_at] = -EFAULT;
    } else if (!strcmp(c, "disabled")) or_entry_param = false;
    else if (!strncmp(c, "missing-", 8)) {
        if (!strcmp(c, "missing-all")) missing = 127;
        else { target = atoi(c + 8); assert(target >= 0 && target < 7); missing = 1U << target; }
    } else if (!strcmp(c, "optional-missing")) optional_missing = true;
    else if (!strcmp(c, "fail-all")) for (i = 0; i < 5; i++) failures[i] = -EIO;
    else if (!strncmp(c, "fail-", 5)) {
        target = atoi(c + 5); assert(target >= 0 && target < 5); failures[target] = -EIO - target;
    } else assert(!strcmp(c, "success"));
    assert(!susfs_or_entry_init());
    int n = or_entry_stat_get(buf, NULL);
    assert(n > 0 && n < 1000 && (size_t)n == strlen(buf));
    assert(!strstr(buf, "init_rc") && !strstr(buf, "hook_rc") && !strstr(buf, "probe_rc"));
    if (fault_at >= 0) {
        assert(installs == fault_at + 1);
        assert(or_entry_probe_active == !fallback_rc);
        assert(or_entry_ready == !fallback_rc && susfs_or_entry_armed() == !fallback_rc);
        assert(strstr(buf, fallback_rc ? "entries=0/5" : "entries=5/5"));
    } else if (!or_entry_param) {
        assert(!lookups && !installs && !or_entry_ready);
        assert(strstr(buf, "entries=0/5"));
    } else if (missing) {
        assert(lookups == 9 && !installs && !or_entry_ready);
        assert(strstr(buf, "entries=0/5"));
    } else {
        assert(lookups == 9 && installs == 5 && !removals && !or_entry_probe_active);
        for (i = 0; i < 5; i++)
            assert(or_hooks[i].installed == !failures[i]);
        if (!strcmp(c, "fail-all")) {
            assert(!or_entry_ready && !susfs_or_entry_armed());
            assert(strstr(buf, "entries=0/5"));
        } else if (target >= 0) {
            assert(or_entry_ready && !susfs_or_entry_armed());
            assert(strstr(buf, "entries=4/5"));
        } else {
            assert(or_entry_ready && susfs_or_entry_armed());
            assert(strstr(buf, "armed=1 entries=5/5"));
        }
    }
    printf("PASS %s\n", c);
    return 0;
}
