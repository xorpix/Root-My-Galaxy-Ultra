/* SPDX-License-Identifier: GPL-2.0 */
#include <assert.h>
#include <ctype.h>
#include <errno.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define __user
#define ARRAY_SIZE(x) (sizeof(x)/sizeof((x)[0]))
#define READ_ONCE(x) __atomic_load_n(&(x), __ATOMIC_ACQUIRE)
#define WRITE_ONCE(x,v) __atomic_store_n(&(x), (v), __ATOMIC_RELEASE)
#define container_of(p,t,m) ((t *)((char *)(p)-offsetof(t,m)))
#define static_assert _Static_assert
#define __same_type(a,b) __builtin_types_compatible_p(a,b)
#define smp_mb__after_atomic() atomic_thread_fence(memory_order_seq_cst)
#define smp_mb__before_atomic() atomic_thread_fence(memory_order_seq_cst)
#define smp_wmb() atomic_thread_fence(memory_order_release)
#define PATH_MAX 4096
#define GFP_KERNEL 0
#define KSU_PATCH_TEXT_FLUSH_DCACHE 1
#define PTRACE_MODE_READ_FSCREDS 16
#define ERR_PTR(x) ((void *)(intptr_t)(x))
#define PTR_ERR(x) ((long)(intptr_t)(x))
#define IS_ERR(x) ((uintptr_t)(x) >= (uintptr_t)-4095)
#define min_t(t,a,b) ((t)(a)<(t)(b)?(t)(a):(t)(b))
typedef uint64_t u64;
typedef _Atomic int atomic_t;
#define ATOMIC_INIT(x) (x)
static void atomic_inc(atomic_t *v) { atomic_fetch_add(v,1); }
static int atomic_read(atomic_t *v) { return atomic_load(v); }
static bool atomic_dec_and_test(atomic_t *v) { return atomic_fetch_sub(v,1)==1; }
struct host_waitq { pthread_mutex_t lock; pthread_cond_t cv; };
#define DECLARE_WAIT_QUEUE_HEAD(n) struct host_waitq n = {PTHREAD_MUTEX_INITIALIZER,PTHREAD_COND_INITIALIZER}
static void wake_up_all(struct host_waitq *q)
{ pthread_mutex_lock(&q->lock); pthread_cond_broadcast(&q->cv); pthread_mutex_unlock(&q->lock); }
#define wait_event(q,condition) do { pthread_mutex_lock(&(q).lock); while (!(condition)) pthread_cond_wait(&(q).cv,&(q).lock); pthread_mutex_unlock(&(q).lock); } while(0)
static atomic_t host_rcu, host_tasks;
static void synchronize_rcu(void) { atomic_inc(&host_rcu); }
static void synchronize_rcu_tasks(void) { atomic_inc(&host_tasks); }
static int host_restore_retries, host_reject_without_write_at;
static void msleep(int n)
{
    (void)n;
    host_restore_retries++;
    /* Bound the old infinite rollback so its negative control fails promptly. */
    assert(!host_reject_without_write_at || host_restore_retries < 4);
}
#define pr_emerg(...) ((void)0)
#define pr_err(...) ((void)0)
static _Thread_local bool host_in_probe;
static _Thread_local unsigned int host_dispatch_calls;
static void host_process_context(void) { assert(!host_in_probe); }

struct list_head { struct list_head *next, *prev; };
#define LIST_HEAD(n) struct list_head n = {&(n), &(n)}
static void list_add(struct list_head *n, struct list_head *h)
{ n->next=h->next; n->prev=h; h->next->prev=n; h->next=n; }
static void list_del(struct list_head *n)
{ n->prev->next=n->next; n->next->prev=n->prev; }
#define list_for_each_entry(p,h,m) for (p=container_of((h)->next,typeof(*p),m); &(p)->m!=(h); p=container_of((p)->m.next,typeof(*p),m))
#define DEFINE_SPINLOCK(n) pthread_mutex_t n=PTHREAD_MUTEX_INITIALIZER
#define spin_lock_irqsave(n,f) do { (f)=0; pthread_mutex_lock(n); } while(0)
#define spin_unlock_irqrestore(n,f) do { (void)(f); pthread_mutex_unlock(n); } while(0)
struct pt_regs { unsigned long regs[31], pc; };
struct kprobe { const char *symbol_name; void *addr; unsigned int flags; int (*pre_handler)(struct kprobe *,struct pt_regs *); };
static void instruction_pointer_set(struct pt_regs *r,unsigned long pc) { r->pc=pc; }
static struct kprobe *host_live_probes[5];
static int host_registration_count,host_registration_fail_at,host_wrong_entry_at;
static int host_dispatch(int slot,struct pt_regs *regs)
{
    assert(++host_dispatch_calls < 1000); /* bounded recursion-defect control */
    struct kprobe *p=READ_ONCE(host_live_probes[slot]);
    if (!p || p->flags) return 0;
    assert(!host_in_probe); host_in_probe=true;
    int rc=p->pre_handler(p,regs);
    host_in_probe=false;
    return rc;
}
struct inode_operations;
struct mm_struct;
struct task_struct { struct mm_struct *mm; int refs; };
static _Thread_local struct task_struct host_current;
#define current (&host_current)
struct super_block { unsigned long s_dev; };
struct inode { unsigned long i_ino; struct super_block *i_sb; struct task_struct *task; const struct inode_operations *i_op; };
struct qstr { const char *name; unsigned int len; };
struct dentry { struct qstr d_name; struct inode *inode; };
struct path { struct dentry *dentry; };
struct file { struct inode *inode; struct path f_path; unsigned int f_mode; };
struct vm_area_struct {
    unsigned long vm_start, vm_end, pad_end;
    struct file *vm_file;
};
#define VMA_PAD_START(v) ((v)->pad_end ? (v)->pad_end : (v)->vm_end)
#define PAGE_SHIFT 12
static unsigned long vma_pad_pages(struct vm_area_struct *vma)
{ return vma->pad_end ? (vma->vm_end - vma->pad_end) >> PAGE_SHIFT : 0; }
struct mm_struct { struct vm_area_struct vmas[4]; int count, refs; bool read_locked; };
struct delayed_call { void *cookie; };
struct dir_context;
typedef bool (*filldir_t)(struct dir_context *,const char *,int,loff_t,u64,unsigned int);
struct dir_context { filldir_t actor; loff_t pos; };
struct file_operations { int (*iterate_shared)(struct file *,struct dir_context *); };
struct inode_operations {
    int (*readlink)(struct dentry *,char *,int);
    const char *(*get_link)(struct dentry *,struct inode *,struct delayed_call *);
    struct dentry *(*lookup)(struct inode *,struct dentry *,unsigned int);
};
struct dentry_operations { int (*d_revalidate)(struct dentry *,unsigned int); };
#define LOOKUP_RCU 0x0040
static int host_uid=10362, host_ptrace=1, host_cap=1;
static bool sus_map_gate_ok(void) { return host_uid>=10000; }
static int nmap=1;
static unsigned long host_rule_ino=100, host_rule_dev=11;
static bool sus_map_lookup(unsigned long ino,unsigned long dev)
{ return nmap && ino==host_rule_ino && (!host_rule_dev || dev==host_rule_dev); }
static int init_user_ns;
static bool checkpoint_restore_ns_capable(void *ns) { assert(ns==&init_user_ns); return host_cap; }
static struct inode *d_inode(struct dentry *d) { return d->inode; }
static struct inode *file_inode(struct file *f) { return f->inode; }
static const struct path *file_user_path(struct file *f) { return &f->f_path; }
static int host_task_calls, host_lock_calls;
static struct task_struct *get_proc_task(struct inode *i)
{ host_process_context(); host_task_calls++; if (!i->task) return NULL; i->task->refs++; return i->task; }
static void put_task_struct(struct task_struct *t) { assert(t->refs>0); t->refs--; }
static struct mm_struct *get_task_mm(struct task_struct *t)
{ host_process_context(); if (!t->mm) return NULL; t->mm->refs++; return t->mm; }
static void mmput(struct mm_struct *mm) { assert(mm->refs>0); mm->refs--; }
static bool ptrace_may_access(struct task_struct *task,unsigned int mode)
{ (void)task; assert(mode==PTRACE_MODE_READ_FSCREDS); return host_ptrace; }
static int host_lock_error;
static int mmap_read_lock_killable(struct mm_struct *mm)
{ host_process_context(); host_lock_calls++; assert(!mm->read_locked); if (host_lock_error) return host_lock_error; mm->read_locked=true; return 0; }
static void mmap_read_unlock(struct mm_struct *mm) { assert(mm->read_locked); mm->read_locked=false; }
static struct vm_area_struct *find_vma(struct mm_struct *mm,unsigned long start)
{ assert(mm->read_locked); for (int i=0;i<mm->count;i++) if (mm->vmas[i].vm_end>start) return &mm->vmas[i]; return NULL; }
static struct vm_area_struct *find_exact_vma(struct mm_struct *mm,unsigned long start,unsigned long end)
{ struct vm_area_struct *v=find_vma(mm,start); return v && v->vm_start==start && v->vm_end==end ? v : NULL; }
static int host_path_refs, host_path_gets, host_path_puts;
static void path_get(const struct path *p) { host_process_context(); assert(p->dentry); host_path_refs++; host_path_gets++; }
static void path_put(const struct path *p) { host_process_context(); assert(p->dentry && host_path_refs>0); host_path_refs--; host_path_puts++; }
static bool host_alloc_fail, host_copy_fail, host_dpath_fail;
static int host_heap_refs;
static void *kmalloc(size_t n,int flags) { host_process_context(); (void)flags; if (host_alloc_fail) return NULL; void *p=malloc(n); if(p) host_heap_refs++; return p; }
static void kfree(void *p) { assert(p && host_heap_refs>0); host_heap_refs--; free(p); }
static char *d_path(const struct path *p,char *buf,int size)
{ (void)p; if (host_dpath_fail) return ERR_PTR(-ENAMETOOLONG); const char *name="/control.bin"; size_t n=strlen(name); memcpy(buf+size-n-1,name,n+1); return buf+size-n-1; }
static int copy_to_user(void *dst,const void *src,size_t n)
{ if (host_copy_fail) return 1; memcpy(dst,src,n); return 0; }
static int host_jump_error;
static int nd_jump_link(const struct path *p) { path_put(p); return host_jump_error; }

static atomic_t n_getlink_calls,n_getlink_skip,n_getlink_nomatch,n_map_files_hides;
static int host_native_reads,host_native_follows;
static struct host_waitq host_block = {PTHREAD_MUTEX_INITIALIZER,PTHREAD_COND_INITIALIZER};
static bool host_block_reader,host_reader_inside,host_release_reader;
static int native_readlink(struct dentry *d,char *buf,int len)
{
    struct pt_regs regs={.regs={(unsigned long)d,(unsigned long)buf,(unsigned long)len}};
    if (host_dispatch(1,&regs))
        return ((int (*)(struct dentry *,char *,int))regs.pc)(d,buf,len);
    (void)d; (void)buf; (void)len; host_native_reads++;
    pthread_mutex_lock(&host_block.lock);
    if (host_block_reader) {
        host_reader_inside=true; pthread_cond_broadcast(&host_block.cv);
        while (!host_release_reader) pthread_cond_wait(&host_block.cv,&host_block.lock);
    }
    pthread_mutex_unlock(&host_block.lock);
    return 7;
}
static const char *native_get_link(struct dentry *d,struct inode *i,struct delayed_call *done)
{
    struct pt_regs regs={.regs={(unsigned long)d,(unsigned long)i,(unsigned long)done}};
    if (host_dispatch(2,&regs))
        return ((const char *(*)(struct dentry *,struct inode *,struct delayed_call *))regs.pc)(d,i,done);
    (void)i; (void)done; host_native_follows++; return ERR_PTR(d ? -EPERM : -ECHILD);
}
static int wrong_iterate(struct file *f,struct dir_context *c) { (void)f;(void)c;return 1; }
static int native_iterate(struct file *f,struct dir_context *ctx);
static struct file_operations host_fops = {.iterate_shared=native_iterate};
static struct inode_operations host_iops = {.readlink=native_readlink,.get_link=native_get_link};
static struct dentry *native_lookup(struct inode *,struct dentry *,unsigned int);
static int native_revalidate(struct dentry *,unsigned int);
static struct dentry *native_instantiate(struct dentry *,struct task_struct *,const void *);
static struct inode_operations host_dir_iops = {.lookup=native_lookup};
static struct dentry_operations host_dops = {.d_revalidate=native_revalidate};
static bool host_missing_symbols,host_ambiguous_symbols,host_missing_access,host_missing_padding;
static bool host_missing_instantiate;
static int ksu_find_symbol_all(const char *name,unsigned long *out,int max)
{
 assert(max==2); if(host_missing_symbols)return 0; if(host_ambiguous_symbols)return 2;
 if(!strcmp(name,"proc_map_files_operations"))out[0]=(unsigned long)&host_fops;
 else if(!strcmp(name,"proc_map_files_link_inode_operations"))out[0]=(unsigned long)&host_iops;
 else if(!strcmp(name,"proc_map_files_inode_operations"))out[0]=(unsigned long)&host_dir_iops;
 else {assert(!strcmp(name,"tid_map_files_dentry_operations"));out[0]=(unsigned long)&host_dops;}
 return 1;
}
static unsigned long find_kernel_symbol_exact(const char *name)
{ assert(!strcmp(name,"nd_jump_link")); return (unsigned long)nd_jump_link; }
static void *ksu_resolve_symbol_for_functable_hook(const char *name)
{ if (!strcmp(name,"vma_pad_pages")) return host_missing_padding ? NULL : vma_pad_pages; if (!strcmp(name,"ptrace_may_access")) return host_missing_access ? NULL : ptrace_may_access; if (!strcmp(name,"proc_map_files_readdir")) return native_iterate; if (!strcmp(name,"proc_pid_readlink")) return native_readlink; if (!strcmp(name,"proc_map_files_get_link")) return native_get_link; if(!strcmp(name,"proc_map_files_lookup"))return native_lookup; if(!strcmp(name,"map_files_d_revalidate"))return native_revalidate; assert(!strcmp(name,"proc_map_files_instantiate"));return host_missing_instantiate ? NULL : native_instantiate; }
static atomic_t host_patch_count;
static int host_patch_fail_at,host_verify_fail_at,host_restore_failures;
static void *host_last_patch_address;
static void *host_rejected_address;
static int ksu_patch_text(void *address,void *src,size_t n,int flags)
{
    assert(n==sizeof(void *) && flags==KSU_PATCH_TEXT_FLUSH_DCACHE);
    int count=atomic_fetch_add(&host_patch_count,1)+1;
    if (count==host_reject_without_write_at || address==host_rejected_address) {
        host_rejected_address=address;
        return -EACCES;
    }
    if (host_restore_failures && count>host_patch_fail_at) { host_restore_failures--; return -EIO; }
    memcpy(address,src,n); host_last_patch_address=address;
    return count==host_patch_fail_at ? -EIO : 0;
}
static int copy_from_kernel_nofault(void *dst,const void *src,size_t n)
{ if (atomic_read(&host_patch_count)==host_verify_fail_at) return -EFAULT; memcpy(dst,src,n); return 0; }

static int register_kprobe(struct kprobe *p)
{
    host_process_context();
    assert(!p->addr && !p->flags);
    int slot=!strcmp(p->symbol_name,"proc_map_files_readdir") ? 0 : !strcmp(p->symbol_name,"proc_pid_readlink") ? 1 : !strcmp(p->symbol_name,"proc_map_files_get_link") ? 2 : !strcmp(p->symbol_name,"proc_map_files_lookup") ? 3 : 4;
    int n=++host_registration_count;
    if (n==host_registration_fail_at) return -ENOENT;
    p->addr=slot==0 ? (void *)native_iterate : slot==1 ? (void *)native_readlink : slot==2 ? (void *)native_get_link : slot==3 ? (void *)native_lookup : (void *)native_revalidate;
    if(n==host_wrong_entry_at) p->addr=(void *)((uintptr_t)p->addr+4);
    WRITE_ONCE(host_live_probes[slot],p);
    return 0;
}
static void unregister_kprobe(struct kprobe *p)
{
    host_process_context();
    for(int i=0;i<5;i++) if(READ_ONCE(host_live_probes[i])==p) WRITE_ONCE(host_live_probes[i],NULL);
    p->flags=1;
}
