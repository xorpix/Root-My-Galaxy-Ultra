/* SPDX-License-Identifier: GPL-2.0 */
#include "host_kernel.h"
#include PRODUCTION

static struct super_block sb={11};
static struct inode mapped_inode[2]={{.i_ino=100,.i_sb=&sb},{.i_ino=101,.i_sb=&sb}};
static struct dentry mapped_dentry[2]={{.inode=&mapped_inode[0]},{.inode=&mapped_inode[1]}};
static struct file mapped_file[2]={{.inode=&mapped_inode[0],.f_path={&mapped_dentry[0]},.f_mode=3},{.inode=&mapped_inode[1],.f_path={&mapped_dentry[1]},.f_mode=1}};
static struct mm_struct mm={.vmas={{.vm_start=0x1000,.vm_end=0x2000,.vm_file=&mapped_file[0]},{.vm_start=0x3000,.vm_end=0x4000,.vm_file=&mapped_file[1]}},.count=2};
static struct task_struct task={.mm=&mm};
static struct inode proc_inode={.task=&task,.i_op=&host_iops};
static struct dentry target={.d_name={"1000-2000",9},.inode=&proc_inode};
static struct dentry control={.d_name={"3000-4000",9},.inode=&proc_inode};
static struct file directory={.inode=&proc_inode};
static int host_native_lookups,host_native_revalidations,host_instantiations;
static int host_revalidate_result=1,host_instantiate_error;
static unsigned long host_instantiated_ino;

static struct dentry *native_instantiate(struct dentry *dentry,struct task_struct *owner,const void *mode)
{
    host_process_context(); assert(owner==&task && mm.read_locked);
    unsigned long start,end;
    assert(sus_map_files_range(dentry->d_name.name,dentry->d_name.len,&start,&end));
    struct vm_area_struct *vma=find_exact_vma(&mm,start,end);
    assert(vma && vma->vm_file && (unsigned long)mode==vma->vm_file->f_mode);
    host_instantiations++;host_instantiated_ino=file_inode(vma->vm_file)->i_ino;
    if(host_instantiate_error)return ERR_PTR(host_instantiate_error);
    dentry->inode=&proc_inode;
    return NULL;
}

static struct dentry *native_lookup(struct inode *dir,struct dentry *dentry,unsigned int flags)
{
    struct pt_regs regs={.regs={(unsigned long)dir,(unsigned long)dentry,flags}};
    if(host_dispatch(3,&regs))
        return ((struct dentry *(*)(struct inode *,struct dentry *,unsigned int))regs.pc)(dir,dentry,flags);
    host_process_context(); assert(!mm.read_locked);host_native_lookups++;
    if(!dir->task || !dir->task->mm)return ERR_PTR(-ENOENT);
    if(!host_ptrace)return ERR_PTR(-EACCES);
    unsigned long start,end;
    if(!sus_map_files_range(dentry->d_name.name,dentry->d_name.len,&start,&end))return ERR_PTR(-ENOENT);
    int rc=mmap_read_lock_killable(&mm);if(rc)return ERR_PTR(-EINTR);
    struct vm_area_struct *vma=find_exact_vma(&mm,start,end);
    struct dentry *result=vma && vma->vm_file ? native_instantiate(dentry,&task,(void *)(unsigned long)vma->vm_file->f_mode) : ERR_PTR(-ENOENT);
    mmap_read_unlock(&mm);return result;
}

static int native_revalidate(struct dentry *dentry,unsigned int flags)
{
    struct pt_regs regs={.regs={(unsigned long)dentry,flags}};
    if(host_dispatch(4,&regs))return ((int (*)(struct dentry *,unsigned int))regs.pc)(dentry,flags);
    if(flags&LOOKUP_RCU)return -ECHILD;
    host_process_context();assert(!mm.read_locked);host_native_revalidations++;
    pthread_mutex_lock(&host_block.lock);
    if(host_block_reader){host_reader_inside=true;pthread_cond_broadcast(&host_block.cv);while(!host_release_reader)pthread_cond_wait(&host_block.cv,&host_block.lock);}
    pthread_mutex_unlock(&host_block.lock);
    if(!host_ptrace)return 0; /* native mm_access denial invalidates the cache */
    return host_revalidate_result;
}

static int native_iterate(struct file *file,struct dir_context *ctx)
{
    struct pt_regs regs={.regs={(unsigned long)file,(unsigned long)ctx}};
    if (host_dispatch(0,&regs))
        return ((int (*)(struct file *,struct dir_context *))regs.pc)(file,ctx);
    pthread_mutex_lock(&host_block.lock);
    if (host_block_reader) {
        host_reader_inside=true; pthread_cond_broadcast(&host_block.cv);
        while(!host_release_reader) pthread_cond_wait(&host_block.cv,&host_block.lock);
    }
    pthread_mutex_unlock(&host_block.lock);
    const char *names[]={".","..","1000-2000","3000-4000"};
    while (ctx->pos<4) {
        const char *name=names[ctx->pos];
        if (!ctx->actor(ctx,name,(int)strlen(name),ctx->pos,700+ctx->pos,ctx->pos<2 ? 4 : 10)) break;
        ctx->pos++;
    }
    return host_ptrace ? 0 : -EACCES;
}
struct output { struct dir_context ctx; int count,capacity; char names[8][40]; loff_t cookies[8]; };
static bool actor(struct dir_context *ctx,const char *name,int len,loff_t offset,u64 ino,unsigned int type)
{
    struct output *o=container_of(ctx,struct output,ctx);
    assert(!mm.read_locked && ctx->pos==offset && ino==(u64)(700+offset));
    assert(type==(offset<2 ? 4U : 10U));
    if (o->count==o->capacity) return false;
    assert(len<40); memcpy(o->names[o->count],name,len); o->names[o->count][len]=0;
    o->cookies[o->count]=offset; o->count++; return true;
}
static void native_restored(void)
{
    assert(host_fops.iterate_shared==native_iterate && host_iops.readlink==native_readlink && host_iops.get_link==native_get_link);
    assert(!map_files_installed && !atomic_read(&map_files_callbacks));
    for(int i=0;i<5;i++)assert(!host_live_probes[i]);
    assert(host_dir_iops.lookup==native_lookup && host_dops.d_revalidate==native_revalidate);
    assert(map_files_guards.next==&map_files_guards && !atomic_read(&host_patch_count));
    assert(!mm.refs && !task.refs && !host_path_refs && !host_heap_refs && !mm.read_locked);
}
static void *sleeping_reader(void *unused)
{ (void)unused; struct output o={.ctx={.actor=actor},.capacity=8}; assert(!host_fops.iterate_shared(&directory,&o.ctx) && o.count==3); return NULL; }
static void *sleeping_metadata(void *unused)
{ (void)unused;assert(host_dops.d_revalidate(&target,0)==-ENOENT);return NULL; }
static atomic_t teardown_finished;
static void *teardown(void *unused)
{ (void)unused; sus_map_files_remove(); atomic_store(&teardown_finished,1); return NULL; }

int main(int argc,char **argv)
{
    assert(argc==2); const char *name=argv[1]; char buf[50]={0};
    if (!strcmp(name,"missing-symbol")) {
        host_missing_symbols=true; assert(sus_map_files_install()==-ENOENT); native_restored();
    } else if (!strcmp(name,"ambiguous-symbol")) {
        host_ambiguous_symbols=true; assert(sus_map_files_install()==-ENOENT); native_restored();
    } else if (!strcmp(name,"missing-access-helper")) {
        host_missing_access=true; assert(sus_map_files_install()==-EINVAL && !atomic_read(&host_patch_count)); native_restored();
    } else if (!strcmp(name,"missing-padding-helper")) {
        host_missing_padding=true; assert(sus_map_files_install()==-EINVAL && !atomic_read(&host_patch_count)); native_restored();
    } else if (!strcmp(name,"missing-instantiate-helper")) {
        host_missing_instantiate=true;assert(sus_map_files_install()==-EINVAL);native_restored();
    } else if (!strcmp(name,"wrong-callback")) {
        host_fops.iterate_shared=wrong_iterate; assert(sus_map_files_install()==-EINVAL);
        assert(!atomic_read(&host_patch_count)); host_fops.iterate_shared=native_iterate; native_restored();
    } else if (!strcmp(name,"first-probe-failure") || !strcmp(name,"later-probe-failure") || !strcmp(name,"lookup-probe-failure") || !strcmp(name,"revalidate-probe-failure") || !strcmp(name,"wrong-entry")) {
        if(!strcmp(name,"wrong-entry")) host_wrong_entry_at=2;
        else host_registration_fail_at=!strcmp(name,"first-probe-failure") ? 1 : !strcmp(name,"lookup-probe-failure") ? 4 : !strcmp(name,"revalidate-probe-failure") ? 5 : 2;
        assert(sus_map_files_install()==(!strcmp(name,"wrong-entry") ? -EINVAL : -ENOENT));
        native_restored();
        assert(atomic_read(&host_tasks)==2);
        host_registration_fail_at=host_wrong_entry_at=0;
        assert(!sus_map_files_install()); sus_map_files_remove(); native_restored();
    } else {
        assert(!sus_map_files_install() && map_files_installed);
        assert(host_fops.iterate_shared==native_iterate && host_iops.readlink==native_readlink && host_iops.get_link==native_get_link);
        for(int i=0;i<5;i++)assert(host_live_probes[i]);
        assert(!atomic_read(&host_patch_count));
        if (!strcmp(name,"range-parser")) {
            unsigned long start,end;
            assert(sus_map_files_range("ABC-DEF",7,&start,&end) && start==0xabc && end==0xdef);
            assert(sus_map_files_range("1-ffffffffffffffff",18,&start,&end));
            const char *invalid[]={".","..","","1000", "01-2","1-02","2-1","1-1","g-2","1-2x","1-10000000000000000"};
            for(size_t i=0;i<ARRAY_SIZE(invalid);i++) assert(!sus_map_files_range(invalid[i],(int)strlen(invalid[i]),&start,&end));
            const char bounded[]={'1','-','2','x'}; assert(sus_map_files_range(bounded,3,&start,&end));
        } else if (!strcmp(name,"hidden-readlink")) {
            assert(host_iops.readlink(&target,buf,sizeof(buf))==-ENOENT);
            assert(!host_path_gets && !host_native_reads && atomic_read(&n_map_files_hides)==1);
        } else if (!strcmp(name,"visible-readlink")) {
            assert(host_iops.readlink(&control,buf,sizeof(buf))==12 && !memcmp(buf,"/control.bin",12));
            assert(host_path_gets==1 && host_path_puts==1 && !host_path_refs);
            assert(host_iops.readlink(&control,buf,4)==4 && !memcmp(buf,"/con",4));
        } else if (!strcmp(name,"path-errors")) {
            host_alloc_fail=true; assert(host_iops.readlink(&control,buf,40)==-ENOMEM);
            host_alloc_fail=false; host_copy_fail=true; assert(host_iops.readlink(&control,buf,40)==-EFAULT);
            host_copy_fail=false; host_dpath_fail=true; assert(host_iops.readlink(&control,buf,40)==-ENAMETOOLONG);
            assert(host_path_gets==3 && host_path_puts==3 && !host_path_refs);
        } else if (!strcmp(name,"root-passthrough") || !strcmp(name,"empty-rules")) {
            if (!strcmp(name,"root-passthrough")) host_uid=0; else nmap=0;
            assert(host_iops.readlink(&target,buf,40)==7 && host_native_reads==1);
            assert(PTR_ERR(host_iops.get_link(&target,&proc_inode,NULL))==-EPERM && host_native_follows==1);
            struct output o={.ctx={.actor=actor},.capacity=8}; assert(!host_fops.iterate_shared(&directory,&o.ctx)); assert(o.count==4);
        } else if (!strcmp(name,"ptrace-denied")) {
            host_ptrace=0; assert(host_iops.readlink(&target,buf,40)==-EACCES);
            assert(PTR_ERR(host_iops.get_link(&target,&proc_inode,NULL))==-EACCES && !host_path_gets);
        } else if (!strcmp(name,"follow-ownership")) {
            assert(PTR_ERR(host_iops.get_link(&target,&proc_inode,NULL))==-ENOENT && !host_path_gets);
            assert(host_iops.get_link(&control,&proc_inode,NULL)==NULL && !host_path_refs);
            host_jump_error=-ELOOP; assert(PTR_ERR(host_iops.get_link(&control,&proc_inode,NULL))==-ELOOP && !host_path_refs);
            assert(host_path_gets==2 && host_path_puts==2 && atomic_read(&n_map_files_jumps)==2);
        } else if (!strcmp(name,"follow-security")) {
            host_cap=0; assert(PTR_ERR(host_iops.get_link(&target,&proc_inode,NULL))==-EPERM);
            assert(PTR_ERR(host_iops.get_link(NULL,&proc_inode,NULL))==-ECHILD && host_native_follows==1 && !host_path_gets);
        } else if (!strcmp(name,"enumeration") || !strcmp(name,"small-buffer")) {
            struct output o={.ctx={.actor=actor},.capacity=!strcmp(name,"small-buffer") ? 1 : 8};
            if (o.capacity==1) {
                assert(!host_fops.iterate_shared(&directory,&o.ctx)); assert(o.ctx.pos==1 && o.count==1 && !strcmp(o.names[0],"."));
                o.count=0; assert(!host_fops.iterate_shared(&directory,&o.ctx)); assert(o.ctx.pos==3 && o.count==1 && !strcmp(o.names[0],".."));
                o.count=0; assert(!host_fops.iterate_shared(&directory,&o.ctx)); assert(o.ctx.pos==4 && o.count==1 && !strcmp(o.names[0],"3000-4000") && o.cookies[0]==3);
            } else {
                assert(!host_fops.iterate_shared(&directory,&o.ctx)); assert(o.ctx.pos==4 && o.count==3 && !strcmp(o.names[2],"3000-4000") && o.cookies[2]==3);
            }
            assert(atomic_read(&n_map_files_entries_hidden)==1);
            o.count=0; o.ctx.pos=2; assert(!host_fops.iterate_shared(&directory,&o.ctx)); assert(o.count==1 && o.cookies[0]==3);
        } else if (!strcmp(name,"lock-interrupt")) {
            host_lock_error=-EINTR; assert(host_iops.readlink(&target,buf,40)==-EINTR);
            struct output o={.ctx={.actor=actor,.pos=2},.capacity=8}; assert(host_fops.iterate_shared(&directory,&o.ctx)==-EINTR && o.ctx.pos==2 && !o.count);
            assert(!host_path_gets && !mm.refs);
        } else if (!strcmp(name,"device-isolation")) {
            host_rule_dev=12; assert(host_iops.readlink(&target,buf,40)==12);
            struct output o={.ctx={.actor=actor},.capacity=8}; assert(!host_fops.iterate_shared(&directory,&o.ctx) && o.count==4);
            host_rule_dev=0; assert(host_iops.readlink(&target,buf,40)==-ENOENT);
        } else if (!strcmp(name,"padding-aware")) {
            mm.vmas[0].vm_end=0x3000; mm.vmas[0].pad_end=0x2000;
            assert(host_iops.readlink(&target,buf,40)==-ENOENT);
            struct output o={.ctx={.actor=actor},.capacity=8}; assert(!host_fops.iterate_shared(&directory,&o.ctx) && o.count==3);
            /* Preserve the native nonresolving padded link for a control too. */
            host_rule_ino=999; assert(host_iops.readlink(&target,buf,40)==-ENOENT && !host_path_gets);
        } else if (!strcmp(name,"remap-identity")) {
            mm.vmas[0].vm_file=&mapped_file[1]; assert(host_iops.readlink(&target,buf,40)==12 && !host_path_refs);
            mm.vmas[0].vm_file=&mapped_file[0]; assert(host_iops.readlink(&target,buf,40)==-ENOENT && !host_path_refs);
        } else if (!strcmp(name,"restore-rules")) {
            assert(host_iops.readlink(&target,buf,40)==-ENOENT); nmap=0;
            assert(host_iops.readlink(&target,buf,40)==7);
            struct output o={.ctx={.actor=actor},.capacity=8}; assert(!host_fops.iterate_shared(&directory,&o.ctx) && o.count==4);
        } else if (!strcmp(name,"cached-hidden")) {
            assert(host_dops.d_revalidate(&target,0)==-ENOENT);
            assert(host_dops.d_revalidate(&target,0)==-ENOENT); /* same cached entry, O_PATH */
            assert(target.inode==&proc_inode && atomic_read(&n_map_files_revalidate_hides)==2);
            assert(host_native_revalidations==2 && !host_instantiations && !host_path_gets);
        } else if (!strcmp(name,"cached-control")) {
            assert(host_dops.d_revalidate(&control,0)==1);
            assert(host_native_revalidations==1 && !atomic_read(&n_map_files_revalidate_hides));
        } else if (!strcmp(name,"cached-rcu")) {
            assert(host_dops.d_revalidate(&target,LOOKUP_RCU)==-ECHILD);
            assert(!host_task_calls && !host_lock_calls && !host_native_revalidations);
            assert(host_dops.d_revalidate(&target,0)==-ENOENT);
        } else if (!strcmp(name,"cached-native-failures")) {
            host_ptrace=0;assert(host_dops.d_revalidate(&target,0)==0 && !host_task_calls);
            host_ptrace=1;host_revalidate_result=-EACCES;
            assert(host_dops.d_revalidate(&target,0)==-EACCES && !host_task_calls);
            host_revalidate_result=-EINTR;assert(host_dops.d_revalidate(&target,0)==-EINTR);
        } else if (!strcmp(name,"cached-restore")) {
            assert(host_dops.d_revalidate(&target,0)==-ENOENT);
            nmap=0;assert(host_dops.d_revalidate(&target,0)==1);
            nmap=1;assert(host_dops.d_revalidate(&target,0)==-ENOENT);
        } else if (!strcmp(name,"cached-remap")) {
            mm.vmas[0].vm_file=&mapped_file[1];assert(host_dops.d_revalidate(&target,0)==1);
            mm.vmas[0].vm_file=&mapped_file[0];assert(host_dops.d_revalidate(&target,0)==-ENOENT);
        } else if (!strcmp(name,"cold-hidden")) {
            struct dentry cold={.d_name={"1000-2000",9}};
            assert(PTR_ERR(host_dir_iops.lookup(&proc_inode,&cold,0))==-ENOENT);
            assert(!cold.inode && !host_instantiations && !host_native_lookups);
        } else if (!strcmp(name,"cold-control")) {
            struct dentry cold={.d_name={"3000-4000",9}};
            assert(host_dir_iops.lookup(&proc_inode,&cold,0)==NULL);
            assert(cold.inode==&proc_inode && host_instantiations==1 && host_instantiated_ino==101);
            assert(!host_path_gets && !host_native_lookups);
        } else if (!strcmp(name,"cold-errors")) {
            host_ptrace=0;assert(PTR_ERR(host_dir_iops.lookup(&proc_inode,&target,0))==-EACCES);
            host_ptrace=1;host_lock_error=-EINTR;
            assert(PTR_ERR(host_dir_iops.lookup(&proc_inode,&target,0))==-EINTR);
            host_lock_error=0;struct dentry bad={.d_name={"1000-2001",9}};
            assert(PTR_ERR(host_dir_iops.lookup(&proc_inode,&bad,0))==-ENOENT);
            bad.d_name.name="01-2";bad.d_name.len=4;assert(PTR_ERR(host_dir_iops.lookup(&proc_inode,&bad,0))==-ENOENT);
            mm.vmas[0].vm_file=NULL;assert(PTR_ERR(host_dir_iops.lookup(&proc_inode,&target,0))==-ENOENT);
            assert(!host_instantiations && !host_path_gets);
        } else if (!strcmp(name,"cold-instantiate-failure")) {
            host_instantiate_error=-ENOMEM;assert(PTR_ERR(host_dir_iops.lookup(&proc_inode,&control,0))==-ENOMEM);
            assert(host_instantiations==1);
        } else if (!strcmp(name,"metadata-root-empty")) {
            host_uid=0;assert(host_dops.d_revalidate(&target,0)==1);
            assert(host_dir_iops.lookup(&proc_inode,&target,0)==NULL);
            host_uid=10362;nmap=0;assert(host_dops.d_revalidate(&target,0)==1);
            assert(host_dir_iops.lookup(&proc_inode,&target,0)==NULL);
            assert(host_native_lookups==2 && host_native_revalidations==2);
        } else if (!strcmp(name,"metadata-device-isolation")) {
            host_rule_dev=12;assert(host_dops.d_revalidate(&target,0)==1);
            assert(host_dir_iops.lookup(&proc_inode,&target,0)==NULL);
            host_rule_dev=0;assert(host_dops.d_revalidate(&target,0)==-ENOENT);
            assert(PTR_ERR(host_dir_iops.lookup(&proc_inode,&target,0))==-ENOENT);
        } else if (!strcmp(name,"sleeping-teardown") || !strcmp(name,"metadata-sleeping-teardown")) {
            host_block_reader=true; pthread_t reader,stop;
            assert(!pthread_create(&reader,NULL,!strcmp(name,"metadata-sleeping-teardown") ? sleeping_metadata : sleeping_reader,NULL));
            pthread_mutex_lock(&host_block.lock);
            while(!host_reader_inside) pthread_cond_wait(&host_block.cv,&host_block.lock);
            pthread_mutex_unlock(&host_block.lock);
            assert(atomic_read(&map_files_callbacks)==1);
            assert(!pthread_create(&stop,NULL,teardown,NULL));
            for(int i=0;i<2000 && !atomic_read(&host_tasks);i++) usleep(1000);
            assert(atomic_read(&host_tasks)==1 && !atomic_read(&teardown_finished));
            assert(host_fops.iterate_shared==native_iterate && host_iops.readlink==native_readlink && host_iops.get_link==native_get_link);
            pthread_mutex_lock(&host_block.lock); host_release_reader=true; pthread_cond_broadcast(&host_block.cv); pthread_mutex_unlock(&host_block.lock);
            assert(!pthread_join(reader,NULL) && !pthread_join(stop,NULL));
            assert(atomic_read(&host_tasks)==2 && atomic_read(&teardown_finished)); native_restored();
        } else if (!strcmp(name,"no-table-write") || !strcmp(name,"repeat-install")) {
            host_reject_without_write_at=1;
            assert(host_iops.readlink(&target,buf,40)==-ENOENT);
            if(!strcmp(name,"repeat-install")) {
                sus_map_files_remove(); native_restored();
                assert(!sus_map_files_install());
                assert(host_iops.readlink(&target,buf,40)==-ENOENT);
            }
            assert(!atomic_read(&host_patch_count));
        } else if (!strcmp(name,"unrelated-readlink")) {
            struct inode other={.task=&task};
            struct dentry other_link={.d_name={"1000-2000",9},.inode=&other};
            assert(host_iops.readlink(&other_link,buf,40)==7 && host_native_reads==1);
            assert(!atomic_read(&n_map_files_diverted));
        } else if (!strcmp(name,"task-guard-isolation")) {
            struct sus_map_files_guard guard;
            sus_map_files_guard_begin(&guard,0);
            assert(sus_map_files_bypass(&map_files_probes[0]));
            assert(!sus_map_files_bypass(&map_files_probes[1]));
            assert(host_iops.readlink(&target,buf,40)==-ENOENT);
            guard.task=&task;
            assert(!sus_map_files_bypass(&map_files_probes[0]));
            sus_map_files_guard_end(&guard);
        } else if (!strcmp(name,"diverted-entry-teardown")) {
            struct pt_regs regs={.regs={(unsigned long)&target,(unsigned long)buf,40}};
            assert(host_dispatch(1,&regs)==1 && atomic_read(&map_files_callbacks)==1);
            pthread_t stop; assert(!pthread_create(&stop,NULL,teardown,NULL));
            for(int i=0;i<2000 && !atomic_read(&host_tasks);i++) usleep(1000);
            assert(atomic_read(&host_tasks)==1 && !atomic_read(&teardown_finished));
            assert(((int (*)(struct dentry *,char *,int))regs.pc)(&target,buf,40)==-ENOENT);
            assert(!pthread_join(stop,NULL)); native_restored();
        } else { assert(!"unknown case"); }
        if(map_files_installed) sus_map_files_remove();
        native_restored();
    }
    printf("PASS %s\n",name); return 0;
}
