#!/usr/bin/env python3
"""Compile actual native map-files callbacks with instrumented kernel API stubs."""
import argparse
import json
import os
from pathlib import Path
import resource
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-dir', type=Path, default=Path(__file__).resolve().parents[2])
parser.add_argument('--sanitizers', action='store_true')
parser.add_argument('--json', type=Path)
args = parser.parse_args()
here = Path(__file__).resolve().parent
production = args.source_dir / 'kernel/sus_map_files.h'
cases = ['range-parser', 'hidden-readlink', 'visible-readlink', 'path-errors',
         'root-passthrough', 'empty-rules', 'ptrace-denied', 'follow-ownership',
         'follow-security', 'enumeration', 'small-buffer', 'lock-interrupt',
         'device-isolation', 'padding-aware', 'remap-identity', 'restore-rules',
         'missing-symbol', 'ambiguous-symbol', 'missing-access-helper', 'missing-padding-helper', 'wrong-callback', 'first-probe-failure',
         'later-probe-failure', 'wrong-entry', 'sleeping-teardown',
         'no-table-write', 'repeat-install', 'unrelated-readlink',
         'task-guard-isolation', 'diverted-entry-teardown']
cases += ['missing-instantiate-helper','lookup-probe-failure','revalidate-probe-failure',
          'cached-hidden','cached-control','cached-rcu','cached-native-failures',
          'cached-restore','cached-remap','cold-hidden','cold-control','cold-errors',
          'cold-instantiate-failure','metadata-root-empty','metadata-device-isolation',
          'metadata-sleeping-teardown']
results = []
negative_controls = []
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
with tempfile.TemporaryDirectory(prefix='susfs-map-files-host-') as temporary:
    exe = Path(temporary) / 'map-files'
    flags = (['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-no-pie']
             if args.sanitizers else ['-O2'])
    subprocess.run([os.environ.get('CC', 'cc'), '-std=gnu11', '-Wall', '-Wextra', '-Werror', '-Wno-c23-extensions',
                    '-Wno-sign-compare', '-Wno-unused-function', '-pthread', *flags,
                    '-I', str(here), '-DPRODUCTION="' + str(production.resolve()) + '"',
                    str(here / 'map_files_test.c'), '-o', str(exe)], check=True)
    for name in cases:
        env = dict(os.environ)
        if args.sanitizers:
            # This executor denies LeakSanitizer's /proc/<pid>/task scan.
            # Path/mm/task/heap ownership is asserted explicitly in every case.
            env.update(ASAN_OPTIONS='detect_leaks=0:abort_on_error=1', UBSAN_OPTIONS='halt_on_error=1')
        run = subprocess.run([str(exe), name], capture_output=True, text=True, env=env, timeout=15)
        results.append({'case': name, 'exit_code': run.returncode, 'stdout': run.stdout.strip(), 'stderr': run.stderr.strip()})
        print(run.stdout.strip() or 'FAIL ' + name + ': ' + run.stderr.strip())
    original=production.read_text()
    mutations=[
        ('readlink-reference-leak','visible-readlink',original.replace('    path_put(&path);','    /* deliberately leaked negative control */',1),False),
        ('follow-double-release','follow-ownership',original.replace('    rc = map_files_jump_link(&path);','    rc = map_files_jump_link(&path);\n    path_put(&path);',1),False),
        ('directory-entry-leak','enumeration',original.replace('    if (hidden) {','    if (false && hidden) {',1),False),
        ('wrong-incoming-type',None,original.replace('static int sus_map_files_readlink(','static long sus_map_files_readlink(',1),True),
        ('missing-recursion-guard','enumeration',original.replace('if (sus_map_files_bypass(probe)) {','if (false && sus_map_files_bypass(probe)) {',1),False),
        ('missing-entry-accounting','diverted-entry-teardown',original.replace('    sus_map_files_enter();','    /* omitted entry accounting */',1),False),
        ('shared-readlink-unscoped','unrelated-readlink',original.replace('READ_ONCE(d_inode(dentry)->i_op) != map_files_native_iops','false',1),False),
        ('missing-probe-flag-reset','repeat-install',original.replace('        map_files_probes[i].flags = 0;','        /* omitted retained flag reset */',1),False),
        ('cached-metadata-leak','cached-hidden',original.replace('            atomic_inc(&n_map_files_revalidate_hides);\n            rc = -ENOENT;','            atomic_inc(&n_map_files_revalidate_hides);\n            rc = 1;',1),False),
        ('cold-metadata-leak','cold-hidden',original.replace('    if (sus_map_files_hidden_vma(vma)) {\n        atomic_inc(&n_map_files_lookup_hides);','    if (false && sus_map_files_hidden_vma(vma)) {\n        atomic_inc(&n_map_files_lookup_hides);',1),False),
        ('cold-mm-reference-leak','cold-control',original.replace('put_mm:\n    mmput(mm);','put_mm:\n    /* deliberately leaked mm reference */',1),False),
        ('cached-wrong-incoming-type',None,original.replace('static int sus_map_files_revalidate(','static long sus_map_files_revalidate(',1),True),
    ]
    for name,case,source,compile_reject in mutations:
        assert source!=original
        changed=Path(temporary)/(name+'.h')
        changed.write_text(source)
        bad=Path(temporary)/name
        build=subprocess.run([os.environ.get('CC','cc'),'-std=gnu11','-Wall','-Wextra','-Werror', '-Wno-c23-extensions',
                              '-Wno-sign-compare','-Wno-unused-function','-pthread','-O2','-I',str(here),
                              '-DPRODUCTION="'+str(changed)+'"',str(here/'map_files_test.c'),'-o',str(bad)],
                             capture_output=True,text=True)
        if compile_reject:
            passed=build.returncode!=0 and 'static assertion failed' in build.stderr
            run=None
        elif build.returncode:
            passed=False
            run=None
        else:
            run=subprocess.run([str(bad),case],capture_output=True,text=True,timeout=15)
            passed=run.returncode!=0 and 'Assertion' in run.stderr
        negative_controls.append({'case':name,'passed':passed,'compiler_exit_code':build.returncode,
                                  'runtime_exit_code':run.returncode if run else None,
                                  'output':(build.stderr if compile_reject else run.stderr if run else build.stderr).replace(temporary,'<temporary>').strip()})
        print(('PASS ' if passed else 'FAIL ')+name+' negative control')
if args.json:
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps({'kind': 'actual production C with instrumented kernel stubs',
                                    'sanitizers': args.sanitizers, 'leak_sanitizer': 'unavailable: executor proc task scan denied',
                                    'reference_ownership': 'instrumented path/mm/task/heap counts must balance', 'hardware_validated': False,
                                    'results': results,'negative_controls':negative_controls}, indent=2) + '\n')
raise SystemExit(any(r['exit_code'] for r in results) or not all(r['passed'] for r in negative_controls))
