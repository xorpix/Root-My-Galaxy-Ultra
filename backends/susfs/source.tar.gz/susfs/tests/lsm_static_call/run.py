#!/usr/bin/env python3
"""Exercise actual LSM static-call verification and foreign-owner restoration."""
import argparse,os,re,subprocess,tempfile
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--sanitizers',action='store_true');a=p.parse_args()
here=Path(__file__).resolve().parent;s=(here.parents[1]/'kernel/lsm_hook.c').read_text()
def fn(n):
    m=re.search(r'^(?:static )?[^\n]*\b'+n+r'\([^;{]*\)\n\{\n.*?^\}\n',s,re.M|re.S)
    assert m,n;return m[0]
fragment=''.join(fn(n) for n in ('ksu_lsm_call_scall_update','ksu_lsm_hook_update_scall','ksu_lsm_unhook'))
with tempfile.TemporaryDirectory(prefix='susfs-lsm-static-') as d:
    d=Path(d);(d/'production.h').write_text(fragment)
    flags=['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-no-pie'] if a.sanitizers else ['-O2']
    subprocess.run(['cc','-std=gnu11','-Wall','-Wextra','-Werror','-pthread',*flags,'-DPRODUCTION="'+str(d/'production.h')+'"',str(here/'static_test.c'),'-o',str(d/'test')],check=True)
    for case in ('runtime-success','runtime-refused','fallback-success','fallback-refused','restore','already-restored','foreign-owner'):
        subprocess.run([str(d/'test'),case],check=True,timeout=10,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1'))
