/* SPDX-License-Identifier: GPL-2.0-only */
#include <assert.h>
#include <errno.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#define __nocfi
#define KERNEL_VERSION(a,b,c) (((a)<<16)|((b)<<8)|(c))
#define LINUX_VERSION_CODE KERNEL_VERSION(6,12,0)
#define READ_ONCE(v) __atomic_load_n(&(v),__ATOMIC_ACQUIRE)
#define smp_wmb() __atomic_thread_fence(__ATOMIC_RELEASE)
#define SUSFS_LOGI(...) ((void)0)
#define pr_err(...) ((void)0)
#define pr_emerg(...) ((void)0)
#define mutex_lock(p) assert(!pthread_mutex_lock(p))
#define mutex_unlock(p) assert(!pthread_mutex_unlock(p))
static pthread_mutex_t ksu_lsm_hook_lock=PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t model=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t changed=PTHREAD_COND_INITIALIZER;
struct static_call_key {void *func;};
struct lsm_static_call {struct static_call_key *key;void *trampoline;};
struct ksu_lsm_hook {void *entry,*original,*replacement;struct lsm_static_call *scall;bool insert;unsigned hook_offset;const char *head_name;};
static bool ignore_update,paused,resume;
static int updates,untracked,drained;
static void update(struct static_call_key *key,void *tramp,void *func)
{ (void)tramp;updates++;if(!ignore_update)__atomic_store_n(&key->func,func,__ATOMIC_RELEASE); }
static void (*ksu_static_call_update_fn)(struct static_call_key *,void *,void *)=update;
#define __static_call_update update
static int ksu_lsm_hook_patch_slot(void **slot,void *value) { *slot=value;return 0; }
static void ksu_lsm_hook_untrack(struct ksu_lsm_hook *h) { (void)h;untracked++; }
static void ksu_lsm_hook_drain(struct ksu_lsm_hook *h) { (void)h;drained++; }
static void msleep(unsigned n)
{
    (void)n;mutex_lock(&model);paused=true;pthread_cond_broadcast(&changed);
    while(!resume)assert(!pthread_cond_wait(&changed,&model));
    mutex_unlock(&model);
}
#include PRODUCTION
static void *remove_hook(void *h) { ksu_lsm_unhook(h);return NULL; }
int main(int argc,char **argv)
{
    assert(argc==2);const char *c=argv[1];int original,replacement,foreign,entry;
    struct static_call_key key={.func=&original};
    struct lsm_static_call call={.key=&key};
    struct ksu_lsm_hook h={.entry=&entry,.original=&original,.replacement=&replacement,.scall=&call,.insert=true,.head_name="test"};
    if(!strncmp(c,"runtime-",8)||!strncmp(c,"fallback-",9)) {
        if(c[0]=='f')ksu_static_call_update_fn=NULL;
        ignore_update=strstr(c,"refused")!=NULL;
        assert(ksu_lsm_hook_update_scall(&call,&replacement)==(ignore_update?-EIO:0));
        assert(key.func==(ignore_update?&original:&replacement));
    } else {
        if(!strcmp(c,"restore"))key.func=&replacement;
        if(!strcmp(c,"foreign-owner")) {
            key.func=&foreign;pthread_t t;assert(!pthread_create(&t,NULL,remove_hook,&h));
            mutex_lock(&model);while(!paused)assert(!pthread_cond_wait(&changed,&model));
            assert(key.func==&foreign && !updates && !untracked && !drained && h.entry);
            __atomic_store_n(&key.func,&original,__ATOMIC_RELEASE);resume=true;
            pthread_cond_broadcast(&changed);mutex_unlock(&model);assert(!pthread_join(t,NULL));
        } else ksu_lsm_unhook(&h);
        assert(key.func==&original && !h.entry && !h.scall && untracked==1 && drained==1);
        assert(updates==(!strcmp(c,"restore")?1:0));
    }
    printf("PASS %s\n",c);return 0;
}
