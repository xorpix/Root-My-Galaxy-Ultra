#!/usr/bin/env python3
"""Verify CP18 incoming KCFI words and retained CP17 callbacks/imports."""
import argparse
import json
import os
from pathlib import Path
import subprocess
from review_cp15_artifact import inspect

p=argparse.ArgumentParser(description=__doc__)
for key in ('baseline','candidate','kdir','clang-bin','rust-bin','evidence-dir'): p.add_argument('--'+key,required=True,type=Path)
a=p.parse_args(); out=a.evidence_dir.resolve(); out.mkdir(parents=True,exist_ok=True)
fixture=out/'cfi-fixture'; fixture.mkdir(exist_ok=True)
(fixture/'Makefile').write_text('obj-m := identity_types.o\n')
(fixture/'identity_types.c').write_text('''#include <linux/module.h>
#include <linux/kprobes.h>
static __used int expected_pre(struct kprobe *p,struct pt_regs *r) { return 0; }
static __used int expected_set(const char *s,const struct kernel_param *p) { return 0; }
static __used int expected_get(char *s,const struct kernel_param *p) { return 0; }
static_assert(__same_type(typeof(&expected_pre),typeof(((struct kprobe*)0)->pre_handler)));
static_assert(__same_type(typeof(&expected_set),typeof(((struct kernel_param_ops*)0)->set)));
static_assert(__same_type(typeof(&expected_get),typeof(((struct kernel_param_ops*)0)->get)));
static struct kprobe probe __used={.pre_handler=expected_pre};
static const struct kernel_param_ops params __used={.set=expected_set,.get=expected_get};
MODULE_LICENSE("GPL");
''')
env=dict(os.environ); env['PATH']=os.pathsep.join([str(a.clang_bin.resolve()),str(a.rust_bin.resolve()),env['PATH']])
with (out/'fixture-build.log').open('w') as log:
 subprocess.run(['make','-s','-C',str(a.kdir.resolve()),f'M={fixture}','ARCH=arm64','CC=clang','LLVM=1','LLVM_IAS=1','CONFIG_DEBUG_INFO_BTF_MODULES=','modules'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
old=inspect(a.baseline); candidate=inspect(a.candidate); expected=inspect(fixture/'identity_types.ko')
callbacks={'avc_audit_post_pre':'expected_pre','bootconfig_reset_set':'expected_set','bootconfig_stat_get':'expected_get'}
actual={key:candidate['types'].get(key) for key in callbacks}
wanted={key:expected['types'].get(value) for key,value in callbacks.items()}
retained=set(old['types'])&set(candidate['types']); added=set(candidate['imports'])-set(old['imports'])
exports={line.split()[1] for line in (a.kdir/'Module.symvers').read_text().splitlines() if len(line.split())>=2}
checks={
 'new_incoming_callback_words_present':all(actual.values()),
 'new_incoming_callback_words_match_real_headers':actual==wanted,
 'retained_callback_type_words_unchanged':all(candidate['types'][key]==old['types'][key] for key in retained),
 'all_cp17_map_files_callbacks_present':all('sus_map_files_'+key in candidate['types'] for key in ('iterate','readlink','get_link','emit','pre')),
 'added_imports_exported_in_pinned_ddk':added<=exports,
 'slow_avc_audit_not_imported':'slow_avc_audit' not in candidate['imports'],
 'version_sections_retain_cp17_behavior':candidate['version_section_sizes']==old['version_section_sizes'],
}
report=dict(scope='Host ARM64 artifact and header-typed KCFI validation; live Samsung callback ABI unqualified',
 baseline_sha256=old['sha256'],candidate_sha256=candidate['sha256'],checks=checks,
 callback_type_words={k:hex(v) if v else None for k,v in actual.items()},expected_type_words={k:hex(v) if v else None for k,v in wanted.items()},
 retained_callback_count=len(retained),imports_added=sorted(added),imports_removed=sorted(set(old['imports'])-set(candidate['imports'])),
 version_section_sizes=candidate['version_section_sizes'],modinfo=candidate['modinfo'],hardware_validated=False)
(out/'artifact-review.json').write_text(json.dumps(report,indent=2)+'\n')
for symbol in callbacks:
 f=candidate['functions'][symbol]
 text=subprocess.check_output([str(a.clang_bin/'llvm-objdump'),'-d',f'--start-address={f["address"]}',f'--stop-address={f["address"]+f["size"]}',str(a.candidate)],text=True)
 (out/(symbol+'-disassembly.txt')).write_text(text)
for name,passed in checks.items(): print(('PASS ' if passed else 'FAIL ')+name)
raise SystemExit(any(not x for x in checks.values()))
