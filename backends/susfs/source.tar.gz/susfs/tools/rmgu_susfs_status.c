// SPDX-License-Identifier: GPL-2.0
/* Read the actual SUSFS reboot ABI. No libc; never interprets an unanswered
 * syscall, unchanged err sentinel, or unterminated reply as a live module. */
typedef long sysarg;
struct short_reply { char value[16]; int err; };
struct features_reply { char value[8192]; int err; };
_Static_assert(sizeof(struct short_reply) == 20, "SUSFS short ABI");
_Static_assert(sizeof(struct features_reply) == 8196, "SUSFS features ABI");
#define MAGIC1 0xDEADBEEFUL
#define MAGIC2 0xFAFAFAFAUL
#define ERR_SEED 126
#ifdef SUSFS_STATUS_HOSTTEST
extern sysarg status_sys4(sysarg, sysarg, sysarg, sysarg, sysarg);
#else
static sysarg status_sys4(sysarg n, sysarg a, sysarg b, sysarg c, sysarg d)
{
    register sysarg x8 __asm__("x8") = n;
    register sysarg x0 __asm__("x0") = a;
    register sysarg x1 __asm__("x1") = b;
    register sysarg x2 __asm__("x2") = c;
    register sysarg x3 __asm__("x3") = d;
    __asm__ volatile("svc #0" : "+r"(x0) : "r"(x8), "r"(x1), "r"(x2), "r"(x3) : "memory", "cc");
    return x0;
}
#endif
static char output[65536];
static unsigned long used;
static void put(const char *s) { while (*s) output[used++] = *s++; }
static void number(long v)
{
    char digits[24]; int n = 0;
    unsigned long u = v < 0 ? 0UL - (unsigned long)v : (unsigned long)v;
    if (v < 0) output[used++] = '-';
    do { digits[n++] = '0' + u % 10; u /= 10; } while (u);
    while (n) output[used++] = digits[--n];
}
static void string(const char *s, unsigned long n)
{
    static const char hex[] = "0123456789abcdef";
    unsigned long i;
    output[used++] = '"';
    for (i = 0; i < n; i++) {
        unsigned char c = s[i];
        if (c == '"' || c == '\\') { output[used++] = '\\'; output[used++] = c; }
        else if (c < 0x20 || c >= 0x7f) {
            put("\\u00"); output[used++] = hex[c >> 4]; output[used++] = hex[c & 15];
        } else output[used++] = c;
    }
    output[used++] = '"';
}
static long length(const char *s, unsigned long capacity)
{
    unsigned long i;
    for (i = 0; i < capacity; i++) if (!s[i]) return (long)i;
    return -1;
}
static void query_json(const char *name, long rc, int error, long size)
{
    put("\""); put(name); put("\":{\"syscall\":"); number(rc);
    put(",\"error\":"); number(error); put(",\"terminated\":");
    put(size >= 0 ? "true}" : "false}");
}
int status_main(void)
{
    struct short_reply version = {{0}, ERR_SEED}, variant = {{0}, ERR_SEED};
    static struct features_reply features;
    long rv, rt, rf, nv, nt, nf;
    int available;
    unsigned long at = 0; int comma = 0;
    features.err = ERR_SEED;
    rv = status_sys4(142, MAGIC1, MAGIC2, 0x555e1, (sysarg)&version);
    rt = status_sys4(142, MAGIC1, MAGIC2, 0x555e3, (sysarg)&variant);
    rf = status_sys4(142, MAGIC1, MAGIC2, 0x555e2, (sysarg)&features);
    nv = length(version.value, sizeof(version.value));
    nt = length(variant.value, sizeof(variant.value));
    nf = length(features.value, sizeof(features.value));
    available = rv == 0 && rt == 0 && rf == 0 && version.err == 0 &&
                variant.err == 0 && features.err == 0 && nv > 0 && nt > 0 && nf > 0;
    used = 0;
    put("{\"schema\":1,\"available\":"); put(available ? "true" : "false");
    put(",\"version\":"); string(version.value, nv > 0 ? nv : 0);
    put(",\"variant\":"); string(variant.value, nt > 0 ? nt : 0);
    put(",\"features\":[");
    while (nf > 0 && at < (unsigned long)nf) {
        unsigned long end = at, size;
        while (end < (unsigned long)nf && features.value[end] != '\n') end++;
        size = end - at;
        if (size && features.value[at + size - 1] == '\r') size--;
        if (size) { if (comma++) put(","); string(features.value + at, size); }
        at = end + 1;
    }
    put("],\"queries\":{");
    query_json("version", rv, version.err, nv); put(",");
    query_json("variant", rt, variant.err, nt); put(",");
    query_json("features", rf, features.err, nf); put("}}\n");
    at = 0;
    while (at < used) {
        long wrote = status_sys4(64, 1, (sysarg)(output + at), used - at, 0);
        if (wrote <= 0) return 2;
        at += wrote;
    }
    return available ? 0 : 1;
}
#ifndef SUSFS_STATUS_HOSTTEST
__asm__(".text\n.global _start\n.type _start,%function\n_start:\n"
        "mov x29, #0\nbl status_main\nmov x8, #93\nsvc #0\n");
#endif
