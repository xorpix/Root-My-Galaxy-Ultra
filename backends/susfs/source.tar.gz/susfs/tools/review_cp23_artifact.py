#!/usr/bin/env python3
"""Review CP23 credential imports and retain compiled code for inspection."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
from elftools.elf.elffile import ELFFile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--clang-bin', type=Path, required=True)
    parser.add_argument('--kdir', type=Path, required=True)
    parser.add_argument('--evidence-dir', type=Path, required=True)
    args = parser.parse_args()
    out = args.evidence_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    module = args.source / 'kernel/susfs_guard_lkm.ko'
    holder = args.source / 'kernel/sus_path_creds.o'
    native = {'prepare_creds', 'abort_creds', 'override_creds', 'revert_creds'}
    with module.open('rb') as stream:
        elf = ELFFile(stream)
        assert elf['e_machine'] == 'EM_AARCH64' and elf.elfclass == 64
        symbols = list(elf.get_section_by_name('.symtab').iter_symbols())
        undefined = {s.name for s in symbols if s['st_shndx'] == 'SHN_UNDEF'}
        assert native <= undefined
        assert '__put_cred' not in undefined
        names = {s.name for s in symbols}
        assert 'sus_path_save_caller_cred' not in names
        assert 'sus_path_cred_prepare' in names and 'sus_path_cred_put' in names
        data = elf.get_section_by_name('__versions').data()
        assert len(data) % 64 == 0
        versions = {data[i+8:i+64].split(b'\0',1)[0].decode():
                    int.from_bytes(data[i:i+8], 'little') for i in range(0,len(data),64)}
        build_id = next(note['n_desc'] for section in elf.iter_sections()
                        if section.name == '.note.gnu.build-id'
                        for note in section.iter_notes() if note['n_type'] == 'NT_GNU_BUILD_ID')
    pins = {}
    for line in (args.kdir / 'Module.symvers').read_text().splitlines():
        columns = line.split()
        if columns[1] in native:
            pins[columns[1]] = int(columns[0],16)
    assert pins.keys() == native
    # Retained CP22 and this pinned GKI build both have empty version tables.
    # Do not invent a CRC qualification or change module loading to obtain it.
    if versions:
        assert native <= versions.keys()
        assert all(versions[name] == pins[name] for name in native)
    disassembly = subprocess.check_output([str(args.clang_bin / 'llvm-objdump'), '-dr',
                                          str(holder)], text=True)
    for name in native:
        assert re.search(r'R_AARCH64_(?:CALL26|JUMP26)\s+' + name + r'\b', disassembly), name
    (out / 'sus_path_creds-disassembly.txt').write_text(disassembly)
    for name in ('sus_path.c','sus_path_creds.c'):
        code = (args.source / 'kernel' / name).read_text()
        code = re.sub(r'/\*.*?\*/|//[^\n]*', '', code, flags=re.S)
        assert not re.search(r'\b(?:get_cred|put_cred|get_new_cred|__put_cred)\s*\(', code)
    marker = b'creds: checkpoint=23 native_copy=1 per_rule=1 live=%d'
    assert marker in module.read_bytes()
    report = dict(checkpoint=23, hardware_validated=False,
                  module_sha256=hashlib.sha256(module.read_bytes()).hexdigest(),
                  module_bytes=module.stat().st_size, build_id=build_id,
                  native_credential_imports=sorted(native),
                  ddk_export_crcs={name:hex(pins[name]) for name in sorted(native)},
                  module_version_entries=len(versions),
                  import_crc_verified=bool(versions),
                  import_crc_scope='Unqualified when the retained GKI module version table is empty',
                  generic_put_cred_import_absent=True,
                  old_save_caller_cred_symbol_absent=True,
                  holder_native_call_relocations=True,
                  cp23_marker_present=True,
                  disassembly_sha256=hashlib.sha256(disassembly.encode()).hexdigest(),
                  scope='Static ARM64 imports, relocations, CRCs and source review; native Samsung execution requires phone verification.')
    (out / 'cp23-artifact-review.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__ == '__main__':
    main()
