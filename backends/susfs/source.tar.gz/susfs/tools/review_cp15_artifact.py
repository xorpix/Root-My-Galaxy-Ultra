#!/usr/bin/env python3
"""Check ARM64 map-files/compiler output against header-typed CFI fixtures and CP14."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess
from elftools.elf.elffile import ELFFile

CALLBACKS = {
    'iterate': ('int', 'struct file *f, struct dir_context *c', 'file_operations', 'iterate_shared'),
    'readlink': ('int', 'struct dentry *d, char __user *b, int n', 'inode_operations', 'readlink'),
    'get_link': ('const char *', 'struct dentry *d, struct inode *i, struct delayed_call *c', 'inode_operations', 'get_link'),
    'emit': ('bool', 'struct dir_context *c, const char *n, int l, loff_t o, u64 i, unsigned int t', 'dir_context', 'actor'),
    'pre': ('int', 'struct kprobe *p, struct pt_regs *r', 'kprobe', 'pre_handler'),
}


def inspect(path):
    with path.open('rb') as stream:
        elf = ELFFile(stream)
        assert elf['e_machine'] == 'EM_AARCH64' and elf.little_endian
        symbols = list(elf.get_section_by_name('.symtab').iter_symbols())
        imports = sorted(s.name for s in symbols if s.name and s['st_shndx'] == 'SHN_UNDEF')
        types = {}
        for symbol in symbols:
            if symbol['st_info']['type'] != 'STT_FUNC' or not isinstance(symbol['st_shndx'], int):
                continue
            mappings = [s for s in symbols if s.name.split('.')[0] == '$d'
                        and s['st_shndx'] == symbol['st_shndx']
                        and s['st_value'] == symbol['st_value'] - 4]
            if not mappings:
                continue
            section = elf.get_section(symbol['st_shndx'])
            offset = symbol['st_value'] - section['sh_addr'] - 4
            types[symbol.name] = struct.unpack_from('<I', section.data(), offset)[0]
        versions = {}
        section = elf.get_section_by_name('__versions')
        if section:
            data = section.data()
            assert len(data) % 64 == 0
            for offset in range(0, len(data), 64):
                name = data[offset + 8:offset + 64].split(b'\0')[0].decode()
                versions[name] = struct.unpack_from('<Q', data, offset)[0]
        info = [v.decode() for v in elf.get_section_by_name('.modinfo').data().split(b'\0') if v]
        version_sizes = {s.name: s['sh_size'] for s in elf.iter_sections() if 'version' in s.name}
        functions = {s.name: {'address': s['st_value'], 'size': s['st_size']}
                     for s in symbols if s['st_info']['type'] == 'STT_FUNC'}
    return {'file': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'imports': imports, 'versions': versions, 'version_section_sizes': version_sizes,
            'modinfo': info, 'types': types, 'functions': functions}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--candidate', type=Path, required=True)
    parser.add_argument('--kdir', type=Path, required=True)
    parser.add_argument('--clang-bin', type=Path, required=True)
    parser.add_argument('--rust-bin', type=Path, required=True)
    parser.add_argument('--evidence-dir', type=Path, required=True)
    args = parser.parse_args()
    out = args.evidence_dir.resolve()
    fixture = out / 'cfi-fixture'
    fixture.mkdir(parents=True, exist_ok=True)
    lines = ['#include <linux/module.h>', '#include <linux/fs.h>', '#include <linux/namei.h>',
             '#include <linux/ptrace.h>', '#include <linux/pgsize_migration.h>', '#include <linux/kprobes.h>']
    for name, (ret, params, owner, field) in CALLBACKS.items():
        lines += [f'static __used {ret} expected_{name}({params}) {{ return 0; }}',
                  f'static_assert(__same_type(typeof(&expected_{name}), typeof(((struct {owner} *)0)->{field})));']
    # Address-taking is necessary: a retained but directly called static
    # function need not receive an incoming KCFI word from Clang.
    lines += ['static const struct file_operations expected_fops __used = { .iterate_shared = expected_iterate };',
              'static const struct inode_operations expected_iops __used = { .readlink = expected_readlink, .get_link = expected_get_link };',
              'static struct dir_context expected_context __used = { .actor = expected_emit };',
              'static struct kprobe expected_probe __used = { .pre_handler = expected_pre };',
              'MODULE_LICENSE("GPL");']
    (fixture / 'cp15_types.c').write_text('\n'.join(lines) + '\n')
    (fixture / 'Makefile').write_text('obj-m := cp15_types.o\n')
    env = dict(os.environ)
    env['PATH'] = os.pathsep.join([str(args.clang_bin.resolve()), str(args.rust_bin.resolve()), env['PATH']])
    command = ['make', '-C', str(args.kdir.resolve()), f'M={fixture}', 'ARCH=arm64', 'CC=clang',
               'LLVM=1', 'LLVM_IAS=1', 'CONFIG_DEBUG_INFO_BTF_MODULES=', 'modules', '-j2']
    with (out / 'cfi-fixture-build.log').open('w') as log:
        subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    before = inspect(args.baseline)
    candidate = inspect(args.candidate)
    expected = inspect(fixture / 'cp15_types.ko')
    actual_words = {name: candidate['types'].get('sus_map_files_' + name) for name in CALLBACKS}
    expected_words = {name: expected['types'].get('expected_' + name) for name in CALLBACKS}
    pinned_versions = {}
    for line in (args.kdir / 'Module.symvers').read_text().splitlines():
        parts = line.split()
        if len(parts) >= 2:
            pinned_versions[parts[1]] = int(parts[0], 16)
    common = set(candidate['versions']) & set(before['versions'])
    added_imports = set(candidate['imports']) - set(before['imports'])
    path_callbacks = [name for name in before['types'] if name.startswith('sus_path_')]
    checks = {
        'all_new_callbacks_have_kcfi_words': all(actual_words.values()),
        'new_callback_words_match_header_typed_fixture': actual_words == expected_words,
        'existing_path_callback_words_unchanged': all(candidate['types'].get(n) == before['types'][n] for n in path_callbacks),
        'version_table_shape_retains_cp14_build_behavior': candidate['version_section_sizes'] == before['version_section_sizes'],
        'all_added_imports_exist_in_pinned_ddk_exports': bool(added_imports) and added_imports <= set(pinned_versions),
        'private_helpers_are_resolved_not_imported': not ({'ptrace_may_access', 'vma_pad_pages', 'nd_jump_link'} & set(candidate['imports'])),
        'tasks_grace_period_import_present': 'synchronize_rcu_tasks' in candidate['imports'],
    }
    disassembly = ''
    trap_counts = {}
    for name in CALLBACKS:
        symbol = 'sus_map_files_' + name
        function = candidate['functions'][symbol]
        # A symbol-filtered LLVM disassembly stops at internal mapping symbols.
        # Address bounds cover each complete function, including its CFI traps.
        text = subprocess.check_output([str(args.clang_bin / 'llvm-objdump'), '-d',
                f'--start-address={function["address"]}',
                f'--stop-address={function["address"] + function["size"]}', str(args.candidate)], text=True)
        disassembly += text
        if name != 'pre':
            trap_counts[name] = len(re.findall(r'\bbrk\s+#0x82[0-9a-f]{2}', text))
    (out / 'map-files-disassembly.txt').write_text(disassembly)
    checks['new_callbacks_retain_outgoing_kcfi_checks'] = all(v >= 1 for v in trap_counts.values())
    report = {'scope': 'Local ARM64 compiler output; live Samsung callback hashes and runtime are unqualified',
              'baseline_sha256': before['sha256'], 'candidate_sha256': candidate['sha256'],
              'callback_type_words': {k: hex(v) if v else None for k, v in actual_words.items()},
              'fixture_type_words': {k: hex(v) if v else None for k, v in expected_words.items()},
              'checks': checks, 'outgoing_kcfi_traps': trap_counts, 'imports_added': sorted(added_imports),
              'imports_removed': sorted(set(before['imports']) - set(candidate['imports'])),
              'common_crc_count': len(common), 'candidate_crc_count': len(candidate['versions']),
              'version_section_sizes': candidate['version_section_sizes'],
              'import_crc_qualification': 'Unqualified: both retained CP14 and candidate version tables are empty',
              'modinfo': candidate['modinfo'], 'hardware_validated': False}
    (out / 'artifact-review.json').write_text(json.dumps(report, indent=2) + '\n')
    for name, passed in checks.items():
        print(('PASS ' if passed else 'FAIL ') + name)
    return int(not all(checks.values()))


if __name__ == '__main__':
    raise SystemExit(main())
