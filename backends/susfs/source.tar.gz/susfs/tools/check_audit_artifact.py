#!/usr/bin/env python3
"""Check syscall ABI/CFI against a real header fixture and prior Samsung module."""
import argparse,json,os,re,struct,subprocess
from pathlib import Path
from elftools.elf.elffile import ELFFile
from review_cp15_artifact import inspect
p=argparse.ArgumentParser(description=__doc__)
for name in ['candidate','baseline','kdir','clang-bin','output']:p.add_argument('--'+name,required=True,type=Path)
a=p.parse_args();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True);root=Path(__file__).resolve().parents[1]
fixture=out/'syscall-fixture';fixture.mkdir(exist_ok=True)
lines=['#include <linux/module.h>','#include <asm/syscall.h>','#include <asm/unistd_compat_32.h>',f'#include "{root / "kernel/susfs_fp_hook.h"}"',
 'static __used long expected_syscall(const struct pt_regs *regs) { return 0; }',
 'static syscall_fn_t expected_pointer __used = expected_syscall;',
 'static_assert(__same_type(susfs_syscall_fn_t, syscall_fn_t));']
text=(root/'kernel/susfs_create_gate.c').read_text()
for name,num in re.findall(r'^#define COMPAT_(\w+)_NR\s+(\d+)',text,re.M):
 lines.append(f'static_assert({num} == __NR_compat32_{name.lower()});')
lines.append('MODULE_LICENSE("GPL");')
(fixture/'fixture.c').write_text('\n'.join(lines)+'\n');(fixture/'Makefile').write_text('obj-m := fixture.o\n')
env=dict(os.environ);env['PATH']=str(a.clang_bin.resolve())+os.pathsep+env['PATH']
with (out/'fixture-build.log').open('w') as log:
 subprocess.run(['make','-C',str(a.kdir.resolve()),f'M={fixture}','ARCH=arm64','CC=clang','LLVM=1','LLVM_IAS=1','CONFIG_DEBUG_INFO_BTF_MODULES=','modules','-j2'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
before=inspect(a.baseline);candidate=inspect(a.candidate);expected=inspect(fixture/'fixture.ko')
wrappers=sorted(n for n in candidate['functions'] if n.startswith(('create_wrap_','or_wrap_')) or n=='supercall_reboot_wrapper')
words={n:candidate['types'].get(n) for n in wrappers};expected_word=expected['types']['expected_syscall']
landing={}
with a.candidate.open('rb') as stream:
 elf=ELFFile(stream)
 for symbol in elf.get_section_by_name('.symtab').iter_symbols():
  if symbol.name in wrappers:
   section=elf.get_section(symbol['st_shndx']);offset=symbol['st_value']-section['sh_addr'];landing[symbol.name]=struct.unpack_from('<I',section.data(),offset)[0]
checks={
 'fourteen_syscall_wrappers':len(wrappers)==14,
 'incoming_kcfi_matches_real_syscall_type':all(v==expected_word for v in words.values()),
 'all_wrappers_have_call_landing_pad':all(v in [0xd503245f,0xd50324df,0xd503233f,0xd503237f] for v in landing.values()),
 'imports_unchanged':candidate['imports']==before['imports'],
 'module_version_table_shape_unchanged':candidate['version_section_sizes']==before['version_section_sizes'],
 'module_metadata_unchanged_except_route_parameter':
    [v for v in candidate['modinfo'] if not v.startswith('parmtype=supercall_route:')]==before['modinfo'],
 'existing_callback_types_unchanged':all(candidate['types'].get(n)==v for n,v in before['types'].items() if n in candidate['types'] and n != 'susfs_fp_drain'),
}
report=dict(hardware_validated=False,checks=checks,candidate_sha256=candidate['sha256'],baseline_sha256=before['sha256'],expected_syscall_kcfi=expected_word,wrapper_kcfi=words,wrapper_landing_instructions=landing,imports=candidate['imports'],version_section_sizes=candidate['version_section_sizes'])
(out/'artifact.json').write_text(json.dumps(report,indent=2)+'\n')
for name,ok in checks.items():print(('PASS ' if ok else 'FAIL ')+name)
raise SystemExit(not all(checks.values()))
