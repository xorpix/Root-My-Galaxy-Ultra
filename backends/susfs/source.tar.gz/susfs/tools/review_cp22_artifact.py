#!/usr/bin/env python3
"""Check CP22 redirect listing kretprobe objects and callback KCFI against pinned headers."""
import argparse,hashlib,json,os,struct,subprocess
from pathlib import Path
from elftools.elf.elffile import ELFFile
from review_cp15_artifact import inspect
from review_cp19_artifact import native_words

p=argparse.ArgumentParser()
for key in ('candidate','kdir','clang-bin','rust-bin','evidence-dir'):p.add_argument('--'+key,type=Path,required=True)
a=p.parse_args();out=a.evidence_dir.resolve();out.mkdir(parents=True,exist_ok=True)
f=out/'fixture';f.mkdir(exist_ok=True)
(f/'types.c').write_text('''#include <linux/module.h>
#include <linux/kprobes.h>
#include <linux/seq_file.h>
static __used int expected_probe(struct kretprobe_instance *i, struct pt_regs *r) { return 0; }
static typeof(&expected_probe) probe_pointer __used = expected_probe;
static_assert(__same_type(typeof(&expected_probe), typeof(((struct kretprobe *)0)->entry_handler)));
static_assert(__same_type(typeof(&expected_probe), typeof(((struct kretprobe *)0)->handler)));
static __used int expected_show(struct seq_file *m, void *v) { return 0; }
static typeof(&expected_show) show_pointer __used = expected_show;
static_assert(__same_type(typeof(&expected_show), typeof(((struct seq_operations *)0)->show)));
const unsigned long off_symbol __used = offsetof(struct kretprobe, kp.symbol_name);
const unsigned long off_entry __used = offsetof(struct kretprobe, entry_handler);
const unsigned long off_return __used = offsetof(struct kretprobe, handler);
const unsigned long off_size __used = offsetof(struct kretprobe, data_size);
MODULE_LICENSE("GPL");
''')
(f/'Makefile').write_text('obj-m := types.o\n')
env=dict(os.environ);env['PATH']=os.pathsep.join([str(a.clang_bin),str(a.rust_bin),env['PATH']])
with (out/'fixture-build.log').open('w') as log:
 subprocess.run(['make','-s','-C',str(a.kdir),f'M={f}','ARCH=arm64','CC=clang','LLVM=1','LLVM_IAS=1','CONFIG_DEBUG_INFO_BTF_MODULES=','modules'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
expected=inspect(f/'types.ko');candidate=inspect(a.candidate)
callbacks={n:candidate['types'].get(n) for n in ('or_maps_entry','or_smaps_entry','or_maps_ret')}
native=native_words(a.kdir/'vmlinux',{'show_map','show_smap'})

def scalar(path,name):
 with path.open('rb') as stream:
  elf=ELFFile(stream);s=elf.get_section_by_name('.symtab').get_symbol_by_name(name)[0]
  data=elf.get_section(s['st_shndx']).data();return struct.unpack_from('<Q',data,s['st_value'])[0]

offsets={key:scalar(f/'types.ko','off_'+key) for key in ('symbol','entry','return','size')}
objects={}
obsolete_probe_absent=False
with a.candidate.open('rb') as stream:
 elf=ELFFile(stream);syms=elf.get_section_by_name('.symtab')
 obsolete_probe_absent=not syms.get_symbol_by_name('krp_kstat_map_vma')
 for name in ('kr_or_maps','kr_or_smaps'):
  sym=syms.get_symbol_by_name(name)[0];sec=elf.get_section(sym['st_shndx']);values={}
  for relocations in elf.iter_sections():
   if relocations['sh_type'] != 'SHT_RELA' or relocations['sh_info'] != sym['st_shndx']:continue
   for reloc in relocations.iter_relocations():
    for field in ('symbol','entry','return'):
     if reloc['r_offset'] != sym['st_value']+offsets[field]:continue
     target=syms.get_symbol(reloc['r_info_sym']);add=reloc['r_addend']
     if field=='symbol':
      raw=elf.get_section(target['st_shndx']).data();start=target['st_value']+add
      values[field]=raw[start:].split(b'\0')[0].decode()
     else:
      # LLD may use a section symbol plus addend for a local function.
      found=[s.name for s in syms.iter_symbols() if s['st_info']['type']=='STT_FUNC' and s['st_shndx']==target['st_shndx'] and s['st_value']==target['st_value']+add]
      assert len(found)==1,found;values[field]=found[0]
  values['size']=struct.unpack_from('<Q',sec.data(),sym['st_value']+offsets['size'])[0]
  objects[name]=values
checks={
 'new_kretprobe_callbacks_match_real_header_kcfi':all(v==expected['types'].get('expected_probe') and v is not None for v in callbacks.values()),
 'pinned_listing_callbacks_match_seq_show_kcfi':all(v==expected['types'].get('expected_show') and v is not None for v in native.values()) and len(native)==2,
 'compiled_maps_probe_targets_show_map':objects['kr_or_maps']==dict(symbol='show_map',entry='or_maps_entry',**{'return':'or_maps_ret'},size=40),
 'compiled_smaps_probe_targets_show_smap':objects['kr_or_smaps']==dict(symbol='show_smap',entry='or_smaps_entry',**{'return':'or_maps_ret'},size=40),
 'no_helper_probe_in_redirect_routes':all(v['symbol'] != 'show_map_vma' for v in objects.values()),
}
report=dict(checkpoint=22,kind='ARM64 artifact and pinned DDK only; live Samsung hook delivery pending',hardware_validated=False,module_sha256=hashlib.sha256(a.candidate.read_bytes()).hexdigest(),callbacks=callbacks,expected_probe_word=expected['types'].get('expected_probe'),native_listing_words=native,expected_show_word=expected['types'].get('expected_show'),offsets=offsets,probe_objects=objects,checks=checks)
(out/'artifact-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2));raise SystemExit(not all(checks.values()))
