#!/usr/bin/env python3
"""Build CP15 with the pinned CP14 DDK; never load a module or publish an APK."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

PINS={
    'include/generated/autoconf.h':'1fbc9de7fd352a6a44f0a67296bad10464b956bf59144382f404ac17d7e2fde2',
    'Module.symvers':'7d6930b74c649e4e2ceda3ef24e74774458844c34a41d29e042ccf916b509f96',
}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--kdir',type=Path,required=True)
    parser.add_argument('--clang-bin',type=Path,required=True)
    parser.add_argument('--rust-bin',type=Path)
    parser.add_argument('--evidence-dir',type=Path,required=True)
    parser.add_argument('--jobs',type=int,default=2)
    args=parser.parse_args()
    source=Path(__file__).resolve().parents[1]
    out=args.evidence_dir.resolve()
    out.mkdir(parents=True,exist_ok=True)
    kdir=args.kdir.resolve()
    clang=args.clang_bin.resolve()/'clang'
    failures=[]
    observed={}
    for relative,wanted in PINS.items():
        path=kdir/relative
        digest=hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
        observed[relative]=digest
        if digest!=wanted:
            failures.append(relative+': missing or different from pinned CP14 DDK')
    compiler=''
    if not clang.is_file() or not os.access(clang,os.X_OK):
        failures.append('Android Clang r536225 executable is unavailable')
    else:
        compiler=subprocess.check_output([str(clang),'--version'],text=True,timeout=10).strip()
        if 'r536225' not in compiler or '19.0.1' not in compiler:
            failures.append('Compiler does not match Android Clang r536225 / 19.0.1')
    private=[kdir/'fs/proc/internal.h',kdir/'source/fs/proc/internal.h']
    if not any(p.is_file() for p in private):
        failures.append('Real fs/proc/internal.h is unavailable in the prepared source tree')
    manifest={'kind':'CP15 matching-build preflight','pins':PINS,'observed':observed,
              'compiler':compiler,'failures':failures,'module_built':False,'hardware_validated':False}
    (out/'preflight.json').write_text(json.dumps(manifest,indent=2)+'\n')
    if failures:
        for failure in failures: print('BLOCKED: '+failure)
        return 2
    env=dict(os.environ)
    bins=[str(args.clang_bin.resolve())]
    if args.rust_bin: bins.append(str(args.rust_bin.resolve()))
    env['PATH']=os.pathsep.join(bins+[env.get('PATH','')])
    for script in ('check_hook_types.py','check_map_files_types.py','check_identity_types.py','check_mount_types.py'):
        subprocess.run([sys.executable,str(source/'tests/build'/script),'--kdir',str(kdir),
                        '--clang-bin',str(args.clang_bin.resolve()),'--json',str(out/(script.removesuffix('.py')+'.json'))],check=True,env=env)
    command=[sys.executable,str(source/'tools/build_review.py'),'--kdir',str(kdir),
             '--clang-bin',str(args.clang_bin.resolve()),'--evidence-dir',str(out/'module-build'),
             '--omit-module-btf','--jobs',str(args.jobs)]
    if args.rust_bin: command+=['--rust-bin',str(args.rust_bin.resolve())]
    subprocess.run(command,check=True,env=env)
    manifest['module_built']=True
    (out/'preflight.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('CP15 module compiled. APK packaging and phone validation remain separate steps.')
    return 0


if __name__=='__main__':
    raise SystemExit(main())
