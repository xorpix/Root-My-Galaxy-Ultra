#!/usr/bin/env python3
"""Build an offline review artifact using explicitly selected kernel headers."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--kdir", required=True, type=Path)
    parser.add_argument("--clang-bin", required=True, type=Path)
    parser.add_argument("--rust-bin", type=Path)
    parser.add_argument("--evidence-dir", required=True, type=Path)
    parser.add_argument("--omit-module-btf", action="store_true",
                        help="Omit module BTF generation when pahole is unavailable; retain DWARF")
    parser.add_argument("--jobs", type=int, default=2)
    args = parser.parse_args()
    if args.jobs < 1:
        parser.error("--jobs must be positive")
    source = Path(__file__).resolve().parents[1]
    kdir = args.kdir.resolve()
    out = args.evidence_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    paths = [str(args.clang_bin.resolve())]
    if args.rust_bin:
        paths.append(str(args.rust_bin.resolve()))
    env = dict(os.environ)
    env["PATH"] = os.pathsep.join(paths + [env.get("PATH", "")])
    command = ["make", "-C", str(kdir), f"M={source / 'kernel'}",
               "ARCH=arm64", "CC=clang", "LLVM=1", "LLVM_IAS=1"]
    if args.omit_module_btf:
        command.append("CONFIG_DEBUG_INFO_BTF_MODULES=")
    commands = [command + ["clean"], command + ["modules", f"-j{args.jobs}"]]
    results = []
    for index, cmd in enumerate(commands):
        with (out / ("clean.log" if index == 0 else "compile.log")).open("w") as log:
            run = subprocess.run(cmd, env=env, stdout=log, stderr=subprocess.STDOUT)
        results.append({"argv": cmd, "exit_code": run.returncode})
        if run.returncode:
            print(f"Build failed; see {out}")
            return run.returncode
    module = source / "kernel/susfs_guard_lkm.ko"
    config = kdir / "include/generated/autoconf.h"
    config_text = config.read_text()
    manifest = {
        "kind": "host cross-compilation only; no kernel module execution",
        "module": {"bytes": module.stat().st_size,
                   "sha256": hashlib.sha256(module.read_bytes()).hexdigest()},
        "commands": results,
        "compiler": subprocess.check_output(["clang", "--version"], env=env, text=True).strip(),
        "kernel_release_header": (kdir / "include/generated/utsrelease.h").read_text().strip(),
        "autoconf_sha256": hashlib.sha256(config.read_bytes()).hexdigest(),
        "module_symvers_sha256": hashlib.sha256((kdir / "Module.symvers").read_bytes()).hexdigest(),
        "module_btf_generation_omitted": args.omit_module_btf,
        "config": {name: f"#define {name} 1" in config_text.splitlines() for name in
                   ["CONFIG_CFI_CLANG", "CONFIG_CFI_ICALL_NORMALIZE_INTEGERS",
                    "CONFIG_TASKS_RCU", "CONFIG_MODVERSIONS", "CONFIG_ARM64_4K_PAGES"]},
        "hardware_validated": False,
    }
    (out / "build.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(f"Compiled {module.name}; this is a review artifact, not device approval.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
