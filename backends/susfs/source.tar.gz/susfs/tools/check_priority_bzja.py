#!/usr/bin/env python3
"""Offline BZJA dependency/CFI checks and comparison of its inlined I/O guard."""
import argparse,hashlib,json,struct
from pathlib import Path
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN
from capstone.arm64 import ARM64_OP_IMM,ARM64_OP_REG
from elftools.elf.elffile import ELFFile
from review_cp15_artifact import inspect
p=argparse.ArgumentParser(description=__doc__)
for n in ('kernel','module','output'):p.add_argument('--'+n,type=Path,required=True)
a=p.parse_args();candidate=inspect(a.module)
with a.kernel.open('rb') as f:
 elf=ELFFile(f);sec=elf.get_section_by_name('.kernel');data=sec.data();base=sec['sh_addr'];symbols=list(elf.get_section_by_name('.symtab').iter_symbols());names={s.name:s['st_value'] for s in symbols};functions=sorted({s['st_value'] for s in symbols if s['st_info']['type']=='STT_FUNC'})
assert hashlib.sha256(data).hexdigest()=='62163366f26c083b7722c61960cab02d3b33acd7d07f8a99049acd078a404695','this comparison is pinned to the reviewed BZJA image'
cs=Cs(CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN);cs.detail=True
def guard(name):
 start=names[name];end=next(v for v in functions if v>start)
 instructions=list(cs.disasm(data[start-base:end-base],start))
 index=next(i for i,v in enumerate(instructions) if v.mnemonic=='ubfx')
 fragment=instructions[index:index+19];assert len(fragment)==19
 origin=fragment[0].address;normal=[]
 for ins in fragment:
  parts=[]
  for i,op in enumerate(ins.operands):
   if op.type==ARM64_OP_REG:
    reg=ins.reg_name(op.reg)
    if (ins.mnemonic=='ubfx' and i==1) or (ins.mnemonic=='tst' and i==0):reg='priority-value'
    if ins.mnemonic=='mov' and i==0 and ins.operands[1].type==ARM64_OP_IMM and ins.operands[1].imm&0xffffffff in [0xffffffff,0xffffffea]:reg='return32'
    parts.append(reg)
   elif op.type==ARM64_OP_IMM:
    value=op.imm
    if (ins.mnemonic.startswith('b') or ins.mnemonic in ['cbz','tbnz']) and i==len(ins.operands)-1:
     address=value&0xffffffffffffffff
     if ins.mnemonic=='bl':assert address==names['capable'];value='capable'
     elif origin<=address<origin+76:value=('instruction',(address-origin)//4)
     elif address==origin+76:value='success'
     else:value='return'
    elif ins.mnemonic=='mov':value=value&0xffffffff
    parts.append(value)
   else:raise AssertionError('Unexpected validation instruction '+ins.mnemonic+' '+ins.op_str)
  normal.append((ins.mnemonic,parts))
 after=instructions[index+19]
 if name=='ioprio_check_cap':assert after.mnemonic=='mov' and after.op_str=='w0, wzr'
 else:assert after.mnemonic=='bl' and after.operands[0].imm&0xffffffffffffffff==names['__rcu_read_lock']
 return normal
missing=sorted(set(candidate['imports'])-set(names));word=struct.unpack_from('<I',data,names['__arm64_sys_getpriority']-base-4)[0]
checks={'all_139_import_names_present':len(candidate['imports'])==139 and not missing,
 'new_string_helpers_present':all(n in names for n in ['_ctype','strim','strsep']),
 'priority_syscall_types_match_bzja':all(candidate['types'].get(n)==word for n in candidate['functions'] if n.startswith('prio_wrap_')),
 'native_inlined_guard_matches_resolved_helper':guard('__arm64_sys_ioprio_set')==guard('ioprio_check_cap')}
report={'hardware_validated':False,'kernel_sha256':hashlib.sha256(data).hexdigest(),'checks':checks,'missing_imports':missing,'kernel_syscall_kcfi':word,'scope':'Import names and syscall CFI; I/O validation comparison normalizes only input register, 32-bit error return register and local branch labels in 19 actual instructions. It does not establish complete kernel ABI compatibility.'}
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(report,indent=2)+'\n')
for k,v in checks.items():print(('PASS ' if v else 'FAIL ')+k)
raise SystemExit(not all(checks.values()))
