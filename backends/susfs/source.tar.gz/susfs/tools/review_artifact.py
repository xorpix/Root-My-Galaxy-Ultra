#!/usr/bin/env python3
"""Compare two ARM64 review builds without loading or executing either artifact.

Requires pyelftools 0.32 and llvm-objdump from the chosen build toolchain.
Checks local compiler output, not the running Samsung kernel's CFI hashes.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess

from elftools.elf.elffile import ELFFile

CALLBACKS = ["inode_getattr", "inode_permission", "inode_unlink", "inode_rmdir",
             "inode_rename", "inode_link", "sb_statfs", "inode_setattr",
             "inode_getxattr", "inode_listxattr", "inode_setxattr",
             "inode_removexattr", "path_notify"]
LIFETIME_IMPORTS = {"synchronize_rcu_tasks", "try_module_get", "module_put", "task_work_add"}


def inspect(path, objdump):
    with path.open("rb") as stream:
        elf = ELFFile(stream)
        if elf["e_machine"] != "EM_AARCH64" or not elf.little_endian:
            raise ValueError("Expected a little-endian ARM64 module")
        symbols = list(elf.get_section_by_name(".symtab").iter_symbols())
        imports = sorted(s.name for s in symbols if s.name and s["st_shndx"] == "SHN_UNDEF")
        types = {}
        for callback in CALLBACKS:
            name = "sus_path_" + callback
            found = [s for s in symbols if s.name == name and s["st_info"]["type"] == "STT_FUNC"]
            if len(found) != 1:
                raise ValueError(f"Missing or ambiguous callback {name}")
            symbol = found[0]
            section_id = symbol["st_shndx"]
            # ARM64 kCFI places its 32-bit type word immediately before entry.
            # Require a data mapping symbol there rather than guessing from code.
            mapping = [s for s in symbols if s.name.split(".")[0] == "$d"
                       and s["st_shndx"] == section_id
                       and s["st_value"] == symbol["st_value"] - 4]
            if not mapping:
                raise ValueError(f"No kCFI data word identified before {name}")
            section = elf.get_section(section_id)
            offset = symbol["st_value"] - section["sh_addr"] - 4
            types[name] = hex(struct.unpack_from("<I", section.data(), offset)[0])
        versions = elf.get_section_by_name("__versions")
        info = [s.decode() for s in elf.get_section_by_name(".modinfo").data().split(b"\0") if s]
        result = {"file": path.name, "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                  "undefined_symbols": imports, "undefined_count": len(imports),
                  "version_section_bytes": versions["sh_size"] if versions else None,
                  "modinfo": info, "callback_kcfi_type_words": types}
    disassembly = subprocess.check_output(
        [str(objdump), "-d", "--disassemble-symbols=ksu_symbol_name_of", str(path)], text=True)
    if "<ksu_symbol_name_of>:" not in disassembly:
        raise ValueError("Symbol-name wrapper was not disassembled")
    result["name_wrapper_indirect_calls"] = len(re.findall(r"\bblr\s+x\d+", disassembly))
    result["name_wrapper_kcfi_traps"] = len(re.findall(r"\bbrk\s+#0x82[0-9a-f]{2}", disassembly))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", required=True, type=Path)
    parser.add_argument("--candidate", required=True, type=Path)
    parser.add_argument("--objdump", required=True, type=Path)
    parser.add_argument("--json", required=True, type=Path)
    args = parser.parse_args()
    before, after = [inspect(p, args.objdump) for p in [args.baseline, args.candidate]]
    checks = {
        "callback_type_words_unchanged": before["callback_kcfi_type_words"] == after["callback_kcfi_type_words"],
        "all_lifetime_imports_present": LIFETIME_IMPORTS <= set(after["undefined_symbols"]),
        "baseline_has_reviewed_instrumentation": before["name_wrapper_kcfi_traps"] == 1,
        "local_wrapper_exception_emitted": after["name_wrapper_kcfi_traps"] == 0,
        "wrapper_still_calls_lookup": before["name_wrapper_indirect_calls"] == after["name_wrapper_indirect_calls"] == 1,
        "no_kallsyms_import_added": not any(n.startswith("kallsyms_") for n in after["undefined_symbols"]),
    }
    report = {
        "scope": "Local compiler-output checks only; no runtime CFI, export policy or Samsung ABI certification",
        "baseline": before, "candidate": after, "checks": checks,
        "imports_added": sorted(set(after["undefined_symbols"]) - set(before["undefined_symbols"])),
        "imports_removed": sorted(set(before["undefined_symbols"]) - set(after["undefined_symbols"])),
        "assessment": "ReviewRequired",
        "unresolved": ["exact Samsung symbol-version data", "protected-memory behavior",
                       "sleeping LSM callback lifetime", "failed hook restoration", "hardware validation"],
    }
    args.json.write_text(json.dumps(report, indent=2) + "\n")
    for name, passed in checks.items():
        print(("PASS " if passed else "FAIL ") + name)
    return int(not all(checks.values()))


if __name__ == "__main__":
    raise SystemExit(main())
