#!/usr/bin/env python3
"""Run every host regression runner, normally and with ASan/UBSan where supported."""
import argparse,concurrent.futures,json,os,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,default=Path('build/host-suite'));p.add_argument('--jobs',type=int,default=2);a=p.parse_args()
root=Path(__file__).resolve().parents[1];out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
work=[]
for file in sorted((root/'tests').glob('*/run.py')):
 for san in [False,True] if '--sanitizers' in file.read_text() else [False]:work.append((file,san))
def run(item):
 file,san=item;label=file.parent.name+('-sanitizers' if san else '');start=time.monotonic();log=out/(label+'.log')
 cmd=['python3',str(file)]+(['--sanitizers'] if san else [])
 with log.open('w') as f:
  try:rc=subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=300,env=dict(os.environ,ASAN_OPTIONS=os.environ.get("ASAN_OPTIONS","detect_leaks=0:abort_on_error=1"),UBSAN_OPTIONS="halt_on_error=1")).returncode
  except subprocess.TimeoutExpired:rc=124
 result=dict(suite=file.parent.name,sanitizers=san,exit_code=rc,seconds=round(time.monotonic()-start,2),log=log.name)
 print(('PASS ' if rc==0 else 'FAIL ')+label,flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=a.jobs) as pool:results=list(pool.map(run,work))
(out/'results.json').write_text(json.dumps(dict(hardware_validated=False,results=results),indent=2)+'\n')
print(f'{sum(r["exit_code"]==0 for r in results)}/{len(results)} runner executions passed',flush=True)
raise SystemExit(any(r['exit_code'] for r in results))
