#!/usr/bin/env python3
"""Verify all 22 syscall wrappers against real headers and preserve baseline ABI."""
import argparse,json,os,re,struct,subprocess
from pathlib import Path
from elftools.elf.elffile import ELFFile
from review_cp15_artifact import inspect
p=argparse.ArgumentParser(description=__doc__)
for n in ('candidate','baseline','kdir','clang-bin','output'):p.add_argument('--'+n,type=Path,required=True)
a=p.parse_args();root=Path(__file__).resolve().parents[1];a.output.mkdir(parents=True,exist_ok=True)
fixture=a.output/'fixture';fixture.mkdir(exist_ok=True)
lines=['#include <linux/module.h>','#include <linux/ioprio.h>','#include <asm/syscall.h>','#include <asm/unistd_compat_32.h>',f'#include "{root / "kernel/susfs_fp_hook.h"}"',f'#include "{root / "kernel/susfs_abi.h"}"',
 'static __used long expected_syscall(const struct pt_regs *r) { return 0; }',
 'static syscall_fn_t expected_pointer __used = expected_syscall;',
 'static_assert(__same_type(susfs_syscall_fn_t, syscall_fn_t));',
 'static_assert(sizeof(struct st_susfs_priority_uid_filter)==65540);',
 'static_assert(offsetof(struct st_susfs_priority_uid_filter,err)==65536);',
 'static_assert(sizeof(struct st_rmgu_susfs_auto_root_apps)==12);',
 'static_assert(offsetof(struct st_rmgu_susfs_auto_root_apps,err)==8);']
for file in ['susfs_create_gate.c','susfs_priority_filter.c']:
 for name,num in re.findall(r'^#define COMPAT_(\w+)_NR\s+(\d+)',(root/'kernel'/file).read_text(),re.M):lines.append(f'static_assert({num} == __NR_compat32_{name.lower()});')
lines.append('MODULE_LICENSE("GPL");');(fixture/'fixture.c').write_text('\n'.join(lines)+'\n');(fixture/'Makefile').write_text('obj-m := fixture.o\n')
env=dict(os.environ);env['PATH']=str(a.clang_bin)+os.pathsep+env['PATH']
with (a.output/'fixture-build.log').open('w') as log:subprocess.run(['make','-C',str(a.kdir.resolve()),'M='+str(fixture.resolve()),'ARCH=arm64','CC=clang','LLVM=1','LLVM_IAS=1','CONFIG_DEBUG_INFO_BTF_MODULES=','modules','-j2'],stdout=log,stderr=subprocess.STDOUT,env=env,check=True)
before=inspect(a.baseline);candidate=inspect(a.candidate);expected=inspect(fixture/'fixture.ko');word=expected['types']['expected_syscall']
wrappers=sorted(n for n in candidate['functions'] if n.startswith(('create_wrap_','or_wrap_','prio_wrap_')) or n=='supercall_reboot_wrapper')
words={n:candidate['types'].get(n) for n in wrappers};landings={}
with a.candidate.open('rb') as f:
 elf=ELFFile(f)
 for s in elf.get_section_by_name('.symtab').iter_symbols():
  if s.name in wrappers:
   sec=elf.get_section(s['st_shndx']);landings[s.name]=struct.unpack_from('<I',sec.data(),s['st_value']-sec['sh_addr'])[0]
added=sorted(set(candidate['imports'])-set(before['imports']));removed=sorted(set(before['imports'])-set(candidate['imports']))
checks={
 '22_syscall_wrappers':len(wrappers)==22,
 'all_incoming_kcfi_match_real_headers':all(v==word for v in words.values()),
 'all_have_call_landing_instructions':len(landings)==22 and all(v in [0xd503245f,0xd50324df,0xd503233f,0xd503237f] for v in landings.values()),
 'baseline_imports_preserved':not removed,
 'new_imports_are_only_string_parsers_and_preempt_schedule':set(added)=={'_ctype','strim','strsep','preempt_schedule'},
 'module_metadata_only_adds_readonly_auto_parameters':sorted(candidate['modinfo'])==sorted(before['modinfo']+['parmtype=priority_auto_root:bool','parmtype=priority_appid:int']),
 'version_table_shape_unchanged':candidate['version_section_sizes']==before['version_section_sizes'],
 'baseline_callback_types_preserved':all(candidate['types'].get(n)==v for n,v in before['types'].items() if n in candidate['types']),
}
report=dict(hardware_validated=False,checks=checks,wrapper_kcfi=words,wrapper_landing_instructions=landings,imports=candidate['imports'],added_imports=added,removed_imports=removed,version_section_sizes=candidate['version_section_sizes'],candidate_sha256=candidate['sha256'],baseline_sha256=before['sha256'])
(a.output/'artifact.json').write_text(json.dumps(report,indent=2)+'\n')
for n,v in checks.items():print(('PASS ' if v else 'FAIL ')+n)
raise SystemExit(not all(checks.values()))
