#!/usr/bin/env python3
"""Check CP19 map_files callback KCFI against real headers and pinned vmlinux."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess

from elftools.elf.elffile import ELFFile
from review_cp15_artifact import CALLBACKS, inspect


def native_words(path, names):
    """Read the incoming ARM64 KCFI word immediately before each function."""
    result = {}
    with path.open('rb') as stream:
        elf = ELFFile(stream)
        assert elf['e_machine'] == 'EM_AARCH64' and elf.little_endian
        symbols = elf.get_section_by_name('.symtab')
        for symbol in symbols.iter_symbols():
            if symbol.name not in names or symbol['st_info']['type'] != 'STT_FUNC':
                continue
            section = elf.get_section(symbol['st_shndx'])
            offset = symbol['st_value'] - section['sh_addr'] - 4
            result[symbol.name] = struct.unpack_from('<I', section.data(), offset)[0]
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for key in ('baseline', 'candidate', 'kdir', 'clang-bin', 'rust-bin', 'evidence-dir'):
        p.add_argument('--' + key, required=True, type=Path)
    a = p.parse_args()
    out = a.evidence_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    fixture = out / 'cfi-fixture'
    fixture.mkdir(exist_ok=True)
    signatures = dict(CALLBACKS)
    signatures.update(
        lookup=('struct dentry *', 'struct inode *i, struct dentry *d, unsigned int f',
                'inode_operations', 'lookup'),
        revalidate=('int', 'struct dentry *d, unsigned int f',
                    'dentry_operations', 'd_revalidate'))
    source = ['#include <linux/module.h>', '#include <linux/kprobes.h>',
              '#include <linux/fs.h>', '#include <linux/dcache.h>']
    for name, (ret, args, owner, field) in signatures.items():
        source += [f'static __used {ret} expected_{name}({args}) {{ return 0; }}',
                   f'static typeof(&expected_{name}) expected_{name}_pointer __used = expected_{name};',
                   f'static_assert(__same_type(typeof(&expected_{name}),'
                   f'typeof(((struct {owner} *)0)->{field})));']
    source += ['static __used struct dentry *expected_instantiate(struct dentry *d,'
               ' struct task_struct *t, const void *p) { return 0; }',
               'static typeof(&expected_instantiate) instantiate_pointer __used = expected_instantiate;',
               'MODULE_LICENSE("GPL");']
    (fixture / 'metadata_types.c').write_text('\n'.join(source) + '\n')
    (fixture / 'Makefile').write_text('obj-m := metadata_types.o\n')
    env = dict(os.environ)
    env['PATH'] = os.pathsep.join([str(a.clang_bin.resolve()), str(a.rust_bin.resolve()), env['PATH']])
    with (out / 'fixture-build.log').open('w') as log:
        subprocess.run(['make', '-s', '-C', str(a.kdir.resolve()), f'M={fixture}',
                        'ARCH=arm64', 'CC=clang', 'LLVM=1', 'LLVM_IAS=1',
                        'CONFIG_DEBUG_INFO_BTF_MODULES=', 'modules'],
                       env=env, stdout=log, stderr=subprocess.STDOUT, check=True)

    before = inspect(a.baseline)
    candidate = inspect(a.candidate)
    expected = inspect(fixture / 'metadata_types.ko')
    actual = {name: candidate['types'].get('sus_map_files_' + name) for name in signatures}
    wanted = {name: expected['types'].get('expected_' + name) for name in signatures}
    vmlinux = a.kdir / 'vmlinux'
    native = native_words(vmlinux, {'proc_map_files_lookup', 'map_files_d_revalidate',
                                   'proc_map_files_instantiate'})
    native_expected = {
        'proc_map_files_lookup': wanted['lookup'],
        'map_files_d_revalidate': wanted['revalidate'],
        'proc_map_files_instantiate': expected['types'].get('expected_instantiate'),
    }
    added = set(candidate['imports']) - set(before['imports'])
    exports = {line.split()[1] for line in (a.kdir / 'Module.symvers').read_text().splitlines()
               if len(line.split()) >= 2}
    retained = set(before['types']) & set(candidate['types'])
    private = {'proc_map_files_instantiate', 'proc_map_files_lookup', 'map_files_d_revalidate',
               'ptrace_may_access', 'vma_pad_pages', 'nd_jump_link'}
    checks = {
        'all_seven_incoming_callback_words_present': all(actual.values()),
        'incoming_callback_words_match_real_headers': actual == wanted,
        'private_and_public_metadata_types_match_pinned_vmlinux':
            all(native_expected.values()) and native == native_expected,
        'retained_callback_words_unchanged':
            all(candidate['types'][key] == before['types'][key] for key in retained),
        'all_added_imports_exported_in_pinned_ddk': added <= exports,
        'private_helpers_resolved_without_imports': not (private & set(candidate['imports'])),
        'task_grace_period_import_retained': 'synchronize_rcu_tasks' in candidate['imports'],
        'version_sections_retain_cp18_behavior':
            candidate['version_section_sizes'] == before['version_section_sizes'],
    }
    traps = {}
    for name in signatures:
        symbol = 'sus_map_files_' + name
        function = candidate['functions'][symbol]
        disassembly = subprocess.check_output([
            str(a.clang_bin / 'llvm-objdump'), '-d',
            f'--start-address={function["address"]}',
            f'--stop-address={function["address"] + function["size"]}',
            str(a.candidate)], text=True)
        (out / (symbol + '-disassembly.txt')).write_text(disassembly)
        if name != 'pre':
            traps[name] = len(re.findall(r'\bbrk\s+#0x82[0-9a-f]{2}', disassembly))
    checks['all_six_callbacks_retain_outgoing_kcfi_checks'] = all(value >= 1 for value in traps.values())
    base = a.kdir / 'source/fs/proc/base.c'
    pinned_source = base.read_bytes()
    (out / 'pinned-fs-proc-base.c').write_bytes(pinned_source)
    report = {
        'scope': 'ARM64 compiler output, prepared DDK headers and DDK vmlinux; phone runtime pending',
        'baseline_sha256': before['sha256'], 'candidate_sha256': candidate['sha256'],
        'checks': checks, 'callback_words': {key: hex(value) if value else None for key, value in actual.items()},
        'fixture_words': {key: hex(value) if value else None for key, value in wanted.items()},
        'native_words': {key: hex(value) for key, value in native.items()},
        'native_expected_words': {key: hex(value) if value else None for key, value in native_expected.items()},
        'outgoing_kcfi_traps': traps, 'retained_callback_count': len(retained),
        'imports_added': sorted(added),
        'imports_removed': sorted(set(before['imports']) - set(candidate['imports'])),
        'modinfo': candidate['modinfo'], 'version_section_sizes': candidate['version_section_sizes'],
        'import_crc_qualification': 'Retains CP18 empty version table; exact Samsung CRC validation unqualified',
        'pinned_vmlinux_sha256': hashlib.file_digest(vmlinux.open('rb'), 'sha256').hexdigest(),
        'pinned_proc_base_sha256': hashlib.sha256(pinned_source).hexdigest(),
        'hardware_validated': False,
    }
    (out / 'artifact-review.json').write_text(json.dumps(report, indent=2) + '\n')
    for name, passed in checks.items():
        print(('PASS ' if passed else 'FAIL ') + name)
    return int(not all(checks.values()))


if __name__ == '__main__':
    raise SystemExit(main())
